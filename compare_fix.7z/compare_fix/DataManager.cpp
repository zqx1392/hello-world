#pragma once
#include "stdafx.h"
#include "AccessSV.h"
#include "ErrorManager.h"
#include "IOManager.h"
#include "DataManager.h"
#include <conio.h>

DataManager::DataManager() {
}

DataManager::~DataManager() {
}

void DataManager::setLogger(IOManager * IOCtrl) {
	m_IOCtrl = IOCtrl;
}
void DataManager::setAccSV(AccessSV * AccSV) {
	m_AccSV = AccSV;
}

void DataManager::setNewFile(const std::string labelName, const std::wstring fileName, IOManager::FileType fileType) {
	if (fileName == L"") {
		if (fileType == IOManager::FileType::ERR) {
			fileName = L"err.log";
		}
		else if (fileType == IOManager::FileType::RUN) {
			fileName = L"run.log";
		}
		else if (fileType == IOManager::FileType::OUTPUT) {
			fileName = L"out.log";
		}
	}
	CString convertedFileName = fileName.c_str();
	fileDesc tempFileDesc (convertedFileName,fileType);
	m_fileList[labelName] = tempFileDesc;
}
void DataManager::setNewDB(const std::string labelName, const std::wstring serverName, const bool isFGDB, const bool doEdit) {
	std::wstring DBName = L"";
	std::wstring versionName = L"";
	if (!isFGDB) {
		size_t startDBName = serverName.find(L"@");
		size_t startVersionName = serverName.find(L"(");
		DBName = serverName.substr(startDBName + 1, startVersionName - startDBName - 1);
		versionName = serverName.substr(startVersionName + 1, serverName.length() - startVersionName - 2);
	}
	CString convertedServerName = serverName.c_str();
	CString convertedOwnerName = DBName.c_str();
	CString convertedVersionName = versionName.c_str();
	CString fullDBName = "";
	if (doEdit) fullDBName = convertedOwnerName + "@" +  convertedServerName + "(" + convertedVersionName + ")";
	else fullDBName = "RONLY@" + convertedServerName + "(" + convertedVersionName + ")";
	if (isFGDB) fullDBName = convertedServerName;
	DBDesc tempDBDesc (
		convertedServerName,
		convertedOwnerName,
		convertedVersionName,
		fullDBName,
		NULL
	);
	m_DBList[labelName] = tempDBDesc;
}
void DataManager::setNewDB_divideUserDBVersion(const std::string labelName, const std::wstring serverName, const std::wstring ownerName, const std::wstring versionName, const bool isFGDB, const bool doEdit) {
	CString convertedServerName = serverName.c_str();
	CString convertedOwnerName = ownerName.c_str();
	CString convertedVersionName = versionName.c_str();
	CString fullDBName = "";
	if (doEdit) fullDBName = convertedOwnerName + "@" + convertedServerName + "(" + convertedVersionName + ")";
	else fullDBName = "RONLY@" + convertedServerName + "(" + convertedVersionName + ")";
	if (isFGDB) fullDBName = convertedServerName;
	DBDesc tempDBDesc (
		convertedServerName,
		convertedOwnerName,
		convertedVersionName,
		fullDBName,
		NULL
	);
	m_DBList[labelName] = tempDBDesc;
}

void DataManager::setNewFeatureClass(const std::string serverLabelName, const std::string labelName, const std::wstring serverName, const std::wstring featureClassName, const bool isFGDB) {
	CString convertedFeatureClassName = featureClassName.c_str();
	std::wstring ownerName = L"";
	if (!isFGDB) {
		size_t startDBName = serverName.find(L"@");
		ownerName = serverName.substr(0, startDBName);
	}
	CString convertedOwnerName = ownerName.c_str();
	CString convertedfullFeatureClassName = convertedOwnerName + "." + convertedFeatureClassName;
	if (isFGDB) convertedfullFeatureClassName = convertedFeatureClassName;
	featureClassDesc tempTableDesc (
		serverLabelName,
		convertedFeatureClassName,
		convertedOwnerName,
		convertedfullFeatureClassName,
		"",
		NULL
	);
	m_featureClassList[labelName] = tempTableDesc;
}
void DataManager::setNewFeatureClass_divideUserDBVersion(const std::string serverLabelName, const std::string labelName, const std::wstring serverOwner, const std::wstring featureClassName, const bool isFGDB) {
	CString convertedFeatureClassName = featureClassName.c_str();
	CString convertedOwnerName = serverOwner.c_str();
	CString convertedfullFeatureClassName = convertedOwnerName + "." + convertedFeatureClassName;
	if (isFGDB) convertedfullFeatureClassName = convertedFeatureClassName;
	featureClassDesc tempTableDesc (
		serverLabelName,
		convertedFeatureClassName,
		convertedOwnerName,
		convertedfullFeatureClassName,
		"",
		NULL
	);
	m_featureClassList[labelName] = tempTableDesc;
}

void DataManager::setNewTable(const std::string serverLabelName, const std::string labelName, const std::wstring serverName, const std::wstring tableName, const bool isFGDB){
	CString convertedTableName = tableName.c_str();
	std::wstring ownerName = L"";
	if (!isFGDB) {
		size_t startDBName = serverName.find(L"@");
		ownerName = serverName.substr(0, startDBName);
	}
	CString convertedOwnerName = ownerName.c_str();
	CString convertedfullTableName = convertedOwnerName + "." + convertedTableName;
	if (isFGDB) convertedfullTableName = convertedTableName;
	tableDesc tempTableDesc(
		serverLabelName,
		convertedTableName,
		convertedOwnerName,
		convertedfullTableName,
		NULL
	);
	m_tableList[labelName] = tempTableDesc;
}
void DataManager::setNewTable_divideUserDBVersion(const std::string serverLabelName, const std::string labelName, const std::wstring serverOwner, const std::wstring tableName, const bool isFGDB){
	CString convertedTableName = tableName.c_str();
	CString convertedOwnerName = serverOwner.c_str();
	CString convertedfullTableName = convertedOwnerName + "." + convertedTableName;
	if (isFGDB) convertedfullTableName = convertedTableName;
	tableDesc tempTableDesc(
		serverLabelName,
		convertedTableName,
		convertedOwnerName,
		convertedfullTableName,
		NULL
	);
	m_tableList[labelName] = tempTableDesc;
}

void DataManager::setNewField(const std::string datasetLabelName, const std::string labelName, const std::wstring fieldName, const bool isTable) {
	CString convertedFieldName = fieldName.c_str();
	fieldDesc tempFieldDesc (
		datasetLabelName,
		convertedFieldName,
		isTable,
		NULL
	);
	m_fieldList[labelName] = tempFieldDesc;
}

int DataManager::createFiles() {
	std::vector<CString> fileNameList;
	for (std::pair<std::string, fileDesc> eachFile : m_fileList) {
		if (ErrorManager::RCode::R_SUCCESS != m_IOCtrl->initFile(eachFile.second.fileName, eachFile.second.fileType)) {
			return ErrorManager::RCode::R_FAILED_FATAL_ERROR;
		}
		else {
			fileNameList.push_back(eachFile.second.fileName);
		}
	}
	for (auto eachFile : fileNameList) {
		m_IOCtrl->print_run(eachFile + " has been created successfully");
	}
	return ErrorManager::RCode::R_SUCCESS;
}

int DataManager::initDBs() {
	for (std::pair<std::string, DBDesc> eachDB : m_DBList) {
		if (HAS_ERROR == m_AccSV->setWorkspace(eachDB.second.fullDBName)) {
			m_IOCtrl->print_error(ErrorManager::ECode::E_FAILED_TO_OPEN_WORKSPACE, eachDB.second.fullDBName);
			return ErrorManager::RCode::R_FAILED_FATAL_ERROR;
		}
		else {
			eachDB.second.workspace = m_AccSV->getWorkspace(eachDB.second.fullDBName);
			CString successMsg = " has been connected successfully";
			CString printMsg = eachDB.second.fullDBName + successMsg;
			m_IOCtrl->print_run(printMsg);
		}
	}
	return ErrorManager::RCode::R_SUCCESS;
}
int DataManager::initDB(const std::string labelName) {
	if (HAS_ERROR == m_AccSV->setWorkspace(m_DBList[labelName].fullDBName)) {
		m_IOCtrl->print_error(ErrorManager::ECode::E_FAILED_TO_OPEN_WORKSPACE, m_DBList[labelName].fullDBName);
		return ErrorManager::RCode::R_FAILED_FATAL_ERROR;
	}
	else {
		m_DBList[labelName].workspace = m_AccSV->getWorkspace(m_DBList[labelName].fullDBName);
		CString successMsg = " has been connected successfully";
		CString printMsg = m_DBList[labelName].fullDBName + successMsg;
		m_IOCtrl->print_run(printMsg);
	}
	return ErrorManager::RCode::R_SUCCESS;
}

int DataManager::initFeatureClasses() {
	for (std::pair<std::string, featureClassDesc> eachFeatureClass : m_featureClassList) {
		CString fullDBName = m_DBList[eachFeatureClass.second.serverLabelName].fullDBName;
		if (HAS_ERROR == m_AccSV->setFeatureClass(fullDBName, eachFeatureClass.second.fullFeatureClassName)) {
			m_IOCtrl->print_error(ErrorManager::ECode::E_FAILED_TO_OPEN_FEATURECLASS, eachFeatureClass.second.fullFeatureClassName);
			return ErrorManager::RCode::R_FAILED_FATAL_ERROR;
		}
		else {
			IFeatureClassPtr featureClass = m_AccSV->getFeatureClass(fullDBName, eachFeatureClass.second.fullFeatureClassName);
			eachFeatureClass.second.featureClass = m_AccSV->getFeatureClass(fullDBName, eachFeatureClass.second.fullFeatureClassName);
			IFeatureDatasetPtr featureDataset;
			if (S_OK != featureClass->get_FeatureDataset(&featureDataset)) {
				m_IOCtrl->print_error(ErrorManager::ECode::E_FAILED_TO_GET_DATA, eachFeatureClass.second.fullFeatureClassName + " featureDataset");
				return ErrorManager::RCode::R_FAILED_FATAL_ERROR;
			}
			BSTR datasetName;
			if (S_OK != featureDataset->get_Name(&datasetName)) {
				m_IOCtrl->print_error(ErrorManager::ECode::E_FAILED_TO_GET_DATA, eachFeatureClass.second.fullFeatureClassName + " dataset name");
				return ErrorManager::RCode::R_FAILED_FATAL_ERROR;
			}
			eachFeatureClass.second.datasetName = datasetName;
			CString successMsg = " featureclass has been connected successfully";
			CString printMsg = eachFeatureClass.second.fullFeatureClassName + successMsg;
			m_IOCtrl->print_run(printMsg);
		}
	}
	return ErrorManager::RCode::R_SUCCESS;
}
int DataManager::initFeatureClass(const std::string labelName) {
	CString fullDBName = m_DBList[m_featureClassList[labelName].serverLabelName].fullDBName;
	if (HAS_ERROR == m_AccSV->setFeatureClass(fullDBName, m_featureClassList[labelName].fullFeatureClassName)) {
		m_IOCtrl->print_error(ErrorManager::ECode::E_FAILED_TO_OPEN_FEATURECLASS, m_featureClassList[labelName].fullFeatureClassName);
		return ErrorManager::RCode::R_FAILED_FATAL_ERROR;
	}
	else {
		IFeatureClassPtr featureClass = m_AccSV->getFeatureClass(fullDBName, m_featureClassList[labelName].fullFeatureClassName);
		m_featureClassList[labelName].featureClass = featureClass;
		IFeatureDatasetPtr featureDataset;
		if (S_OK != featureClass->get_FeatureDataset(&featureDataset)) {
			m_IOCtrl->print_error(ErrorManager::ECode::E_FAILED_TO_GET_DATA, m_featureClassList[labelName].fullFeatureClassName + " featureDataset");
			return ErrorManager::RCode::R_FAILED_FATAL_ERROR;
		}
		BSTR datasetName;
		if (S_OK != featureDataset->get_Name(&datasetName)) {
			m_IOCtrl->print_error(ErrorManager::ECode::E_FAILED_TO_GET_DATA, m_featureClassList[labelName].fullFeatureClassName + " dataset name");
			return ErrorManager::RCode::R_FAILED_FATAL_ERROR;
		}
		m_featureClassList[labelName].datasetName = datasetName;
		CString successMsg = " featureclass has been connected successfully";
		CString printMsg = m_featureClassList[labelName].fullFeatureClassName + successMsg;
		m_IOCtrl->print_run(printMsg);
	}
	return ErrorManager::RCode::R_SUCCESS;
}

int DataManager::initTables() {
	for (std::pair<std::string, tableDesc> eachTable : m_tableList) {
		CString fullDBName = m_DBList[eachTable.second.serverLabelName].fullDBName;
		if (HAS_ERROR == m_AccSV->setTable(fullDBName, eachTable.second.fullTableName)) {
			m_IOCtrl->print_error(ErrorManager::ECode::E_FAILED_TO_OPEN_TABLE, eachTable.second.fullTableName);
			return ErrorManager::RCode::R_FAILED_FATAL_ERROR;
		}
		else {
			ITablePtr table = m_AccSV->getTable(fullDBName, eachTable.second.fullTableName);
			eachTable.second.table = m_AccSV->getTable(fullDBName, eachTable.second.fullTableName);
			CString successMsg = " table has been connected successfully";
			CString printMsg = eachTable.second.fullTableName + successMsg;
			m_IOCtrl->print_run(printMsg);
		}
	}
	return ErrorManager::RCode::R_SUCCESS;
}
int DataManager::initTable(const std::string labelName) {
	CString fullDBName = m_DBList[m_tableList[labelName].serverLabelName].fullDBName;
	if (HAS_ERROR == m_AccSV->setTable(fullDBName, m_tableList[labelName].fullTableName)) {
		m_IOCtrl->print_error(ErrorManager::ECode::E_FAILED_TO_OPEN_TABLE, m_tableList[labelName].fullTableName);
		return ErrorManager::RCode::R_FAILED_FATAL_ERROR;
	}
	else {
		ITablePtr table = m_AccSV->getTable(fullDBName, m_tableList[labelName].fullTableName);
		m_tableList[labelName].table = table;
		CString successMsg = " table has been connected successfully";
		CString printMsg = m_tableList[labelName].fullTableName + successMsg;
		m_IOCtrl->print_run(printMsg);
	}
	return ErrorManager::RCode::R_SUCCESS;
}

int DataManager::initFields() {
	for (std::pair<std::string, fieldDesc> eachField : m_fieldList) {
		CString fullDBName = m_DBList[m_featureClassList[eachField.second.datasetLabelName].serverLabelName].fullDBName;
		if (fullDBName == "") {
			fullDBName = m_DBList[m_tableList[eachField.second.datasetLabelName].serverLabelName].fullDBName;
		}
		CString fullDatasetName = m_featureClassList[eachField.second.datasetLabelName].fullFeatureClassName;
		if (fullDatasetName == "") {
			fullDatasetName = m_tableList[eachField.second.datasetLabelName].fullTableName;
		}
		if (HAS_ERROR == m_AccSV->setField(fullDBName, fullDatasetName, eachField.second.fieldName, eachField.second.isDatasetTable)) {
			m_IOCtrl->print_error(ErrorManager::ECode::E_FAILED_TO_OPEN_FIELD, eachField.second.fieldName);
			return ErrorManager::RCode::R_FAILED_FATAL_ERROR;
		}
		else {
			eachField.second.field = m_AccSV->getField(fullDBName, fullDatasetName, eachField.second.fieldName);
			CString successMsg = " field has been connected successfully";
			CString printMsg = fullDatasetName + "." + eachField.second.fieldName + successMsg;
			m_IOCtrl->print_run(printMsg);
		}
	}
	return ErrorManager::RCode::R_SUCCESS;
}

int DataManager::initField(const std::string labelName) {
	CString fullDBName = m_DBList[m_featureClassList[m_fieldList[labelName].datasetLabelName].serverLabelName].fullDBName;
	if (fullDBName == "") {
		fullDBName = m_DBList[m_tableList[m_fieldList[labelName].datasetLabelName].serverLabelName].fullDBName;
	}
	CString fullDatasetName = m_featureClassList[m_fieldList[labelName].datasetLabelName].fullFeatureClassName;
	if (fullDatasetName == "") {
		fullDatasetName = m_tableList[m_fieldList[labelName].datasetLabelName].fullTableName;
	}
	if (HAS_ERROR == m_AccSV->setField(fullDBName, fullDatasetName, m_fieldList[labelName].fieldName, m_fieldList[labelName].isDatasetTable)) {
		m_IOCtrl->print_error(ErrorManager::ECode::E_FAILED_TO_OPEN_FIELD, m_fieldList[labelName].fieldName);
		return ErrorManager::RCode::R_FAILED_FATAL_ERROR;
	}
	else {
		m_fieldList[labelName].field = m_AccSV->getField(fullDBName, fullDatasetName, m_fieldList[labelName].fieldName);
		CString successMsg = " field has been connected successfully";
		CString printMsg = fullDatasetName + "." + m_fieldList[labelName].fieldName + successMsg;
		m_IOCtrl->print_run(printMsg);
	}
	return ErrorManager::RCode::R_SUCCESS;
	
}

std::map<std::string, DataManager::DBDesc> DataManager::getDBList() {
	return m_DBList;
}
DataManager::DBDesc DataManager::getDB(const std::string labelName) {
	return m_DBList[labelName];
}

std::map<std::string, DataManager::featureClassDesc> DataManager::getFeatureClassList() {
	return m_featureClassList;
}
DataManager::featureClassDesc DataManager::getFeatureClass(const std::string labelName) {
	return m_featureClassList[labelName];
}
std::map<std::string, DataManager::tableDesc> DataManager::getTableList(){
	return m_tableList;
}
DataManager::tableDesc DataManager::getTable(const std::string labelName) {
	return m_tableList[labelName];
}
std::map<std::string, DataManager::fieldDesc> DataManager::getFieldList() {
	return  m_fieldList;
}
DataManager::fieldDesc DataManager::getField(const std::string labelName) {
	return m_fieldList[labelName];
}


