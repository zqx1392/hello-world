// PoiInfoToHNPUpdater.cpp : Defines the entry point for the console application.
//

#pragma once
#include "stdafx.h"
#include "PoiInfoToHNPUpdater.h"

using namespace sindy::schema::global;

PoiInfoToHNPUpdater::PoiInfoToHNPUpdater() {
	//error class setup
	IOManager::getInstance().initErrorMessage();
	m_OptionManager = new OptionManager();

	
}

PoiInfoToHNPUpdater::~PoiInfoToHNPUpdater() {
}

int PoiInfoToHNPUpdater::ConnectToFileAndData() {

	OptionManager * opt = m_OptionManager;
	//set log files
	if (is_success != IOManager::getInstance().initFile(opt->m_err_log.c_str(), IOManager::FileType::ERR)) {
		IOManager::getInstance().print_error(IOManager::ECode::E_FAILED_TO_SET_DATA, true, _T("Failed to create error log file"));
		return IOManager::RCode::R_FAILED_FATAL_ERROR;
	}
	if (is_success != IOManager::getInstance().initFile(opt->m_run_log.c_str(), IOManager::FileType::RUN)) {
		IOManager::getInstance().print_error(IOManager::ECode::E_FAILED_TO_SET_DATA, true, _T("Failed to create run log file"));
		return IOManager::RCode::R_FAILED_FATAL_ERROR;
	}

	//try to connect to database
	CString serverName = opt->m_db.c_str();
	if (is_success != AccessSV::getInstance().getWorkspace(serverName, m_workspace)) {
		IOManager::getInstance().print_error(IOManager::ECode::E_FAILED_TO_SET_DATA, true, _T("Failed to connect to database"));
		return IOManager::RCode::R_FAILED_FATAL_ERROR;
	}

	//set owner name if this database is not FGDB [EX. THA2017A]	
	CString ownerName = _T("");
	if (!opt->is_FGDB) {
		int startServerName = serverName.Find(_T("@"));
		if (startServerName == -1) {
			IOManager::getInstance().print_error(IOManager::ECode::E_FAILED_TO_SET_DATA, true, _T("Failed to find owner name"));
			return IOManager::RCode::R_FAILED_FATAL_ERROR;
		}
		ownerName = serverName.Mid(0, startServerName);
	}
	
	//for FGDB, just input layer/table name
	int isAllSuccess = 0;
	if (opt->is_FGDB) {
		isAllSuccess += AccessSV::getInstance().getFeatureClass(serverName, opt->m_hnp.c_str(), m_layer_hnp);
		isAllSuccess += AccessSV::getInstance().getFeatureClass(serverName, opt->m_poi_info.c_str(), m_layer_poi_info);
		isAllSuccess += AccessSV::getInstance().getFeatureClass(serverName, opt->m_hnp_entrypoint.c_str(), m_layer_hnp_entry);
		isAllSuccess += AccessSV::getInstance().getFeatureClass(serverName, opt->m_poi_entrypoint.c_str(), m_layer_poi_entry);
		isAllSuccess += AccessSV::getInstance().getTable(serverName, opt->m_poi_asso.c_str(), m_table_poi_asso);
		isAllSuccess += AccessSV::getInstance().getTable(serverName, opt->m_official.c_str(), m_table_official);
		isAllSuccess += AccessSV::getInstance().getTable(serverName, opt->m_translation.c_str(), m_table_translation);
	}
	//for SINDY database, need to add ownerName in front of layer/table name
	else {
		isAllSuccess += AccessSV::getInstance().getFeatureClass(serverName, ownerName + _T(".") + opt->m_hnp.c_str(), m_layer_hnp);
		isAllSuccess += AccessSV::getInstance().getFeatureClass(serverName, ownerName + _T(".") + opt->m_poi_info.c_str(), m_layer_poi_info);
		isAllSuccess += AccessSV::getInstance().getFeatureClass(serverName, ownerName + _T(".") + opt->m_hnp_entrypoint.c_str(), m_layer_hnp_entry);
		isAllSuccess += AccessSV::getInstance().getFeatureClass(serverName, ownerName + _T(".") + opt->m_poi_entrypoint.c_str(), m_layer_poi_entry);
		isAllSuccess += AccessSV::getInstance().getTable(serverName, ownerName + _T(".") + opt->m_poi_asso.c_str(), m_table_poi_asso);
		isAllSuccess += AccessSV::getInstance().getTable(serverName, ownerName + _T(".") + opt->m_official.c_str(), m_table_official);
		isAllSuccess += AccessSV::getInstance().getTable(serverName, ownerName + _T(".") + opt->m_translation.c_str(), m_table_translation);
	}
	if (isAllSuccess != is_success) {
		IOManager::getInstance().print_error(IOManager::ECode::E_FAILED_TO_SET_DATA, true, _T("Failed to connect to layer/table"));
		return IOManager::RCode::R_FAILED_FATAL_ERROR;
	}
	return IOManager::RCode::R_SUCCESS;
}

int PoiInfoToHNPUpdater::presetData(const int& argc, _TCHAR* argv[])
{
	try {
		//Get option list from console
		if (is_success != m_OptionManager->getOption(argc, argv)) {
			return IOManager::getInstance().endProgramWithError(_T("getting options"));
		}
		//Preset default value for optional arguments
		if (is_success != m_OptionManager->presetOption()) {
			return IOManager::getInstance().endProgramWithError(_T("setting options"));
		}
		//Connect to file and ARCGIS data
		if (is_success != ConnectToFileAndData()) {
			return IOManager::getInstance().endProgramWithError(_T("connect to file and database"));
		}
		//Print specified options into run log 
		m_OptionManager->printDescription();
	}
	catch (const _com_error e) {
		std::cout << std::endl;
		IOManager::getInstance().print_error(IOManager::ECode::E_COM_ERROR_IS_CATCHED, true, _T("E_COM_ERROR"), _T(""), (CString)e.ErrorMessage());
		return IOManager::getInstance().endProgramWithError("Com Error");
		std::cout << "Press any key to continue...";
		std::cin.get();
	}
	return IOManager::RCode::R_SUCCESS;
}

int PoiInfoToHNPUpdater::run() {
	//get child POI list <OBJECTID> from POI_ASSOCIATION
	PoiAssociation cPoiAssociation(m_OptionManager->m_poi_asso.c_str(), m_table_poi_asso);
	std::set<long> childPOIList;
	if (is_success != cPoiAssociation.getChildPOI(&childPOIList)) {
	return IOManager::getInstance().endProgramWithError(_T("get child POI list from POI_ASSOCIATION"));
	}
	IOManager::getInstance().print_run(true, true, _T("Successfully: Extracted CHILDID from POI_ASSOCIATION"));

	//get poi entry point from POI_ENTRYPOINT
	PoiEntrypoint cPoiEntrypoint(m_OptionManager->m_poi_entrypoint.c_str(), m_layer_poi_entry);
	std::set<long> poiEntrypointList;
	if (is_success != cPoiEntrypoint.getPoiEntrypoint(m_OptionManager->m_sql_poientry.c_str(), &poiEntrypointList)) {
		return IOManager::getInstance().endProgramWithError(_T("get POI Entrypoint list from POI_ENTRYPOINT"));
	}
	IOManager::getInstance().print_run(true, true, _T("Successfully: Extracted POIINFOID from POI_ASSOCIATION"));

	//get official name list <OBJECTID, NAME> from OFFICIAL_NAME
	Hnp cHnp(m_OptionManager->m_hnp.c_str(), m_layer_hnp);
	OfficialName cOfficialName(m_OptionManager->m_official.c_str(), m_table_official, &cHnp);
	std::map<long, CString> officialNameList;
	if (is_success != cOfficialName.getOfficalName(&officialNameList)) {
		return IOManager::getInstance().endProgramWithError(_T("get name list from OFFICIAL_NAME"));
	}
	IOManager::getInstance().print_run(true, true, _T("Successfully: Extracted NAME from OFFICIAL_NAME"));

	//get only unique houseNumber information for POI_INFO
	PoiInfo cPoiInfo(m_OptionManager->m_poi_info.c_str(), m_layer_poi_info);
	std::vector<CommonData::poiInfo> uniquePoiInfoList;
	if (is_success != cPoiInfo.getUniquePoiInfoID(m_OptionManager->m_sql_poiinfo.c_str(), m_OptionManager->m_buffer_size, &childPOIList, &poiEntrypointList, &officialNameList, &uniquePoiInfoList)) {
		return IOManager::getInstance().endProgramWithError(_T("get unique house number list from POI_INFO"));
	}
	IOManager::getInstance().print_run(true, true, _T("Successfully: Extracted unique POI_INFO"));


	//create new records on HNP (where ROADNAMEID is NULL)
	std::map<long, long> updatedPoiHnpList;
	/*updatedPoiHnpList.insert(std::make_pair(641, 1759101));
	updatedPoiHnpList.insert(std::make_pair(581131, 1758737));
	updatedPoiHnpList.insert(std::make_pair(381521, 1758735));*/
	if (is_success != cHnp.insertNewRecordToHNP(m_workspace, &uniquePoiInfoList, &updatedPoiHnpList)) {
		return IOManager::getInstance().endProgramWithError(_T("Create new records on HNP"));
	}

	//create new records on HNP and OFFICIAL_NAME (where ROADNAMEID is NOT NULL)
	std::map<long, long> translationList;
	if (is_success != cOfficialName.insertNewRecordToHNPAndOfficial(m_workspace, &uniquePoiInfoList, &updatedPoiHnpList, &translationList)) {
		return IOManager::getInstance().endProgramWithError(_T("Create new records on HNP and OFFICIAL_NAME"));
	}
	IOManager::getInstance().print_run(true, true, _T("Successfully: Created new records on HNP and OFFICIAL_NAME"));

	//create new records on TRANSLATION
	//translationList.insert(std::make_pair(46, 1111));
	//translationList.insert(std::make_pair(397, 2222));
	//translationList.insert(std::make_pair(21, 3333));
	if (is_success != insertNewRecordToTranslation(&translationList)) {
		return IOManager::getInstance().endProgramWithError(_T("Create new records on TRANSLATION"));
	}
	IOManager::getInstance().print_run(true, true, _T("Successfully: Created new records on TRANSLATION"));

	//create new records on TRANSLATION
	if (is_success != insertNewRecordToHNPEntrypoint(&updatedPoiHnpList)) {
		return IOManager::getInstance().endProgramWithError(_T("Create new records on HNP_ENTRYPOINT"));
	}
	IOManager::getInstance().print_run(true, true, _T("Successfully: Created new records on HNP_ENTRYPOINT"));

	return IOManager::getInstance().printSuccessfulEnd();
}


int PoiInfoToHNPUpdater::insertNewRecordToTranslation(std::map<long, long> * translationList) {

	long successUpdateCount = 0;	//count total successfully update records

	CString translationTableName = m_OptionManager->m_translation.c_str();

	//set all condition into query variable
	_ICursorPtr ipTranslationCursor;
	IQueryFilterPtr translationIpQueryFilter(CLSID_QueryFilter);
	if (S_OK != m_table_translation->Search(translationIpQueryFilter, VARIANT_FALSE, &ipTranslationCursor)) {
		IOManager::getInstance().print_error(IOManager::ECode::E_FAILED_TO_GET_DATA, true, translationTableName, _T(""), _T("Failed to get all records"));
		return IOManager::RCode::R_FAILED_FATAL_ERROR;
	}

	//prepare column indexes for TRANSLATION
	long objectIDIndex = 0, transIDIndex = 0, operatorIndex = 0, progModifyDateIndex = 0;
	long updateTypeCIndex = 0, modifyProgNameIndex = 0;
	//check if all columns got index without any error
	int returnStatus = 0;
	returnStatus += getTableColumnIndex(m_table_translation, translation::kObjectID, &objectIDIndex);
	returnStatus += getTableColumnIndex(m_table_translation, translation::kOperator, &operatorIndex);
	returnStatus += getTableColumnIndex(m_table_translation, translation::kUpdateType, &updateTypeCIndex);
	returnStatus += getTableColumnIndex(m_table_translation, translation::kProgModifyDate, &progModifyDateIndex);
	returnStatus += getTableColumnIndex(m_table_translation, translation::kModifyProgName, &modifyProgNameIndex);
	returnStatus += getTableColumnIndex(m_table_translation, translation::kID, &transIDIndex);
	if (returnStatus != IOManager::RCode::R_SUCCESS) {
		return IOManager::RCode::R_FAILED_FATAL_ERROR;
	}
	//setup cursor and buffer for inputting new OFFICIAL_NAME records
	_ICursorPtr insertTranslationCursor;
	IRowBufferPtr tableBuffer;
	if (S_OK != m_table_translation->CreateRowBuffer(&tableBuffer)) {
		IOManager::getInstance().print_error(IOManager::ECode::E_FAILED_TO_GET_DATA, true, translationTableName, _T(""), _T("Failed to create buffer"));
		return IOManager::RCode::R_FAILED_FATAL_ERROR;
	}

	//create new records
	_IRowPtr ipTranslationRow;
	while (ipTranslationCursor->NextRow(&ipTranslationRow) == S_OK && ipTranslationRow) {
		// get postal point OID
		long OIDNum;
		if (S_OK != ipTranslationRow->get_OID(&OIDNum)) {
			IOManager::getInstance().print_error(IOManager::ECode::E_FAILED_TO_GET_DATA, true, translationTableName, _T(""), _T("Failed to get OBJECTID of one ") + translationTableName);
			return IOManager::RCode::R_FAILED_FATAL_ERROR;
		}
		//convert OID from long to CString
		CString OID;
		OID.Format(L"%ld", OIDNum);
		//get TRANS_ID
		CComVariant transID;
		if (S_OK != ipTranslationRow->get_Value(transIDIndex, &transID)) {
			IOManager::getInstance().print_error(IOManager::ECode::E_FAILED_TO_GET_DATA, true, translationTableName + _T(" OBJECTID"), OID, _T("Failed to get POIINFOID value"));
			return IOManager::RCode::R_FAILED_FATAL_ERROR;
		}
		long convertedTransID = transID.lVal;
		//if found this TRANSLATION TRANS_ID in target translationList
		if (translationList->find(convertedTransID) != translationList->end()) {
			//start editing
			if (successUpdateCount % 10000 == 0) {
				if (!startEditTable(m_table_translation)) {
					IOManager::getInstance().print_error(IOManager::ECode::E_FAILED_TO_GET_DATA, true, _T("Start Editing"));
					return IOManager::RCode::R_FAILED_FATAL_ERROR;
				}
				//insert cursor for creating records
				if (S_OK != m_table_translation->Insert(VARIANT_TRUE, &insertTranslationCursor)) {
					IOManager::getInstance().print_error(IOManager::ECode::E_FAILED_TO_GET_DATA, true, translationTableName, _T(""), _T("Create new cursor for new records"));
					return IOManager::RCode::R_FAILED_FATAL_ERROR;
				}
			}
			//create new HNP_ENTRYPOINT record
			for (int i = 0; i<m_table_translation->Fields->FieldCount; i++) {
				//discard index and transID
				if (i == objectIDIndex) {
					continue;
				}
				//get value on old record
				CComVariant tempValue;
				if (S_OK != ipTranslationRow->get_Value(i, &tempValue)) {
					CComBSTR columnName = "";
					//get field name to print description error
					if (S_OK != m_table_translation->Fields->GetField(i)->get_Name(&columnName)) {
						IOManager::getInstance().print_error(IOManager::ECode::E_FAILED_TO_GET_DATA, true, translationTableName + _T(" OBJECTID"), OID, _T("Failed to get field name and value"));
						return IOManager::RCode::R_FAILED_FATAL_ERROR;
					}
					//print error with field name
					CString msg = "Failed to get ";
					msg += columnName; 
					msg += " value";
					IOManager::getInstance().print_error(IOManager::ECode::E_FAILED_TO_GET_DATA, true, translationTableName + _T(" OBJECTID"), OID, msg);
					return IOManager::RCode::R_FAILED_FATAL_ERROR;
				}
				//set value on new record
				//set value for TRANS_ID
				if (i == transIDIndex) {
					//not found this OIDNum in target translationList
					if (translationList->find(OIDNum) == translationList->end()) {
						IOManager::getInstance().print_error(IOManager::ECode::E_FAILED_TO_GET_DATA, true, translationTableName + _T(" OBJECTID"), OID, _T("Not found in translationList"));
						return IOManager::RCode::R_FAILED_FATAL_ERROR;
					}
					if (S_OK != tableBuffer->put_Value(i, CComVariant(translationList->find(OIDNum)->second))) {
						IOManager::getInstance().print_error(IOManager::ECode::E_FAILED_TO_GET_DATA, true, translationTableName + _T(" OBJECTID"), OID, _T("Failed to set TRANS_ID field value"));
						return IOManager::RCode::R_FAILED_FATAL_ERROR;
					}
				}
				//operator = sindy
				else if (i == operatorIndex) {
					if (S_OK != tableBuffer->put_Value(i, CComVariant(m_operator))) {
						IOManager::getInstance().print_error(IOManager::ECode::E_FAILED_TO_GET_DATA, true, translationTableName + _T(" OBJECTID"), OID, _T("Failed to set OPERATOR value"));
						return IOManager::RCode::R_FAILED_FATAL_ERROR;
					}
				}
				//updatetypeC = 6
				else if (i == updateTypeCIndex) {
					if (S_OK != tableBuffer->put_Value(i, CComVariant(m_updateType))) {
						IOManager::getInstance().print_error(IOManager::ECode::E_FAILED_TO_GET_DATA, true, translationTableName + _T(" OBJECTID"), OID, _T("Failed to set UPDATETYPE_C value"));
						return IOManager::RCode::R_FAILED_FATAL_ERROR;
					}
				}
				//prog modify date = now
				else if (i == progModifyDateIndex) {
					COleDateTime date = COleDateTime::GetCurrentTime();
					double dateTime = date.m_dt;
					if (S_OK != tableBuffer->put_Value(i, CComVariant(dateTime))) {
						IOManager::getInstance().print_error(IOManager::ECode::E_FAILED_TO_GET_DATA, true, translationTableName + _T(" OBJECTID"), OID, _T("Failed to set PROGMODIFYDATE value"));
						return IOManager::RCode::R_FAILED_FATAL_ERROR;
					}
				}
				//modify prog name = "PoiInfoToHnpUpdater.exe"
				else if (i == modifyProgNameIndex) {
					if (S_OK != tableBuffer->put_Value(i, CComVariant(m_modifyProgName))) {
						IOManager::getInstance().print_error(IOManager::ECode::E_FAILED_TO_GET_DATA, true, translationTableName + _T(" OBJECTID"), OID, _T("Failed to set MODIFYPROGNAME value"));
						return IOManager::RCode::R_FAILED_FATAL_ERROR;
					}
				}
				else {
					if (S_OK != tableBuffer->put_Value(i, tempValue)) {
						IOManager::getInstance().print_error(IOManager::ECode::E_FAILED_TO_GET_DATA, true, translationTableName + _T(" OBJECTID"), OID, _T("Failed to set field value"));
						return IOManager::RCode::R_FAILED_FATAL_ERROR;
					}
				}
			}
			
			//insert new row into TRANSLATION
			CComVariant newTranslationOID;
			if (S_OK != insertTranslationCursor->InsertRow(tableBuffer, &newTranslationOID)) {
				IOManager::getInstance().print_error(IOManager::ECode::E_FAILED_TO_SET_DATA, true, translationTableName, _T(""), _T("Failed to insert new record into cursor"));
				return IOManager::RCode::R_FAILED_FATAL_ERROR;
			}

			IOManager::getInstance().print_run(false, translationTableName + _T(" OBJECTID"), newTranslationOID, _T("Record has been created successfully"));
			successUpdateCount++;
		}
		//flush to database every 10000 new records
		if (successUpdateCount % 10000 == 0 && successUpdateCount > 0) {
			///CAUTION!!! UPDATE NEW RECORDS TO DATABASE
			///CAUTION!!! UPDATE NEW RECORDS TO DATABASE
			if (S_OK != insertTranslationCursor->Flush()) {
				IOManager::getInstance().print_error(IOManager::ECode::E_FAILED_TO_GET_DATA, true, translationTableName, _T(""), _T("Failed to insert new record into database"));
				return IOManager::RCode::R_FAILED_FATAL_ERROR;
			}
			///CAUTION!!! UPDATE NEW RECORDS TO DATABASE
			///CAUTION!!! UPDATE NEW RECORDS TO DATABASE
			if (!stopEditTable(m_table_translation)) {
				IOManager::getInstance().print_error(IOManager::ECode::E_FAILED_TO_GET_DATA, true, _T("Abort Editing"));
				return IOManager::RCode::R_FAILED_FATAL_ERROR;
			}
		}
	}
	//flush last group of new records
	if (successUpdateCount % 10000 != 0 || successUpdateCount == 0) {
		///CAUTION!!! UPDATE NEW RECORDS TO DATABASE
		///CAUTION!!! UPDATE NEW RECORDS TO DATABASE
		if (S_OK != insertTranslationCursor->Flush()) {
			IOManager::getInstance().print_error(IOManager::ECode::E_FAILED_TO_GET_DATA, true, translationTableName, _T(""), _T("Failed to insert new record into database"));
			return IOManager::RCode::R_FAILED_FATAL_ERROR;
		}
		///CAUTION!!! UPDATE NEW RECORDS TO DATABASE
		///CAUTION!!! UPDATE NEW RECORDS TO DATABASE
		if (!stopEditTable(m_table_translation)) {
			IOManager::getInstance().print_error(IOManager::ECode::E_FAILED_TO_GET_DATA, true, _T("Abort Editing"));
			return IOManager::RCode::R_FAILED_FATAL_ERROR;
		}
	}
	//print total update count
	IOManager::getInstance().print_run(true, true, _T("Successfully updated TRANSLATION"));
	CString updateCount = std::to_string(successUpdateCount).c_str();
	IOManager::getInstance().print_run(true, true, _T("Total updated record : ") + updateCount);
	return IOManager::RCode::R_SUCCESS;
}

int PoiInfoToHNPUpdater::insertNewRecordToHNPEntrypoint(std::map<long, long> * updatedPoiHnpList) {

	CString poiEntryFeatureClassName = m_OptionManager->m_poi_entrypoint.c_str();

	//create condition to get only childID column
	IQueryFilterPtr poiEntryIpQueryFilter(CLSID_QueryFilter);
	CString columnFilter;
	columnFilter.Format(_T("%s,%s,%s,%s"), poi_entry_point::kObjectID, poi_entry_point::kPoiInfoID, poi_entry_point::kAccuracyCode, poi_entry_point::kShape);
	if (S_OK != poiEntryIpQueryFilter->put_SubFields((CComBSTR)columnFilter)) {
		IOManager::getInstance().print_error(IOManager::ECode::E_FAILED_TO_SET_DATA, true, poiEntryFeatureClassName, _T(""), _T("Failed to set search column for POIINFOID column"));
		return IOManager::RCode::R_FAILED_FATAL_ERROR;
	}

	//search only records with user input condition
	CComBSTR queryFilter = m_OptionManager->m_sql_poientry.c_str();
	if (S_OK != poiEntryIpQueryFilter->put_WhereClause(queryFilter)) {
		IOManager::getInstance().print_error(IOManager::ECode::E_FAILED_TO_SET_DATA, true, poiEntryFeatureClassName, _T(""), _T("Failed to set search query"));
		return IOManager::RCode::R_FAILED_FATAL_ERROR;
	}

	//set all condition into query variable
	IFeatureCursorPtr poiEntrypointCursor;
	if (S_OK != m_layer_poi_entry->Search(poiEntryIpQueryFilter, VARIANT_FALSE, &poiEntrypointCursor)) {
		IOManager::getInstance().print_error(IOManager::ECode::E_FAILED_TO_GET_DATA, true, poiEntryFeatureClassName, _T(""), _T("Failed to get all records"));
		return IOManager::RCode::R_FAILED_FATAL_ERROR;
	}
	//get columns index of POI_ENTRYPOINT
	long poiInfoIDIndex = 0, accuracyCIndex = 0;

	//check if all columns got index without any error
	int returnStatus = 0;
	returnStatus += getFeatureClassColumnIndex(m_layer_poi_entry, poi_entry_point::kPoiInfoID, &poiInfoIDIndex);
	returnStatus += getFeatureClassColumnIndex(m_layer_poi_entry, poi_entry_point::kAccuracyCode, &accuracyCIndex);
	if (returnStatus != IOManager::RCode::R_SUCCESS) {
		return IOManager::RCode::R_FAILED_FATAL_ERROR;
	}

	long successUpdateCount = 0;	//count total successfully update records

	CString hnpEntryFeatureClassName = m_OptionManager->m_hnp_entrypoint.c_str();

	//prepare column indexes for HNP_ENTRYPOINT
	long	operatorIndex, purposeCIndex, modifyDateIndex, updateTypeCIndex, progModifyDateIndex,
		modifyProgNameIndex, userClaimFIndex, sourceIndex, hnpAccuracyCIndex, hnpPointIDIndex;

	returnStatus = 0;
	returnStatus += getFeatureClassColumnIndex(m_layer_hnp_entry, hnp_entry_point::kOperator, &operatorIndex);
	returnStatus += getFeatureClassColumnIndex(m_layer_hnp_entry, hnp_entry_point::kPurpose, &purposeCIndex);
	returnStatus += getFeatureClassColumnIndex(m_layer_hnp_entry, hnp_entry_point::kModifyDate, &modifyDateIndex);
	returnStatus += getFeatureClassColumnIndex(m_layer_hnp_entry, hnp_entry_point::kUpdateType, &updateTypeCIndex);
	returnStatus += getFeatureClassColumnIndex(m_layer_hnp_entry, hnp_entry_point::kProgModifyDate, &progModifyDateIndex);
	returnStatus += getFeatureClassColumnIndex(m_layer_hnp_entry, hnp_entry_point::kModifyProgName, &modifyProgNameIndex);
	returnStatus += getFeatureClassColumnIndex(m_layer_hnp_entry, hnp_entry_point::kUserClaim, &userClaimFIndex);
	returnStatus += getFeatureClassColumnIndex(m_layer_hnp_entry, hnp_entry_point::kSource, &sourceIndex);
	returnStatus += getFeatureClassColumnIndex(m_layer_hnp_entry, hnp_entry_point::kAccuracyCode, &hnpAccuracyCIndex);
	returnStatus += getFeatureClassColumnIndex(m_layer_hnp_entry, hnp_entry_point::kHnpPointID, &hnpPointIDIndex);
	if (returnStatus != IOManager::RCode::R_SUCCESS) {
		return IOManager::RCode::R_FAILED_FATAL_ERROR;
	}
	//setup cursor and buffer for inputting new OFFICIAL records
	IFeatureBufferPtr featureBuffer;
	if (S_OK != m_layer_hnp_entry->CreateFeatureBuffer(&featureBuffer)) {
		IOManager::getInstance().print_error(IOManager::ECode::E_FAILED_TO_GET_DATA, true, hnpEntryFeatureClassName, _T(""), _T("Failed to create buffer"));
		return IOManager::RCode::R_FAILED_FATAL_ERROR;
	}
	IFeatureCursorPtr insertHnpEntryCursor;

	//loop POI_ENTRYPOINT
	IFeaturePtr ipPoiEntryFeature;
	while (poiEntrypointCursor->NextFeature(&ipPoiEntryFeature) == S_OK && ipPoiEntryFeature) {
		// get OID
		long OIDNum;
		if (S_OK != ipPoiEntryFeature->get_OID(&OIDNum)) {
			IOManager::getInstance().print_error(IOManager::ECode::E_FAILED_TO_GET_DATA, true, poiEntryFeatureClassName, _T(""), _T("Failed to get OBJECTID of one ") + poiEntryFeatureClassName);
			return IOManager::RCode::R_FAILED_FATAL_ERROR;
		}
		//convert OID from long to CString
		CString OID;
		OID.Format(L"%ld", OIDNum);
		// get POI_INFO_ID data
		CComVariant poiInfoID;
		if (S_OK != ipPoiEntryFeature->get_Value(poiInfoIDIndex, &poiInfoID)) {
			IOManager::getInstance().print_error(IOManager::ECode::E_FAILED_TO_GET_DATA, true, poiEntryFeatureClassName + _T(" OBJECTID"), OID, _T("Failed to get POIINFOID value"));
			return IOManager::RCode::R_FAILED_FATAL_ERROR;
		}
		long convertedPoiInfoID = poiInfoID.lVal;
		//find if this POI_ENTRYPOINT's parent is target
		if (updatedPoiHnpList->find(convertedPoiInfoID) != updatedPoiHnpList->end()) {
			// get accuracy_c data
			CComVariant accuracyC;
			if (S_OK != ipPoiEntryFeature->get_Value(accuracyCIndex, &accuracyC)) {
				IOManager::getInstance().print_error(IOManager::ECode::E_FAILED_TO_GET_DATA, true, poiEntryFeatureClassName + _T(" OBJECTID"), OID, _T("Failed to get ACCURACY_C value"));
				return IOManager::RCode::R_FAILED_FATAL_ERROR;
			}
			CString convertedAccuracyC = accuracyC.bstrVal;
			// get shape
			IGeometryPtr ipPoiEntryGeom;
			if (S_OK != ipPoiEntryFeature->get_ShapeCopy(&ipPoiEntryGeom)) {
				IOManager::getInstance().print_error(IOManager::ECode::E_FAILED_TO_GET_DATA, true, poiEntryFeatureClassName + _T(" OBJECTID"), OID, _T("Failed to get shape"));
				return IOManager::RCode::R_FAILED_FATAL_ERROR;
			}

			//start editing
			if (successUpdateCount % 10000 == 0) {
				if (!startEditFeatureClass(m_layer_hnp_entry)) {
					IOManager::getInstance().print_error(IOManager::ECode::E_FAILED_TO_GET_DATA, true, _T("Start Editing"));
					return IOManager::RCode::R_FAILED_FATAL_ERROR;
				}
				//insert cursor for creating records
				if (S_OK != m_layer_hnp_entry->Insert(VARIANT_TRUE, &insertHnpEntryCursor)) {
					IOManager::getInstance().print_error(IOManager::ECode::E_FAILED_TO_GET_DATA, true, hnpEntryFeatureClassName, _T(""), _T("Create new cursor for new records"));
					return IOManager::RCode::R_FAILED_FATAL_ERROR;
				}
			}
			//create new HNP_ENTRYPOINT record
			returnStatus = 0;
			returnStatus += putFeatureClassColumnValue(hnpEntryFeatureClassName, featureBuffer, operatorIndex, CComVariant(m_operator));
			returnStatus += putFeatureClassColumnValue(hnpEntryFeatureClassName, featureBuffer, purposeCIndex, CComVariant(m_purpose));
			returnStatus += putFeatureClassColumnValue(hnpEntryFeatureClassName, featureBuffer, updateTypeCIndex, CComVariant(m_updateType));
			//get current datetime
			COleDateTime date = COleDateTime::GetCurrentTime();
			double dateTime = date.m_dt;
			returnStatus += putFeatureClassColumnValue(hnpEntryFeatureClassName, featureBuffer, progModifyDateIndex, CComVariant(dateTime));
			returnStatus += putFeatureClassColumnValue(hnpEntryFeatureClassName, featureBuffer, modifyProgNameIndex, CComVariant(m_modifyProgName));
			returnStatus += putFeatureClassColumnValue(hnpEntryFeatureClassName, featureBuffer, userClaimFIndex, CComVariant(m_userClaim));
			//set message for source column
			CString objectID = _T("POI_ENTRYPOINT OBJECTID: ");
			objectID += OID;
			returnStatus += putFeatureClassColumnValue(hnpEntryFeatureClassName, featureBuffer, sourceIndex, CComVariant(objectID));
			returnStatus += putFeatureClassColumnValue(hnpEntryFeatureClassName, featureBuffer, hnpAccuracyCIndex, accuracyC);
			CComBSTR hnpObjectID = std::to_string(updatedPoiHnpList->find(convertedPoiInfoID)->second).c_str();
			returnStatus += putFeatureClassColumnValue(hnpEntryFeatureClassName, featureBuffer, hnpPointIDIndex, CComVariant(hnpObjectID));
			if (returnStatus != IOManager::RCode::R_SUCCESS) {
				return IOManager::RCode::R_FAILED_FATAL_ERROR;
			}
			if (S_OK != featureBuffer->putref_Shape(ipPoiEntryGeom)) {
				IOManager::getInstance().print_error(IOManager::ECode::E_FAILED_TO_SET_DATA, true, hnpEntryFeatureClassName, _T(""), _T("Failed to input new shape"));
				return IOManager::RCode::R_FAILED_FATAL_ERROR;
			}

			//insert new row into HNP_ENTRYPOINT
			CComVariant newHnpEntryOID;
			if (S_OK != insertHnpEntryCursor->InsertFeature(featureBuffer, &newHnpEntryOID)) {
				IOManager::getInstance().print_error(IOManager::ECode::E_FAILED_TO_SET_DATA, true, hnpEntryFeatureClassName, _T(""), _T("Failed to insert new record into cursor"));
				return IOManager::RCode::R_FAILED_FATAL_ERROR;
			}
			IOManager::getInstance().print_run(false, poiEntryFeatureClassName + _T(" OBJECTID"), newHnpEntryOID, _T("Record has been created successfully"));
			successUpdateCount++;
		}
		//flush to database every 10000 new records
		if (successUpdateCount % 10000 == 0 && successUpdateCount > 0) {
			///CAUTION!!! UPDATE NEW RECORDS TO DATABASE
			///CAUTION!!! UPDATE NEW RECORDS TO DATABASE
			if (S_OK != insertHnpEntryCursor->Flush()) {
				IOManager::getInstance().print_error(IOManager::ECode::E_FAILED_TO_GET_DATA, true, hnpEntryFeatureClassName, _T(""), _T("Failed to insert new record into database"));
				return IOManager::RCode::R_FAILED_FATAL_ERROR;
			}
			///CAUTION!!! UPDATE NEW RECORDS TO DATABASE
			///CAUTION!!! UPDATE NEW RECORDS TO DATABASE
			if (!stopEditFeatureClass(m_layer_hnp_entry)) {
				IOManager::getInstance().print_error(IOManager::ECode::E_FAILED_TO_GET_DATA, true, _T("Abort Editing"));
				return IOManager::RCode::R_FAILED_FATAL_ERROR;
			}
		}
	}
	//flush last group of new records
	if (successUpdateCount % 10000 != 0 || successUpdateCount == 0) {
		///CAUTION!!! UPDATE NEW RECORDS TO DATABASE
		///CAUTION!!! UPDATE NEW RECORDS TO DATABASE
		if (S_OK != insertHnpEntryCursor->Flush()) {
			IOManager::getInstance().print_error(IOManager::ECode::E_FAILED_TO_GET_DATA, true, hnpEntryFeatureClassName, _T(""), _T("Failed to insert new record into database"));
			return IOManager::RCode::R_FAILED_FATAL_ERROR;
		}
		///CAUTION!!! UPDATE NEW RECORDS TO DATABASE
		///CAUTION!!! UPDATE NEW RECORDS TO DATABASE
		if (!stopEditFeatureClass(m_layer_hnp_entry)) {
			IOManager::getInstance().print_error(IOManager::ECode::E_FAILED_TO_GET_DATA, true, _T("Abort Editing"));
			return IOManager::RCode::R_FAILED_FATAL_ERROR;
		}
	}
	//print total updated count
	IOManager::getInstance().print_run(true, true, _T("Successfully updated HNP_ENTRYPOINT"));
	CString updateCount = std::to_string(successUpdateCount).c_str();
	IOManager::getInstance().print_run(true, true, _T("Total updated record : ") + updateCount);
	return IOManager::RCode::R_SUCCESS;
}

