#pragma once

/**
* @brief Manage Input/Output file and control output print, also manage error code and type
*/
class IOManager
{
public:
	
	/**
	* @brief�@specific file type into error, run, output type.
	*/
	enum FileType : int {
	RUN 					= 0,
	ERR						= 1,
	OUTPUT					= 2,
	UNDEFINED				= 3
	};
	
	/* static access method */
	static IOManager & getInstance();

	~IOManager();

	/**
	* @brief�@error enum
	*/
	enum ECode : int {
		E_INVALID_OPTION = 101,
		E_FAILED_TO_OPEN_FILE_PATH = 201,
		E_FAILED_TO_OPEN_WORKSPACE = 202,
		E_FAILED_TO_OPEN_FEATURECLASS = 203,
		E_FAILED_TO_OPEN_TABLE = 204,
		E_FAILED_TO_OPEN_FIELD = 205,
		E_FAILED_TO_SEARCH = 301,
		E_FAILED_TO_GET_DATA = 302,
		E_FAILED_TO_SET_DATA = 303,
		E_FAILED_TO_PROCESS = 304,
		E_COM_ERROR_IS_CATCHED = 900
	};

	/**
	* @brief�@return result value
	*/
	enum RCode : int {
		R_SUCCESS = 0,
		R_FAILED_FATAL_ERROR = 1,
		R_FAILED_EXCEPTION_ERROR = 2
	};

	/**
	* @brief Error message structure
	*/
	struct errorMsg {
		ECode errorCode;
		CString errorType;
		CString errorDesc;
	};

	/**
	* @brief Initialize error message
	*/
	void initErrorMessage();

	/**
	* @brief Create every type of error message
	* @param errorCode		[in]	ECode
	* @param errorType		[in]	Error type(FILE_ERROR,PROCESS_ERROR,ETC.)
	* @param errorDesc		[in]	Error details
	*/
	void createEachMessageFormat(const ECode& errorCode, const CString& errorType, const CString&errorDesc);
	/**
	* @brief Get error message type and description
	* @return	error message type and description
	*/
	errorMsg getErrorMessage(ECode errorCode);

	/**
	* @brief Initialize selected file
	* @param filePath		[in]	File path
	* @param fileType		[in]	run�Aerror�Aoutput file
	* @return	True if success�Afalse if error
	*/
	int initFile(const CString& filePath, const FileType& fileType);
	/**
	* @brief Close all file stream
	*/
	void closeFile();
	/**
	* @brief Print error message into error log and cerr
	* @param errorCode		[in]	ECode
	* @param isPrintCerr	[in]	Is print this error to cerr
	* @param errorDesc1		[in]	First description of error(Source of error such as file path, DB, field setting)
	* @param errorDesc2		[in]	Second description of error(Row number at which an error occured, record's OID)
	* @param errorDesc3		[in]	Third description of error(Detail description)
	*/
	void print_error(const ECode& errorCode, const bool& isPrintCerr, const CString& errorDesc1, const CString& errorDesc2 = _T(""), const CString& errorDesc3 = _T(""));
	/**
	* @brief Print run message into run log and cout
	* @param isTimeStamp	[in]	Is print this run message with current timestamp
	* @param isPrintCout	[in]	Is print this run meesage to cout
	* @param runMsg1		[in]	First message to print in 3rd column
	* @param runMsg2		[in]	Second message to print in 4th column
	* @param runMsg3		[in]	Third message to print in 5th column
	*/
	void print_run(const bool& isTimeStamp, const bool& isPrintCout, const CString& runMsg1, const CString& runMsg2 = _T(""), const CString& runMsg3 = _T(""));
	/**
	* @brief Print start line (timestamp + "Start :" messsage) into run log and cout
	*/
	void print_start();
	/**
	* @brief Print fix messsage when the tool ends successfully
	* @return	RCode::R_SUCCESS
	*/
	int printSuccessfulEnd();
	/**
	* @brief when error occured, print error details and ends program
	* @return	RCode::R_FAILED_FATAL_ERROR
	*/
	int endProgramWithError(const CString& errorPoint);
	

private:
	IOManager(IOManager const&);
	IOManager();
	std::map<ECode, errorMsg> m_errorMessageGroup;	//Error Meesage Group
	std::fstream m_runLog,m_errLog;					//filestream for log
	//std::ofstream m_outputFile;					//filestream for output file
	time_t m_start_time;
};