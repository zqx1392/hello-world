#pragma once


class PoiAssociation {
public:

	PoiAssociation(const CString& poiAssoTableName, ITablePtr& poiAssoTable);
	~PoiAssociation();
	/**
	* @brief start the tool
	* @return	RCode value [ex�FR_SUCCESS=0�AR_FAILED_FATAL_ERROR=1�A...]
	*/
	int getChildPOI(std::set<long> * childPOIList);

	

private:
	CString poiAssoTableName;
	ITablePtr poiAssoTable;
};
