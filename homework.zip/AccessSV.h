#pragma once

/**
* @brief Manage server connection and ARCGIS-related function.
*/
class AccessSV
{
public:
	/* static access method */
	static AccessSV & getInstance();

	~AccessSV();

	/**
	* @brief Get workspace
	* @param workspaceName		[in]	workspace full name [ex. TEST2017@gaia(SDE.DEFAULT)]
	* @param workspace			[out]	IWorkspace variable
	* @return	success��0�Afailure��1
	*/
	int getWorkspace(const CString& workspaceName, IWorkspacePtr & workspace);
		
	/**
	* @brief Get featureClass
	* @param workspaceName		[in]	workspace full name [ex. TEST2017@gaia(SDE.DEFAULT)]
	* @param featureClassName	[in]	featureclass full name [ex. TEST2017.ROAD_LINK]
	* @param featureClass		[out]	IFeatureClass variable
	* @return	success��0�Afailure��1
	*/
	int getFeatureClass (const CString& workspaceName,const CString& featureClassName, IFeatureClassPtr & featureClass);
	
	/**
	* @brief Get table
	* @param workspaceName		[in]	workspace full name [ex. TEST2017@gaia(SDE.DEFAULT)]
	* @param tableName			[in]	table full name [ex. TEST2017.ALTERNATIVE_NAME]
	* @param table				[out]	ITable variable
	* @return	success��0�Afailure��1
	*/
	int getTable(const CString& workspaceName, const CString& tablesName, ITablePtr & table);
	
	/**
	* @brief Get field
	* @param workspaceName		[in]	workspace full name [ex. TEST2017@gaia(SDE.DEFAULT)]
	* @param datasetName		[in]	target dataset name [ex. sindy::schema::example:kfeatureClassName, "ROAD_LINK", "ALTERNATIVE_NAME"]
	* @param fieldName			[in]	field name [ex. OBJECTID]
	* @param isTable				[in]	Is input dataset name table name or featureClass name
	* @param field				[out]	IField variable
	* @return	success��0�Afailure��1
	*/
	int getField(const CString& workspaceName, const CString& datasetName, const CString& fieldName, const bool& isTable, IFieldPtr & field);

	int getFeatureClassColumnIndex(const IFeatureClassPtr& ipFeatureClass, const CComBSTR& fieldName, long * index);

	int getTableColumnIndex(const ITablePtr& ipFeatureClass, const CComBSTR& fieldName, long * index);

	int putFeatureClassColumnValue(const CString& featureClassName, IFeatureBufferPtr featureBuffer, const long& index, CComVariant value);

	int putTableColumnValue(const CString& tableName, IRowBufferPtr rowBuffer, const long& index, CComVariant value);

	/**
	* @brief   �o�[�W�����Ή����C����
	* @param   ipFeatureClass  [in] �t�B�[�`���N���X
	* @retval  true  �o�[�W�����Ή�
	* @retval  false �o�[�W������Ή�
	*/
	bool isVersionedFeatureClass( IFeatureClassPtr& ipFeatureClass);
	bool isVersionedTable(ITablePtr& ipTable);

	/**
	* @brief   �ҏW�J�n
	* @retval  true  ����
	* @retval  false ���s
	*/
	bool startEditFeatureClass(IWorkspacePtr& workspace, IFeatureClassPtr& ipFeatureClass);
	bool startEditTable(IWorkspacePtr& workspace, ITablePtr& ipTable);
	/**
	* @brief   �ҏW�I��
	* @retval  true  ����
	* @retval  false ���s
	*/
	bool stopEditFeatureClass(IWorkspacePtr& workspace, IFeatureClassPtr& ipFeatureClass);
	bool stopEditTable(IWorkspacePtr& workspace, ITablePtr& ipTable);
	/**
	* @brief   �ҏW�j��
	*/
	void abortEdit(IWorkspacePtr& workspace);



private:
	AccessSV(AccessSV const&);
	AccessSV();
};