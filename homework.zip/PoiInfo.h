#pragma once

class PoiInfo {
public:

	PoiInfo(const CString& poiInfoFeatureClassName, IFeatureClassPtr& poiInfoFeatureClass);
	~PoiInfo();
	/**
	* @brief start the tool
	* @return	RCode value [ex�FR_SUCCESS=0�AR_FAILED_FATAL_ERROR=1�A...]
	*/
	int presetPoiInfoFeatureCursor(const CComBSTR & queryFilter, IQueryFilterPtr PoiInfoIpQueryFilter, IFeatureCursorPtr ipPoiInfoCursor);
	/**
	* @brief start the tool
	* @return	RCode value [ex�FR_SUCCESS=0�AR_FAILED_FATAL_ERROR=1�A...]
	*/
	int getUniquePoiInfoID(const CComBSTR & queryFilter, std::wstring bufferSize, std::set<long> * childPOIList, std::set<long> * PoiInfoList, std::map<long, CString> * officialNameList, std::vector<CommonData::poiInfo> * uniquePoiInfoList);
	/**
	* @brief start the tool
	* @return	RCode value [ex�FR_SUCCESS=0�AR_FAILED_FATAL_ERROR=1�A...]
	*/
	double	GetDist(double		eLon1,
		double		eLat1,
		double		eLon2,
		double		eLat2);



private:
	CString poiInfoFeatureClassName;
	IFeatureClassPtr poiInfoFeatureClass;
};

