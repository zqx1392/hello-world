#pragma once

#include "OptionManager.h"
#include "PoiAssociation.h"
#include "PoiEntrypoint.h"
#include "Hnp.h"
#include "OfficialName.h"
#include "PoiInfo.h"


/**
* @brief	Tool main process :
	1.Create new HNP record by copying value from POI_INFO record whose HN value not null 
	2.Copy: HN, Coordinates.
	3.Create new record on OFFICIAL_NAME and TRANSLATION. the new record will copy value from POI_INFO's using POI_INFO.ROADNAMEID
	4.Copy new OFFICIAL_NAME.OBJECTID to HNP.ROADNAMEID
	5.(Planning) update existed HNP records which were created by this tool
*/

class PoiInfoToHNPUpdater
{
public:
	OptionManager *  m_OptionManager;
	PoiInfoToHNPUpdater();
	~PoiInfoToHNPUpdater();

	

	/**
	* @brief Connect to necessary files and ARCGIS data
	*/
	int ConnectToFileAndData();
	/**
	* @brief Preset all input and output such as log files, DBs and featureclasses variables before start ArcGIS-related process
	* @return	RCode value [ex�FR_SUCCESS=0�AR_FAILED_FATAL_ERROR=1�A...]
	*/
	int presetData(const int& argc, _TCHAR* argv[]);
	/**
	* @brief start the tool
	* @return	RCode value [ex�FR_SUCCESS=0�AR_FAILED_FATAL_ERROR=1�A...]
	*/
	int run();



	
	
	
	
	
	
	

	
	/**
	* @brief start the tool
	* @return	RCode value [ex�FR_SUCCESS=0�AR_FAILED_FATAL_ERROR=1�A...]
	*/
	int insertNewRecordToTranslation(std::map<long, long> * translationList);
	/**
	* @brief start the tool
	* @return	RCode value [ex�FR_SUCCESS=0�AR_FAILED_FATAL_ERROR=1�A...]
	*/
	int insertNewRecordToHNPEntrypoint(std::map<long, long> * updatedPoiHnpList);

	

	


	
private:
	static const int is_success = IOManager::RCode::R_SUCCESS;
	
	//ArcGIS data
	IWorkspacePtr m_workspace;
	IFeatureClassPtr m_layer_hnp;
	IFeatureClassPtr m_layer_poi_info;
	IFeatureClassPtr m_layer_hnp_entry;
	IFeatureClassPtr m_layer_poi_entry;
	ITablePtr m_table_poi_asso;
	ITablePtr m_table_official;
	ITablePtr m_table_translation;
	


};