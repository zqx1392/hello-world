#pragma once
#include "stdafx.h"
#include <arctl/coinitializer.h>
#include "PoiInfoToHNPUpdater.h"

int _tmain(int argc, _TCHAR* argv[])
{

	arctl::coinitializer aCoInitializer;
	PoiInfoToHNPUpdater cPoiInfoToHNPUpdater;
	if (0 != cPoiInfoToHNPUpdater.presetData(argc, argv)) {
		system("pause");
		return 1;
	}
	int isSuccess = cPoiInfoToHNPUpdater.run();
	std::cout << "end prog" << std::endl;
	system("pause");
	//return isSuccess;
}