#include "stdafx.h"
#include "OfficialName.h"
#include "Hnp.h"

using namespace sindy::schema::global;

OfficialName::OfficialName(const CString& officialTableName, ITablePtr& officialTable, Hnp * cHnp) {
	this->officialTableName = officialTableName;
	this->officialTable = officialTable;
	this->cHnp = cHnp;
}

OfficialName::~OfficialName() {
}

int OfficialName::getOfficalName(std::map<long, CString> * officialNameList) {

	//create condition to get only childID column
	IQueryFilterPtr officialIpQueryFilter(CLSID_QueryFilter);
	CString columnFilter;
	columnFilter.Format(_T("%s,%s"), official_name::kObjectID, official_name::kName);
	if (S_OK != officialIpQueryFilter->put_SubFields((CComBSTR)columnFilter)) {
		IOManager::getInstance().print_error(IOManager::ECode::E_FAILED_TO_SET_DATA, true, officialTableName, _T(""), _T("Failed to set search column for NAME column"));
		return IOManager::RCode::R_FAILED_FATAL_ERROR;
	}
	//set all condition into query variable
	_ICursorPtr ipOfficialCursor;
	//search only records with layer=33 (POI_INFO)
	CComBSTR queryFilter = _T("LAYER_C = 33");
	if (S_OK != officialIpQueryFilter->put_WhereClause(queryFilter)) {
		IOManager::getInstance().print_error(IOManager::ECode::E_FAILED_TO_SET_DATA, true, officialTableName, _T(""), _T("Failed to set search query"));
		return IOManager::RCode::R_FAILED_FATAL_ERROR;
	}
	if (S_OK != officialTable->Search(officialIpQueryFilter, VARIANT_FALSE, &ipOfficialCursor)) {
		IOManager::getInstance().print_error(IOManager::ECode::E_FAILED_TO_GET_DATA, true, officialTableName, _T(""), _T("Failed to get all records"));
		return IOManager::RCode::R_FAILED_FATAL_ERROR;
	}
	// get column index for child id
	long nameColumnIndex = 0;
	if (S_OK != ipOfficialCursor->Fields->FindField((CComBSTR)official_name::kName, &nameColumnIndex)) {
		IOManager::getInstance().print_error(IOManager::ECode::E_FAILED_TO_GET_DATA, true, officialTableName, _T("FIELD INDEX"), _T("Failed to get NAME field index"));
		return IOManager::RCode::R_FAILED_FATAL_ERROR;
	}

	//set to store childID list
	//get target postal code
	_IRowPtr ipOfficialRow;
	while (ipOfficialCursor->NextRow(&ipOfficialRow) == S_OK && ipOfficialRow) {
		// get postal point OID
		long OIDNum;
		if (S_OK != ipOfficialRow->get_OID(&OIDNum)) {
			IOManager::getInstance().print_error(IOManager::ECode::E_FAILED_TO_GET_DATA, true, officialTableName, _T(""), _T("Failed to get OBJECTID of one ") + ipOfficialRow);
			return IOManager::RCode::R_FAILED_FATAL_ERROR;
		}
		//convert OID from long to CString
		CString OID;
		OID.Format(L"%ld", OIDNum);
		// get child id data
		CComVariant name;
		if (S_OK != ipOfficialRow->get_Value(nameColumnIndex, &name)) {
			IOManager::getInstance().print_error(IOManager::ECode::E_FAILED_TO_GET_DATA, true, officialTableName + _T(" OBJECTID"), OID, _T("Failed to get NAME value"));
			return IOManager::RCode::R_FAILED_FATAL_ERROR;
		}
		CString convertedName = name.bstrVal;
		convertedName = convertedName.Trim();
		if (!officialNameList->insert(std::make_pair(OIDNum, name.bstrVal)).second) {
			IOManager::getInstance().print_error(IOManager::ECode::E_FAILED_TO_PROCESS, true, officialTableName + _T(" OBJECTID"), OID, _T("Unexpected error occured while storing OFFICIAL_NAME data"));
			return IOManager::RCode::R_FAILED_FATAL_ERROR;
		}
	}
	return IOManager::RCode::R_SUCCESS;
}

int OfficialName::insertNewRecordToHNPAndOfficial(IWorkspacePtr& workspace, std::vector<CommonData::poiInfo> * uniquePoiInfoList, std::map<long, long> * updatedPoiHnpList, std::map<long, long> * translationList) {
	long successUpdateCount = 0;	//count total successfully update records

	IQueryFilterPtr officialIpQueryFilter(CLSID_QueryFilter);

	//set all condition into query variable
	_ICursorPtr ipOfficialCursor;
	//search only records with layer=33 (POI_INFO)
	CComBSTR queryFilter = _T("LAYER_C = 33");
	if (S_OK != officialIpQueryFilter->put_WhereClause(queryFilter)) {
		IOManager::getInstance().print_error(IOManager::ECode::E_FAILED_TO_SET_DATA, true, officialTableName, _T(""), _T("Failed to set search query"));
		return IOManager::RCode::R_FAILED_FATAL_ERROR;
	}
	if (S_OK != officialTable->Search(officialIpQueryFilter, VARIANT_FALSE, &ipOfficialCursor)) {
		IOManager::getInstance().print_error(IOManager::ECode::E_FAILED_TO_GET_DATA, true, officialTableName, _T(""), _T("Failed to get all records"));
		return IOManager::RCode::R_FAILED_FATAL_ERROR;
	}

	//create new map for <POI_INFO.ROADNAMEID, position in uniquePoiInfoList> to reduce query time
	std::map<long, int> roadNameMap;
	for (int i = 0; i < uniquePoiInfoList->size(); i++) {
		//skip null ROADNAMEID
		if (uniquePoiInfoList->operator[](i).roadNameID == 0) {
			continue;
		}
		if (!roadNameMap.insert(std::make_pair(uniquePoiInfoList->operator[](i).roadNameID, i)).second) {
			IOManager::getInstance().print_error(IOManager::ECode::E_FAILED_TO_PROCESS, true, officialTableName, _T(""), _T("Unexpected error occured while creating roadNameMap variable"));
			return IOManager::RCode::R_FAILED_FATAL_ERROR;
		}
	}
	//prepare column indexes for OFFICIAL_NAME
	//check if all columns got index without any error
	int returnStatus = 0;
	//find each column index of HNP
	long officialObjectIDIndex = 0, officialLayerCIndex = 0, officialOperatorIndex = 0, officialProgModifyDateIndex = 0;
	long officialUpdateTypeCIndex = 0, officialModifyProgNameIndex = 0;
	returnStatus += AccessSV::getInstance().getTableColumnIndex(officialTable, official_name::kObjectID, &officialObjectIDIndex);
	returnStatus += AccessSV::getInstance().getTableColumnIndex(officialTable, official_name::kOperator, &officialOperatorIndex);
	returnStatus += AccessSV::getInstance().getTableColumnIndex(officialTable, official_name::kUpdateType, &officialUpdateTypeCIndex);
	returnStatus += AccessSV::getInstance().getTableColumnIndex(officialTable, official_name::kProgModifyDate, &officialProgModifyDateIndex);
	returnStatus += AccessSV::getInstance().getTableColumnIndex(officialTable, official_name::kModifyProgName, &officialModifyProgNameIndex);
	returnStatus += AccessSV::getInstance().getTableColumnIndex(officialTable, official_name::kLayerCode, &officialLayerCIndex);
	if (returnStatus != IOManager::RCode::R_SUCCESS) {
		return IOManager::RCode::R_FAILED_FATAL_ERROR;
	}

	//setup cursor and buffer for inputting new OFFICIAL_NAME records
	_ICursorPtr insertOfficialCursor;
	IRowBufferPtr tableBuffer;
	if (S_OK != officialTable->CreateRowBuffer(&tableBuffer)) {
		IOManager::getInstance().print_error(IOManager::ECode::E_FAILED_TO_GET_DATA, true, officialTableName, _T(""), _T("Failed to create buffer"));
		return IOManager::RCode::R_FAILED_FATAL_ERROR;
	}

	//setup cursor and buffer for inputting new HNP records
	if (IOManager::RCode::R_SUCCESS != cHnp->createNewBuffer()) {
		return IOManager::RCode::R_FAILED_FATAL_ERROR;
	}

	//create new records
	_IRowPtr ipOfficialRow;
	while (ipOfficialCursor->NextRow(&ipOfficialRow) == S_OK && ipOfficialRow) {
		// get postal point OID
		long OIDNum;
		if (S_OK != ipOfficialRow->get_OID(&OIDNum)) {
			IOManager::getInstance().print_error(IOManager::ECode::E_FAILED_TO_GET_DATA, true, officialTableName, _T(""), _T("Failed to get OBJECTID of one ") + officialTableName);
			return IOManager::RCode::R_FAILED_FATAL_ERROR;
		}
		//convert OID from long to CString
		CString OID;
		OID.Format(L"%ld", OIDNum);
		//if found this OFFICIAL_NAME OBJECTID record in target POI_INFO
		if (roadNameMap.find(OIDNum) != roadNameMap.end()) {
			//start editing
			if (successUpdateCount % 10000 == 0) {
				if (!AccessSV::getInstance().startEditTable(workspace, officialTable)) {
					IOManager::getInstance().print_error(IOManager::ECode::E_FAILED_TO_GET_DATA, true, _T("Start Editing"));
					return IOManager::RCode::R_FAILED_FATAL_ERROR;
				}
				//insert cursor for creating records
				if (S_OK != officialTable->Insert(VARIANT_TRUE, &insertOfficialCursor)) {
					IOManager::getInstance().print_error(IOManager::ECode::E_FAILED_TO_GET_DATA, true, officialTableName, _T(""), _T("Create new cursor for new records"));
					return IOManager::RCode::R_FAILED_FATAL_ERROR;
				}
				if (IOManager::RCode::R_SUCCESS != cHnp->startAndInsertHnpCursor(workspace)) {
					return IOManager::RCode::R_FAILED_FATAL_ERROR;
				}
			}
			//create new OFFICIAL_NAME record
			for (int i = 0; i < officialTable->Fields->FieldCount; i++) {
				//discard index and layer
				if (i == officialObjectIDIndex) {
					continue;
				}
				//get value on old record
				CComVariant tempValue;
				if (S_OK != ipOfficialRow->get_Value(i, &tempValue)) {
					CComBSTR columnName = "";
					//get field name to print description error
					if (S_OK != officialTable->Fields->GetField(i)->get_Name(&columnName)) {
						IOManager::getInstance().print_error(IOManager::ECode::E_FAILED_TO_GET_DATA, true, officialTableName + _T(" OBJECTID"), OID, _T("Failed to get field name and value"));
						return IOManager::RCode::R_FAILED_FATAL_ERROR;
					}
					//print error with field name
					CString msg = "Failed to get ";
					msg += columnName;
					msg += " value";
					IOManager::getInstance().print_error(IOManager::ECode::E_FAILED_TO_GET_DATA, true, officialTableName + _T(" OBJECTID"), OID, msg);
					return IOManager::RCode::R_FAILED_FATAL_ERROR;
				}
				//set layer_c = 34 value on new record
				if (i == officialLayerCIndex) {
					if (S_OK != tableBuffer->put_Value(i, CComVariant(m_HNP_layerC))) {
						IOManager::getInstance().print_error(IOManager::ECode::E_FAILED_TO_GET_DATA, true, officialTableName + _T(" OBJECTID"), OID, _T("Failed to set LAYER_C field value"));
						return IOManager::RCode::R_FAILED_FATAL_ERROR;
					}
				}
				//operator = sindy
				else if (i == officialOperatorIndex) {
					if (S_OK != tableBuffer->put_Value(i, CComVariant(m_operator))) {
						IOManager::getInstance().print_error(IOManager::ECode::E_FAILED_TO_GET_DATA, true, officialTableName + _T(" OBJECTID"), OID, _T("Failed to set OPERATOR value"));
						return IOManager::RCode::R_FAILED_FATAL_ERROR;
					}
				}
				//updatetypeC = 6
				else if (i == officialUpdateTypeCIndex) {
					if (S_OK != tableBuffer->put_Value(i, CComVariant(m_updateType))) {
						IOManager::getInstance().print_error(IOManager::ECode::E_FAILED_TO_GET_DATA, true, officialTableName + _T(" OBJECTID"), OID, _T("Failed to set UPDATETYPE_C value"));
						return IOManager::RCode::R_FAILED_FATAL_ERROR;
					}
				}
				//prog modify date = now
				else if (i == officialProgModifyDateIndex) {
					COleDateTime date = COleDateTime::GetCurrentTime();
					double dateTime = date.m_dt;
					if (S_OK != tableBuffer->put_Value(i, CComVariant(dateTime))) {
						IOManager::getInstance().print_error(IOManager::ECode::E_FAILED_TO_GET_DATA, true, officialTableName + _T(" OBJECTID"), OID, _T("Failed to set PROGMODIFYDATE value"));
						return IOManager::RCode::R_FAILED_FATAL_ERROR;
					}
				}
				//modify prog name = "PoiInfoToHnpUpdater.exe"
				else if (i == officialModifyProgNameIndex) {
					if (S_OK != tableBuffer->put_Value(i, CComVariant(m_modifyProgName))) {
						IOManager::getInstance().print_error(IOManager::ECode::E_FAILED_TO_GET_DATA, true, officialTableName + _T(" OBJECTID"), OID, _T("Failed to set MODIFYPROGNAME value"));
						return IOManager::RCode::R_FAILED_FATAL_ERROR;
					}
				}
				//copy other value from POI_INFO's to HNP's on new record
				else {
					if (S_OK != tableBuffer->put_Value(i, CComVariant(tempValue))) {
						IOManager::getInstance().print_error(IOManager::ECode::E_FAILED_TO_GET_DATA, true, officialTableName + _T(" OBJECTID"), OID, _T("Failed to set field value"));
						return IOManager::RCode::R_FAILED_FATAL_ERROR;
					}
				}
			}
			CComVariant newOfficialOID;
			//insert new row into OFFICIAL_NAME
			if (S_OK != insertOfficialCursor->InsertRow(tableBuffer, &newOfficialOID)) {
				IOManager::getInstance().print_error(IOManager::ECode::E_FAILED_TO_SET_DATA, true, officialTableName, _T(""), _T("Failed to insert new record into cursor"));
				return IOManager::RCode::R_FAILED_FATAL_ERROR;
			}

			//get index value from uniquePoiInfoList
			int uniqIndex = roadNameMap[OIDNum];


			double x = uniquePoiInfoList->operator[](uniqIndex).x;
			double y = uniquePoiInfoList->operator[](uniqIndex).y;
			long poiInfoObjectID = uniquePoiInfoList->operator[](uniqIndex).OBJECTID;
			CString hn = uniquePoiInfoList->operator[](uniqIndex).houseNumber;
			if (IOManager::RCode::R_SUCCESS != cHnp->putValueIntoFields(poiInfoObjectID, hn, newOfficialOID.lVal, x, y)) {
				return IOManager::RCode::R_FAILED_FATAL_ERROR;
			}
			
			CComVariant newHnpOID;
			if (IOManager::RCode::R_SUCCESS != cHnp->insertNewFeature(&newHnpOID)) {
				return IOManager::RCode::R_FAILED_FATAL_ERROR;
			}

			//insert into updatedPoiHnpList map to create new records on HNP_ENTRYPOINT later
			if (!updatedPoiHnpList->insert(std::make_pair(uniquePoiInfoList->operator[](uniqIndex).OBJECTID, newHnpOID.intVal)).second) {
				IOManager::getInstance().print_error(IOManager::ECode::E_FAILED_TO_PROCESS, true, _T("Unexpected error occured while creating updatedPoiHnpList variable"));
				return IOManager::RCode::R_FAILED_FATAL_ERROR;
			}
			//insert into translationList map to create new records on TRANSLATION later
			if (!translationList->insert(std::make_pair(OIDNum, newOfficialOID.intVal)).second) {
				IOManager::getInstance().print_error(IOManager::ECode::E_FAILED_TO_PROCESS, true, officialTableName + _T(" OBJECTID"), OID, _T("Unexpected error occured while storing OFFICIAL_NAME data"));
				return IOManager::RCode::R_FAILED_FATAL_ERROR;
			}

			IOManager::getInstance().print_run(false, officialTableName + _T(" OBJECTID"), newOfficialOID, _T("Record has been created successfully"));
			successUpdateCount++;
		}
		//flush to database every 10000 new records
		if (successUpdateCount % 10000 == 0 && successUpdateCount > 0) {
			///CAUTION!!! UPDATE NEW RECORDS TO DATABASE
			///CAUTION!!! UPDATE NEW RECORDS TO DATABASE
			if (S_OK != insertOfficialCursor->Flush()) {
				IOManager::getInstance().print_error(IOManager::ECode::E_FAILED_TO_GET_DATA, true, officialTableName, _T(""), _T("Failed to insert new record into database"));
				return IOManager::RCode::R_FAILED_FATAL_ERROR;
			}
			///CAUTION!!! UPDATE NEW RECORDS TO DATABASE
			///CAUTION!!! UPDATE NEW RECORDS TO DATABASE
			if (!AccessSV::getInstance().stopEditTable(workspace, officialTable)) {
				IOManager::getInstance().print_error(IOManager::ECode::E_FAILED_TO_GET_DATA, true, _T("Abort Editing"));
				return IOManager::RCode::R_FAILED_FATAL_ERROR;
			}
			if (IOManager::RCode::R_SUCCESS != cHnp->flushAndStopHnpEdit(workspace)) {
				return IOManager::RCode::R_FAILED_FATAL_ERROR;
			}
		}
	}
	//flush last group of new records
	if (successUpdateCount % 10000 != 0 || successUpdateCount == 0) {
		///CAUTION!!! UPDATE NEW RECORDS TO DATABASE
		///CAUTION!!! UPDATE NEW RECORDS TO DATABASE
		if (S_OK != insertOfficialCursor->Flush()) {
			IOManager::getInstance().print_error(IOManager::ECode::E_FAILED_TO_GET_DATA, true, officialTableName, _T(""), _T("Failed to insert new record into database"));
			return IOManager::RCode::R_FAILED_FATAL_ERROR;
		}
		///CAUTION!!! UPDATE NEW RECORDS TO DATABASE
		///CAUTION!!! UPDATE NEW RECORDS TO DATABASE
		if (!AccessSV::getInstance().stopEditTable(workspace, officialTable)) {
			IOManager::getInstance().print_error(IOManager::ECode::E_FAILED_TO_GET_DATA, true, _T("Abort Editing"));
			return IOManager::RCode::R_FAILED_FATAL_ERROR;
		}
		if (IOManager::RCode::R_SUCCESS != cHnp->flushAndStopHnpEdit(workspace)) {
			return IOManager::RCode::R_FAILED_FATAL_ERROR;
		}
	}
	//print total update count
	IOManager::getInstance().print_run(true, true, _T("Successfully updated HNP and OFFICIAL_NAME"));
	CString updateCount = std::to_string(successUpdateCount).c_str();
	IOManager::getInstance().print_run(true, true, _T("Total updated record : ") + updateCount);
	return IOManager::RCode::R_SUCCESS;
}