#pragma once
#include "stdafx.h"
#include "OptionManager.h"
#include <WinLib/VersionInfo.h>
#include <conio.h>



OptionManager::OptionManager() {
	k_db = "input_db";
	k_hnp = "input_hnp_layer";
	k_hnp_entrypoint = "input_hnpentry_layer";
	k_poi_info = "input_poiinfo_layer";
	k_poi_entrypoint = "input_poientry_layer";
	k_poi_asso = "input_poiasso_layer";
	k_official = "input_official_layer";
	k_translation = "input_translation_layer";
	k_sql_poiinfo = "SQL_poiinfo";
	k_sql_poientry = "SQL_poientry";
	k_buffer_size = "buffer_size";
	k_run_log = "run_log";
	k_err_log = "err_log";
}

OptionManager::~OptionManager() {
}


int OptionManager::getOption(const int& argc, _TCHAR* argv[]) {
	using namespace boost::program_options;
	using namespace uh;
	options_description desc("Options");
	try {
		desc.add_options()
			("help,h", "Help screen")
			(k_db, wvalue<std::wstring>(&m_db)->required(), "HNP DB User")
			(k_poi_info, wvalue<std::wstring>(&m_poi_info), "POI_INFO layer name")
			(k_poi_entrypoint, wvalue<std::wstring>(&m_poi_entrypoint), "POI_ENTRYPOINT layer name")
			(k_hnp, wvalue<std::wstring>(&m_hnp), "HNP layer name")
			(k_hnp_entrypoint, wvalue<std::wstring>(&m_hnp_entrypoint), "HNP_ENTRYPOINT layer name")
			(k_poi_asso, wvalue<std::wstring>(&m_poi_asso), "POI_ASSOCIATION layer name")
			(k_official, wvalue<std::wstring>(&m_official), "OFFICIAL_NAME layer name")
			(k_translation, wvalue<std::wstring>(&m_translation), "TRANSLATION layer name")
			(k_sql_poiinfo, wvalue<std::wstring>(&m_sql_poiinfo), "SQL search query for POI_INFO")
			(k_sql_poientry, wvalue<std::wstring>(&m_sql_poientry), "SQL search query for POI_ENTRYPOINT")
			(k_buffer_size, wvalue<std::wstring>(&m_buffer_size), "distance(metre) to detect duplicate POI_INFO")
			(k_run_log, wvalue<std::wstring>(&m_run_log)->required(), "Run log file path")
			(k_err_log, wvalue<std::wstring>(&m_err_log)->required(), "Error log file path");
		//END OF SETTING
		m_vm.clear();
		store(parse_command_line(argc, argv, desc), m_vm);
		notify(m_vm);

	}
	catch (const error &ex)
	{
		std::cerr << ex.what() << std::endl;
		std::cout << desc << std::endl;
		IOManager::getInstance().print_error(IOManager::ECode::E_INVALID_OPTION, true, "INPUT OPTION");
		return IOManager::RCode::R_FAILED_FATAL_ERROR;
	}
	return IOManager::RCode::R_SUCCESS;
}

int OptionManager::presetOption() {
	is_FGDB = false;
	//check if the input is FGDB 
	if (m_db.find(L"@") == std::string::npos  && m_db.find(L".gdb") != std::string::npos) is_FGDB = true;
	//since boost can't define default value for wstring. Define the default value here
	if (m_hnp.empty()) {
		m_hnp = L"HNP";
	}
	if (m_hnp_entrypoint.empty()) {
		m_hnp_entrypoint = L"HNP_ENTRYPOINT";
	}
	if (m_poi_info.empty()) {
		m_poi_info = L"POI_INFO";
	}
	if (m_poi_entrypoint.empty()) {
		m_poi_entrypoint = L"POI_ENTRYPOINT";
	}
	if (m_poi_asso.empty()) {
		m_poi_asso = L"POI_ASSOCIATION";
	}
	if (m_official.empty()) {
		m_official = L"OFFICIAL_NAME";
	}
	if (m_translation.empty()) {
		m_translation = L"TRANSLATION";
	}
	if (m_sql_poiinfo.empty()) {
		m_sql_poiinfo = L"(ACCURACY_C between 1 and 2) and DELETION_C=0 and HOUSENUMBER is not null";
	}
	if (m_sql_poientry.empty()) {
		m_sql_poientry = L"PRIORITY_F = 1 and (ACCURACY_C between 1 and 2)";
	}
	if (m_buffer_size.empty()) {
		m_buffer_size = L"100";
	}
	if (m_err_log.empty()) {
		m_err_log = L"err.log";
	}
	if (m_run_log.empty()) {
		m_run_log = L"run.log";
	}
	return IOManager::RCode::R_SUCCESS;
}

void OptionManager::printDescription() {
	//SETTING HERE
	CVersion cVer;
	CString toolName = cVer.GetInternalName();
	CString fileVersion = cVer.GetFileVersion();
	CString productVersion = cVer.GetProductVersion();
	IOManager::getInstance().print_run(false, true, toolName + " " + fileVersion + " " + productVersion);
	IOManager::getInstance().print_run(false,true, _T("[option]"));
	IOManager::getInstance().print_run(false,true, _T(""));
	print_all_option();
	IOManager::getInstance().print_start();
	//END OF SETTING
}

void OptionManager::print_all_option() {
	using namespace boost::program_options;
	for (const auto& it : m_vm) {
		CString tmpString = _T("--") + (CString)it.first.c_str() + _T(": ");
		auto value = it.second.value();
		if (auto v = boost::any_cast<std::wstring>(&value)) {
			tmpString += v->c_str();
		}
		IOManager::getInstance().print_run(false,true, tmpString);
	}
	IOManager::getInstance().print_run(false,true, "");
}

