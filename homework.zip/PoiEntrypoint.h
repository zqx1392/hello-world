#pragma once

class PoiEntrypoint {
public:

	PoiEntrypoint(const CString& poiEntryFeatureClassName, IFeatureClassPtr& poiEntryFeatureClass);
	~PoiEntrypoint();
	/**
	* @brief start the tool
	* @return	RCode value [ex�FR_SUCCESS=0�AR_FAILED_FATAL_ERROR=1�A...]
	*/
	int getPoiEntrypoint(const CComBSTR & queryFilter, std::set<long> * poiEntrypointList);



private:
	CString poiEntryFeatureClassName;
	IFeatureClassPtr poiEntryFeatureClass;
};

