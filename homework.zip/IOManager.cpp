#pragma once
#include "stdafx.h"
#include "IOManager.h"

IOManager::IOManager(void)
{ 
}

IOManager::~IOManager(void)
{
}

IOManager & IOManager::getInstance() {

	static IOManager instance;
	return instance;
}

void IOManager::initErrorMessage() {
	createEachMessageFormat(E_INVALID_OPTION, _T("OPTION_ERROR"), _T("is incorrect"));
	createEachMessageFormat(E_FAILED_TO_OPEN_FILE_PATH, _T("FILE_ERROR"), _T("filepath cannot be found"));
	createEachMessageFormat(E_FAILED_TO_OPEN_WORKSPACE, _T("DB_ERROR"), _T("DB cannot be opened"));
	createEachMessageFormat(E_FAILED_TO_OPEN_FEATURECLASS, _T("FEATURECLASS_ERROR"), _T("featureclass cannot be opened"));
	createEachMessageFormat(E_FAILED_TO_OPEN_TABLE, _T("TABLE_ERROR"), _T("table cannot be opened"));
	createEachMessageFormat(E_FAILED_TO_OPEN_FIELD, _T("FIELD_ERROR"), _T("field cannot be opened"));
	createEachMessageFormat(E_FAILED_TO_SEARCH, _T("PROCESS_ERROR"), _T("failed to search"));
	createEachMessageFormat(E_FAILED_TO_GET_DATA, _T("PROCESS_ERROR"), _T("cannot be acquired"));
	createEachMessageFormat(E_FAILED_TO_SET_DATA, _T("PROCESS_ERROR"), _T("cannot be set"));
	createEachMessageFormat(E_FAILED_TO_PROCESS, _T("PROCESS_ERROR"), _T("has unexpected error"));
	createEachMessageFormat(E_COM_ERROR_IS_CATCHED, _T("COM_ERROR"), _T("catch _com_error in method"));
}

void IOManager::createEachMessageFormat(const ECode& errorCode, const CString& errorType, const CString& errorDesc) {
	errorMsg tempErrorMessage = { errorCode,errorType,errorDesc };
	m_errorMessageGroup[errorCode] = tempErrorMessage;
}



IOManager::errorMsg IOManager::getErrorMessage(IOManager::ECode errorCode) {
	return m_errorMessageGroup[errorCode];
}


int IOManager::initFile(const CString& filePath, const FileType& fileType) {
	if (!_tcscmp(filePath, _T(""))) {
		CString typeOfFile;
		if (fileType == FileType::ERR) {
			typeOfFile = "ERROR LOG";
		}
		else if (fileType == FileType::RUN) {
			typeOfFile = "RUN LOG";
		}
		else if (fileType == FileType::OUTPUT) {
			typeOfFile = "OUTPUT FILE";
		}
		print_error(ECode::E_FAILED_TO_OPEN_FILE_PATH, true, typeOfFile, "", "File path is empty");
		return RCode::R_FAILED_FATAL_ERROR;
	}
	if (fileType == FileType::ERR) {
		m_errLog.open(filePath, std::ios_base::app);
		if (!m_errLog.is_open()) {
			print_error(ECode::E_FAILED_TO_OPEN_FILE_PATH, true, filePath);
			return RCode::R_FAILED_FATAL_ERROR;
		}
		m_errLog.seekg(0, m_errLog.end);
		//If error log is empty, add error header to the log
		if (!m_errLog.tellg()) {
			m_errLog << "TIME" << "\t" << "ERROR_TYPE" << "\t" << "ERROR_CODE" << "\t" << "ERROR_DESC1" << "\t" << "ERROR_DESC2" << "\t" << "ERROR_DESC3" << std::endl;
		}
		m_errLog.seekg(0, m_errLog.beg);
	}
	else if (fileType == FileType::RUN) {
		m_runLog.open(filePath, std::ios_base::app);
		if (!m_runLog.is_open()) {
			print_error(ECode::E_FAILED_TO_OPEN_FILE_PATH, true, filePath);
			return RCode::R_FAILED_FATAL_ERROR;
		}
	}
	//TODO make map that support multiple output file
	/*else if (fileType == FileType::OUTPUT) {
		m_outputFile.open(filePath);
		if (!m_outputFile.is_open()) {
			print_error(ECode::E_FAILED_TO_OPEN_FILE_PATH, true, filePath);
			return RCode::R_FAILED_FATAL_ERROR;
		}
	}*/
	else {
		return RCode::R_FAILED_FATAL_ERROR;
	}
	return RCode::R_SUCCESS;
}

void IOManager::closeFile() {
	if (m_runLog.is_open()) {
		m_runLog.close();
	}
	if (m_errLog.is_open()) {
		m_errLog.close();
	}
	/*if (m_outputFile.is_open()) {
		m_outputFile.close();
	}*/
}

void IOManager::print_error(const IOManager::ECode& errorCode, const bool& isPrintCerr, const CString& errorDesc1, const CString& errorDesc2, const CString& errorDesc3) {
	CString errMsg = errorDesc1 + "\t" + errorDesc2;
	if (errorDesc3.Compare(_T("")) != 0) {
		errMsg += "\t" + errorDesc3;
	}
	if (m_errLog.is_open()) {
		time_t rawtime;
		char buffer[80];
		time(&rawtime);
		struct tm * timeinfo = localtime(&rawtime);
		strftime(buffer, 80, "%Y-%m-%d %I:%M:%S", timeinfo);
		CString currentTime(buffer);
		CString errorType = getErrorMessage(errorCode).errorType;
		m_errLog << CT2A(currentTime) << "\t" << CT2A(errorType) << "\t" << errorCode << "\t" << CT2CA(errMsg) << std::endl;
	}
	if (isPrintCerr) {
		std::cerr << CT2CA(errMsg) << std::endl;
	}
}

void IOManager::print_run(const bool& isTimeStamp, const bool& isPrintCout, const CString& runMsg1, const CString& runMsg2, const CString& runMsg3) {
	CString currentTime = _T("");
	if (isTimeStamp) {
		time_t rawtime;
		char buffer[80];
		time(&rawtime);
		struct tm * timeinfo = localtime(&rawtime);
		strftime(buffer, 80, "%Y-%m-%d %I:%M:%S", timeinfo);
		CString currentTime(buffer);
		currentTime += "\t";
	}
	if (m_runLog.is_open()) {
		m_runLog << CT2A(currentTime) << CT2A(runMsg1) << "\t" << CT2A(runMsg2) << "\t" << CT2A(runMsg3) << std::endl;
	}

	if (isPrintCout) {
		if (isTimeStamp) {
			currentTime.Delete(currentTime.GetLength() - 1);
			currentTime += " ";
		}
		std::cout << CT2A(currentTime) << CT2A(runMsg1) << " " << CT2A(runMsg2) << " " << CT2A(runMsg3) << std::endl;
	}
}

void IOManager::print_start() {
	char buffer[80];
	time(&m_start_time);
	struct tm * timeinfo = localtime(&m_start_time);
	strftime(buffer, 80, "%Y-%m-%d %I:%M:%S", timeinfo);
	CString startTime(buffer);
	m_runLog << "Start: " << CT2A(startTime) << std::endl << std::endl;
	std::cout << "Start: " << CT2A(startTime) << std::endl << std::endl;
}

int IOManager::printSuccessfulEnd() {
	print_run(true, true, _T("Program ends successfully"));
	print_run(false, true, _T(""));
	double total_time;
	time_t end_time;
	time(&end_time);
	total_time = difftime(end_time, m_start_time);
	m_runLog << "Total execution time: " << total_time << "s" << std::endl;
	std::cout << "Total execution time: " << total_time << "s" << std::endl;
	closeFile();
	return RCode::R_SUCCESS;
}

int IOManager::endProgramWithError(const CString& errorPoint) {
	CString errorDesc = _T("An error occured during ") + errorPoint;
	print_run(true, true, errorDesc);
	CString errorType;
	if (!_tcscmp(errorPoint, _T("Com Error"))) {
		errorType = _T("Exception Error");
	}
	else {
		errorType = _T("Unsuccessful Termination");
	}
	print_run(false, true, errorType);
	print_run(false, true, "");
	closeFile();
	return RCode::R_FAILED_FATAL_ERROR;
}
