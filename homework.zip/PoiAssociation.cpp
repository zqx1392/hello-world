

#include "stdafx.h"
#include "PoiAssociation.h"

using namespace sindy::schema::global;

PoiAssociation::PoiAssociation(const CString& poiAssoTableName, ITablePtr& poiAssoTable) {
	this->poiAssoTableName = poiAssoTableName;
	this->poiAssoTable = poiAssoTable;
}

PoiAssociation::~PoiAssociation() {
}

int PoiAssociation::getChildPOI(std::set<long> * childPOIList) {

	//create condition to get only childID column
	IQueryFilterPtr PoiAssoIpQueryFilter(CLSID_QueryFilter);
	CString columnFilter;
	columnFilter.Format(_T("%s,%s"), poi_association::kObjectID, poi_association::kChildID);
	if (S_OK != PoiAssoIpQueryFilter->put_SubFields((CComBSTR)columnFilter)) {
		IOManager::getInstance().print_error(IOManager::ECode::E_FAILED_TO_SET_DATA, true, poiAssoTableName, _T(""), _T("Failed to set search column for CHILDID column"));
		return IOManager::RCode::R_FAILED_FATAL_ERROR;
	}
	//set all condition into query variable
	_ICursorPtr ipPoiAssoCursor;

	if (S_OK != poiAssoTable->Search(PoiAssoIpQueryFilter, VARIANT_FALSE, &ipPoiAssoCursor)) {
		IOManager::getInstance().print_error(IOManager::ECode::E_FAILED_TO_GET_DATA, true, poiAssoTableName, _T(""), _T("Failed to get all records"));
		return IOManager::RCode::R_FAILED_FATAL_ERROR;
	}
	// get column index for child id
	long childIDIndex = 0;
	if (S_OK != ipPoiAssoCursor->Fields->FindField((CComBSTR)poi_association::kChildID, &childIDIndex)) {
		IOManager::getInstance().print_error(IOManager::ECode::E_FAILED_TO_GET_DATA, true, poiAssoTableName, _T("FIELD INDEX"), _T("Failed to get CHILDID field index"));
		return IOManager::RCode::R_FAILED_FATAL_ERROR;
	}

	//set to store childID list
	//get target postal code
	_IRowPtr ipPoiAssoRow;
	while (ipPoiAssoCursor->NextRow(&ipPoiAssoRow) == S_OK && ipPoiAssoRow) {
		// get postal point OID
		long OIDNum;
		if (S_OK != ipPoiAssoRow->get_OID(&OIDNum)) {
			IOManager::getInstance().print_error(IOManager::ECode::E_FAILED_TO_GET_DATA, true, poiAssoTableName, _T(""), _T("Failed to get OBJECTID of one ") + poiAssoTableName);
			return IOManager::RCode::R_FAILED_FATAL_ERROR;
		}
		//convert OID from long to CString
		CString OID;
		OID.Format(L"%ld", OIDNum);
		// get child id data
		CComVariant childID;
		if (S_OK != ipPoiAssoRow->get_Value(childIDIndex, &childID)) {
			IOManager::getInstance().print_error(IOManager::ECode::E_FAILED_TO_GET_DATA, true, poiAssoTableName + _T(" OBJECTID"), OID, _T("Failed to get CHILDID value"));
			return IOManager::RCode::R_FAILED_FATAL_ERROR;
		}
		childPOIList->insert(childID.intVal);
	}
	return IOManager::RCode::R_SUCCESS;
}