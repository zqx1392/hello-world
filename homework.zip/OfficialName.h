#pragma once

class OfficialName {
public:

	OfficialName(const CString& officialTableName, ITablePtr& officialTable, Hnp * cHnp);
	~OfficialName();
	/**
	* @brief start the tool
	* @return	RCode value [ex�FR_SUCCESS=0�AR_FAILED_FATAL_ERROR=1�A...]
	*/
	int getOfficalName(std::map<long, CString> * officialNameList);
	/**
	* @brief start the tool
	* @return	RCode value [ex�FR_SUCCESS=0�AR_FAILED_FATAL_ERROR=1�A...]
	*/
	int insertNewRecordToHNPAndOfficial(IWorkspacePtr& workspace, std::vector<CommonData::poiInfo> * uniquePoiInfoList, std::map<long, long> * updatedPoiHnpList, std::map<long, long> * translationList);


private:
	CString officialTableName;
	ITablePtr officialTable;
	Hnp * cHnp;
};
