#include "stdafx.h"
#include "PoiEntrypoint.h"

using namespace sindy::schema::global;

PoiEntrypoint::PoiEntrypoint(const CString& poiEntryFeatureClassName, IFeatureClassPtr& poiEntryFeatureClass) {
	this->poiEntryFeatureClassName = poiEntryFeatureClassName;
	this->poiEntryFeatureClass = poiEntryFeatureClass;
}

PoiEntrypoint::~PoiEntrypoint() {
}

int PoiEntrypoint::getPoiEntrypoint(const CComBSTR & queryFilter, std::set<long> * poiEntrypointList) {

	//create condition to get only childID column
	IQueryFilterPtr poiEntryIpQueryFilter(CLSID_QueryFilter);
	CString columnFilter;
	columnFilter.Format(_T("%s,%s"), poi_entry_point::kObjectID, poi_entry_point::kPoiInfoID);
	if (S_OK != poiEntryIpQueryFilter->put_SubFields((CComBSTR)columnFilter)) {
		IOManager::getInstance().print_error(IOManager::ECode::E_FAILED_TO_SET_DATA, true, poiEntryFeatureClassName, _T(""), _T("Failed to set search column for POIINFOID column"));
		return IOManager::RCode::R_FAILED_FATAL_ERROR;
	}
	//set all condition into query variable
	if (S_OK != poiEntryIpQueryFilter->put_WhereClause(queryFilter)) {
		IOManager::getInstance().print_error(IOManager::ECode::E_FAILED_TO_SET_DATA, true, poiEntryFeatureClassName, _T(""), _T("Failed to set search query"));
		return IOManager::RCode::R_FAILED_FATAL_ERROR;
	}

	IFeatureCursorPtr poiEntrypointCursor;

	if (S_OK != poiEntryFeatureClass->Search(poiEntryIpQueryFilter, VARIANT_FALSE, &poiEntrypointCursor)) {
		IOManager::getInstance().print_error(IOManager::ECode::E_FAILED_TO_GET_DATA, true, poiEntryFeatureClassName, _T(""), _T("Failed to get all records"));
		return IOManager::RCode::R_FAILED_FATAL_ERROR;
	}
	// get column index for child id
	long poiInfoIDIndex = 0;
	if (S_OK != poiEntrypointCursor->Fields->FindField((CComBSTR)poi_entry_point::kPoiInfoID, &poiInfoIDIndex)) {
		IOManager::getInstance().print_error(IOManager::ECode::E_FAILED_TO_GET_DATA, true, poiEntryFeatureClassName, _T("FIELD INDEX"), _T("Failed to get POIINFOID field index"));
		return IOManager::RCode::R_FAILED_FATAL_ERROR;
	}

	//set to store childID list
	//get target postal code
	IFeaturePtr ipPoiEntryFeature;
	while (poiEntrypointCursor->NextFeature(&ipPoiEntryFeature) == S_OK && ipPoiEntryFeature) {
		// get postal point OID
		long OIDNum;
		if (S_OK != ipPoiEntryFeature->get_OID(&OIDNum)) {
			IOManager::getInstance().print_error(IOManager::ECode::E_FAILED_TO_GET_DATA, true, poiEntryFeatureClassName, _T(""), _T("Failed to get OBJECTID of one ") + poiEntryFeatureClassName);
			return IOManager::RCode::R_FAILED_FATAL_ERROR;
		}
		//convert OID from long to CString
		CString OID;
		OID.Format(L"%ld", OIDNum);
		// get child id data
		CComVariant poiInfoID;
		if (S_OK != ipPoiEntryFeature->get_Value(poiInfoIDIndex, &poiInfoID)) {
			IOManager::getInstance().print_error(IOManager::ECode::E_FAILED_TO_GET_DATA, true, poiEntryFeatureClassName + _T(" OBJECTID"), OID, _T("Failed to get POIINFOID value"));
			return IOManager::RCode::R_FAILED_FATAL_ERROR;
		}
		poiEntrypointList->insert(poiInfoID.intVal);
	}
	return IOManager::RCode::R_SUCCESS;
}