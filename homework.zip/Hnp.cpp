#include "stdafx.h"
#include "Hnp.h"


using namespace sindy::schema::global;

Hnp::Hnp(const CString& HnpFeatureClassName, IFeatureClassPtr& HnpFeatureClass) {
	this->HnpFeatureClassName = HnpFeatureClassName;
	this->HnpFeatureClass = HnpFeatureClass;
	//get field index value
	AccessSV::getInstance().getFeatureClassColumnIndex(HnpFeatureClass, hnp::kOperator, &m_operatorIndex);
	AccessSV::getInstance().getFeatureClassColumnIndex(HnpFeatureClass, hnp::kPurpose, &m_purposeCIndex);
	AccessSV::getInstance().getFeatureClassColumnIndex(HnpFeatureClass, hnp::kModifyDate, &m_modifyDateIndex);
	AccessSV::getInstance().getFeatureClassColumnIndex(HnpFeatureClass, hnp::kUpdateType, &m_updateTypeCIndex);
	AccessSV::getInstance().getFeatureClassColumnIndex(HnpFeatureClass, hnp::kProgModifyDate, &m_progModifyDateIndex);
	AccessSV::getInstance().getFeatureClassColumnIndex(HnpFeatureClass, hnp::kModifyProgName, &m_modifyProgNameIndex);
	AccessSV::getInstance().getFeatureClassColumnIndex(HnpFeatureClass, hnp::kUserClaim, &m_userClaimFIndex);
	AccessSV::getInstance().getFeatureClassColumnIndex(HnpFeatureClass, hnp::kSource, &m_sourceIndex);
	AccessSV::getInstance().getFeatureClassColumnIndex(HnpFeatureClass, hnp::kHn, &m_HNIndex);
	AccessSV::getInstance().getFeatureClassColumnIndex(HnpFeatureClass, hnp::kHnType, &m_HNTypeIndex);
	AccessSV::getInstance().getFeatureClassColumnIndex(HnpFeatureClass, hnp::kLinkID, &m_linkIDIndex);
	AccessSV::getInstance().getFeatureClassColumnIndex(HnpFeatureClass, hnp::kRoadNameID, &m_roadNameIDIndex);
}

Hnp::~Hnp() {
}

int Hnp::insertNewRecordToHNP(IWorkspacePtr& workspace, std::vector<CommonData::poiInfo> * uniquePoiInfoList, std::map<long, long> * updatedPoiHnpList) {

	long successUpdateCount = 0;	//count total successfully update records

	if (IOManager::RCode::R_SUCCESS != createNewBuffer()) {
		return IOManager::RCode::R_FAILED_FATAL_ERROR;
	}
	
	//update HNP with POI_INFO where ROADNAMEID = NULL
	for (int i = 0; i<uniquePoiInfoList->size(); i++) {
		//skip not null ROADNAMEID
		if (uniquePoiInfoList->operator[](i).roadNameID != 0) {
			continue;
		}
		//start editing (restart every 10000 records to flush records in memory)
		if (successUpdateCount % 10000 == 0) {
			if (IOManager::RCode::R_SUCCESS != startAndInsertHnpCursor(workspace)) {
				return IOManager::RCode::R_FAILED_FATAL_ERROR;
			}
		}

		double x = uniquePoiInfoList->operator[](i).x;
		double y = uniquePoiInfoList->operator[](i).y;
		long poiInfoObjectID = uniquePoiInfoList->operator[](i).OBJECTID;
		CString hn = uniquePoiInfoList->operator[](i).houseNumber;
		if (IOManager::RCode::R_SUCCESS != putValueIntoFields(poiInfoObjectID, hn, 0, x, y)) {
			return IOManager::RCode::R_FAILED_FATAL_ERROR;
		}

		CComVariant newHnpOID;
		if (IOManager::RCode::R_SUCCESS != insertNewFeature(&newHnpOID)) {
			return IOManager::RCode::R_FAILED_FATAL_ERROR;
		}
		

		//insert into updatedPoiHnpList map to create new records on HNP_ENTRYPOINT later
		if (!updatedPoiHnpList->insert(std::make_pair(uniquePoiInfoList->operator[](i).OBJECTID, newHnpOID.intVal)).second) {
			IOManager::getInstance().print_error(IOManager::ECode::E_FAILED_TO_PROCESS, true, _T("Unexpected error occured while creating updatedPoiHnpList variable"));
			return IOManager::RCode::R_FAILED_FATAL_ERROR;
		}
		
		successUpdateCount++;

		//flush to database every 10000 new records
		if (successUpdateCount % 10000 == 0 && successUpdateCount > 0) {
			if (IOManager::RCode::R_SUCCESS != flushAndStopHnpEdit(workspace)) {
				return IOManager::RCode::R_FAILED_FATAL_ERROR;
			}
		}
	}
	//flush last group of new records
	if (successUpdateCount % 10000 != 0 || successUpdateCount == 0) {
		if (IOManager::RCode::R_SUCCESS != flushAndStopHnpEdit(workspace)) {
			return IOManager::RCode::R_FAILED_FATAL_ERROR;
		}
	}

	//print total update count
	IOManager::getInstance().print_run(true, true, _T("Successfully updated HNP where ROADNAMEID is NULL"));
	CString updateCount = std::to_string(successUpdateCount).c_str();
	IOManager::getInstance().print_run(true, true, _T("Total updated record : ") + updateCount);
	return IOManager::RCode::R_SUCCESS;
}

int Hnp::createNewBuffer() {
	if (S_OK != HnpFeatureClass->CreateFeatureBuffer(&featureBuffer)) {
		IOManager::getInstance().print_error(IOManager::ECode::E_FAILED_TO_GET_DATA, true, HnpFeatureClassName, _T(""), _T("Failed to create buffer"));
		return IOManager::RCode::R_FAILED_FATAL_ERROR;
	}
	return IOManager::RCode::R_SUCCESS;
}

int Hnp::putValueIntoFields(const long& poiInfoObjectID, const CString& hn, const long& roadNameID, const double& x, const double& y) {
	//create new HNP record
	int returnStatus = 0;
	returnStatus += AccessSV::getInstance().putFeatureClassColumnValue(HnpFeatureClassName, featureBuffer, m_operatorIndex, CComVariant(CommonData::getInstance().getOperator()));
	returnStatus += AccessSV::getInstance().putFeatureClassColumnValue(HnpFeatureClassName, featureBuffer, m_purposeCIndex, CComVariant(CommonData::getInstance().getPurpose()));
	returnStatus += AccessSV::getInstance().putFeatureClassColumnValue(HnpFeatureClassName, featureBuffer, m_updateTypeCIndex, CComVariant(CommonData::getInstance().getUpdateType()));
	returnStatus += AccessSV::getInstance().putFeatureClassColumnValue(HnpFeatureClassName, featureBuffer, m_progModifyDateIndex, CComVariant(CommonData::getInstance().getCurrentDateTime()));
	returnStatus += AccessSV::getInstance().putFeatureClassColumnValue(HnpFeatureClassName, featureBuffer, m_modifyProgNameIndex, CComVariant(CommonData::getInstance().getModifyProgName()));
	returnStatus += AccessSV::getInstance().putFeatureClassColumnValue(HnpFeatureClassName, featureBuffer, m_userClaimFIndex, CComVariant(CommonData::getInstance().getUserClaim()));
	//set message for source column
	CString objectID = _T("POI_INFO OBJECTID: ");
	objectID += std::to_string(poiInfoObjectID).c_str();
	returnStatus += AccessSV::getInstance().putFeatureClassColumnValue(HnpFeatureClassName, featureBuffer, m_sourceIndex, CComVariant(objectID));
	returnStatus += AccessSV::getInstance().putFeatureClassColumnValue(HnpFeatureClassName, featureBuffer, m_HNIndex, CComVariant(hn));
	returnStatus += AccessSV::getInstance().putFeatureClassColumnValue(HnpFeatureClassName, featureBuffer, m_HNTypeIndex, CComVariant(CommonData::getInstance().getHNType()));
	returnStatus += AccessSV::getInstance().putFeatureClassColumnValue(HnpFeatureClassName, featureBuffer, m_linkIDIndex, CComVariant(CommonData::getInstance().getLinkID()));
	returnStatus += AccessSV::getInstance().putFeatureClassColumnValue(HnpFeatureClassName, featureBuffer, m_roadNameIDIndex, CComVariant(roadNameID));
	if (returnStatus != IOManager::RCode::R_SUCCESS) {
		return IOManager::RCode::R_FAILED_FATAL_ERROR;
	}
	//set new coordinates to base shape
	IGeometryPtr ipGeom = CommonData::getInstance().getExamplePointShape();
	if (S_OK != IPointPtr(ipGeom)->PutCoords(x, y)) {
		IOManager::getInstance().print_error(IOManager::ECode::E_FAILED_TO_SET_DATA, true, HnpFeatureClassName, _T(""), _T("Failed to set coordinates for a new HNP record"));
		return IOManager::RCode::R_FAILED_FATAL_ERROR;
	}

	//add edited shape to this new record
	if (S_OK != featureBuffer->putref_Shape(ipGeom)) {
		IOManager::getInstance().print_error(IOManager::ECode::E_FAILED_TO_SET_DATA, true, HnpFeatureClassName, _T(""), _T("Failed to input new shape"));
		return IOManager::RCode::R_FAILED_FATAL_ERROR;
	}
	return IOManager::RCode::R_SUCCESS;
}

int Hnp::insertNewFeature(CComVariant * newHnpOID) {
	if (S_OK != insertHnpCursor->InsertFeature(featureBuffer, newHnpOID)) {
		IOManager::getInstance().print_error(IOManager::ECode::E_FAILED_TO_SET_DATA, true, HnpFeatureClassName, _T(""), _T("Failed to insert new record into cursor"));
		return IOManager::RCode::R_FAILED_FATAL_ERROR;
	}
	IOManager::getInstance().print_run(false, HnpFeatureClassName + _T(" OBJECTID"), *newHnpOID, _T("Record has been created successfully"));
	return IOManager::RCode::R_SUCCESS;
}

int Hnp::startAndInsertHnpCursor(IWorkspacePtr& workspace) {
	if (!AccessSV::getInstance().startEditFeatureClass(workspace, HnpFeatureClass)) {
		IOManager::getInstance().print_error(IOManager::ECode::E_FAILED_TO_GET_DATA, true, HnpFeatureClassName, _T(""), _T("Start Editing"));
		return IOManager::RCode::R_FAILED_FATAL_ERROR;
	}
	//insert cursor for creating records
	if (S_OK != HnpFeatureClass->Insert(VARIANT_TRUE, &insertHnpCursor)) {
		IOManager::getInstance().print_error(IOManager::ECode::E_FAILED_TO_GET_DATA, true, HnpFeatureClassName, _T(""), _T("Create new cursor for new records"));
		return IOManager::RCode::R_FAILED_FATAL_ERROR;
	}
	return IOManager::RCode::R_SUCCESS;
}

int Hnp::flushAndStopHnpEdit(IWorkspacePtr& workspace) {
	///CAUTION!!! UPDATE NEW RECORDS TO DATABASE
	///CAUTION!!! UPDATE NEW RECORDS TO DATABASE
	if (S_OK != insertHnpCursor->Flush()) {
		IOManager::getInstance().print_error(IOManager::ECode::E_FAILED_TO_GET_DATA, true, HnpFeatureClassName, _T(""), _T("Failed to insert new record into database"));
		return IOManager::RCode::R_FAILED_FATAL_ERROR;
	}
	///CAUTION!!! UPDATE NEW RECORDS TO DATABASE
	///CAUTION!!! UPDATE NEW RECORDS TO DATABASE
	if (!AccessSV::getInstance().stopEditFeatureClass(workspace, HnpFeatureClass)) {
		IOManager::getInstance().print_error(IOManager::ECode::E_FAILED_TO_GET_DATA, true, _T("Abort Editing"));
		return IOManager::RCode::R_FAILED_FATAL_ERROR;
	}
	return IOManager::RCode::R_SUCCESS;
}