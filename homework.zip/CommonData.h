#pragma once

/**
* @brief Manage server connection and ARCGIS-related function.
*/
class CommonData
{
public:
	/* static access method */
	static CommonData & getInstance();

	~CommonData();

	//Structure for POI_INFO
	struct poiInfo {
		poiInfo() :OBJECTID(-1), houseNumber(_T("")), actualAddress(_T("")), roadNameID(-1), x(-1), y(-1) {}
		poiInfo(long OBJECTID, CString houseNumber, CString actualAddress, long roadNameID, double x, double y) :
			OBJECTID(OBJECTID),
			houseNumber(houseNumber),
			actualAddress(actualAddress),
			roadNameID(roadNameID),
			x(x),
			y(y) {}
		long OBJECTID;
		CString houseNumber;
		CString actualAddress;
		long roadNameID;
		double x;
		double y;
	};

	CString getOperator();
	int getPurpose();
	int getUpdateType();
	CString getModifyProgName();
	int getUserClaim();
	int getHNType();
	int getLinkID();
	int getHnpLayerC();
	double getCurrentDateTime();

	IGeometryPtr& getExamplePointShape();

	int setExamplePointShape(IGeometryPtr& ipGeom);


private:
	CommonData(CommonData const&);
	CommonData();
	IGeometryPtr ipGeom;
	//constant value for new record field value
	CString m_operator;
	int m_purpose;
	int m_updateType;
	CString m_modifyProgName;
	int m_userClaim;
	int m_hntype;
	int m_linkID;
	int m_HNP_layerC;
};