#pragma once
#include "stdafx.h"
#include "CommonData.h"
#include <ATLComTime.h>

CommonData::CommonData(void)
{
	//set const value
	m_operator = _T("sindy");
	m_purpose = 0;
	m_updateType = 6;
	m_modifyProgName = _T("PoiInfoToHNPUpdater.exe");
	m_userClaim = 0;
	m_hntype = 0;
	m_linkID = 0;
	m_HNP_layerC = 34;
}

CommonData::~CommonData(void)
{
}

CommonData & CommonData::getInstance() {

	static CommonData instance;
	return instance;
}

CString CommonData::getOperator() {
	return m_operator;
}
int CommonData::getPurpose() {
	return m_purpose;
}
int CommonData::getUpdateType(){
	return m_updateType;
}
CString CommonData::getModifyProgName() {
	return m_modifyProgName;
}
int CommonData::getUserClaim() {
	return m_userClaim;
}
int CommonData::getHNType() {
	return m_hntype;
}
int CommonData::getLinkID() {
	return m_linkID;
}
int CommonData::getHnpLayerC() {
	return m_HNP_layerC;
}
double CommonData::getCurrentDateTime() {
	COleDateTime date = COleDateTime::GetCurrentTime();
	return date.m_dt;
}

IGeometryPtr& CommonData::getExamplePointShape() {
	return ipGeom;
}

int CommonData::setExamplePointShape(IGeometryPtr& ipGeom) {
	this->ipGeom = ipGeom;
}

