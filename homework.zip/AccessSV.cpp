#pragma once
#include "stdafx.h"
#include "AccessSV.h"

AccessSV::AccessSV(void)
{
}

AccessSV::~AccessSV(void)
{
}

AccessSV & AccessSV::getInstance() {

	static AccessSV instance;
	return instance;
}

int AccessSV::getWorkspace(const CString& workspaceName, IWorkspacePtr & workspace){
	workspace = sindy::create_workspace(workspaceName);
	if (workspace == NULL){
		return 1;
	}
	return 0;
}

int AccessSV::getFeatureClass (const CString& workspaceName, const CString& featureClassName, IFeatureClassPtr & featureClass){
	IWorkspacePtr targetWorkspace; 
	if (1 == getWorkspace(workspaceName, targetWorkspace)) {
		return 1;
	}
	if (S_OK != IFeatureWorkspacePtr(targetWorkspace)->OpenFeatureClass(featureClassName.AllocSysString(), &featureClass)){
		return 1;
	}
	return 0;
}

int AccessSV::getTable(const CString& workspaceName, const CString& tableName, ITablePtr & table) {
	IWorkspacePtr targetWorkspace;
	if (1 == getWorkspace(workspaceName, targetWorkspace)) {
		return 1;
	}
	if (S_OK != IFeatureWorkspacePtr(targetWorkspace)->OpenTable(tableName.AllocSysString(), &table)) {
		return 1;
	}
	return 0;
}


int AccessSV::getField(const CString& workspaceName, const CString& datasetName, const CString& fieldName, const bool& isTable, IFieldPtr & field) {
	long fieldIndex;
	if (isTable) {
		ITablePtr targetTable;
		if (1 == getTable(workspaceName, datasetName, targetTable)) {
			return 1;
		}
		targetTable->FindField(fieldName.AllocSysString(), &fieldIndex);
		if (S_OK != targetTable->GetFields()->get_Field(fieldIndex, &field)) {
			return 1;
		}
	}
	else {
		IFeatureClassPtr targetFeatureClass; 
		if (1 == getFeatureClass(workspaceName, datasetName, targetFeatureClass)) {
			return 1;
		}
		targetFeatureClass->FindField(fieldName.AllocSysString(), &fieldIndex);
		if (S_OK != targetFeatureClass->GetFields()->get_Field(fieldIndex, &field)) {
			return 1;
		}
	}
	return 0;
}

int AccessSV::getFeatureClassColumnIndex(const IFeatureClassPtr& ipFeatureClass, const CComBSTR& fieldName, long * index) {
	if (S_OK != ipFeatureClass->FindField(fieldName, index)) {
		IOManager::getInstance().print_error(IOManager::ECode::E_FAILED_TO_GET_DATA, true, (LPCTSTR)fieldName, _T("FIELD INDEX"), _T("Failed to get field index"));
		return IOManager::RCode::R_FAILED_FATAL_ERROR;
	}
	return IOManager::RCode::R_SUCCESS;
}

int AccessSV::getTableColumnIndex(const ITablePtr& ipTable, const CComBSTR& fieldName, long * index) {
	if (S_OK != ipTable->FindField(fieldName, index)) {
		IOManager::getInstance().print_error(IOManager::ECode::E_FAILED_TO_GET_DATA, true, (LPCTSTR)fieldName, _T("FIELD INDEX"), _T("Failed to get field index"));
		return IOManager::RCode::R_FAILED_FATAL_ERROR;
	}
	return IOManager::RCode::R_SUCCESS;
}

int AccessSV::putFeatureClassColumnValue(const CString& featureClassName, IFeatureBufferPtr featureBuffer, const long& index, CComVariant value) {
	if (S_OK != featureBuffer->put_Value(index, value)) {
		IOManager::getInstance().print_error(IOManager::ECode::E_FAILED_TO_GET_DATA, true, featureClassName, _T(""), _T("Set new field values"));
		return IOManager::RCode::R_FAILED_FATAL_ERROR;
	}
	return IOManager::RCode::R_SUCCESS;
}

int AccessSV::putTableColumnValue(const CString& tableName, IRowBufferPtr rowBuffer, const long& index, CComVariant value) {
	if (S_OK != rowBuffer->put_Value(index, value)) {
		IOManager::getInstance().print_error(IOManager::ECode::E_FAILED_TO_GET_DATA, true, tableName, _T(""), _T("Set new field values"));
		return IOManager::RCode::R_FAILED_FATAL_ERROR;
	}
	return IOManager::RCode::R_SUCCESS;
}

bool AccessSV::isVersionedFeatureClass(IFeatureClassPtr& ipFeatureClass)
{
	VARIANT_BOOL vbIsVersioned = VARIANT_FALSE;
	IVersionedObjectPtr(ipFeatureClass)->get_IsRegisteredAsVersioned(&vbIsVersioned);
	return vbIsVersioned ? true : false;
}
bool AccessSV::isVersionedTable(ITablePtr& ipTable)
{
	VARIANT_BOOL vbIsVersioned = VARIANT_FALSE;
	IVersionedObjectPtr(ipTable)->get_IsRegisteredAsVersioned(&vbIsVersioned);
	return vbIsVersioned ? true : false;
}

bool AccessSV::startEditFeatureClass(IWorkspacePtr& workspace, IFeatureClassPtr& ipFeatureClass)
{
	IMultiuserWorkspaceEditPtr ipMultiuserWorkspace(workspace);
	if (ipMultiuserWorkspace)
	{
		// �Ԑ������N�̃o�[�W�����Ή����\�Ƃ��Č��Ă���
		esriMultiuserEditSessionMode mode = isVersionedFeatureClass(ipFeatureClass) ? esriMESMVersioned : esriMESMNonVersioned;
		if (FAILED(ipMultiuserWorkspace->StartMultiuserEditing(mode)))
		{
			IOManager::getInstance().print_error(IOManager::ECode::E_FAILED_TO_PROCESS, true, _T("EDITING"), _T(""), _T("Failed to start database editing for MultiUserWorkspace"));
			return false;
		}
		if (mode == esriMESMVersioned)
		{
			if (FAILED(IWorkspaceEditPtr(workspace)->StartEditOperation()))
			{
				CString errorMsg = _T("Start editing");
				IOManager::getInstance().print_error(IOManager::ECode::E_FAILED_TO_PROCESS, true, _T("EDITING"), _T(""), _T("Failed to start database editing for esriMESMVersioned"));
				return false;
			}
		}
	}
	else
	{
		if (FAILED(IWorkspaceEditPtr(workspace)->StartEditing(VARIANT_FALSE)))
		{
			CString errorMsg = _T("Start editing");
			IOManager::getInstance().print_error(IOManager::ECode::E_FAILED_TO_PROCESS, true, _T("EDITING"), _T(""), _T("Failed to start database editing"));
			return false;
		}
	}
	return true;
}
bool AccessSV::startEditTable(IWorkspacePtr& workspace, ITablePtr& ipTable)
{

	IMultiuserWorkspaceEditPtr ipMultiuserWorkspace(workspace);
	if (ipMultiuserWorkspace)
	{
		// �Ԑ������N�̃o�[�W�����Ή����\�Ƃ��Č��Ă���
		esriMultiuserEditSessionMode mode = isVersionedTable(ipTable) ? esriMESMVersioned : esriMESMNonVersioned;
		if (FAILED(ipMultiuserWorkspace->StartMultiuserEditing(mode)))
		{
			IOManager::getInstance().print_error(IOManager::ECode::E_FAILED_TO_PROCESS, true, _T("EDITING"), _T(""), _T("Failed to start database editing for MultiUserWorkspace"));
			return false;
		}
		if (mode == esriMESMVersioned)
		{
			if (FAILED(IWorkspaceEditPtr(workspace)->StartEditOperation()))
			{
				CString errorMsg = _T("Start editing");
				IOManager::getInstance().print_error(IOManager::ECode::E_FAILED_TO_PROCESS, true, _T("EDITING"), _T(""), _T("Failed to start database editing for esriMESMVersioned"));
				return false;
			}
		}
	}
	else
	{
		if (FAILED(IWorkspaceEditPtr(workspace)->StartEditing(VARIANT_FALSE)))
		{
			CString errorMsg = _T("Start editing");
			IOManager::getInstance().print_error(IOManager::ECode::E_FAILED_TO_PROCESS, true, _T("EDITING"), _T(""), _T("Failed to start database editing"));
			return false;
		}
	}
	return true;
}

bool AccessSV::stopEditFeatureClass(IWorkspacePtr& workspace, IFeatureClassPtr& ipFeatureClass)
{

	IMultiuserWorkspaceEditPtr ipMultiuserWorkspace(workspace);
	if (ipMultiuserWorkspace && isVersionedFeatureClass(ipFeatureClass))
	{
		if (FAILED(IWorkspaceEditPtr(workspace)->StopEditOperation()))
		{
			CString errorMsg = _T("Stop editing");
			IOManager::getInstance().print_error(IOManager::ECode::E_FAILED_TO_PROCESS, true, _T("EDITING"), _T(""), _T("Failed to stop database editing for MultiUserWorkspace"));
			abortEdit(workspace);
			return false;
		}
	}
	if (FAILED(IWorkspaceEditPtr(workspace)->StopEditing(VARIANT_TRUE)))
	{
		CString errorMsg = _T("Stop editing");
		IOManager::getInstance().print_error(IOManager::ECode::E_FAILED_TO_PROCESS, true, _T("EDITING"), _T(""), _T("Failed to stop database editing"));
		abortEdit(workspace);
		return false;
	}
	return true;
}
bool AccessSV::stopEditTable(IWorkspacePtr& workspace, ITablePtr& ipTable)
{

	IMultiuserWorkspaceEditPtr ipMultiuserWorkspace(workspace);
	if (ipMultiuserWorkspace && isVersionedTable(ipTable))
	{
		if (FAILED(IWorkspaceEditPtr(workspace)->StopEditOperation()))
		{
			CString errorMsg = _T("Stop editing");
			IOManager::getInstance().print_error(IOManager::ECode::E_FAILED_TO_PROCESS, true, _T("EDITING"), _T(""), _T("Failed to stop database editing for MultiUserWorkspace"));
			abortEdit(workspace);
			return false;
		}
	}
	if (FAILED(IWorkspaceEditPtr(workspace)->StopEditing(VARIANT_TRUE)))
	{
		CString errorMsg = _T("Stop editing");
		IOManager::getInstance().print_error(IOManager::ECode::E_FAILED_TO_PROCESS, true, _T("EDITING"), _T(""), _T("Failed to stop database editing"));
		abortEdit(workspace);
		return false;
	}
	return true;
}

void AccessSV::abortEdit(IWorkspacePtr& workspace)
{

	VARIANT_BOOL vb = VARIANT_FALSE;
	IWorkspaceEditPtr(workspace)->IsBeingEdited(&vb);
	if (!vb)
		return;
	if (FAILED(IWorkspaceEditPtr(workspace)->AbortEditOperation()) ||
		FAILED(IWorkspaceEditPtr(workspace)->StopEditing(VARIANT_FALSE))) {
		CString errorMsg = _T("Abort editing");
		IOManager::getInstance().print_error(IOManager::ECode::E_FAILED_TO_PROCESS, true, _T("EDITING"), _T(""), _T("Failed to abort database editing"));
	}
}





