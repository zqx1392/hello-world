#pragma once

class Hnp {
public:

	Hnp(const CString& HnpFeatureClassName, IFeatureClassPtr& HnpFeatureClass);
	~Hnp();
	/**
	* @brief start the tool
	* @return	RCode value [ex�FR_SUCCESS=0�AR_FAILED_FATAL_ERROR=1�A...]
	*/
	int insertNewRecordToHNP(IWorkspacePtr& workspace, std::vector<CommonData::poiInfo> * uniqueHnpList, std::map<long, long> * updatedPoiHnpList);

	int createNewBuffer();

	int putValueIntoFields(const long& poiInfoObjectID, const CString& hn, const long& roadNameID, const double& x, const double& y);

	int insertNewFeature(CComVariant * newHnpOID);

	int startAndInsertHnpCursor(IWorkspacePtr& workspace);

	int flushAndStopHnpEdit(IWorkspacePtr& workspacer);

private:
	CString HnpFeatureClassName;
	IFeatureClassPtr HnpFeatureClass;
	IFeatureCursorPtr insertHnpCursor;
	IFeatureBufferPtr featureBuffer;
	//HNP field index
	long m_operatorIndex;
	long m_purposeCIndex;
	long m_modifyDateIndex;
	long m_updateTypeCIndex;
	long m_progModifyDateIndex;
	long m_modifyProgNameIndex;
	long m_userClaimFIndex;
	long m_sourceIndex;
	long m_HNIndex;
	long m_HNTypeIndex;
	long m_linkIDIndex;
	long m_roadNameIDIndex;

};

