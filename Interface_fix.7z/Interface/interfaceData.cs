﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using DBComparerWrapper;

/// <summary>
/// Manage and store all data such as DBuser information, dataset condition and selection, field selection.
/// most of data is stored in m_datasetList and track every selection of every connected DBuser
/// Used by IOManager for reading and writing data and by mainWindow for display
/// can input second user to compare the data
/// </summary>
public class interfaceData
{

    //Variables and session data
    private String m_currentDB;                         //gaia
    private String m_currentUser;                       //TEST2017A
    private String m_currentVersion;                    //SDE.DEFAULT
    private String m_previousDB;                        //gaia
    private String m_previousUser;                      //TEST2017A
    private String m_previousVersion;                   //SDE.DEFAULT
    private String m_currentDB2;                        //gaia
    private String m_currentUser2;                      //TEST2017A
    private String m_currentVersion2;                   //SDE.DEFAULT
    private String m_currentlySelectedDataset;          //ROAD_LINK
    private String datasetListKeywordSeparator = "-";   //ex. gaia-TEST2017A-SDE.DEFAULT-ROAD_LINK

    //related class
    public functionWrapper m_DBComparer;

	//store all dataset and field data
    public struct datasetInfo
    {
        public bool isTable;                           //check if this dataset is table or not
        public bool isDatasetSelected;                 //check if a dataset is selected by user
        public bool isFieldSelectedAll;                //check if all fields are selected in this table
        public String parentDatasetName;               //record this dataset's parent dataset name
        public String searchCondition;                 //record search text for where clause ex. OBJECTID = 10
        public List<Tuple<String, bool>> fieldInfo;    //record all field names and select state of this dataset
    };
    private Dictionary<String, datasetInfo> m_datasetList;	//use getDatasetInfoKey() function to get key
    private HashSet<String> m_DBList;                  //use to record connected DB list
	//Initializer
    public interfaceData()
    {
        m_DBComparer = new functionWrapper();
        m_DBComparer.init();
        m_datasetList = new Dictionary<String, datasetInfo>();
        m_DBList = new HashSet<String>();
        m_currentDB = "";
        m_currentUser = "";
        m_currentVersion = "";
    }
	//----------------------------------------Get/set local variables-------------------------------------------------//
	public String getCurrentDB()
    {
        return m_currentDB;
    }
    public void setCurrentDB(String currentDB)
    {
        m_previousDB = m_currentDB;
        m_currentDB = currentDB;
    }
    public String getCurrentUser()
    {
        return m_currentUser;
    }
    public void setCurrentUser(String currentUser)
    {
        m_previousUser = m_currentUser;
        m_currentUser = currentUser.ToUpper();
    }
    public String getCurrentVersion()
    {
        return m_currentVersion;
    }
    public void setCurrentVersion(String currentVersion)
    {
        m_previousVersion = m_currentVersion;
        m_currentVersion = currentVersion;
        if (String.IsNullOrWhiteSpace(m_currentVersion))
        {
            m_currentVersion = "SDE.DEFAULT";
        }
    }
    public String getPreviousDB()
    {
        return m_previousDB;
    }
    public void setPreviousDB(String previousDB)
    {
        m_previousDB = previousDB;
    }
    public String getPreviousUser()
    {
        return m_previousUser;
    }
    public void setPreviousUser(String previousUser)
    {
        m_previousUser = previousUser.ToUpper();
    }
    public String getPreviousVersion()
    {
        return m_previousVersion;
    }
    public void setPreviousVersion(String previousVersion)
    {
        m_previousVersion = previousVersion;
        if (String.IsNullOrWhiteSpace(m_previousVersion))
        {
            m_previousVersion = "SDE.DEFAULT";
        }
    }
    public bool isCurrentAndPreviousDBUserSame()
    {
        if (m_previousDB.ToLower() == m_currentDB.ToLower() && m_previousUser.ToLower() == m_currentUser.ToLower() && m_previousVersion.ToLower() == m_currentVersion.ToLower())
            return true;
        return false;
    }
    public String getCurrentDB2()
    {
        return m_currentDB2;
    }
    public void setCurrentDB2(String currentDB2)
    {
        m_currentDB2 = currentDB2;
    }
    public String getCurrentUser2()
    {
        return m_currentUser2;
    }
    public void setCurrentUser2(String currentUser2)
    {
        m_currentUser2 = currentUser2.ToUpper();
    }
    public String getCurrentVersion2()
    {
        return m_currentVersion2;
    }
    public void setCurrentVersion2(String currentVersion2)
    {
        m_currentVersion2 = currentVersion2;
        if (String.IsNullOrWhiteSpace(m_currentVersion2))
        {
            m_currentVersion2 = "SDE.DEFAULT";
        }
    }
    public bool isCurrent1AndCurrent2DBUserSame()
    {
        if (m_currentDB2.ToLower() == m_currentDB.ToLower() && m_currentUser2.ToLower() == m_currentUser.ToLower() && m_currentVersion2.ToLower() == m_currentVersion.ToLower())
            return true;
        return false;
    }
    public String getCurrentlySelectedDataset()
    {
        return m_currentlySelectedDataset;
    }
    public void setCurrentlySelectedDataset(String currentlySelectedDataset)
    {
        m_currentlySelectedDataset = currentlySelectedDataset;
    }
	public String getDatasetListKeywordSeparator()
    {
        return datasetListKeywordSeparator;
    }
	//----------------------------------------Get/set dataset-related info-------------------------------------------------//
	/**
	* @brief create new dataset and store into m_datasetList for selection tracking
	* @param db		    [in]	target db
	* @param user	    [in]    target user
	* @param version	[in]    target user version
	* @param dataset	[in]    target dataset
	* @param isTable	[in]    is dataset a table
	* @param isOverwrite[in]	is overwrite the dataset regardless of existance    
	*/
	 public void setNewDataset(String db, String user, String version, String dataset, bool isTable, bool isOverwrite)
    {
        bool isExist = isDatasetExist(db, user, version, dataset);
        if (isExist && !isOverwrite)
        {
            return;
        }
        String datasetKey = getDatasetInfoKey(db, user, version, dataset);
        datasetInfo newDataset = new datasetInfo();
        newDataset.fieldInfo = new List<Tuple<String, bool>>();
        newDataset.isFieldSelectedAll = false;
        newDataset.isDatasetSelected = false;
        newDataset.parentDatasetName = "";
        newDataset.searchCondition = "";
        newDataset.isTable = isTable;
        if (!isExist)
        {
            m_datasetList.Add(datasetKey, newDataset);
        }
        else if (isExist && isOverwrite)
        {
            m_datasetList[datasetKey] = newDataset;
        }
    }
	/**
	* @brief get datasetList for writing to output file
	*/
	public Dictionary<String, datasetInfo> getDatasetList()
    {
        return m_datasetList;
    }
	/**
	* @brief clear all currently connect DBUser's datasets from m_datasetList
	*/
	public void clearDatasetList()
	{
		foreach (KeyValuePair<String, datasetInfo> dataset in m_datasetList)
		{
			if (dataset.Key.IndexOf(m_currentDB) < 0 || dataset.Key.IndexOf(m_currentUser) < 0 || dataset.Key.IndexOf(m_currentVersion) < 0)
			{
				continue;
			}
			m_datasetList.remove(dataset.Key);
		}
	}
	/**
	* @brief check whether a dataset exists in m_datasetList
	* @brief create new dataset and store into m_datasetList for selection tracking
	* @param db		    [in]	target db
	* @param user	    [in]    target user
	* @param version	[in]    target user version
	* @param dataset	[in]    target dataset
	* @param isTable	[in]    is dataset a table
	*/
    public bool isDatasetExist(String db, String user, String version, String dataset)
    {
        String datasetKey = getDatasetInfoKey(db, user, version, dataset);
        return m_datasetList.ContainsKey(datasetKey);
    }
	/**
	* @brief get key for m_datasetList 
	* @param db		    [in]	target db
	* @param user	    [in]    target user
	* @param version	[in]    target user version
	* @param dataset	[in]    target dataset 
	*/
    public String getDatasetInfoKey(String db, String user, String version, String dataset)
    {
        String s = datasetListKeywordSeparator;
        if (String.IsNullOrWhiteSpace(db)) db = getCurrentDB();
        if (String.IsNullOrWhiteSpace(user)) user = getCurrentUser();
        if (String.IsNullOrWhiteSpace(version)) version = getCurrentVersion();
        if (String.IsNullOrWhiteSpace(dataset)) dataset = getCurrentlySelectedDataset();
        return db + s + user + s + version + s + dataset;
    }
	public bool isDatasetSelected(String db, String user, String version, String dataset)
    {
        String datasetKey = getDatasetInfoKey(db, user, version, dataset);
        return m_datasetList[datasetKey].isDatasetSelected;
    }
	
    public void setDatasetSelected(String db, String user, String version, String dataset, bool isSelected)
    {
        String datasetKey = getDatasetInfoKey(db, user, version, dataset);
        datasetInfo newDataset = m_datasetList[datasetKey];
        newDataset.isDatasetSelected = isSelected;
        m_datasetList[datasetKey] = newDataset;
    }
    public bool isDatasetTable(String db, String user, String version, String dataset)
    {
        String datasetKey = getDatasetInfoKey(db, user, version, dataset);
        return m_datasetList[datasetKey].isTable;
    }
    public void setDatasetTable(String db, String user, String version, String dataset, bool isTable)
    {
        String datasetKey = getDatasetInfoKey(db, user, version, dataset);
        datasetInfo newDataset = m_datasetList[datasetKey];
        newDataset.isTable = isTable;
        m_datasetList[datasetKey] = newDataset;
    }
    public bool isAllFieldSelected(String db, String user, String version, String dataset)
    {
        String datasetKey = getDatasetInfoKey(db, user, version, dataset);
        return m_datasetList[datasetKey].isFieldSelectedAll;
    }
    public void setAllFieldSelected(String db, String user, String version, String dataset, bool isAllSelected)
    {
        String datasetKey = getDatasetInfoKey(db, user, version, dataset);
        datasetInfo newDataset = m_datasetList[datasetKey];
        newDataset.isFieldSelectedAll = isAllSelected;
        m_datasetList[datasetKey] = newDataset;
    }
    public String getParentDatasetName(String db, String user, String version, String dataset)
    {
        String datasetKey = getDatasetInfoKey(db, user, version, dataset);
        return m_datasetList[datasetKey].parentDatasetName;
    }
    public void setParentDatasetName(String db, String user, String version, String dataset)
    {
        String datasetKey = getDatasetInfoKey(db, user, version, dataset);
        datasetInfo newDataset = m_datasetList[datasetKey];
        String parentDatasetName = m_DBComparer.getFeatureClassDataSetName(db, user, version, dataset);
        int a = parentDatasetName.IndexOf(".");
        int b = parentDatasetName.Length;
        parentDatasetName = parentDatasetName.Substring(a + 1, b - a - 1);
        newDataset.parentDatasetName = parentDatasetName;
        m_datasetList[datasetKey] = newDataset;
    }
    public String getDatasetCondition(String db, String user, String version, String dataset)
    {
        String datasetKey = getDatasetInfoKey(db, user, version, dataset);
        return m_datasetList[datasetKey].searchCondition;
    }
    public void setDatasetCondition(String db, String user, String version, String dataset, String searchCondition)
    {
        String datasetKey = getDatasetInfoKey(db, user, version, dataset);
        datasetInfo newDataset = m_datasetList[datasetKey];
        newDataset.searchCondition = searchCondition;
        m_datasetList[datasetKey] = newDataset;
    }

    public List<Tuple<String, bool>> getDatasetFieldInfo(String db, String user, String version, String dataset)
    {
        String datasetKey = getDatasetInfoKey(db, user, version, dataset);
        return m_datasetList[datasetKey].fieldInfo;
    }
    public void setDatasetFieldInfo(String db, String user, String version, String dataset, List<Tuple<String, bool>> fieldInfo)
    {
        String datasetKey = getDatasetInfoKey(db, user, version, dataset);
        datasetInfo newDataset = m_datasetList[datasetKey];
        newDataset.fieldInfo = fieldInfo;
        m_datasetList[datasetKey] = newDataset;
    }
    public bool isDatasetFieldSelected(String db, String user, String version, String dataset, String field)
    {
        String datasetKey = getDatasetInfoKey(db, user, version, dataset);
        Tuple<String, bool> tempTuple = new Tuple<string, bool>(field, true);
        return m_datasetList[datasetKey].fieldInfo.Contains(tempTuple);
    }
    public void setDatasetFieldSelected(String db, String user, String version, String dataset, String field, bool columnSelected)
    {
        String datasetKey = getDatasetInfoKey(db, user, version, dataset);
        Tuple<String, bool> tempTuple = new Tuple<string, bool>(field, columnSelected);
        if (!m_datasetList[datasetKey].fieldInfo.Contains(tempTuple))
        {
            Tuple<String, bool> tempTuple2 = new Tuple<string, bool>(field, !columnSelected);
            if (m_datasetList[datasetKey].fieldInfo.Contains(tempTuple2))
            {
                m_datasetList[datasetKey].fieldInfo.Remove(tempTuple2);
            }
            m_datasetList[datasetKey].fieldInfo.Add(tempTuple);
        }
    }
	
	//-----------------------------Communicate to server-side C++ class-------------------------------------------------//
	public bool connectToUser1()
    {
        bool isSuccess = m_DBComparer.connectToDB(m_currentDB, m_currentUser, m_currentVersion);
        if (!isSuccess)
        {
            return false;
        }
        String s = datasetListKeywordSeparator;
        m_DBList.Add(m_currentDB+ s + m_currentUser + s + m_currentVersion);
        return true;
    }
    public bool connectToUser2()
    {
        bool isSuccess = m_DBComparer.connectToDB(m_currentDB2, m_currentUser2, m_currentVersion2);
        if (!isSuccess)
        {
            return false;
        }
        String s = datasetListKeywordSeparator;
        m_DBList.Add(m_currentDB2 + s + m_currentUser2 + s + m_currentVersion2);
        return true;
    }
    public bool isDBAlreadyConnected(String db, String user, String version)
    {
        String s = datasetListKeywordSeparator;
        return m_DBList.Contains(db + s + user + s + version);
    }
    public List<String> getFeatureClassList(String db, String user, String version)
    {
        List<String> datasetList = new List<String>(m_DBComparer.getFeatureClassAndCount(db, user, version));
        return datasetList;
    }
    public List<String> getTableList(String db, String user, String version)
    {
        List<String> datasetList = new List<String>(m_DBComparer.getTableAndCount(db, user, version));
        return datasetList;
    }
    
    public List<String> getFieldNameList(String datasetName)
    {
        bool isTable = isDatasetTable(m_currentDB, m_currentUser, m_currentVersion, datasetName);
        List<String> fieldNameList = new List<String>(m_DBComparer.getfieldNameList(m_currentDB, m_currentUser, m_currentVersion, datasetName, isTable));
        return fieldNameList;
    }
    public bool checkSQLSyntax(String SQLText, String datasetName)
    {
        bool isTable = isDatasetTable(m_currentDB, m_currentUser, m_currentVersion, datasetName);
        return m_DBComparer.checkSQLSyntax(SQLText, m_currentDB, m_currentUser, m_currentVersion, datasetName, isTable);
    }
    public String getRecordNumber(String SQLText, String db, String user, String version, String datasetName)
    {
        bool isTable = isDatasetTable(m_currentDB, m_currentUser, m_currentVersion, datasetName);
        int num = m_DBComparer.getRecordNumber(SQLText, db, user, version, datasetName, isTable);
        if (num < 0) return "-";
        return num.ToString();
    }
	public List<String> getDomainNameList(String datasetName, String fieldName)
    {
        bool isTable = isDatasetTable(m_currentDB, m_currentUser, m_currentVersion, datasetName);
        return new List<String>(m_DBComparer.getDomainNameList(m_currentDB, m_currentUser, m_currentVersion, datasetName, fieldName, isTable));
    }
    public String getTotalDistArea(String SQLText, String db, String user, String version, String datasetName)
    {
        bool isTable = isDatasetTable(m_currentDB, m_currentUser, m_currentVersion, datasetName);
        if (isTable)
        {
            return "-";
        }
        double num = m_DBComparer.getTotalDistArea(SQLText, db, user, version, datasetName);
        if (num < 0) return "-";
        return string.Format("{0:N2}", num );
    }
}


