﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Runtime.InteropServices;

namespace DBStatsComparer
{
    /// <summary>
    /// Connect to SiNDY via ArcSDE and acquire selected user's datasets, fields and domains.
    /// also get total record count and total distance or area of each domain under specified where clause condition.
    /// can input second user to compare the data
    /// Input:
    ///     User1 -- Username, DB name, version
    ///     User2 -- Username, DB name, version
    /// Target data:
    ///     dataset name
    ///		field name
    ///     domain code, name
    ///     record count
    ///     Area, Distance (if avaliable)
    /// Output:
    ///     TSV file
    /// </summary>
    public partial class MainWindow : Window
    {
        //necessary variable to automatically close messagebox
        [DllImport("user32.dll", EntryPoint = "FindWindow", SetLastError = true)]
        static extern IntPtr FindWindowByCaption(IntPtr ZeroOnly, string lpWindowName);
        [DllImport("user32.Dll")]
        static extern int PostMessage(IntPtr hWnd, UInt32 msg, int wParam, int lParam);
        const UInt32 WM_CLOSE = 0x0010;
        //related class
        public interfaceData m_interfaceData;
        public IOManager m_IOManager;

        //interface object and library resource
        //for dataset and field button
        static private String suffix_close = "_close";
        static private String suffix_check = "_chk";
        static private String suffix_set = "_set";
        static private String suffix_condition = "_condit";
		//for resource
        static private String res_gridFieldButton = "gridFieldButton";
        static private String res_fieldButton = "fieldButton";
        static private String res_closeButton = "closeButton";
        static private String res_borderDatasetHeader = "borderDatasetHeader";
        static private String res_borderDatasetRow = "borderDatasetRow";
        static private String res_borderDatasetInner = "borderDatasetInner";
        static private String res_textBlockDataset = "textBlockDataset";
        static private String res_textBoxDataset = "textBoxDataset";
        /// <summary>
  	    /// Initialize main component and data.
  	    /// </summary>
        public MainWindow()
        {
            InitializeComponent();
            m_interfaceData = new interfaceData();
            m_IOManager = new IOManager(m_interfaceData);
        }

        //--------------------------------------------------------------DATASET PART------------------------------------------------------------------//
        /// <summary>
        /// 1. get dataset list from interfaceData class
        /// 2. format dataset panel
        /// 3. insert all table and featureClass rows into interface panel
        /// </summary>
        /// <param name="sender">triggered interface object</param>
        /// <param name="e">triggered event</param>
        private void clickGetDatasets(object sender, RoutedEventArgs e)
        {
			      //get DBuser data from textboxes
            String user = user1.Text;
            String db = db1.Text;
            String version = version1.Text;
            if (String.IsNullOrWhiteSpace(user))
            {
                System.Windows.MessageBox.Show("Please input user1", "Input Error");
                return;
            }
            if (String.IsNullOrWhiteSpace(db))
            {
                System.Windows.MessageBox.Show("Please input db1", "Input Error");
                return;
            }
            if (String.IsNullOrWhiteSpace(version))
            {
                version = "SDE.DEFAULT";
            }
            user = user.ToUpper();
            //show loading messagebox
            Task.Factory.StartNew(() =>
            {
                MessageBox.Show("Connecting to DB...","Loading");

            });
			m_interfaceData._m_currentDB = db;
            m_interfaceData._m_currentUser = user;
            m_interfaceData._m_currentVersion = version;
            //Connect to SiNDY
            if (!m_interfaceData.isDBAlreadyConnected(db, user, version))
            {
                bool isSuccess = m_interfaceData.connectToUser1();
                if (!isSuccess)
                {
                    resetInterface(isSuccess);
                    System.Windows.MessageBox.Show("Cannot connect to DBUser1", "Connection Error");
                    return;
                }
            }

			//format dataset panel interface
            formatDatasetPanel();
            //get dataset from SiNDY and send to interface
            bool failConnection = false;
			if (!getDatasetAndUpdateInterface(db, user, version, false) || !getDatasetAndUpdateInterface(db, user, version, true))
            {
				resetInterface(failConnection);
                return;
            }
            //check if all input dataset and field name from a config file are correct
            if (!m_IOManager.isAllInputNameCorrect())
            {
				resetInterface(failConnection);
                return;
            }
            bool successConnection = true;
            resetInterface(successConnection);
        }
        /// <summary>
        /// get featureclasses and tables data from SiNDY, then update to interface
        /// </summary>
        /// <param name="db">target db</param>
        /// <param name="user">target user</param>
        /// <param name="version">target user version</param>
        /// <param name="isTable">get data as Table or Featureclass</param>
        /// <returns>true if success, false if failed</returns>
		private bool getDatasetAndUpdateInterface(String db, String user, String version, bool isTable){
			List <String> datasetList;
			if (isTable) datasetList = m_interfaceData.getTableList(db, user, version);
			else datasetList = m_interfaceData.getFeatureClassList(db, user, version);
            //if fail to get data, quit process
            if (datasetList.Contains("-1"))
            {
                return false;
            }
            //update dataset row to interface
            for (int i = 0; i < datasetList.Count; i ++ )
            {
                String datasetName = datasetList[i];
                //if load from config file or previous selection exist, auto select dataset row and paste input condition
                if (m_interfaceData.isDatasetExist(db, user, version, datasetName))
                {
                    //if load from config file and currently connect DB is the same as config file target DB, but dataset not selected
                    if (m_interfaceData.isCurrentAndPreviousDBUserSame() && !m_IOManager.isDatasetNameExistInConfig(datasetName,isTable))
                    {
                        //overwrite the old dataset
                        bool isOverwrite = true;
                        m_interfaceData.setNewDataset(db, user, version, datasetName, isTable, isOverwrite);
                        //update parent dataset name data
                    }
                    m_interfaceData.setParentDatasetName(db, user, version, datasetName);
                    String parentDatasetName = m_interfaceData.getParentDatasetName(db, user, version, datasetName);
                    //create dataset row into dataset panel
                    createDatasetRow(datasetName, parentDatasetName);
                    //Auto input condition
                    TextBox txtBox = (TextBox)LogicalTreeHelper.FindLogicalNode(datasetWrapper, datasetName + suffix_condition);
                    txtBox.Text = m_interfaceData.getDatasetCondition(db, user, version, datasetName); // condition string
                                                                                                        //Auto select dataset row
                    if (m_interfaceData.isDatasetSelected(db, user, version, datasetName)) // bool
                    {
                        CheckBox chkBox = (CheckBox)LogicalTreeHelper.FindLogicalNode(datasetWrapper, datasetName + suffix_check);
                        chkBox.IsChecked = true;
                    }
                }
				//create new dataset
                else
                {
                    bool isOverwrite = false;
                    m_interfaceData.setNewDataset(db, user, version, datasetName, isTable, isOverwrite);
                    //update parent dataset name data
                    m_interfaceData.setParentDatasetName(db, user, version, datasetName);
                    String parentDatasetName = m_interfaceData.getParentDatasetName(db, user, version, datasetName);
                    //create dataset row into dataset panel
                    createDatasetRow(datasetName, parentDatasetName);
                }
                if (!isTable) m_interfaceData.setParentDatasetName(db, user, version, datasetName);
                //check if the name exists in input list (if load from config file);
                m_IOManager.checkInputName(datasetName, isTable);
            }
            return true;
		}
        /// <summary>
        /// Clear dataset panel before inserting dataset row.
        /// </summary>
        private void formatDatasetPanel()
        {
            Border headTable = (Border)LogicalTreeHelper.FindLogicalNode(datasetWrapper, res_borderDatasetHeader);
            datasetWrapper.Children.Clear();
            datasetWrapper.Background = Brushes.White;
            datasetWrapper.Children.Add(headTable);
            tableScrollViewer.ScrollToTop();
        }
        /// <summary>
        /// Create all dataset rows interface from target DB when click 'get datasets' button
        /// </summary>
        /// <param name="datasetName">Dataset Name</param>
        /// <param name="parenDatasetName">Parent Dataset Name</param>
        private void createDatasetRow(String datasetName, String parentDatasetName)
        {
            //Create border for coloured border and grid for button layout
            //    WIDTH
            //   3 12  38   47     = 100%
            //   _______________
            //  |_|__|____|_____|  checkbox:dataset:dataset name:condition

            //Create border
            Border newOuterBorder = new Border();
            newOuterBorder.Style = FindResource(res_borderDatasetRow) as Style;
            //Specify grid
            Grid newGrid = new Grid();
            double columnWidth1 = 3;
            double columnWidth2 = 12;
            double columnWidth3 = 38;
            double columnWidth4 = 47;
            ColumnDefinition gridCol = new ColumnDefinition();
            gridCol.Width = new GridLength(columnWidth1, GridUnitType.Star);
            ColumnDefinition gridCol2 = new ColumnDefinition();
            gridCol2.Width = new GridLength(columnWidth2, GridUnitType.Star);
            ColumnDefinition gridCol3 = new ColumnDefinition();
            gridCol3.Width = new GridLength(columnWidth3, GridUnitType.Star);
            ColumnDefinition gridCol4 = new ColumnDefinition();
            gridCol4.Width = new GridLength(columnWidth4, GridUnitType.Star);
            newGrid.ColumnDefinitions.Add(gridCol);
            newGrid.ColumnDefinitions.Add(gridCol2);
            newGrid.ColumnDefinitions.Add(gridCol3);
            newGrid.ColumnDefinitions.Add(gridCol4);
            //Create checkbox
            Viewbox newViewbox = new Viewbox();
            CheckBox newCheckbox = new CheckBox();
            newCheckbox.Name = datasetName + suffix_check;
            newCheckbox.Unchecked += datasetCheckboxSelected;
            newCheckbox.Checked += datasetCheckboxSelected;
            newViewbox.Child = newCheckbox;
            //Add checkbox into the layout
            newGrid.Children.Add(newViewbox);
            //Create parent dataset name textblock and its border
            Border setInnerBorder = new Border();
            setInnerBorder.Style = FindResource(res_borderDatasetInner) as Style;
            setInnerBorder.SetValue(Grid.ColumnProperty, 1);
            TextBlock setTextBlock = new TextBlock();
            setTextBlock.Style = FindResource(res_textBlockDataset) as Style;
            setTextBlock.Name = datasetName + suffix_set;
            setTextBlock.Text = parentDatasetName;
            setInnerBorder.Child = setTextBlock;
            //Add textblock into the layout
            newGrid.Children.Add(setInnerBorder);
            //Create dataset textblock and its border
            Border nameInnerBorder = new Border();
            nameInnerBorder.Style = FindResource(res_borderDatasetInner) as Style;
            nameInnerBorder.SetValue(Grid.ColumnProperty, 2);
            nameInnerBorder.Cursor = Cursors.Hand;
            TextBlock nameTextBlock = new TextBlock();
            nameTextBlock.Style = FindResource(res_textBlockDataset) as Style;
            nameTextBlock.Text = datasetName;
            nameTextBlock.PreviewMouseLeftButtonDown += ClickDatasetName;
            nameTextBlock.Name = datasetName;
            nameInnerBorder.Child = nameTextBlock;
            //Add textblock into the layout
            newGrid.Children.Add(nameInnerBorder);
            //Create condition textbox and its border
            Border conditionInnerBorder = new Border();
            conditionInnerBorder.Style = FindResource(res_borderDatasetInner) as Style;
            conditionInnerBorder.SetValue(Grid.ColumnProperty, 3);
            TextBox conditionTextBox = new TextBox();
            conditionTextBox.Style = FindResource(res_textBoxDataset) as Style;
            conditionTextBox.Name = datasetName + suffix_condition;
            conditionTextBox.PreviewKeyDown += pressEnterConditionField;
            conditionTextBox.LostFocus += lostFocusConditionField;
            conditionInnerBorder.Child = conditionTextBox;
            //Add textbox into the layout
            newGrid.Children.Add(conditionInnerBorder);

            newOuterBorder.Child = newGrid;
            //Add the layout into dataset panel
            datasetWrapper.Children.Add(newOuterBorder);
        }
        /// <summary>
        /// When dataset checkbox is selected or deselected, update dataset select status.
        /// </summary>
        /// <param name="sender">triggered interface object</param>
        /// <param name="e">triggered event</param>
        private void datasetCheckboxSelected(object sender, RoutedEventArgs e)
        {
            CheckBox obj = sender as CheckBox;
            bool chkBoxChecked = (bool)obj.IsChecked;
            String datasetName = obj.Name.Substring(0, obj.Name.Length - suffix_check.Length);
            m_interfaceData.setDatasetSelected(string.Empty, string.Empty, string.Empty, datasetName, chkBoxChecked);
        }
        /// <summary>
        /// When a datasetname textblock is clicked, show its field list and auto select field.
        /// </summary>
        /// <param name="sender">triggered interface object</param>
        /// <param name="e">triggered event</param>
        private void ClickDatasetName(object sender, RoutedEventArgs e)
        {
            DependencyObject obj = sender as DependencyObject;
            TextBlock txtBlock = sender as TextBlock;
            String datasetName = txtBlock.Name;
            //if this dataset is not selected already, show its field list
            if (datasetName != m_interfaceData._m_currentlySelectedDataset)
            {
                m_interfaceData._m_currentlySelectedDataset = datasetName;
                formatFieldPanel();
                //print all field buttons into field panel.
                setFieldList(datasetName);
                //check if there is any pre-selected field
                List<Tuple<String, bool>> fieldInfo = new List<Tuple<String, bool>>(m_interfaceData.getDatasetFieldInfo(string.Empty, string.Empty, string.Empty, datasetName));
                bool isSelectAll = m_interfaceData.isAllFieldSelected(string.Empty, string.Empty, string.Empty, datasetName);
                //if pre-selected, auto select the fields on interface
                foreach (Tuple<String, bool> eachField in fieldInfo)
                {
                    String fieldName = eachField.Item1;
                    if (eachField.Item2 == true || isSelectAll)
                    {
                        Button btn = (Button)LogicalTreeHelper.FindLogicalNode(fieldWrapper, fieldName);
                        btn.RaiseEvent(new RoutedEventArgs(Button.ClickEvent));
                    }
                }
            }
            //auto select the dataset's checkbox.
            String targetDataset;
            do
            {
                obj = LogicalTreeHelper.GetParent(obj);
                targetDataset = obj.GetType().Name;
            } while (targetDataset != "Grid");
            foreach (CheckBox chkBox in FindVisualChildren<CheckBox>(obj))
            {
                if (chkBox.IsChecked == false)
                    chkBox.IsChecked = true;
            }
            //enable field select or clear all button
            selectAllFieldButton.IsEnabled = true;
            clearAllFieldButton.IsEnabled = true;
            //set Label
            datasetName = datasetName.Replace("_", "__"); //fix label bug not show underscore correctly
            datasetLabel.Content = "Select target field(s) for " + datasetName;
        }
        /// <summary>
        /// press entered when keyboard focus on a condition textblock to update a change.
        /// </summary>
        /// <param name="sender">triggered interface object</param>
        /// <param name="e">triggered event</param>
        private void pressEnterConditionField(object sender, KeyEventArgs e)
        {
            if (Key.Enter == e.Key)
            {
                TextBox obj = sender as TextBox;
                String conditTxt = obj.Text;
                String datasetName = obj.Name.Substring(0, obj.Name.Length - suffix_condition.Length);
                m_interfaceData.setDatasetCondition(string.Empty, string.Empty, string.Empty, datasetName, conditTxt);
                Keyboard.ClearFocus();
                obj.Background = Brushes.Transparent;
            }
        }
        /// <summary>
        /// lost focus on a condition textblock to update a change.
        /// </summary>
        /// <param name="sender">triggered interface object</param>
        /// <param name="e">triggered event</param>
        private void lostFocusConditionField(object sender, RoutedEventArgs e)
        {
            TextBox obj = sender as TextBox;
            String conditTxt = obj.Text;
            String chkBoxName = obj.Name.Substring(0, obj.Name.Length - suffix_condition.Length) + suffix_check;
            String datasetName = obj.Name.Substring(0, obj.Name.Length - suffix_condition.Length);
            m_interfaceData.setDatasetCondition(string.Empty, string.Empty, string.Empty, datasetName, conditTxt);
            obj.Background = Brushes.Transparent;
        }
        /// <summary>
        /// Select all dataset checkboxes programmatically when "Select All" button is clicked.
        /// Disable field select button too.
        /// </summary>
        /// <param name="sender">triggered interface object</param>
        /// <param name="e">triggered event</param>
        private void selectAllDatasets(object sender, RoutedEventArgs e)
        {
            foreach (CheckBox chkBox in FindVisualChildren<CheckBox>(datasetWrapper))
            {
                chkBox.IsChecked = true;
            }
            formatFieldPanel();
            m_interfaceData._m_currentlySelectedDataset = string.Empty;
            selectAllFieldButton.IsEnabled = false;
            clearAllFieldButton.IsEnabled = false;
        }
        /// <summary>
        /// Deselect all dataset checkboxes programmatically when "Clear All" button is clicked.
        /// Disable field select button too.
        /// </summary>
        /// <param name="sender">triggered interface object</param>
        /// <param name="e">triggered event</param>
        private void clearAllDatasets(object sender, RoutedEventArgs e)
        {
            foreach (CheckBox chkBox in FindVisualChildren<CheckBox>(datasetWrapper))
            {
                chkBox.IsChecked = false;
            }
            formatFieldPanel();
            m_interfaceData._m_currentlySelectedDataset = string.Empty;
            selectAllFieldButton.IsEnabled = false;
            clearAllFieldButton.IsEnabled = false;

        }
        //--------------------------------------------------------------FIELD PART------------------------------------------------------------------//
        /// <summary>
        /// Clear field panel before inserting field buttons.
        /// </summary>
        private void formatFieldPanel()
        {
            fieldWrapper.Children.Clear();
            fieldWrapper.Background = Brushes.White;
        }
        /// <summary>
        /// Print all field buttons into field panel.
        /// </summary>
        /// <param name="dataset">target dataset name</param>
        private void setFieldList(String datasetName)
        {
            List<String> fieldList = m_interfaceData.getFieldNameList(datasetName);
            List<Tuple<String, bool>> newColumnInfo = new List<Tuple<String, bool>>();
            fieldList = fieldList.OrderBy(q => q).ToList();
			//create button 1 by 1
            for (int i = 0; i < fieldList.Count; i++)
            {
                String fieldName = fieldList[i];
                if (fieldName.Contains(".")) continue;
                createFieldButton(fieldName);
                Tuple<String, bool> newTuple = new Tuple<String, bool>(fieldName,false);
                newColumnInfo.Add(newTuple);
            }
            //if field data is string.Empty (not load from config or previously selected)
            if (m_interfaceData.getDatasetFieldInfo(string.Empty, string.Empty, string.Empty, datasetName).Count == 0)
            {
                m_interfaceData.setDatasetFieldInfo(string.Empty, string.Empty, string.Empty, datasetName, newColumnInfo);
            }
        }
        /// <summary>
        /// Create a field button when a dataset is selected.
        /// </summary>
        /// <param name="fieldName">Field Name [ex. OBJECTID]</param>
        private void createFieldButton(String fieldName)
        {
            //Create button layout
            //    WIDTH
            //   _______
            //  |_|_|_|_|  HEI
            //  |_|_|_|_|  GHT

            //Create grid
            Grid newGrid = new Grid();
            newGrid.Style = FindResource(res_gridFieldButton) as Style;
            ColumnDefinition gridCol = new ColumnDefinition();
            gridCol.Width = new GridLength(1, GridUnitType.Star);
            ColumnDefinition gridCol2 = new ColumnDefinition();
            gridCol2.Width = new GridLength(1, GridUnitType.Star);
            ColumnDefinition gridCol3 = new ColumnDefinition();
            gridCol3.Width = new GridLength(1, GridUnitType.Star);
            ColumnDefinition gridCol4 = new ColumnDefinition();
            gridCol4.Width = new GridLength(1, GridUnitType.Star);
            newGrid.ColumnDefinitions.Add(gridCol);
            newGrid.ColumnDefinitions.Add(gridCol2);
            newGrid.ColumnDefinitions.Add(gridCol3);
            newGrid.ColumnDefinitions.Add(gridCol4);
            RowDefinition gridRow = new RowDefinition();
            RowDefinition gridRow2 = new RowDefinition();
            gridRow.Height = new GridLength(1, GridUnitType.Star);
            gridRow2.Height = new GridLength(1, GridUnitType.Star);
            newGrid.RowDefinitions.Add(gridRow);
            newGrid.RowDefinitions.Add(gridRow2);
            //Create field button
            Button fieldButton = new Button();
            fieldButton.Style = FindResource(res_fieldButton) as Style;
            fieldButton.Content = fieldName;
            fieldButton.Click += clickFieldButton;
            fieldButton.Name = fieldName;
            //Create close button
            Button closeButton = new Button();
            closeButton.Style = FindResource(res_closeButton) as Style;
            closeButton.Visibility = Visibility.Hidden;
            closeButton.Click += clickCloseFieldButton;
            closeButton.Name = fieldName + suffix_close;
            //Add both buttons into the layout
            newGrid.Children.Add(closeButton);
            newGrid.Children.Add(fieldButton);
            //Add the layout into column panel
            fieldWrapper.Children.Add(newGrid);
        }

        /// <summary>
        /// Show animation and record selected column when a field button is clicked
        /// </summary>
        /// <param name="sender">triggered interface object</param>
        /// <param name="e">triggered event</param>
        private void clickFieldButton(object sender, RoutedEventArgs e)
        {
            Button btn = sender as Button;
            String fieldName = btn.Name;
            //if it not selected yet
            if (btn.Background == Brushes.White)
            {
                //change background to green and show close button
                btn.Background = Brushes.LightGreen;
                Button closeButton = (Button)LogicalTreeHelper.FindLogicalNode(fieldWrapper, fieldName + suffix_close);
                if (closeButton == null)
                {
                    return;
                }
                closeButton.Visibility = Visibility.Visible;
                //record select status
                bool selectField = true;
                m_interfaceData.setDatasetFieldSelected(string.Empty, string.Empty, string.Empty, string.Empty, fieldName, selectField);
            }
        }
        /// <summary>
        /// Show animation and record deselected field when a close field button is clicked
        /// </summary>
        /// <param name="sender">triggered interface object</param>
        /// <param name="e">triggered event</param>
        private void clickCloseFieldButton(object sender, RoutedEventArgs e)
        {
            Button btn = sender as Button;
            String fieldName = btn.Name.Substring(0, btn.Name.Length - suffix_close.Length);
            Button fieldButton = (Button)LogicalTreeHelper.FindLogicalNode(fieldWrapper, fieldName);
            //change background to white and hide close button
            fieldButton.Background = Brushes.White;
            btn.Visibility = Visibility.Hidden;
            //record status into dict
            bool selectField = false;
            m_interfaceData.setDatasetFieldSelected(string.Empty, string.Empty, string.Empty, string.Empty, fieldName, selectField);
            String datasetName = m_interfaceData._m_currentlySelectedDataset;
            m_interfaceData.setAllFieldSelected(string.Empty, string.Empty, string.Empty, datasetName, selectField);
        }
        /// <summary>
        /// Select all field programmatically when "Select All" button is clicked.
        /// </summary>
        /// <param name="sender">triggered interface object</param>
        /// <param name="e">triggered event</param>
        private void selectAllFields(object sender, RoutedEventArgs e)
        {
            foreach(Button btn in FindVisualChildren<Button>(fieldWrapper))
            {
                int finding = btn.Name.IndexOf(suffix_close);
                if (finding == -1)
                    btn.RaiseEvent(new RoutedEventArgs(Button.ClickEvent));
            }
            String datasetName = m_interfaceData._m_currentlySelectedDataset;
            bool selectField = true;
            m_interfaceData.setAllFieldSelected(string.Empty, string.Empty, string.Empty, datasetName, selectField);
        }
        /// <summary>
        /// Deselect all fields programmatically when "Clear All" button is clicked.
        /// </summary>
        /// <param name="sender">triggered interface object</param>
        /// <param name="e">triggered event</param>
        private void clearAllFields(object sender, RoutedEventArgs e)
        {
            foreach (Button btn in FindVisualChildren<Button>(fieldWrapper))
            {
                int finding = btn.Name.IndexOf(suffix_close);
                if (finding != -1)
                    btn.RaiseEvent(new RoutedEventArgs(Button.ClickEvent));
            }
            String datasetName = m_interfaceData._m_currentlySelectedDataset;
            bool selectField = false;
            m_interfaceData.setAllFieldSelected(string.Empty, string.Empty, string.Empty, datasetName, selectField);
        }
        //--------------------------------------------------------------INTERFACE UTILITY PART------------------------------------------------------------------//
        /// <summary>
        /// Find all child objects which match selected object type under the selected element
        /// </summary>
        /// <param name="T">object type [ex. Checkbox, textblock]</param>
        /// <param name="depObj">parent element</param>
        /// <returns>List of found object</returns>
        private static IEnumerable<T> FindVisualChildren<T>(DependencyObject depObj) where T : DependencyObject
        {
            if (depObj != null)
            {
                for (int i = 0; i < VisualTreeHelper.GetChildrenCount(depObj); i++)
                {
                    DependencyObject child = VisualTreeHelper.GetChild(depObj, i);
                    if (child != null && child is T)
                    {
                        yield return (T)child;
                    }

                    foreach (T childOfChild in FindVisualChildren<T>(child))
                    {
                        yield return childOfChild;
                    }
                }
            }
        }
        /// <summary>
        /// Clear program interface to default state
        /// </summary>
        private void resetInterface(bool isSuccess)
        {
            if (!isSuccess)
            {
                m_interfaceData.clearDatasetList();
                formatDatasetPanel();
            }
            formatFieldPanel();
            m_interfaceData._m_currentlySelectedDataset = string.Empty;
            compareButton.IsEnabled = isSuccess;
            selectAllDataButton.IsEnabled = isSuccess;
            clearAllDataButton.IsEnabled = isSuccess;
            selectAllFieldButton.IsEnabled = isSuccess;
            clearAllFieldButton.IsEnabled = isSuccess;
            menuSaveFile.IsEnabled = isSuccess;
            IntPtr hWnk = FindWindowByCaption(IntPtr.Zero, "Loading");
            //automatically close loading messagebox after finished connecting to SiNDY
            if (hWnk != IntPtr.Zero)
                PostMessage(hWnk, WM_CLOSE, 0, 0);
        }
        /// <summary>
        /// Auto change compare button text when user2 input textbox has a change.
        /// </summary>
        /// <param name="sender">triggered interface object</param>
        /// <param name="e">triggered event</param>
        private void user2TextChanged(object sender, TextChangedEventArgs e)
        {
            TextBox txtBox = sender as TextBox;
            if (String.IsNullOrWhiteSpace(user2.Text) || String.IsNullOrWhiteSpace(db2.Text))
            {
                compareButton.Content = "Get Data";
            }
            else
            {
                compareButton.Content = "Compare";
            }
        }
        //--------------------------------------------------------------IO PART------------------------------------------------------------------//
        /// <summary>
        /// When click 'Open Setting File' button, get all config data and update to interface
        /// </summary>
        /// <param name="sender">triggered interface object</param>
        /// <param name="e">triggered event</param>
        private void clickOpenFile(object sender, RoutedEventArgs e)
        {
            bool? isSuccess = m_IOManager.readConfigFile();
            //finished reading config file, update the interface.
            if (isSuccess == true)
            {
                db1.Text = m_IOManager.DB1Variable;
                db2.Text = m_IOManager.DB2Variable;
                user1.Text = m_IOManager.user1Variable;
                user2.Text = m_IOManager.user2Variable;
                version1.Text = m_IOManager.version1Variable;
                version2.Text = m_IOManager.version2Variable;
                System.Windows.MessageBox.Show("Successfully read the config file", "Success");
                clickGetDatasets(sender, e);
                m_interfaceData._m_currentlySelectedDataset = string.Empty;
            }
            else if (isSuccess == false)
            {
                bool failToOpenFile = false;
                resetInterface(failToOpenFile);
                System.Windows.MessageBox.Show("Failed to open the file. Please try another file.", "File Error");
                return;
            }
        }

        /// <summary>
        /// When click 'Save Setting File' button, write new config file
        /// </summary>
        /// <param name="sender">triggered interface object</param>
        /// <param name="e">triggered event</param>
        private void clickSaveFile(object sender, RoutedEventArgs e)
        {
            m_interfaceData._m_currentUser2 = user2.Text;
            m_interfaceData._m_currentDB2 = db2.Text;
            m_interfaceData._m_currentVersion2 = version2.Text;
            if (String.IsNullOrWhiteSpace(m_interfaceData._m_currentUser))
            {
                System.Windows.MessageBox.Show("Please connect to DBUser1 first", "Error");
                return;
            }
            if (m_IOManager.writeConfigFile()){
                System.Windows.MessageBox.Show("Successfully write the config file", "Success");
            }

        }

        /// <summary>
        /// When click 'Get Data/Compare' button, check all dataset's conditions correctness,
        /// and start writing to TSV file
        /// </summary>
        /// <param name="sender">triggered interface object</param>
        /// <param name="e">triggered event</param>
        private void clickGetOrCompareData(object sender, RoutedEventArgs e)
        {
            if (String.IsNullOrWhiteSpace(m_interfaceData._m_currentUser))
            {
                System.Windows.MessageBox.Show("Please connect to DBUser1 first.", "Error");
            }
            if ( !checkAllDatasetCondition())
            {
                return;
            }
            m_interfaceData._m_currentUser2 = user2.Text;
            m_interfaceData._m_currentDB2 = db2.Text;
            m_interfaceData._m_currentVersion2 = version2.Text;
            string filename = m_IOManager.selectWriteFileForTSV();
            if (filename == "cancel")
            {
                return;
            }
            //if user2 is not defined
            bool isCompare;
            if (String.IsNullOrWhiteSpace(m_interfaceData._m_currentUser2) || String.IsNullOrWhiteSpace(m_interfaceData._m_currentDB2))
            {
                isCompare = false;
                if (!m_IOManager.writeToTSV(filename, isCompare))
                {
                    return;
                }
            }
            //if user2 is defined
            else
            {
                isCompare = true;
                if (!m_IOManager.writeToTSV(filename, isCompare))
                {
                    return;
                }
            }
        }

        /// <summary>
        /// Connect to SiNDY and try to search each dataset data using written condition
        /// </summary>
        private bool checkAllDatasetCondition()
        {
            foreach (TextBox txtBox in FindVisualChildren<TextBox>(datasetWrapper))
            {
                int finding = txtBox.Name.IndexOf(suffix_condition);
                if (finding != -1)
                {
                    String SQLText = txtBox.Text;
                    String datasetName = txtBox.Name.Substring(0, finding);
                    if (m_interfaceData.isDatasetSelected(string.Empty, string.Empty, string.Empty, datasetName))
                    {
                        bool isCorrect = m_interfaceData.checkSQLSyntax(SQLText, datasetName);
                        if (!isCorrect)
                        {
                            System.Windows.MessageBox.Show(datasetName + ": has wrong search condition(syntax or variable)", "Condition Error");
                            txtBox.Background = Brushes.Tomato;
                            return false;
                        }
                    }

                }
            }
            return true;
        }
    }
}
