﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Runtime.InteropServices;

namespace DBStatsComparer
{
    /// <summary>
    /// Connect to SiNDY via ArcSDE and acquire selected user's datasets, fields and domains.
	/// also get total record count and total distance or area of each domain under specified where clause condition.
    /// can input second user to compare the data
    /// Input:
    ///     User1 -- Username, DB name, version
    ///     User2 -- Username, DB name, version
    /// Target data: 
    ///     dataset name
	///		field name
    ///     domain code, name
    ///     record count
    ///     Area, Distance (if avaliable)
    /// Output:
    ///     TSV file
    /// </summary>
    public partial class MainWindow : Window
    {
        //current tool version
        static private String TOOL_VERSION = "0.0.0.9";

        //necessary variable to automatically close messagebox
        [DllImport("user32.dll", EntryPoint = "FindWindow", SetLastError = true)]
        static extern IntPtr FindWindowByCaption(IntPtr ZeroOnly, string lpWindowName);
        [DllImport("user32.Dll")]
        static extern int PostMessage(IntPtr hWnd, UInt32 msg, int wParam, int lParam);
        const UInt32 WM_CLOSE = 0x0010;
        //related class
        public interfaceData m_interfaceData;
        public IOManager m_IOManager;
		
		//interface object and library resource
		//for dataset and field button
        static private String suffix_close = "_close";              
        static private String suffix_check = "_chk";
        static private String suffix_count = "_count";
        static private String suffix_condition = "_condit";
		//for resource
        static private String res_gridFieldButton = "gridFieldButton";
        static private String res_fieldButton = "fieldButton"; 
        static private String res_closeButton = "closeButton";
        static private String res_borderDatasetHeader = "borderDatasetHeader";
        static private String res_borderDatasetRow = "borderDatasetRow"; 
        static private String res_borderDatasetInner = "borderDatasetInner";
        static private String res_textBlockDataset = "textBlockDataset";
        static private String res_textBoxDataset = "textBoxDataset";
        /**
	    * @brief Initialize main component and data.
	    */
        public MainWindow()
        {
            InitializeComponent();
            m_interfaceData = new interfaceData();
            m_IOManager = new IOManager(m_interfaceData);
        }

        //--------------------------------------------------------------DATASET PART------------------------------------------------------------------//
        /**
	    * @brief Action when 'Get Datasets' button is clicked
        * 1. get dataset list from interfaceData class
        * 2. format dataset panel
        * 3. insert all table&featureClass rows into interface panel
	    * @param sender		    [in]	triggered interface object
	    * @param e	        	[in]    triggered event
	    */
        private void clickGetDatasets(object sender, RoutedEventArgs e)
        {   
			//get DBuser data from textboxes
            String user = user1.Text;
            String db = db1.Text;
            String version = version1.Text;
            if (String.IsNullOrWhiteSpace(user))
            {
                System.Windows.MessageBox.Show("Please input user1", "Input Error");
                return;
            }
            if (String.IsNullOrWhiteSpace(db))
            {
                System.Windows.MessageBox.Show("Please input db1", "Input Error");
                return;
            }
            if (String.IsNullOrWhiteSpace(version))
            {
                version = "SDE.DEFAULT";
            }
            user = user.ToUpper();
            m_interfaceData.setCurrentDB(db);
            m_interfaceData.setCurrentUser(user);
            m_interfaceData.setCurrentVersion(version);
            //show loading messagebox
            Task.Factory.StartNew(() =>
            {
                MessageBox.Show("Connecting to DB...","Loading");

            });
            //Connect to SiNDY
            if (!m_interfaceData.isDBAlreadyConnected(db, user, version))
            {
                bool isSuccess = m_interfaceData.connectToUser1();
                if (!isSuccess)
                {
                    IntPtr hWnds = FindWindowByCaption(IntPtr.Zero, "Loading");
                    if (hWnds != IntPtr.Zero)
                        PostMessage(hWnds, WM_CLOSE, 0, 0);
                    System.Windows.MessageBox.Show("Cannot connect to DB1", "Connection Error");
                    return;
                }
            }    
			//format dataset panel interface
            formatDatasetPanel();
			if (!getDatasetAndUpdateInterface(db, user, version, false))
            {
                formatDatasetPanel();
                formatFieldPanel();
                return;
            }
			if (!getDatasetAndUpdateInterface(db, user, version, true))
            {
                formatDatasetPanel();
                formatFieldPanel();
                return;
            }
            if (!m_IOManager.isAllInputNameCorrect())
            {
                formatDatasetPanel();
                formatFieldPanel();
                IntPtr hWnk = FindWindowByCaption(IntPtr.Zero, "Loading");
                if (hWnk != IntPtr.Zero)
                    PostMessage(hWnk, WM_CLOSE, 0, 0);
                return;
            }
            formatFieldPanel();
            //enable below buttons
            compareButton.IsEnabled = true;
            selectAllDataButton.IsEnabled = true;
            clearAllDataButton.IsEnabled = true;
            menuSaveFile.IsEnabled = true;
            //automatically close loading messagebox after finished connecting to SiNDY
            IntPtr hWnd = FindWindowByCaption(IntPtr.Zero, "Loading");
            if (hWnd != IntPtr.Zero)
                PostMessage(hWnd, WM_CLOSE, 0, 0);
        }
		/**
	    * @brief get featureclasses and tables data from SiNDY, then update to interface
	    * @param db		    [in]	target db
	    * @param user	    [in]    target user
		* @param version	[in]    target user version
		* @param isTable	[in]    get data as Table or Featureclass
        * @return true if success, false if failed.
	    */
		private bool getDatasetAndUpdateInterface(String db, String user, String version, bool isTable){
			List <String> datasetList;
			if (isTable) datasetList = m_interfaceData.getTableList(db, user, version);
			else datasetList = m_interfaceData.getFeatureClassList(db,user,version);
            if (datasetList.Contains("-1"))
            {
                IntPtr hWnd = FindWindowByCaption(IntPtr.Zero, "Loading");
                if (hWnd != IntPtr.Zero)
                    PostMessage(hWnd, WM_CLOSE, 0, 0);
                System.Windows.MessageBox.Show("Cannot acquire data from database", "Data Error");
                return false;
            }
            //update dataset row to interface
            for (int i = 0; i < datasetList.Count; i += 2)
            {
                String datasetName = datasetList[i];
                int recordCount = Int32.Parse(datasetList[i + 1]);
                //create dataset row into dataset panel
                createDatasetRow(datasetName, recordCount);
				//if load from config file or previous selection exist, auto select dataset row and paste input condition
                if (m_interfaceData.isDatasetExist(db, user, version, datasetName))
                {
                    //if load from config file and currently connect DB is the same as config file target DB, but dataset not selected
                    if (m_interfaceData.isCurrentAndPreviousDBUserSame() && !m_IOManager.isDatasetNameExist(datasetName,isTable))
                    {
                        m_interfaceData.setNewDataset(db, user, version, datasetName, isTable, true);
                    }
                    //Auto input condition
                    TextBox txtBox = (TextBox)LogicalTreeHelper.FindLogicalNode(datasetWrapper, datasetName + suffix_condition);
                        txtBox.Text = m_interfaceData.getDatasetCondition(db, user, version, datasetName); // condition string
                                                                                                           //Auto select dataset row
                        if (m_interfaceData.isDatasetSelected(db, user, version, datasetName)) // bool
                        {
                            CheckBox chkBox = (CheckBox)LogicalTreeHelper.FindLogicalNode(datasetWrapper, datasetName + suffix_check);
                            chkBox.IsChecked = true;
                        }
                    
                }
				//create new dataset
                else
                {
                    //if load from config file and currently connect DB is the same as config file target DB 
                    if (m_interfaceData.isCurrentAndPreviousDBUserSame())
                    {
                        m_interfaceData.setNewDataset(db, user, version, datasetName, isTable, true);
                    }
                    else
                    {
                        m_interfaceData.setNewDataset(db, user, version, datasetName, isTable, false);
                    }
                    
                }
                if (!isTable) m_interfaceData.setParentDatasetName(db, user, version, datasetName);
                //check if the name exists in input list (if load file);
                checkInputName(datasetName, isTable);
            }
            return true;
		}
        /**
	    * @brief if a config file is read, check if input dataset and field names exists in target DBUser
        * @param datasetName		[in]	Dataset Name
		* @param isTable	[in]    get data as Table or Featureclass
        * @return true if success, false if failed.
	    */
        private void checkInputName (String datasetName, bool isTable)
        {
            if (isTable) m_IOManager.removeInputTableName(datasetName);
            else m_IOManager.removeInputLayerName(datasetName);
            List<String> fieldList = m_interfaceData.getFieldNameList(datasetName);
            for (int i = 0; i < fieldList.Count; i++)
            {
                String fieldName = fieldList[i];
                m_IOManager.removeInputFieldName(datasetName + "." + fieldName);
            }
        }
        /**
        * @brief Clear dataset panel before inserting dataset row. 
        */
        private void formatDatasetPanel()
        {
            Border headTable = (Border)LogicalTreeHelper.FindLogicalNode(datasetWrapper, res_borderDatasetHeader);
            datasetWrapper.Children.Clear();
            datasetWrapper.Background = Brushes.White;
            datasetWrapper.Children.Add(headTable);
            tableScrollViewer.ScrollToTop();
        }
        /**
        * @brief Create all dataset rows interface from target DB when click 'get datasets' button
        * @param datasetName		[in]	Dataset Name
        * @param recoudCount	    [in]    The table's total record number
        */
        private void createDatasetRow(String datasetName, int recordCount)
        {
            //Create border for coloured border and grid for button layout
            //    WIDTH
            //   3  38   47   12  = 100%
            //   _______________
            //  |_|____|_____|__|  checkbox:datasetname:condition:recordcount

            //Create border
            Border newOuterBorder = new Border();
            newOuterBorder.Style = FindResource(res_borderDatasetRow) as Style;
            //Specify grid
            Grid newGrid = new Grid();
            double columnWidth1 = 3;
            double columnWidth2 = 38;
            double columnWidth3 = 47;
            double columnWidth4 = 12;
            ColumnDefinition gridCol = new ColumnDefinition();
            gridCol.Width = new GridLength(columnWidth1, GridUnitType.Star);
            ColumnDefinition gridCol2 = new ColumnDefinition();
            gridCol2.Width = new GridLength(columnWidth2, GridUnitType.Star);
            ColumnDefinition gridCol3 = new ColumnDefinition();
            gridCol3.Width = new GridLength(columnWidth3, GridUnitType.Star);
            ColumnDefinition gridCol4 = new ColumnDefinition();
            gridCol4.Width = new GridLength(columnWidth4, GridUnitType.Star);
            newGrid.ColumnDefinitions.Add(gridCol);
            newGrid.ColumnDefinitions.Add(gridCol2);
            newGrid.ColumnDefinitions.Add(gridCol3);
            newGrid.ColumnDefinitions.Add(gridCol4);
            //Create checkbox
            Viewbox newViewbox = new Viewbox();
            CheckBox newCheckbox = new CheckBox();
            newCheckbox.Name = datasetName + suffix_check;
            newCheckbox.Unchecked += datasetCheckboxSelected;
            newCheckbox.Checked += datasetCheckboxSelected;
            newViewbox.Child = newCheckbox;
            //Add checkbox into the layout
            newGrid.Children.Add(newViewbox);
            //Create dataset textblock and its border
            Border nameInnerBorder = new Border();
            nameInnerBorder.Style = FindResource(res_borderDatasetInner) as Style;
            nameInnerBorder.SetValue(Grid.ColumnProperty, 1);
            nameInnerBorder.Cursor = Cursors.Hand;
            TextBlock nameTextBlock = new TextBlock();
            nameTextBlock.Style = FindResource(res_textBlockDataset) as Style;
            nameTextBlock.Text = datasetName;
            nameTextBlock.PreviewMouseLeftButtonDown += ClickDatasetName;
            nameTextBlock.Name = datasetName;
            nameInnerBorder.Child = nameTextBlock;
            //Add textblock into the layout
            newGrid.Children.Add(nameInnerBorder);
            //Create condition textbox and its border
            Border conditionInnerBorder = new Border();
            conditionInnerBorder.Style = FindResource(res_borderDatasetInner) as Style;
            conditionInnerBorder.SetValue(Grid.ColumnProperty, 2);
            TextBox conditionTextBox = new TextBox();
            conditionTextBox.Style = FindResource(res_textBoxDataset) as Style;
            conditionTextBox.Name = datasetName + suffix_condition;
            conditionTextBox.PreviewKeyDown += pressEnterConditionField;
            conditionTextBox.LostFocus += lostFocusConditionField;
            conditionInnerBorder.Child = conditionTextBox;
            //Add textbox into the layout
            newGrid.Children.Add(conditionInnerBorder);
            //Create recordcount textblock and its border
            Border countInnerBorder = new Border();
            countInnerBorder.Style = FindResource(res_borderDatasetInner) as Style;
            countInnerBorder.SetValue(Grid.ColumnProperty, 3);
            TextBlock countTextBlock = new TextBlock();
            countTextBlock.Style = FindResource(res_textBlockDataset) as Style;
            countTextBlock.Text = recordCount.ToString();
            countTextBlock.Name = datasetName + suffix_count;
            countInnerBorder.Child = countTextBlock;
            //Add textblock into the layout
            newGrid.Children.Add(countInnerBorder);
            newOuterBorder.Child = newGrid;
            //Add the layout into dataset panel
            datasetWrapper.Children.Add(newOuterBorder);
        }
        /**
        * @brief When dataset checkbox is selected or deselected, update dataset select status.
        * @param sender		    [in]	triggered interface object
        * @param e	        	[in]    triggered event
        */
        private void datasetCheckboxSelected(object sender, RoutedEventArgs e)
        {
            CheckBox obj = sender as CheckBox;
            bool chkBoxChecked = (bool)obj.IsChecked;
            String datasetName = obj.Name.Substring(0, obj.Name.Length - suffix_check.Length);
            m_interfaceData.setDatasetSelected("", "", "", datasetName, chkBoxChecked);
        }
        /**
		* @brief When a datasetname textblock is clicked, show its field list and auto select field. 
		* @param sender		    [in]	triggered interface object
		* @param e	        	[in]    triggered event
		*/
        private void ClickDatasetName(object sender, RoutedEventArgs e)
        {
            DependencyObject obj = sender as DependencyObject;
            TextBlock txtBlock = sender as TextBlock;
            String datasetName = txtBlock.Name;
            //if this dataset is not selected already, show its field list
            if (datasetName != m_interfaceData.getCurrentlySelectedDataset())
            {
                m_interfaceData.setCurrentlySelectedDataset(datasetName);
                formatFieldPanel();
                //print all field buttons into field panel.
                setFieldList(datasetName);
                //check if there is any pre-selected field 
                List<Tuple<String, bool>> fieldInfo = new List<Tuple<String, bool>>(m_interfaceData.getDatasetFieldInfo("", "", "", datasetName));
                bool isSelectAll = m_interfaceData.isAllFieldSelected("", "", "", datasetName);
                foreach (Tuple<String, bool> eachField in fieldInfo)
                {
                    String fieldName = eachField.Item1;
                    if (eachField.Item2 == true || isSelectAll)
                    {
                        Button btn = (Button)LogicalTreeHelper.FindLogicalNode(fieldWrapper, fieldName);
                        btn.RaiseEvent(new RoutedEventArgs(Button.ClickEvent));
                    }
                }
            }
            //auto select the dataset's checkbox.
            String targetDataset;
            do
            {
                obj = LogicalTreeHelper.GetParent(obj);
                targetDataset = obj.GetType().Name;
            } while (targetDataset != "Grid");
            foreach (CheckBox chkBox in FindVisualChildren<CheckBox>(obj))
            {
                if (chkBox.IsChecked == false)
                    chkBox.IsChecked = true;
            }
            //enable field select or clear all button
            selectAllFieldButton.IsEnabled = true;
            clearAllFieldButton.IsEnabled = true;
            //set Label
            datasetName = datasetName.Replace("_", "__"); //fix label bug not show underscore correctly
            datasetLabel.Content = "Select target field(s) for " + datasetName;
        }
        /**
        * @brief press entered when keyboard focus on a condition textblock to update a change.
        * @param sender		    [in]	triggered interface object
        * @param e	        	[in]    triggered event
        */
        private void pressEnterConditionField(object sender, KeyEventArgs e)
        {
            if (Key.Enter == e.Key)
            {
                TextBox obj = sender as TextBox;
                String conditTxt = obj.Text;
                String datasetName = obj.Name.Substring(0, obj.Name.Length - suffix_condition.Length); 
                m_interfaceData.setDatasetCondition("", "", "", datasetName, conditTxt);
                Keyboard.ClearFocus();
                obj.Background = Brushes.Transparent;
            }
        }
        /**
        * @brief lost focus on a condition textblock to update a change.
        * @param sender		    [in]	triggered interface object
        * @param e	        	[in]    triggered event
        */
        private void lostFocusConditionField(object sender, RoutedEventArgs e)
        {
            TextBox obj = sender as TextBox;
            String conditTxt = obj.Text;
            String chkBoxName = obj.Name.Substring(0, obj.Name.Length - suffix_condition.Length) + suffix_check;
            String datasetName = obj.Name.Substring(0, obj.Name.Length - suffix_condition.Length);
            m_interfaceData.setDatasetCondition("", "", "", datasetName, conditTxt);
            obj.Background = Brushes.Transparent;
        }

        /**
        * @brief Select all dataset checkboxes programmatically when "Select All" button is clicked. Disable field select button too.
        * @param sender		    [in]	triggered interface object
        * @param e	        	[in]    triggered event
        */
        private void selectAllDatasets(object sender, RoutedEventArgs e)
        {
            foreach (CheckBox chkBox in FindVisualChildren<CheckBox>(datasetWrapper))
            {
                chkBox.IsChecked = true;
            }
            formatFieldPanel();
            m_interfaceData.setCurrentlySelectedDataset("");
            selectAllFieldButton.IsEnabled = false;
            clearAllFieldButton.IsEnabled = false;
        }
        /**
        * @brief Deselect all dataset checkboxes programmatically when "Clear All" button is clicked. Disable field select button too.
        * @param sender		    [in]	triggered interface object
        * @param e	        	[in]    triggered event
        */
        private void clearAllDatasets(object sender, RoutedEventArgs e)
        {
            foreach (CheckBox chkBox in FindVisualChildren<CheckBox>(datasetWrapper))
            {
                chkBox.IsChecked = false;
            }
            formatFieldPanel();
            m_interfaceData.setCurrentlySelectedDataset("");
            selectAllFieldButton.IsEnabled = false;
            clearAllFieldButton.IsEnabled = false;

        }
        //--------------------------------------------------------------FIELD PART------------------------------------------------------------------//
        /**
        * @brief Clear field panel before inserting field buttons. 
        */
        private void formatFieldPanel()
        {
            fieldWrapper.Children.Clear();
            fieldWrapper.Background = Brushes.White;
        }
        /**
        * @brief Print all field buttons into field panel 
        * @param dataset		[in]	target dataset name
        */
        private void setFieldList(String datasetName)
        {
            List<String> fieldList = m_interfaceData.getFieldNameList(datasetName);
            List<Tuple<String, bool>> newColumnInfo = new List<Tuple<String, bool>>();
			//create button 1 by 1
            for (int i = 0; i < fieldList.Count; i++)
            {
                String fieldName = fieldList[i];
                if (fieldName.Contains(".")) continue;
                createFieldButton(fieldName);
                Tuple<String, bool> newTuple = new Tuple<String, bool>(fieldName,false);
                newColumnInfo.Add(newTuple);
            }
			//if field data is empty (not load from config or previously selected)
            if (m_interfaceData.getDatasetFieldInfo("", "", "", datasetName).Count == 0)
            {
                m_interfaceData.setDatasetFieldInfo("", "", "", datasetName, newColumnInfo);
            }
        }
        /**
        * @brief Create a field button when a dataset is selected
        * @param fieldName		    [in]	Field Name [ex. OBJECTID]
        */
        private void createFieldButton(String fieldName)
        {

            //Create button layout
            //    WIDTH
            //   _______
            //  |_|_|_|_|  HEI
            //  |_|_|_|_|  GHT

            //Create grid
            Grid newGrid = new Grid();
            newGrid.Style = FindResource(res_gridFieldButton) as Style;
            ColumnDefinition gridCol = new ColumnDefinition();
            gridCol.Width = new GridLength(1, GridUnitType.Star);
            ColumnDefinition gridCol2 = new ColumnDefinition();
            gridCol2.Width = new GridLength(1, GridUnitType.Star);
            ColumnDefinition gridCol3 = new ColumnDefinition();
            gridCol3.Width = new GridLength(1, GridUnitType.Star);
            ColumnDefinition gridCol4 = new ColumnDefinition();
            gridCol4.Width = new GridLength(1, GridUnitType.Star);
            newGrid.ColumnDefinitions.Add(gridCol);
            newGrid.ColumnDefinitions.Add(gridCol2);
            newGrid.ColumnDefinitions.Add(gridCol3);
            newGrid.ColumnDefinitions.Add(gridCol4);
            RowDefinition gridRow = new RowDefinition();
            RowDefinition gridRow2 = new RowDefinition();
            gridRow.Height = new GridLength(1, GridUnitType.Star);
            gridRow2.Height = new GridLength(1, GridUnitType.Star);
            newGrid.RowDefinitions.Add(gridRow);
            newGrid.RowDefinitions.Add(gridRow2);
            //Create field button
            Button fieldButton = new Button();
            fieldButton.Style = FindResource(res_fieldButton) as Style;
            fieldButton.Content = fieldName;
            fieldButton.Click += clickFieldButton;
            fieldButton.Name = fieldName;
            //Create close button
            Button closeButton = new Button();
            closeButton.Style = FindResource(res_closeButton) as Style;
            closeButton.Visibility = Visibility.Hidden;
            closeButton.Click += clickCloseFieldButton;
            closeButton.Name = fieldName + suffix_close;
            //Add both buttons into the layout
            newGrid.Children.Add(closeButton);
            newGrid.Children.Add(fieldButton);
            //Add the layout into column panel
            fieldWrapper.Children.Add(newGrid);
        }
        /**
        * @brief Show animation and record selected column when a field button is clicked
        * @param sender		    [in]	triggered interface object
        * @param e	        	[in]    triggered event
        */
        private void clickFieldButton(object sender, RoutedEventArgs e)
        {
            Button btn = sender as Button;
            String fieldName = btn.Name;
            //if it not selected yet
            if (btn.Background == Brushes.White)
            {
                //change background to green and show close button
                btn.Background = Brushes.LightGreen;
                Button closeButton = (Button)LogicalTreeHelper.FindLogicalNode(fieldWrapper, fieldName + suffix_close);
                if (closeButton == null)
                {
                    return;
                }
                closeButton.Visibility = Visibility.Visible;
                //record select status
                m_interfaceData.setDatasetFieldSelected("", "", "", "", fieldName, true);
            }
        }
        /**
        * @brief Show animation and record deselected field when a close field button is clicked
        * @param sender		    [in]	triggered interface object
        * @param e	        	[in]    triggered event
        */
        private void clickCloseFieldButton(object sender, RoutedEventArgs e)
        {
            Button btn = sender as Button;
            String fieldName = btn.Name.Substring(0, btn.Name.Length - suffix_close.Length);
            Button fieldButton = (Button)LogicalTreeHelper.FindLogicalNode(fieldWrapper, fieldName);
            //change background to white and hide close button
            fieldButton.Background = Brushes.White;
            btn.Visibility = Visibility.Hidden;
            //record status into dict
            m_interfaceData.setDatasetFieldSelected("", "", "", "", fieldName, false);
            String datasetName = m_interfaceData.getCurrentlySelectedDataset();
            m_interfaceData.setAllFieldSelected("", "", "", datasetName, false);
        }
        /**
        * @brief Select all field programmatically when "Select All" button is clicked. 
        * @param sender		    [in]	triggered interface object
        * @param e	        	[in]    triggered event
        */
        private void selectAllFields(object sender, RoutedEventArgs e)
        {
            foreach(Button btn in FindVisualChildren<Button>(fieldWrapper))
            {
                int finding = btn.Name.IndexOf(suffix_close);
                if (finding == -1)
                    btn.RaiseEvent(new RoutedEventArgs(Button.ClickEvent));
            }
            String datasetName = m_interfaceData.getCurrentlySelectedDataset();
            m_interfaceData.setAllFieldSelected("", "", "", datasetName, true);
        }
        /**
        * @brief Deselect all fields programmatically when "Clear All" button is clicked. 
        * @param sender		    [in]	triggered interface object
        * @param e	        	[in]    triggered event
        */
        private void clearAllFields(object sender, RoutedEventArgs e)
        {
            foreach (Button btn in FindVisualChildren<Button>(fieldWrapper))
            {
                int finding = btn.Name.IndexOf(suffix_close);
                if (finding != -1)
                    btn.RaiseEvent(new RoutedEventArgs(Button.ClickEvent));
            }
            String datasetName = m_interfaceData.getCurrentlySelectedDataset();
            m_interfaceData.setAllFieldSelected("", "", "", datasetName, false);
        }
        //--------------------------------------------------------------INTERFACE UTILITY PART------------------------------------------------------------------//
        /**
        * @brief Find all child objects which match selected object type under the selected element
        * @param T    	     [in]	object type [ex. Checkbox, textblock]
        * @param depObj      [in]	parent element
        * return List of found object
        */
        private static IEnumerable<T> FindVisualChildren<T>(DependencyObject depObj) where T : DependencyObject
        {
            if (depObj != null)
            {
                for (int i = 0; i < VisualTreeHelper.GetChildrenCount(depObj); i++)
                {
                    DependencyObject child = VisualTreeHelper.GetChild(depObj, i);
                    if (child != null && child is T)
                    {
                        yield return (T)child;
                    }

                    foreach (T childOfChild in FindVisualChildren<T>(child))
                    {
                        yield return childOfChild;
                    }
                }
            }
        }
        /**
        * @brief Auto change compare button text when user2 input textbox has a change. 
        * @param sender		    [in]	triggered interface object
        * @param e	        	[in]    triggered event
        */
        private void user2TextChanged(object sender, TextChangedEventArgs e)
        {
            TextBox txtBox = sender as TextBox;
            if (String.IsNullOrWhiteSpace(user2.Text) || String.IsNullOrWhiteSpace(db2.Text))
            {
                compareButton.Content = "Get Data";
            }
            else
            {
                compareButton.Content = "Compare";
            }
        }
        //--------------------------------------------------------------IO PART------------------------------------------------------------------//
        /**
        * @brief When click 'Open Setting File' button, get all config data and update to interface
        * @param sender		    [in]	triggered interface object
        * @param e	        	[in]    triggered event
        */
        private void clickOpenFile(object sender, RoutedEventArgs e)
        {
            bool isSuccess = m_IOManager.readConfigFile();
            //finished reading config file, update the interface.
            if (isSuccess)
            {
                db1.Text = m_IOManager.getDB1Variable();
                db2.Text = m_IOManager.getDB2Variable();
                user1.Text = m_IOManager.getUser1Variable();
                user2.Text = m_IOManager.getUser2Variable();
                version1.Text = m_IOManager.getVersion1Variable();
                version2.Text = m_IOManager.getVersion2Variable();
                System.Windows.MessageBox.Show("Successfully read the config file", "Success");
                clickGetDatasets(sender, e);
                m_interfaceData.setCurrentlySelectedDataset("");
            }
            else
            {
                System.Windows.MessageBox.Show("Failed to open the file. Please try another file.", "File Error");
                return;
            }
        }

        /**
        * @brief When click 'Save Setting File' button, write new config file
        * @param sender		    [in]	triggered interface object
        * @param e	        	[in]    triggered event
        */
        private void clickSaveFile(object sender, RoutedEventArgs e)
        {
            m_interfaceData.setCurrentUser2(user2.Text);
            m_interfaceData.setCurrentDB2(db2.Text);
            m_interfaceData.setCurrentVersion2(version2.Text);
            if (String.IsNullOrWhiteSpace(m_interfaceData.getCurrentUser()))
            {
                System.Windows.MessageBox.Show("Please connect to DBUser1 first", "Error");
                return;
            }
            if (m_IOManager.writeConfigFile()){
                System.Windows.MessageBox.Show("Successfully write the config file", "Success");
            }
            
        }
        
        /**
        * @brief When click 'Get Data/Compare' button, check all dataset's conditions correctness, and start writing to TSV file 
        * @param sender		    [in]	triggered interface object
        * @param e	        	[in]    triggered event
        */
        private void clickGetOrCompareData(object sender, RoutedEventArgs e)
        {
            if (String.IsNullOrWhiteSpace(m_interfaceData.getCurrentUser()))
            {
                System.Windows.MessageBox.Show("Please connect to DBUser1 first.", "Error");
            }
            if ( !checkAllDatasetCondition())
            {
                return;
            }
            m_interfaceData.setCurrentDB2(db2.Text);
            m_interfaceData.setCurrentUser2(user2.Text);
            m_interfaceData.setCurrentVersion2(version2.Text);
            string filename = m_IOManager.selectWriteFileForTSV();
            if (filename == "cancel")
            {
                return;
            }
            //if user2 is not defined
            if (String.IsNullOrWhiteSpace(m_interfaceData.getCurrentUser2()) || String.IsNullOrWhiteSpace(m_interfaceData.getCurrentDB2()))
            {
                if (!m_IOManager.writeToTSV(filename, false))
                {
                    return;
                }
            }
            //if user2 is defined
            else
            {
                if (!m_IOManager.writeToTSV(filename, true))
                {
                    return;
                }
            }
        }
		/**
        * @brief Connect to SiNDY and try to search each dataset data using written condition
        */
        private bool checkAllDatasetCondition()
        {
            foreach (TextBox txtBox in FindVisualChildren<TextBox>(datasetWrapper))
            {
                int finding = txtBox.Name.IndexOf(suffix_condition);
                if (finding != -1)
                {
                    String SQLText = txtBox.Text;
                    String datasetName = txtBox.Name.Substring(0, finding);
                    if (m_interfaceData.isDatasetSelected("", "", "", datasetName))
                    {
                        bool isCorrect = m_interfaceData.checkSQLSyntax(SQLText, datasetName);
                        if (!isCorrect)
                        {
                            System.Windows.MessageBox.Show(datasetName + ": has wrong search condition(syntax or variable)", "Condition Error");
                            txtBox.Background = Brushes.Tomato;
                            return false;
                        }
                    }
                    
                }
            }
            return true;
        }
    }
}
