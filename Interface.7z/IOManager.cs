﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

public class IOManager
{
    //related class
    private interfaceData m_interfaceData;

    //variables
    private String user1Variable;
    private String DB1Variable;
    private String version1Variable;
    private String user2Variable;
    private String DB2Variable;
    private String version2Variable;
    private String delimiter = "\t";
    public IOManager(interfaceData interfaceData)
    {
        m_interfaceData = interfaceData;
    }
    public String getUser1Variable()
    {
        return user1Variable;
    }
    public String getDB1Variable()
    {
        return DB1Variable;
    }
    public String getVersion1Variable()
    {
        return version1Variable;
    }
    public String getUser2Variable()
    {
        return user2Variable;
    }
    public String getDB2Variable()
    {
        return DB2Variable;
    }
    public String getVersion2Variable()
    {
        return version2Variable;
    }
    public bool readFile()
    {
        // Create OpenFileDialog 
        Microsoft.Win32.OpenFileDialog dlg = new Microsoft.Win32.OpenFileDialog();
        // Set filter for file extension and default file extension 
        dlg.Filter = "Text Files (*.txt)|*.txt|INI Files (*.ini)|*.ini|All Files (*.*)|*.*";
        // Display OpenFileDialog by calling ShowDialog method 
        Nullable<bool> result = dlg.ShowDialog();
        // Get the selected file name and proceed the settings 
        if (result == true)
        {
            // Open document 
            String filename = dlg.FileName;
            String datasetName = "";
            bool isReadingField = false;
            List<String> previousLine = new List<String>();
            //proceed to read line by line
            foreach (String line in File.ReadLines(filename))
            {
                String editedLine = excludeCommentandTrim(line);
                //get DBuser info
                getDBUserInfo(editedLine);
                //while reading field...
                if (editedLine == "%TABLE" || editedLine == "%LAYER")
                {
                    //end of field list
                    if (isReadingField == true)
                    {
                        isReadingField = false;
                    }
                    else if (datasetName != "")
                    {
                        System.Windows.MessageBox.Show("Config file format is incorrect while reading field list of " + datasetName, "File Error");
                        return false;

                    }
                }
                //when find %FIELD, proceed to read a dataset's condition and dataset name, then start reading fields
                else if (editedLine == "%FIELD")
                {
                    //if reading field list but found field header again
                    if (isReadingField == true)
                    {
                        System.Windows.MessageBox.Show("Config file format is incorrect while reading field list of " + datasetName, "File Error");
                        return false;
                    }
                    //Acquire a dataset's condition and dataset name
                    String conditionTxt = "";
                    for (int i = previousLine.Count - 1; i >= 0; i--)
                    {
                        //have condition
                        if (previousLine[i] == "%WHERE")
                        {
                            datasetName = previousLine[i - 1];
                            if (previousLine[i - 2] == "%TABLE") m_interfaceData.setNewDataset(DB1Variable, user1Variable, version1Variable, datasetName, true, true);
                            else m_interfaceData.setNewDataset(DB1Variable, user1Variable, version1Variable, datasetName, false, true);
                            m_interfaceData.setDatasetSelected(DB1Variable, user1Variable, version1Variable, datasetName, true);
                            m_interfaceData.setDatasetCondition(DB1Variable, user1Variable, version1Variable, datasetName, conditionTxt);
                            break;
                        }
                        //not have condition
                        else if (previousLine[i] == "%TABLE" || previousLine[i] == "%LAYER")
                        {
                            datasetName = previousLine[i + 1].Trim();
                            if (previousLine[i] == "%TABLE") m_interfaceData.setNewDataset(DB1Variable, user1Variable, version1Variable, datasetName, true, true);
                            else m_interfaceData.setNewDataset(DB1Variable, user1Variable, version1Variable, datasetName, false, true);
                            m_interfaceData.setDatasetSelected(DB1Variable, user1Variable, version1Variable, datasetName, true);
                            break;
                        }
                        //read till very first line == error
                        else if (i == 0)
                        {
                            System.Windows.MessageBox.Show("Config file format is incorrect while reading condition of " + datasetName, "File Error");
                            break;
                        }
                        //concat condition string
                        conditionTxt = previousLine[i] + " " + conditionTxt;
                    }
                    //start reading field list
                    isReadingField = true;
                }
                //reading field list
                else if (isReadingField)
                {
                    setField(editedLine.Trim(), datasetName);
                }
                previousLine.Add(editedLine);
            }
        }
        return true;
    }
    /**
    * @brief Get a string line, delete comment (#...) and trim whitespace
    * @param line		    [in]	input string line
    * @return   processed string
    */
    public String excludeCommentandTrim(String line)
    {
        if (line.IndexOf("#") != -1)
            return line.Substring(0, line.IndexOf("#")).Trim();
        else
            return line.Trim();
    }
    /**
    * @brief Get a string line, detect if a line is related to DBuser information and copy to a class variable
    * @param userInfo		    [in]	input string line
    */
    public void getDBUserInfo(String userInfo)
    {
        if (userInfo.Contains("user_1"))
        {
            user1Variable = getLineVariable(userInfo);
        }
        else if (userInfo.Contains("user_2"))
        {
            user2Variable = getLineVariable(userInfo);
        }
        else if (userInfo.Contains("server_1"))
        {
            DB1Variable = getLineVariable(userInfo);
        }
        else if (userInfo.Contains("server_2"))
        {
            DB2Variable = getLineVariable(userInfo);
        }
        else if (userInfo.Contains("version_1"))
        {
            version1Variable = getLineVariable(userInfo);
            if (String.IsNullOrWhiteSpace(version1Variable))
            {
                version1Variable = "SDE.DEFAULT";
            }
        }
        else if (userInfo.Contains("version_2"))
        {
            version2Variable = getLineVariable(userInfo);
            if (String.IsNullOrWhiteSpace(version2Variable))
            {
                version2Variable = "SDE.DEFAULT";
            }
        }
    }
    /**
    * @brief Get variable value from a line in config file [ex. user_1 = TEST2017]
    * @param userInfo	    [in]	input string line
    * @return   variable value [ex. TEST2017]
    */
    public String getLineVariable(String userInfo)
    {
        int start = userInfo.IndexOf('=') + 1;
        int end = userInfo.Length;
        String variableValue = userInfo.Substring(start, end - start).Trim();
        return variableValue;
    }
    /**
    * @brief Get field selection into interfaceData for later process.
    * @param fieldName		    [in]	column name
    * @param datasetName		[in]	dataset name
    */
    public void setField(String fieldName, String datasetName)
    {
        //if none selected
        if (fieldName == "-" || String.IsNullOrWhiteSpace(fieldName))
        {
            return;
        }
        //if all selected
        else if (fieldName == "*")
        {
            m_interfaceData.setAllFieldSelected(DB1Variable, user1Variable, version1Variable, datasetName, true);

            return;
        }
        //insert 1 field
        m_interfaceData.setDatasetFieldSelected(DB1Variable, user1Variable, version1Variable, datasetName, fieldName, true);
    }
    public void writeFile()
    {
        // Create OpenFileDialog 
        Microsoft.Win32.SaveFileDialog dlg = new Microsoft.Win32.SaveFileDialog();

        // Set filter for file extension and default file extension 
        dlg.Filter = "Text Files (*.txt)|*.txt|INI Files (*.ini)|*.ini|All Files (*.*)|*.*";

        // Display OpenFileDialog by calling ShowDialog method 
        Nullable<bool> result = dlg.ShowDialog();

        // Get the selected file name and display in a TextBox 
        if (result == true)
        {
            // Open document 
            String filename = dlg.FileName;
            List<String> configText = new List<String>();
            configText.Add("###CONFIG LIST###");
            configText.Add("");
            configText.Add("##User 1 information");
            configText.Add("user_1=" + m_interfaceData.getCurrentUser());
            configText.Add("server_1=" + m_interfaceData.getCurrentDB());
            configText.Add("version_1=" + m_interfaceData.getCurrentVersion() + "\t#BLANK = 'SDE.DEFAULT'");
            configText.Add("##User 2 information");
            configText.Add("user_2=" + m_interfaceData.getCurrentUser2());
            configText.Add("server_2=" + m_interfaceData.getCurrentDB2());
            configText.Add("version_2=" + m_interfaceData.getCurrentVersion2() + "\t#BLANK = 'SDE.DEFAULT'");
            configText.Add("");
            configText.Add("##Layer, table and field list");
            configText.Add("#Below is format for input data");
            configText.Add("#%TABLE");
            configText.Add("#<TABLE_NAME>");
            configText.Add("#%WHERE");
            configText.Add("#<CONDITION>");
            configText.Add("#%FIELD");
            configText.Add("#<FIELD_NAME1>");
            configText.Add("#<FIELD_NAME2>");
            configText.Add("#:");
            configText.Add("#%LAYER");
            configText.Add("#<LAYER_NAME>");
            configText.Add("#%FIELD");
            configText.Add("#<FIELD_NAME1>");
            configText.Add("#<FIELD_NAME2>");
            configText.Add("#:");
            configText.Add("");
            configText.Add("#If you want a table or layer to output all fields: use '*' under %FIELD line");
            configText.Add("#If you want a table or layer to output no field: use '-' under %FIELD line");
            //get table with selected condition
            Dictionary<String, interfaceData.datasetInfo> datasetList = m_interfaceData.getDatasetList();
            foreach (KeyValuePair<String, interfaceData.datasetInfo> dataset in datasetList)
            {
                interfaceData.datasetInfo datasetInf = dataset.Value;
                //if not select, skip
                if (!datasetInf.isDatasetSelected)
                    continue;
                String datasetName = dataset.Key;
                int a = datasetName.LastIndexOf(m_interfaceData.getDatasetListKeywordSeparator());
                int b = datasetName.Length;
                datasetName = datasetName.Substring(a + 1, b - a - 1);
                //add %TABLE or %LAYER and dataset line
                if (datasetInf.isTable) configText.Add("%TABLE");
                else configText.Add("%LAYER");
                configText.Add(datasetName);
                //if condition is not empty, add %WHERE and condition line
                String datasetCondition = datasetInf.searchCondition;
                if (!String.IsNullOrWhiteSpace(datasetCondition))
                {
                    configText.Add("%WHERE");
                    configText.Add(datasetCondition);
                }
                //get selected column
                configText.Add("%FIELD");
                //if select all
                if (datasetInf.isFieldSelectedAll)
                {
                    configText.Add("*");
                    continue;
                }
                List<Tuple<String, bool>> fieldList = datasetInf.fieldInfo;
                //if select none
                if (fieldList.Count <= 0)
                {
                    configText.Add("-");
                    continue;
                }
                foreach (Tuple<String, bool> field in fieldList)
                {
                    if (field.Item2 == true) //if selected
                        configText.Add(field.Item1); //add field name
                }
                configText.Add("");
            }
            configText.Add("###End of File###");
            File.WriteAllLines(filename, configText);
        }
    }
    public bool writeTSV()
    {
        // Create OpenFileDialog 
        Microsoft.Win32.SaveFileDialog dlg = new Microsoft.Win32.SaveFileDialog();

        // Set filter for file extension and default file extension 
        dlg.Filter = "TSV Files (*.tsv)| *.tsv";

        // Display OpenFileDialog by calling ShowDialog method 
        Nullable<bool> fileResult = dlg.ShowDialog();

        // Get the selected file name and display in a TextBox 
        if (fileResult == true)
        {
            // Open document 
            String filename = dlg.FileName;
            //if user2 is not defined
            if (String.IsNullOrWhiteSpace(m_interfaceData.getCurrentUser2()) || String.IsNullOrWhiteSpace(m_interfaceData.getCurrentDB2()))
            {
                printDataToTSV(filename, false);
            }
            //if user2 is defined
            else
            {
                printDataToTSV(filename, true);
            }
        }
        else
        {
            return false;
        }
        return true;
    }
    /**
    * @brief print all selection and condition to TSV file. While including header and check for error
    * @param fileName	    [in]	TSV filename
    * @param isCompare     	[in]    only get 1 user or compare 2 users data
    */
    public void printDataToTSV(String filename, bool isCompare)
    {
        List<String> tsvText = new List<String>();

        //print TSV header
        List<String> tsvHeader;
        if (isCompare)
        {
            tsvHeader = new List<String> { "DATASET", "NAME", "QUERY_KEYWORD", "CODE", "DESCRIPTION", "RECORD_COUNT1", "DISTANCE(KM) AREA(KM2)", "RECORD_COUNT2", "DISTANCE(KM) AREA(KM2)" };
            bool isSuccess = m_interfaceData.connectToUser2();
            if (!isSuccess)
            {
                System.Windows.MessageBox.Show("Cannot connect to DB 2", "Connection Error");
                return;
            }
        }
        else
        {
            tsvHeader = new List<String> { "DATASET", "NAME", "QUERY_KEYWORD", "CODE", "DESCRIPTION", "RECORD_COUNT", "DISTANCE(KM) AREA(KM2)" };
        }
        String headerLine = String.Join(delimiter, tsvHeader);
        tsvText.Add(headerLine);
        //get dataset 1 by 1
        Dictionary<String, interfaceData.datasetInfo> datasetList = m_interfaceData.getDatasetList();
        foreach (KeyValuePair<String, interfaceData.datasetInfo> dataset in datasetList)
        {
            interfaceData.datasetInfo datasetInf = dataset.Value;
            //if not select, skip
            if (!datasetInf.isDatasetSelected)
                continue;
            String datasetName = dataset.Key;
            int a = datasetName.LastIndexOf(m_interfaceData.getDatasetListKeywordSeparator());
            int b = datasetName.Length;
            datasetName = datasetName.Substring(a + 1, b - a - 1);

            String datasetCondition = datasetInf.searchCondition;
            //get processed TSV format dataset data
            String datasetRow = String.Join(delimiter, getDatasetRow(datasetName, datasetCondition, isCompare));
            tsvText.Add(datasetRow);
            //to print field list
            List<Tuple<String, bool>> fieldList = datasetInf.fieldInfo;
            //if select none
            if (fieldList.Count <= 0)
            {
                continue;
            }
            String currentDB = m_interfaceData.getCurrentDB();
            String currentUser = m_interfaceData.getCurrentUser();
            String currentVersion = m_interfaceData.getCurrentVersion();
            foreach (Tuple<String, bool> field in fieldList)
            {
                if (field.Item2 == true || datasetInf.isFieldSelectedAll) //if selected
                {
                    // if the field has no domain, print only 1 line
                    if (!m_interfaceData.m_DBComparer.hasDomain(currentDB, currentUser, currentVersion, datasetName, field.Item1))
                    {
                        String fieldRow = String.Join(delimiter, getSingleFieldRow(field.Item1, isCompare));
                        tsvText.Add(fieldRow); //add field name
                    }
                    else
                    {
                        List<String> multiFieldRow = getMultiFieldRow(datasetName, datasetCondition, field.Item1, isCompare);
                        foreach (String line in multiFieldRow)
                        {
                            tsvText.Add(line);
                        }
                    }
                }

            }
        }
        File.WriteAllLines(filename, tsvText);
        if (isCompare)
        {
            System.Windows.MessageBox.Show(" Successfully output the compare result to the TSV file", "Success");
        }
        else
        {
            System.Windows.MessageBox.Show(" Successfully output the result to the TSV file", "Success");
        }
    }
    /**
    * @brief Get TSV format table data
    * @param dataSetName	        [in]	dataset name
    * @param datasetCondition       [in]    dataset search condition
    * @param isCompare     	        [in]    only get 1 user or compare 2 users data
    * return one line of string which is dataset data in TSV format
    */
    public List<String> getDatasetRow(String datasetName, String datasetCondition, bool isCompare)
    {
        /// TO ADD DATASET NAME
        String parentDataset = "*";
        if (m_interfaceData.isDatasetTable("", "", "", datasetName))
        {
            parentDataset = m_interfaceData.getParentDatasetName("", "", "", datasetName);
        }
        String currentDB = m_interfaceData.getCurrentDB();
        String currentUser = m_interfaceData.getCurrentUser();
        String currentVersion = m_interfaceData.getCurrentVersion();
        String code = "";
        String description = "";
        String recordCount = m_interfaceData.getRecordNumber(datasetCondition, currentDB, currentUser, currentVersion, datasetName);
        String distArea = m_interfaceData.getTotalDistArea(datasetCondition, currentDB, currentUser, currentVersion, datasetName);
        List<String> datasetRow;
        if (isCompare)
        {
            String currentDB2 = m_interfaceData.getCurrentDB2();
            String currentUser2 = m_interfaceData.getCurrentUser2();
            String currentVersion2 = m_interfaceData.getCurrentVersion2();
            String recordCount2 = m_interfaceData.getRecordNumber(datasetCondition, currentDB2, currentUser2, currentVersion2, datasetName);
            String distArea2 = m_interfaceData.getTotalDistArea(datasetCondition, currentDB2, currentUser2, currentVersion2, datasetName).ToString();
            datasetRow = new List<String> { parentDataset, datasetName, datasetCondition, code, description, recordCount, distArea, recordCount2, distArea2 };
        }
        else
        {
            datasetRow = new List<String> { parentDataset, datasetName, datasetCondition, code, description, recordCount, distArea };
        }

        return datasetRow;
    }
    /**
    * @brief Get TSV format field data
    * @param fieldName	            [in]	field name
    * @param isCompare     	        [in]    only get 1 user or compare 2 users data
    * return one line of string which is field data in TSV format
    */
    public List<String> getSingleFieldRow(String fieldName, bool isCompare)
    {
        String parentDataset = "";
        String condition = "";
        String code = "";
        String description = "";
        String recordCount = "";
        String distArea = "";
        List<String> fieldRow;
        if (isCompare)
        {
            fieldRow = new List<String> { parentDataset, fieldName, condition, code, description, recordCount, distArea, recordCount, distArea };
        }
        else
        {
            fieldRow = new List<String> { parentDataset, fieldName, condition, code, description, recordCount, distArea };
        }
        return fieldRow;
    }
    /**
    * @brief Get TSV format column data
    * @param datasetName            [in]    dataset name
    * @param datasetCondtion        [in]    search condition
    * @param fieldName	            [in]	field name
    * @param isCompare     	        [in]    only get 1 user or compare 2 users data
    * return multiple lines of string which is field and domain data in TSV format
    */
    public List<String> getMultiFieldRow(String datasetName, String datasetCondition, String fieldName, bool isCompare)
    {
        // get all domain
        // print one line with code and desc
        // also search record_count and distArea using that domain
        String parentDataset = "";
        String condition = "";
        String currentDB = m_interfaceData.getCurrentDB();
        String currentUser = m_interfaceData.getCurrentUser();
        String currentVersion = m_interfaceData.getCurrentVersion();
        List<String> domainDetails = m_interfaceData.getDomainNameList(datasetName, fieldName);
        String code = domainDetails[0];
        String description = "";
        String totalRecordCount = m_interfaceData.getRecordNumber(datasetCondition, currentDB, currentUser, currentVersion, datasetName);
        String totalDistArea = m_interfaceData.getTotalDistArea(datasetCondition, currentDB, currentUser, currentVersion, datasetName);

        List<String> multiFieldRow = new List<String>();
        if (isCompare)
        {
            String currentDB2 = m_interfaceData.getCurrentDB2();
            String currentUser2 = m_interfaceData.getCurrentUser2();
            String currentVersion2 = m_interfaceData.getCurrentVersion2();
            String totalRecordCount2 = m_interfaceData.getRecordNumber(datasetCondition, currentDB2, currentUser2, currentVersion2, datasetName);
            String totalDistArea2 = m_interfaceData.getTotalDistArea(datasetCondition, currentDB2, currentUser2, currentVersion2, datasetName).ToString();
            List<String> fieldRow = new List<String> { parentDataset, fieldName, condition, code, description, totalRecordCount, totalDistArea, totalRecordCount2, totalDistArea2 };
            String convertedFieldRow = String.Join(delimiter, fieldRow);
            multiFieldRow.Add(convertedFieldRow);
            for (int i = 1; i < domainDetails.Count; i += 2)
            {
                code = domainDetails[i];
                description = domainDetails[i + 1];
                String SQLText = datasetCondition + " AND " + fieldName + " = " + code; //ex. where OBJECTID > 10 AND PRODUCT_C = 3
                String fieldRecordCount = m_interfaceData.getRecordNumber(SQLText, currentDB, currentUser, currentVersion, datasetName);
                String fieldRecordCount2 = m_interfaceData.getRecordNumber(SQLText, currentDB2, currentUser2, currentVersion2, datasetName);
                String fieldDistArea = m_interfaceData.getTotalDistArea(SQLText, currentDB, currentUser, currentVersion, datasetName);
                String fieldDistArea2 = m_interfaceData.getTotalDistArea(SQLText, currentDB2, currentUser2, currentVersion2, datasetName);
                fieldRow = new List<String> { parentDataset, fieldName, condition, code, description, fieldRecordCount, fieldDistArea, fieldRecordCount2, fieldDistArea2 };
                convertedFieldRow = String.Join(delimiter, fieldRow);
                multiFieldRow.Add(convertedFieldRow);
            }
        }
        else
        {
            List<String> fieldRow = new List<String> { parentDataset, fieldName, condition, code, description, totalRecordCount, totalDistArea };
            String convertedFieldRow = String.Join(delimiter, fieldRow);
            multiFieldRow.Add(convertedFieldRow);
            for (int i = 1; i < domainDetails.Count; i += 2)
            {
                code = domainDetails[i];
                description = domainDetails[i + 1];
                String SQLText = datasetCondition + " AND " + fieldName + " = " + code; //ex. where OBJECTID > 10 AND PRODUCT_C = 3
                String fieldRecordCount = m_interfaceData.getRecordNumber(SQLText, currentDB, currentUser, currentVersion, datasetName);
                String fieldDistArea = m_interfaceData.getTotalDistArea(SQLText, currentDB, currentUser, currentVersion, datasetName);
                fieldRow = new List<String> { parentDataset, fieldName, condition, code, description, fieldRecordCount, fieldDistArea };
                convertedFieldRow = String.Join(delimiter, fieldRow);
                multiFieldRow.Add(convertedFieldRow);
            }

        }
        return multiFieldRow;
    }
}
