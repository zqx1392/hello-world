﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Threading.Tasks;
using System.Runtime.InteropServices;
using System.Linq;
/// <summary>
/// Manage all input and output files (except log file)
/// 1. config file
/// 2. TSV file
/// Parse input data from config file to interfaceData for server-side management
/// Parse output data from interfaceData to output TSV file and config file
/// </summary>
public class IOManager
{
    //necessary variable to automatically close messagebox
    [DllImport("user32.dll", EntryPoint = "FindWindow", SetLastError = true)]
    static extern IntPtr FindWindowByCaption(IntPtr ZeroOnly, string lpWindowName);
    [DllImport("user32.Dll")]
    static extern int PostMessage(IntPtr hWnd, UInt32 msg, int wParam, int lParam);
    const UInt32 WM_CLOSE = 0x0010;

    //related class
    private interfaceData m_interfaceData;

    //variables
    public String user1Variable { get; private set; }
    public String DB1Variable { get; private set; }
    public String version1Variable { get; private set; }
    public String user2Variable { get; private set; }
    public String DB2Variable { get; private set; }
    public String version2Variable { get; private set; }
    private String delimiter = "\t";

    //record all name from input config file, and check if each name exists in database or not later.
    private HashSet<String> inputTableNameList;
    private HashSet<String> inputLayerNameList;
    private HashSet<String> inputFieldNameList;


    //initializer
    public IOManager(interfaceData interfaceData)
    {
        m_interfaceData = interfaceData;
        inputTableNameList = new HashSet<String>();
        inputLayerNameList = new HashSet<String>();
        inputFieldNameList = new HashSet<String>();
    }

    /// <summary>
    /// Remove target table from input config table name list if exists
    /// </summary>
    /// <param name="tableName">target table</param>
    /// <returns>true if exist and removed, false if not</returns>
    public bool isRemoveInputTableName (String tableName)
    {
        if (inputTableNameList.Contains(tableName))
        {
            inputTableNameList.Remove(tableName);
            return true;
        }
		return false;
    }
    /// <summary>
    /// Remove target layer from input config layer name list if exists
    /// </summary>
    /// <param name="layerName">target layer</param>
    /// <returns>true if exist and removed, false if not</returns>
    public bool isRemoveInputLayerName(String layerName)
    {
        if (inputLayerNameList.Contains(layerName))
        {
            inputLayerNameList.Remove(layerName);
			return true;
        }
		return false;
    }
    /// <summary>
    /// Remove target field from input config field name list if exists
    /// </summary>
    /// <param name="fieldName">target field</param>
    /// <returns>true if exist and removed, false if not</returns>
    public bool isRemoveInputFieldName(String fieldName)
    {
        if (inputFieldNameList.Contains(fieldName))
        {
            inputFieldNameList.Remove(fieldName);
			return true;
        }
		return false;
    }
    /// <summary>
    /// if a config file is read, check if input dataset and field names exists in target DBUser
    /// </summary>
    /// <param name="datasetName">target dataset</param>
    /// <param name="isTable">is dataset a table or a featureclass</param>
    /// <returns>true if success, false if fail</returns>
    public void checkInputName(String datasetName, bool isTable)
    {
        bool isHave = false;
        if (isTable) isHave = isRemoveInputTableName(datasetName);
        else isHave = isRemoveInputLayerName(datasetName);
        if (isHave)
        {
            List<String> fieldList = m_interfaceData.getFieldNameList(datasetName);
            for (int i = 0; i < fieldList.Count; i++)
            {
                String fieldName = fieldList[i];
                String fullFieldName = datasetName + "." + fieldName;
                isRemoveInputFieldName(fullFieldName);
            }
        }
    }
    /// <summary>
    /// Check whether a dataset name is mentioned in input config file
    /// </summary>
    /// <param name="datasetName">target dataset</param>
    /// <param name="isTable">is dataset a table or a featureclass</param>
    /// <returns>true if yes, false if no</returns>
    public bool isDatasetNameExistInConfig(String datasetName, bool isTable)
    {
        if (isTable && inputTableNameList.Contains(datasetName))
        {
            return true;
        }
        if (inputLayerNameList.Contains(datasetName))
        {
            return true;
        }
        return false;
    }
    /// <summary>
    /// Check that all input names in input config file are legally exists in DBUser
    /// If all exists DBUser data removed from checklist input***NameList then all data names are correct
    /// </summary>
    /// <returns>true if yes, false if no</returns>
    public bool isAllInputNameCorrect()
    {
        if (inputTableNameList.Count != 0)
        {
            String tableNames = string.Empty;
            foreach (String name in inputTableNameList)
            {
                if (String.IsNullOrWhiteSpace(tableNames))
                {
                    tableNames = name;
                }
                else
                {
                    tableNames += ", " + name;
                }
            }
            System.Windows.MessageBox.Show("Incorrect table name(s): " + tableNames, "File Error");
            return false;
        }
        if (inputLayerNameList.Count != 0)
        {
            String layerNames = string.Empty;
            foreach (String name in inputLayerNameList)
            {
                if (String.IsNullOrWhiteSpace(layerNames))
                {
                    layerNames = name;
                }
                else
                {
                    layerNames += ", " + name;
                }
            }
            System.Windows.MessageBox.Show("Incorrect layer name(s): " + layerNames, "File Error");
            return false;
        }
        if (inputFieldNameList.Count != 0)
        {
            String fieldNames = string.Empty;
            foreach (String name in inputFieldNameList)
            {
                if (String.IsNullOrWhiteSpace(fieldNames))
                {
                    fieldNames = name;
                }
                else
                {
                    fieldNames += ", " + name;
                }
            }
            System.Windows.MessageBox.Show("Incorrect field name(s): " + fieldNames, "File Error");
            return false;
        }
        return true;
    }
    /// <summary>
    /// Read a config file, get all config data into interfaceData before connecting to target DBuser
    /// </summary>
    /// <returns>true if suvvess, false if not, null if cancel</returns>
    public bool? readConfigFile()
    {
        // Create OpenFileDialog
        Microsoft.Win32.OpenFileDialog dlg = new Microsoft.Win32.OpenFileDialog();
        // Set filter for file extension and default file extension
        dlg.Filter = "Text Files (*.txt)|*.txt|INI Files (*.ini)|*.ini";
        // Display OpenFileDialog by calling ShowDialog method
        Nullable<bool> result = dlg.ShowDialog();
        // Get the selected file name and proceed the settings
        if (result == true)
        {
            //set name checker list
            inputTableNameList = new HashSet<String>();
            inputLayerNameList = new HashSet<String>();
            inputFieldNameList = new HashSet<String>();
            // Open document
            String filename = dlg.FileName;
            String datasetName = string.Empty;
            String db1 = DB1Variable;
            String user1 = user1Variable;
            String version1 = version1Variable;
            bool isGettingTableOrLayer = true;
            bool isGettingWhereOrField = false;
            bool isGettingField = false;
            List<String> lines = new List<String>();
            //clear comment
            foreach (String line in File.ReadLines(filename))
            {
                String editedLine = excludeCommentandTrim(line);
                //get DBuser info line, if not then add to processing lines
                if (!getDBUserInfo(editedLine))
                {
                    lines.Add(editedLine);
                }
            }
            for (int i = 0; i < lines.Count; i++)
            {
                //get dataset name and create record into m_interfaceData
                if ((lines[i] == "%TABLE" || lines[i] == "%LAYER") && isGettingTableOrLayer)
                {
                    if (i + 1 >= lines.Count)
                    {
                        System.Windows.MessageBox.Show("Found incorrect config file format while reading layer or table name", "File Error");
                        return false;
                    }
                    datasetName = lines[i + 1];
                    bool isOverwrite = true;
                    if (lines[i] == "%TABLE")
                    {
                        bool isTable = true;
                        m_interfaceData.setNewDataset(db1, user1, version1, datasetName, isTable, isOverwrite);   //create new table
                        inputTableNameList.Add(datasetName);
                    }

                    else
                    {
                        bool isTable = false;
                        m_interfaceData.setNewDataset(db1, user1, version1, datasetName, isTable, isOverwrite);  //create new dataset
                        inputLayerNameList.Add(datasetName);
                    }
                    bool isSelected = true;
                    m_interfaceData.setDatasetSelected(db1, user1, version1, datasetName, isSelected);        //set new dataset as selected
                    isGettingTableOrLayer = false;
                    isGettingWhereOrField = true;
                    i++;
                }
                //get where clause (if available) and record into m_interfaceDAta
                else if (lines[i] == "%WHERE" && isGettingWhereOrField)
                {
                    if (i + 1 >= lines.Count)
                    {
                        System.Windows.MessageBox.Show("Found incorrect config file format while reading " + datasetName + " where clause", "File Error");
                        return false;
                    }
                    String conditionTxt = string.Empty;
                    int j;
                    for (j = i + 1; j < lines.Count; j++)
                    {
                        if (lines[j] == "%FIELD")
                        {
                            j--;
                            break;
                        }

                        if (lines[j] == "%WHERE" || lines[j] == "%TABLE" || lines[j] == "%LAYER" || j + 1 >= lines.Count)
                        {
                            System.Windows.MessageBox.Show("Found incorrect config file format while reading " + datasetName + " where clause", "File Error");
                            return false;
                        }
                        conditionTxt += lines[j] + " ";
                    }
                    if (String.IsNullOrWhiteSpace(conditionTxt))
                    {
                        System.Windows.MessageBox.Show("Found incorrect config file format while reading " + datasetName + " where clause", "File Error");
                        return false;
                    }
                    i = j;
                    m_interfaceData.setDatasetCondition(db1, user1, version1, datasetName,conditionTxt);
                    isGettingWhereOrField = false;
                    isGettingField = true;
                }
                //get fields and record into m_interfaceDAta
                else if (lines[i] == "%FIELD" && (isGettingWhereOrField || isGettingField))
                {
                    if (i + 1 >= lines.Count)
                    {
                        System.Windows.MessageBox.Show("Found incorrect config file format while reading " + datasetName + " field", "File Error");
                        return false;
                    }
                    if (lines[i + 1] == "-")
                    {
                        i++;
                    }
                    else if (lines[i + 1] == "*")
                    {
                        bool isSelected = true;
                        m_interfaceData.setAllFieldSelected(db1, user1, version1, datasetName, isSelected);
                        i++;
                    }
                    else
                    {
                        bool isAnyFieldReceived = false;
                        int j = i;
                        for (j = i + 1; j < lines.Count; j++)
                        {
                            if (lines[j] == "*" || lines[j] == "-" || lines[j] == "%WHERE" || lines[j] == "%FIELD")
                            {
                                System.Windows.MessageBox.Show("Found incorrect config file format while reading " + datasetName + " field", "File Error");
                                return false;
                            }
                            if (lines[j] == "%TABLE" || lines[j] == "%LAYER")
                            {
                                j--;
                                break;
                            }
                            if (j + 1 >= lines.Count)
                            {
                                break;
                            }
                            if (!String.IsNullOrWhiteSpace(lines[j]))
                            {
                                String fieldName = lines[j];
                                bool isSelected = true;
                                m_interfaceData.setDatasetFieldSelected(db1, user1, version1, datasetName, fieldName, isSelected);
                                inputFieldNameList.Add(datasetName + "." +fieldName);
                                isAnyFieldReceived = true;
                            }
                        }
                        if (!isAnyFieldReceived)
                        {
                            System.Windows.MessageBox.Show("Found incorrect config file format while reading " + datasetName + " field", "File Error");
                            return false;
                        }
                        i = j;
                    }
                    isGettingWhereOrField = false;
                    isGettingField = false;
                    isGettingTableOrLayer = true;
                }
                //if line is not empty and has incorrect format
                else if (!String.IsNullOrWhiteSpace(lines[i]))
                {
                    System.Windows.MessageBox.Show("Config file format is incorrect", "File Error");
                    return false;
                }
            }
            //should set to reading table or layer when finish last line
            if (!isGettingTableOrLayer)
            {
                System.Windows.MessageBox.Show("Config file format is incorrect", "File Error");
                return false;
            }
            return true;
        }
        //cancel read
        else
        {
            return null;
        }
    }
    /// <summary>
    /// Get a string line, delete comment (#...) and trim whitespace
    /// </summary>
    /// <param name="line">input string line</param>
    /// <returns>processed string</returns>
    public String excludeCommentandTrim(String line)
    {
        if (line.IndexOf("#") != -1)
            return line.Substring(0, line.IndexOf("#")).Trim();
        else
            return line.Trim();
    }
    /// <summary>
    /// Get a string line, detect if a line is related to DBuser information and copy to a class variable
    /// </summary>
    /// <param name="userInfo">input string line</param>
    /// <returns>true if userinfo avaliable, false if not </returns>
    public bool getDBUserInfo(String userInfo)
    {
        if (userInfo.Contains("user_1"))
        {
            user1Variable = getLineVariable(userInfo);
            return true;
        }
        else if (userInfo.Contains("user_2"))
        {
            user2Variable = getLineVariable(userInfo);
            return true;
        }
        else if (userInfo.Contains("server_1"))
        {
            DB1Variable = getLineVariable(userInfo);
            return true;
        }
        else if (userInfo.Contains("server_2"))
        {
            DB2Variable = getLineVariable(userInfo);
            return true;
        }
        else if (userInfo.Contains("version_1"))
        {
            version1Variable = getLineVariable(userInfo);
            if (String.IsNullOrWhiteSpace(version1Variable))
            {
                version1Variable = "SDE.DEFAULT";
            }
            return true;
        }
        else if (userInfo.Contains("version_2"))
        {
            version2Variable = getLineVariable(userInfo);
            if (String.IsNullOrWhiteSpace(version2Variable))
            {
                version2Variable = "SDE.DEFAULT";
            }
            return true;
        }
        return false;
    }
    /// <summary>
    /// Get variable value from DBUser information line in config file [ex. user_1 = TEST2017, get TEST2017]
    /// </summary>
    /// <param name="userInfo">input string line</param>
    /// <returns>variable value [ex. TEST2017]</returns>
    public String getLineVariable(String userInfo)
    {
        int start = userInfo.IndexOf('=') + 1;
        int end = userInfo.Length;
        String variableValue = userInfo.Substring(start, end - start).Trim();
        return variableValue;
    }
    /// <summary>
    /// Write a config file, get all data from interfaceData,
    /// convert into config file format and output the data.
    /// </summary>
    /// <returns>true if success, false if not</returns>
    public bool writeConfigFile()
    {
        //set current connect DBUSer
        user1Variable = m_interfaceData._m_currentUser;
        DB1Variable = m_interfaceData._m_currentDB;
        version1Variable = m_interfaceData._m_currentVersion;
        // Create OpenFileDialog
        Microsoft.Win32.SaveFileDialog dlg = new Microsoft.Win32.SaveFileDialog();

        // Set filter for file extension and default file extension
        dlg.Filter = "Text Files (*.txt)|*.txt|INI Files (*.ini)|*.ini";

        // Display OpenFileDialog by calling ShowDialog method
        Nullable<bool> result = dlg.ShowDialog();

        // Get the selected file name and display in a TextBox
        if (result == true)
        {
            String filename = dlg.FileName;
            if (!filename.EndsWith(".txt") && !filename.EndsWith(".ini"))
            {
                System.Windows.MessageBox.Show("Target file is not .txt or .ini file type.", "File Error");
                return false;
            }
            // Open document

            List<String> configText = new List<String>();
            configText.Add("###CONFIG LIST###");
            configText.Add("");
            configText.Add("##User 1 information");
            configText.Add("user_1=" + m_interfaceData._m_currentUser);
            configText.Add("server_1=" + m_interfaceData._m_currentDB);
            configText.Add("version_1=" + m_interfaceData._m_currentVersion + "\t#BLANK = 'SDE.DEFAULT'");
            configText.Add("##User 2 information");
            configText.Add("user_2=" + m_interfaceData._m_currentUser2);
            configText.Add("server_2=" + m_interfaceData._m_currentDB2);
            configText.Add("version_2=" + m_interfaceData._m_currentVersion2 + "\t#BLANK = 'SDE.DEFAULT'");
            configText.Add("");
            configText.Add("##Layer, table and field list");
            configText.Add("#Below is format for input data");
            configText.Add("#%TABLE");
            configText.Add("#<TABLE_NAME>");
            configText.Add("#%WHERE");
            configText.Add("#<CONDITION>");
            configText.Add("#%FIELD");
            configText.Add("#<FIELD_NAME1>");
            configText.Add("#<FIELD_NAME2>");
            configText.Add("#:");
            configText.Add("#%LAYER");
            configText.Add("#<LAYER_NAME>");
            configText.Add("#%FIELD");
            configText.Add("#<FIELD_NAME1>");
            configText.Add("#<FIELD_NAME2>");
            configText.Add("#:");
            configText.Add("");
            configText.Add("#If you want a table or layer to output all fields: use '*' under %FIELD line");
            configText.Add("#If you want a table or layer to output no field: use '-' under %FIELD line");
            //get table with selected condition
            Dictionary<String, interfaceData.datasetInfo> datasetList = m_interfaceData.getDatasetList();
            foreach (KeyValuePair<String, interfaceData.datasetInfo> dataset in datasetList)
            {
                // if dataset is not currently selected DBUser, skip
                if (dataset.Key.IndexOf(DB1Variable) < 0 || dataset.Key.IndexOf(user1Variable) < 0 || dataset.Key.IndexOf(version1Variable) < 0)
                {
                    continue;
                }
                interfaceData.datasetInfo datasetInf = dataset.Value;
                //if not select, skip
                if (!datasetInf.isDatasetSelected)
                    continue;
                String datasetName = dataset.Key;
                int a = datasetName.LastIndexOf(m_interfaceData._m_datasetListKeywordSeparator);
                int b = datasetName.Length;
                datasetName = datasetName.Substring(a + 1, b - a - 1);
                //add %TABLE or %LAYER and dataset line
                if (datasetInf.isTable) configText.Add("%TABLE");
                else configText.Add("%LAYER");
                configText.Add(datasetName);
                //if condition is not empty, add %WHERE and condition line
                String datasetCondition = datasetInf.searchCondition;
                if (!String.IsNullOrWhiteSpace(datasetCondition))
                {
                    configText.Add("%WHERE");
                    configText.Add(datasetCondition);
                }
                //get selected column
                configText.Add("%FIELD");
                List<Tuple<String, bool>> fieldList = datasetInf.fieldInfo;
                List<String> DBFieldList = m_interfaceData.getFieldNameList(datasetName);
                int fieldCount = 0;
                foreach (String fieldName in DBFieldList)
                {
                    if (!fieldName.Contains("."))
                    {
                        fieldCount++;
                    }
                }
                //if select all
                bool isSelectedAllManually = true;
                bool isAllFalse = true;
                if (datasetInf.isFieldSelectedAll)
                {
                    configText.Add("*");
                    continue;
                }
                if (fieldList.Count <= 0)
                {
                    configText.Add("-");
                    continue;
                }
                foreach (Tuple<String, bool> field in fieldList)
                {
                    if (field.Item2 == false) //if not selected
                    {
                        isSelectedAllManually = false;
                    }
                    else if (field.Item2 == true)
                    {
                        isAllFalse = false;
                    }
                }
                if (isSelectedAllManually && fieldCount == fieldList.Count)
                {
                    configText.Add("*");
                    continue;
                }
                //if select none
                if (isAllFalse)
                {
                    configText.Add("-");
                    continue;
                }
                foreach (Tuple<String, bool> field in fieldList)
                {
                    if (field.Item2 == true) //if selected
                        configText.Add(field.Item1); //add field name
                }
                configText.Add("");
            }
            configText.Add("###End of File###");
            File.WriteAllLines(filename, configText);
            return true;
        }
        else
        {
            return false;
        }
    }
    /// <summary>
    /// Select target TSV write file
    /// convert into config file format and output the data.
    /// </summary>
    /// <returns>file name</returns>
    public string selectWriteFileForTSV()
    {
        String filename;
        // Create OpenFileDialog
        Microsoft.Win32.SaveFileDialog dlg = new Microsoft.Win32.SaveFileDialog();

        // Set filter for file extension and default file extension
        dlg.Filter = "TSV Files (*.tsv)| *.tsv";

        // Display OpenFileDialog by calling ShowDialog method
        Nullable<bool> fileResult = dlg.ShowDialog();

        // Get the selected file name and display in a TextBox
        if (fileResult == true)
        {
            // Open document
            filename = dlg.FileName;
            return filename;
        }
        else
        {
            return "cancel";
        }
    }
    /// <summary>
    /// write all data to TSV file.
    /// </summary>
    /// <param name="filename">file name</param>
    /// <param name="isCompare">get data for 1 user or 2 users</param>
    /// <returns>true if success, false if fail</returns>
    public bool writeToTSV(String filename, bool isCompare)
    {
        List<String> tsvText = new List<String>();
        DB1Variable = m_interfaceData._m_currentDB;
        user1Variable = m_interfaceData._m_currentUser;
        version1Variable = m_interfaceData._m_currentVersion;
        String DBUser1 = user1Variable + "@" + DB1Variable + "(" + version1Variable + ")";
        tsvText.Add("User1 : " + DBUser1);
        //print TSV header
        List<String> tsvHeader;
        if (isCompare)
        {
            tsvHeader = new List<String> { "DATASET", "NAME", "QUERY_KEYWORD", "CODE", "DESCRIPTION", "RECORD_COUNT1", "DISTANCE(KM) AREA(KM2)1", "RECORD_COUNT2", "DISTANCE(KM) AREA(KM2)2" };
            //show connecting messagebox
            Task.Factory.StartNew(() =>
            {
                System.Windows.MessageBox.Show("Connecting to DBUser2...", "Connecting");
            });
            bool isSuccess = m_interfaceData.connectToUser2();
            if (!isSuccess)
            {
                IntPtr hWns = FindWindowByCaption(IntPtr.Zero, "Connecting");
                if (hWns != IntPtr.Zero)
                    PostMessage(hWns, WM_CLOSE, 0, 0);
                System.Windows.MessageBox.Show("Cannot connect to DBUser 2", "Connection Error");
                return false;
            }
            DB2Variable = m_interfaceData._m_currentDB2;
            user2Variable = m_interfaceData._m_currentUser2;
            version2Variable = m_interfaceData._m_currentVersion2;
            if (m_interfaceData.isCurrent1AndCurrent2DBUserSame())
            {
                IntPtr hWns = FindWindowByCaption(IntPtr.Zero, "Connecting");
                if (hWns != IntPtr.Zero)
                    PostMessage(hWns, WM_CLOSE, 0, 0);
                System.Windows.MessageBox.Show("DBUser1 and DBUser2 are identical. Stop comparing", "Error");
                return false;
            }
            String DBUser2 = user2Variable + "@" + DB2Variable + "(" + version2Variable + ")";
            tsvText.Add("User2 : " + DBUser2);
        }
        else
        {
            tsvHeader = new List<String> { "DATASET", "NAME", "QUERY_KEYWORD", "CODE", "DESCRIPTION", "RECORD_COUNT", "DISTANCE(KM) AREA(KM2)" };
        }
        IntPtr hWnj = FindWindowByCaption(IntPtr.Zero, "Connecting");
        if (hWnj != IntPtr.Zero)
            PostMessage(hWnj, WM_CLOSE, 0, 0);
        //show writing messagebox
        Task.Factory.StartNew(() =>
        {
            System.Windows.MessageBox.Show("Writing to TSV file...", "Writing");
        });
        String headerLine = String.Join(delimiter, tsvHeader);
        tsvText.Add(headerLine);
        //get dataset 1 by 1
        Dictionary<String, interfaceData.datasetInfo> datasetList = new Dictionary<string, interfaceData.datasetInfo>(m_interfaceData.getDatasetList());
        foreach (KeyValuePair<String, interfaceData.datasetInfo> dataset in datasetList)
        {
            // if dataset is not currently selected DBUser, skip
            if (  dataset.Key.IndexOf(DB1Variable)<0 || dataset.Key.IndexOf(user1Variable) < 0 || dataset.Key.IndexOf(version1Variable) < 0)
            {
                continue;
            }
            interfaceData.datasetInfo datasetInf = dataset.Value;
            //if not select, skip
            if (!datasetInf.isDatasetSelected)
                continue;
            String datasetName = dataset.Key;
            int a = datasetName.LastIndexOf(m_interfaceData._m_datasetListKeywordSeparator);
            int b = datasetName.Length;
            datasetName = datasetName.Substring(a + 1, b - a - 1);

            String datasetCondition = datasetInf.searchCondition;
            //get processed TSV format dataset data
            String datasetRow = String.Join(delimiter, getDatasetRow(datasetName, datasetCondition, isCompare));
            tsvText.Add(datasetRow);
            //to print field list
            List<Tuple<String, bool>> fieldList = datasetInf.fieldInfo;
            fieldList = fieldList.OrderBy(t => t.Item1).ToList();
            if (fieldList.Count == 0 && datasetInf.isFieldSelectedAll)
            {
                List<String> tempFieldList = m_interfaceData.getFieldNameList(datasetName);
                List<Tuple<String, bool>> newColumnInfo = new List<Tuple<String, bool>>();
                //get all fields
                for (int i = 0; i < tempFieldList.Count; i++)
                {
                    String fieldName = tempFieldList[i];
                    if (fieldName.Contains(".")) continue;
                    Tuple<String, bool> newTuple = new Tuple<String, bool>(fieldName, true);
                    newColumnInfo.Add(newTuple);
                }
                m_interfaceData.setDatasetFieldInfo(string.Empty, string.Empty, string.Empty, datasetName, newColumnInfo);
                fieldList = newColumnInfo;
            }
            //if select none
            else if (fieldList.Count <= 0)
            {
                continue;
            }
            foreach (Tuple<String, bool> field in fieldList)
            {
                if (field.Item2 == true) //if selected
                {
                    // if the field has no domain, print only 1 line
                    String db1 = DB1Variable;
                    String user1 = user1Variable;
                    String version1 = version1Variable;
                    bool isTable = m_interfaceData.isDatasetTable(db1, user1, version1, datasetName);
                    String fieldName = field.Item1;
                    int isDomain = m_interfaceData.hasDomain(datasetName, fieldName);
                    int isNullable = m_interfaceData.isNullable(datasetName, fieldName);
                    List<String> multiFieldRow;
                    if (isDomain == -1 || isNullable == -1)
                    {
                        IntPtr hWns = FindWindowByCaption(IntPtr.Zero, "Connecting");
                        if (hWns != IntPtr.Zero)
                            PostMessage(hWns, WM_CLOSE, 0, 0);
                        System.Windows.MessageBox.Show("Error while acquiring domain from " +field.Item1, "Error");
                        return false;
                    }
                    else if (isDomain == 0)
                    {
                        multiFieldRow = getDomainRows(datasetName, datasetCondition, fieldName, isCompare);
                    }
                    else
                    {
                        multiFieldRow = getNormalRows(datasetName, datasetCondition, fieldName, isCompare, isNullable);
                    }
                    foreach (String line in multiFieldRow)
                    {
                        tsvText.Add(line);
                    }
                }

            }
        }
        File.WriteAllLines(filename, tsvText);
        //close writing messagebox
        IntPtr hWnd = FindWindowByCaption(IntPtr.Zero, "Writing");
        if (hWnd != IntPtr.Zero)
            PostMessage(hWnd, WM_CLOSE, 0, 0);
        System.Windows.MessageBox.Show(" Successfully output the result to the TSV file", "Success");

        return true;
    }
    /// <summary>
    /// Get TSV format dataset row.
    /// </summary>
    /// <param name="dataSetName">target dataset</param>
    /// <param name="datasetCondition">dataset search condition</param>
    /// <param name="isCompare">get data for 1 user or 2 users</param>
    /// <returns>one line of string which is dataset data in TSV format</returns>
    public List<String> getDatasetRow(String datasetName, String datasetCondition, bool isCompare)
    {
        String parentDataset = "*";
        String db1 = DB1Variable;
        String user1 = user1Variable;
        String version1 = version1Variable;
        String db2 = DB2Variable;
        String user2 = user2Variable;
        String version2 = version2Variable;
        // check if target dataset is table or featureclass
        if (!m_interfaceData.isDatasetTable(string.Empty, string.Empty, string.Empty, datasetName))
        {
            //if featureclass, get parent dataset name
            parentDataset = m_interfaceData.getParentDatasetName(string.Empty, string.Empty, string.Empty, datasetName);
        }
        //set all necessary data before converted into TSV line

        String code = string.Empty;
        String description = string.Empty;
        String recordCount = m_interfaceData.getRecordNumber(datasetCondition, db1, user1, version1, datasetName);
        String distArea = m_interfaceData.getTotalDistArea(datasetCondition, db1, user1, version1, datasetName);
        List<String> datasetRow;
        // if compare data between 2 users, write the second user's data too
        if (isCompare)
        {
            String recordCount2 = m_interfaceData.getRecordNumber(datasetCondition, db2, user2, version2, datasetName);
            String distArea2 = m_interfaceData.getTotalDistArea(datasetCondition, db2, user2, version2, datasetName).ToString();
            datasetRow = new List<String> { parentDataset, datasetName, datasetCondition, code, description, recordCount, distArea, recordCount2, distArea2 };
        }
        else
        {
            datasetRow = new List<String> { parentDataset, datasetName, datasetCondition, code, description, recordCount, distArea };
        }

        return datasetRow;
    }
    /// <summary>
    /// Get multiple rows TSV format for field which contains domain
    /// </summary>
    /// <param name="dataSetName">target dataset</param>
    /// <param name="datasetCondition">dataset search condition</param>
    /// <param name="fieldName">target field</param>
    /// <param name="isCompare">get data for 1 user or 2 users</param>
    /// <returns>multiple lines of string which is field and domain data in TSV format</returns>
    public List<String> getDomainRows(String datasetName, String datasetCondition, String fieldName, bool isCompare)
    {
        //set all necessary data before converted into TSV line
        String db1 = DB1Variable;
        String user1 = user1Variable;
        String version1 = version1Variable;
        String db2 = DB2Variable;
        String user2 = user2Variable;
        String version2 = version2Variable;
        String parentDataset = string.Empty;
        String condition = string.Empty;
        List<String> domainDetails = m_interfaceData.getDomainNameList(datasetName, fieldName);
        String code = domainDetails[0];
        String description = string.Empty;
        if (domainDetails[1] == "Range")
        {
            String min = string.Format("{0:N1}", domainDetails[2]);
            String max = string.Format("{0:N1}", domainDetails[3]);
            description = "Range " + min + " - " +max;
        }
        String totalRecordCount = m_interfaceData.getRecordNumber(datasetCondition, db1, user1, version1, datasetName);
        String totalDistArea = m_interfaceData.getTotalDistArea(datasetCondition, db1, user1, version1, datasetName);

        List<String> multiFieldRow = new List<String>();
        // if compare data between 2 users, write the second user's data too
        List<String> fieldRow;
        if (isCompare)
        {
            String totalRecordCount2 = m_interfaceData.getRecordNumber(datasetCondition, db2, user2, version2, datasetName);
            String totalDistArea2 = m_interfaceData.getTotalDistArea(datasetCondition, db2, user2, version2, datasetName).ToString();
            fieldRow = new List<String> { parentDataset, fieldName, condition, code, description, totalRecordCount, totalDistArea, totalRecordCount2, totalDistArea2 };
        }
        else
        {
            fieldRow = new List<String> { parentDataset, fieldName, condition, code, description, totalRecordCount, totalDistArea };
        }

        String convertedFieldRow = String.Join(delimiter, fieldRow);
        multiFieldRow.Add(convertedFieldRow);
        //for coded value
        if (domainDetails[1] == "Coded Value")
        {
            //sort coded value
            List<Tuple<int,String>> domainList = new List<Tuple<int, String>>();
            for (int i = 2; i < domainDetails.Count; i += 2)
            {
                Tuple<int, String> newTuple = new Tuple<int, String>(Int32.Parse(domainDetails[i]), domainDetails[i + 1]);
                domainList.Add(newTuple);
            }
            domainList = domainList.OrderBy(t => t.Item1).ToList();
            //get multiline domain details
            for (int i = 0; i < domainList.Count; i ++)
            {
                code = domainList[i].Item1.ToString();
                description = domainList[i].Item2;
                String SQLText = fieldName + " = " + code; //ex. where OBJECTID > 10 AND PRODUCT_C = 3
                if (!String.IsNullOrWhiteSpace(datasetCondition))
                {
                    SQLText += " AND " + datasetCondition;
                }
                String fieldRecordCount = m_interfaceData.getRecordNumber(SQLText, db1, user1, version1, datasetName);
                String fieldDistArea = m_interfaceData.getTotalDistArea(SQLText, db1, user1, version1, datasetName);
                if (isCompare)
                {
                    String fieldRecordCount2 = m_interfaceData.getRecordNumber(SQLText, db2, user2, version2, datasetName);
                    String fieldDistArea2 = m_interfaceData.getTotalDistArea(SQLText, db2, user2, version2, datasetName);
                    fieldRow = new List<String> { parentDataset, string.Empty, condition, code, description, fieldRecordCount, fieldDistArea, fieldRecordCount2, fieldDistArea2 };
                }
                else
                {
                    fieldRow = new List<String> { parentDataset, string.Empty, condition, code, description, fieldRecordCount, fieldDistArea };
                }
                convertedFieldRow = String.Join(delimiter, fieldRow);
                multiFieldRow.Add(convertedFieldRow);
            }
        }
        //for range domain
        else
        {
            code = string.Empty;
            String SQLText;
            for (int i = 0; i < 2; i++)
            {
                if (i == 0)
                {
                    SQLText = fieldName + " = 0";
                    description = "0";
                }
                else
                {
                    SQLText = fieldName + " != 0";
                    description = "NOT 0";
                }
                if (!String.IsNullOrWhiteSpace(datasetCondition))
                {
                    SQLText += " AND " + datasetCondition;
                }
                String fieldRecordCount = m_interfaceData.getRecordNumber(SQLText, db1, user1, version1, datasetName);
                String fieldDistArea = m_interfaceData.getTotalDistArea(SQLText, db1, user1, version1, datasetName);
                if (isCompare)
                {
                    String fieldRecordCount2 = m_interfaceData.getRecordNumber(SQLText, db2, user2, version2, datasetName);
                    String fieldDistArea2 = m_interfaceData.getTotalDistArea(SQLText, db2, user2, version2, datasetName);
                    fieldRow = new List<String> { parentDataset, string.Empty, condition, code, description, fieldRecordCount, fieldDistArea, fieldRecordCount2, fieldDistArea2 };
                }
                else
                {
                    fieldRow = new List<String> { parentDataset, string.Empty, condition, code, description, fieldRecordCount, fieldDistArea };
                }
                convertedFieldRow = String.Join(delimiter, fieldRow);
                multiFieldRow.Add(convertedFieldRow);
            }
        }
        return multiFieldRow;
    }
    /// <summary>
    /// Get multiple rows TSV format for field and check is it nullable or not
    /// If nullable then divide the output into 2 lines: null or not null with their respective record number
    /// If not nullable then divide the output into 2 lines: 0 or not 0 with their respective record number
    /// </summary>
    /// <param name="dataSetName">target dataset</param>
    /// <param name="datasetCondition">dataset search condition</param>
    /// <param name="fieldName">target field</param>
    /// <param name="isCompare">get data for 1 user or 2 users</param>
    /// <param name="isNull">is this field nullable or not</param>
    /// <returns>multiple lines of string which is field and details data in TSV format</returns>
    public List<String> getNormalRows(String datasetName, String datasetCondition, String fieldName, bool isCompare, int isNullable)
    {
        //set all necessary data before converted into TSV line
        String db1 = DB1Variable;
        String user1 = user1Variable;
        String version1 = version1Variable;
        String db2 = DB2Variable;
        String user2 = user2Variable;
        String version2 = version2Variable;
        String parentDataset = string.Empty;
        String condition = string.Empty;
        String code = string.Empty;
        String description = string.Empty;
        String totalRecordCount = m_interfaceData.getRecordNumber(datasetCondition, db1, user1, version1, datasetName);
        String totalDistArea = m_interfaceData.getTotalDistArea(datasetCondition, db1, user1, version1, datasetName);

        List<String> multiFieldRow = new List<String>();
        // if compare data between 2 users, write the second user's data too
        List<String> fieldRow;
        if (isCompare)
        {
            String totalRecordCount2 = m_interfaceData.getRecordNumber(datasetCondition, db2, user2, version2, datasetName);
            String totalDistArea2 = m_interfaceData.getTotalDistArea(datasetCondition, db2, user2, version2, datasetName).ToString();
            fieldRow = new List<String> { parentDataset, fieldName, condition, code, description, totalRecordCount, totalDistArea, totalRecordCount2, totalDistArea2 };
        }
        else
        {
            fieldRow = new List<String> { parentDataset, fieldName, condition, code, description, totalRecordCount, totalDistArea };
        }

        String convertedFieldRow = String.Join(delimiter, fieldRow);
        multiFieldRow.Add(convertedFieldRow);

        //get 2 rows
        String SQLText;
        for (int i=0; i < 2; i++)
        {
            if (isNullable == 0 && i ==0)
            {
                SQLText = fieldName + " IS NULL ";
                description = "NULL";
            }
            else if (isNullable == 0 && i == 1)
            {
                SQLText = fieldName + " IS NOT NULL ";
                description = "NOT NULL";
            }
            else if (i==0)
            {
                SQLText = fieldName + " = 0";
                description = "0";
            }
            else
            {
                SQLText = fieldName + " != 0";
                description = "NOT 0";
            }
            if (!String.IsNullOrWhiteSpace(datasetCondition))
            {
                SQLText += " AND " + datasetCondition;
            }
            String fieldRecordCount = m_interfaceData.getRecordNumber(SQLText, db1, user1, version1, datasetName);
            String fieldDistArea = m_interfaceData.getTotalDistArea(SQLText, db1, user1, version1, datasetName);
            if (isCompare)
            {
                String fieldRecordCount2 = m_interfaceData.getRecordNumber(SQLText, db2, user2, version2, datasetName);
                String fieldDistArea2 = m_interfaceData.getTotalDistArea(SQLText, db2, user2, version2, datasetName);
                fieldRow = new List<String> { parentDataset, string.Empty, condition, code, description, fieldRecordCount, fieldDistArea, fieldRecordCount2, fieldDistArea2 };
            }
            else
            {
                fieldRow = new List<String> { parentDataset, string.Empty, condition, code, description, fieldRecordCount, fieldDistArea };
            }
            convertedFieldRow = String.Join(delimiter, fieldRow);
            multiFieldRow.Add(convertedFieldRow);
        }
        return multiFieldRow;
    }
}
