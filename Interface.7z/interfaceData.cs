﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using DBComparerWrapper;

/// <summary>
/// Manage and store all data such as DBuser information, dataset condition and selection, field selection.
/// most of data is stored in m_datasetList and track every selection of every connected DBuser
/// Used by IOManager for reading and writing data and by mainWindow for display
/// can input second user to compare the data
/// </summary>
public class interfaceData
{

    //Variables and session data
    private String m_currentDB;                          //gaia
    public String _m_currentDB
    {
        get
        {
            return m_currentDB;
        }
        set
        {
            m_previousDB = m_currentDB;
            m_currentDB = value;
        }
    }
    private String m_currentUser;                        //TEST2017A
    public String _m_currentUser
    {
        get
        {
            return m_currentUser;
        }
        set
        {
            m_previousUser = m_currentUser;
            m_currentUser = value.ToUpper();
        }
    }
    private String m_currentVersion;                    //SDE.DEFAULT
    public String _m_currentVersion
    {
        get
        {
            return m_currentVersion;
        }
        set
        {
            m_previousVersion = m_currentVersion;
            m_currentVersion = value;
            if (String.IsNullOrWhiteSpace(m_currentVersion))
            {
                m_currentVersion = "SDE.DEFAULT";
            }
        }
    }
    private String m_previousDB;                        //gaia
    public String _m_previousDB
    {
        get
        {
            return m_previousDB;
        }
        set
        {
            m_previousDB = value;
        }
    }
    private String m_previousUser;                      //TEST2017A
    public String _m_previousUser
    {
        get
        {
            return m_previousUser;
        }
        set
        {
            m_previousUser = value.ToUpper();
        }
    }
    private String m_previousVersion;                   //SDE.DEFAULT
    public String _m_previousVersion
    {
        get
        {
            return m_previousVersion;
        }
        set
        {
            m_previousVersion = value;
            if (String.IsNullOrWhiteSpace(m_previousVersion))
            {
                m_previousVersion = "SDE.DEFAULT";
            }
        }
    }
    private String m_currentDB2;                        //gaia
    public String _m_currentDB2
    {
        get
        {
            return m_currentDB2;
        }
        set
        {
            m_currentDB2 = value;
        }
    }
    private String m_currentUser2;                      //TEST2017A
    public String _m_currentUser2
    {
        get
        {
            return m_currentUser2;
        }
        set
        {
            m_currentUser2 = value.ToUpper();
        }
    }
    private String m_currentVersion2;                   //SDE.DEFAULT
    public String _m_currentVersion2
    {
        get
        {
            return m_currentVersion2;
        }
        set
        {
            m_currentVersion2 = value;
            if (String.IsNullOrWhiteSpace(m_currentVersion2))
            {
                m_currentVersion2 = "SDE.DEFAULT";
            }
        }
    }
    private String m_currentlySelectedDataset;          //ROAD_LINK
    public String _m_currentlySelectedDataset
    {
        get
        {
            return m_currentlySelectedDataset;
        }
        set
        {
            m_currentlySelectedDataset = value;
        }
    }
    private String m_datasetListKeywordSeparator = "-";         //ex. gaia-TEST2017A-SDE.DEFAULT-ROAD_LINK
    public String _m_datasetListKeywordSeparator
    {
      get
        {
            return m_datasetListKeywordSeparator;
        }
        private set
        {
            m_datasetListKeywordSeparator = value;
        }
    } 
    //related class
    private functionWrapper m_DBComparer;

	//store all dataset and field data
    public struct datasetInfo
    {
        public bool isTable;                           //check if this dataset is table or not
        public bool isDatasetSelected;                 //check if a dataset is selected by user
        public bool isFieldSelectedAll;                //check if all fields are selected in this table
        public String parentDatasetName;               //record this dataset's parent dataset name
        public String searchCondition;                 //record search text for where clause ex. OBJECTID = 10
        public List<Tuple<String, bool>> fieldInfo;    //record all field names and select state of this dataset
    };
    private Dictionary<String, datasetInfo> m_datasetList;	//use getDatasetInfoKey() function to get key
    private HashSet<String> m_DBList;                  //use to record connected DB list
	//Initializer
    public interfaceData()
    {
        m_DBComparer = new functionWrapper();
        m_DBComparer.init();
        m_datasetList = new Dictionary<String, datasetInfo>();
        m_DBList = new HashSet<String>();
        m_currentDB = string.Empty;
        m_currentUser = string.Empty;
        m_currentVersion = string.Empty;
    }
	//----------------------------------------Compare variables-------------------------------------------------//
    public bool isCurrentAndPreviousDBUserSame()
    {
        if (m_previousDB.ToLower() == m_currentDB.ToLower() && m_previousUser.ToLower() == m_currentUser.ToLower() && m_previousVersion.ToLower() == m_currentVersion.ToLower())
            return true;
        return false;
    }
    public bool isCurrent1AndCurrent2DBUserSame()
    {
        if (m_currentDB2.ToLower() == m_currentDB.ToLower() && m_currentUser2.ToLower() == m_currentUser.ToLower() && m_currentVersion2.ToLower() == m_currentVersion.ToLower())
            return true;
        return false;
    }
	//----------------------------------------Get/set dataset-related info-------------------------------------------------//
    /// <summary>
    /// create new dataset and store into m_datasetList for selection tracking
    /// </summary>
    /// <param name="db">target db</param>
    /// <param name="user">target user</param>
    /// <param name="version">target user version</param>
    /// <param name="dataset">target dataset</param>
    /// <param name="isTable">is dataset a table</param>
    /// <param name="isOverwrite">is overwrite the dataset regardless of existance</param>
	 public void setNewDataset(String db, String user, String version, String dataset, bool isTable, bool isOverwrite)
    {
        bool isExist = isDatasetExist(db, user, version, dataset);
        if (isExist && !isOverwrite)
        {
            return;
        }
        String datasetKey = getDatasetInfoKey(db, user, version, dataset);
        datasetInfo newDataset = new datasetInfo();
        newDataset.fieldInfo = new List<Tuple<String, bool>>();
        newDataset.isFieldSelectedAll = false;
        newDataset.isDatasetSelected = false;
        newDataset.parentDatasetName = string.Empty;
        newDataset.searchCondition = string.Empty;
        newDataset.isTable = isTable;
        if (!isExist)
        {
            m_datasetList.Add(datasetKey, newDataset);
        }
        else if (isExist && isOverwrite)
        {
            m_datasetList[datasetKey] = newDataset;
        }
    }

    /// <summary>
    /// get datasetList for writing to output file
    /// </summary>
    /// <returns>DatasetList</returns>
	public Dictionary<String, datasetInfo> getDatasetList()
    {
        return m_datasetList;
    }
    /// <summary>
    /// clear all currently connect DBUser's datasets from m_datasetList
    /// </summary>
	public void clearDatasetList()
	{
        Dictionary<String, datasetInfo> tempDatasetList = new Dictionary<String, datasetInfo>(m_datasetList);
		foreach (KeyValuePair<String, datasetInfo> dataset in tempDatasetList)
		{
			if (dataset.Key.IndexOf(m_currentDB) < 0 || dataset.Key.IndexOf(m_currentUser) < 0 || dataset.Key.IndexOf(m_currentVersion) < 0)
			{
				continue;
			}
			m_datasetList.Remove(dataset.Key);
		}
	}
    /// <summary>
    /// check whether a dataset exists in m_datasetList
    /// </summary>
    /// <param name="db">target db</param>
    /// <param name="user">target user</param>
    /// <param name="version">target user version</param>
    /// <param name="dataset">target dataset</param>
    /// <param name="isTable">is dataset a table</param>
    /// <returns>true if exist, false if not</returns>
    public bool isDatasetExist(String db, String user, String version, String dataset)
    {
        String datasetKey = getDatasetInfoKey(db, user, version, dataset);
        return m_datasetList.ContainsKey(datasetKey);
    }

    /// <summary>
    /// get key for m_datasetList
    /// </summary>
    /// <param name="db">target db</param>
    /// <param name="user">target user</param>
    /// <param name="version">target user version</param>
    /// <param name="dataset">target dataset</param>
    /// <returns>key for DatasetInfo</returns>
    public String getDatasetInfoKey(String db, String user, String version, String dataset)
    {
        String s = _m_datasetListKeywordSeparator;
        if (String.IsNullOrWhiteSpace(db)) db = m_currentDB;
        if (String.IsNullOrWhiteSpace(user)) user = m_currentUser;
        if (String.IsNullOrWhiteSpace(version)) version = m_currentVersion;
        if (String.IsNullOrWhiteSpace(dataset)) dataset = m_currentlySelectedDataset;
        return db + s + user + s + version + s + dataset;
    }
    /// GET/SET for DatasetInfo;
	public bool isDatasetSelected(String db, String user, String version, String dataset)
    {
        String datasetKey = getDatasetInfoKey(db, user, version, dataset);
        return m_datasetList[datasetKey].isDatasetSelected;
    }

    public void setDatasetSelected(String db, String user, String version, String dataset, bool isSelected)
    {
        String datasetKey = getDatasetInfoKey(db, user, version, dataset);
        datasetInfo newDataset = m_datasetList[datasetKey];
        newDataset.isDatasetSelected = isSelected;
        m_datasetList[datasetKey] = newDataset;
    }
    public bool isDatasetTable(String db, String user, String version, String dataset)
    {
        String datasetKey = getDatasetInfoKey(db, user, version, dataset);
        return m_datasetList[datasetKey].isTable;
    }
    public void setDatasetTable(String db, String user, String version, String dataset, bool isTable)
    {
        String datasetKey = getDatasetInfoKey(db, user, version, dataset);
        datasetInfo newDataset = m_datasetList[datasetKey];
        newDataset.isTable = isTable;
        m_datasetList[datasetKey] = newDataset;
    }
    public bool isAllFieldSelected(String db, String user, String version, String dataset)
    {
        String datasetKey = getDatasetInfoKey(db, user, version, dataset);
        return m_datasetList[datasetKey].isFieldSelectedAll;
    }
    public void setAllFieldSelected(String db, String user, String version, String dataset, bool isAllSelected)
    {
        String datasetKey = getDatasetInfoKey(db, user, version, dataset);
        datasetInfo newDataset = m_datasetList[datasetKey];
        newDataset.isFieldSelectedAll = isAllSelected;
        m_datasetList[datasetKey] = newDataset;
    }
    public String getParentDatasetName(String db, String user, String version, String dataset)
    {
        String datasetKey = getDatasetInfoKey(db, user, version, dataset);
        String name = m_datasetList[datasetKey].parentDatasetName;
        if (String.IsNullOrWhiteSpace(name))
        {
            name = "*";
        }
        return name;
    }
    public void setParentDatasetName(String db, String user, String version, String dataset)
    {
        String datasetKey = getDatasetInfoKey(db, user, version, dataset);
        datasetInfo newDataset = m_datasetList[datasetKey];
        String parentDatasetName = m_DBComparer.getFeatureClassDataSetName(db, user, version, dataset);
        int a = parentDatasetName.IndexOf(".");
        int b = parentDatasetName.Length;
        parentDatasetName = parentDatasetName.Substring(a + 1, b - a - 1);
        newDataset.parentDatasetName = parentDatasetName;
        m_datasetList[datasetKey] = newDataset;
    }
    public String getDatasetCondition(String db, String user, String version, String dataset)
    {
        String datasetKey = getDatasetInfoKey(db, user, version, dataset);
        return m_datasetList[datasetKey].searchCondition;
    }
    public void setDatasetCondition(String db, String user, String version, String dataset, String searchCondition)
    {
        String datasetKey = getDatasetInfoKey(db, user, version, dataset);
        datasetInfo newDataset = m_datasetList[datasetKey];
        newDataset.searchCondition = searchCondition;
        m_datasetList[datasetKey] = newDataset;
    }

    public List<Tuple<String, bool>> getDatasetFieldInfo(String db, String user, String version, String dataset)
    {
        String datasetKey = getDatasetInfoKey(db, user, version, dataset);
        return m_datasetList[datasetKey].fieldInfo;
    }
    public void setDatasetFieldInfo(String db, String user, String version, String dataset, List<Tuple<String, bool>> fieldInfo)
    {
        String datasetKey = getDatasetInfoKey(db, user, version, dataset);
        datasetInfo newDataset = m_datasetList[datasetKey];
        newDataset.fieldInfo = fieldInfo;
        m_datasetList[datasetKey] = newDataset;
    }
    public bool isDatasetFieldSelected(String db, String user, String version, String dataset, String field)
    {
        String datasetKey = getDatasetInfoKey(db, user, version, dataset);
        Tuple<String, bool> tempTuple = new Tuple<string, bool>(field, true);
        return m_datasetList[datasetKey].fieldInfo.Contains(tempTuple);
    }
    public void setDatasetFieldSelected(String db, String user, String version, String dataset, String field, bool fieldSelected)
    {
        String datasetKey = getDatasetInfoKey(db, user, version, dataset);
        Tuple<String, bool> tempTuple = new Tuple<string, bool>(field, fieldSelected);
        if (!m_datasetList[datasetKey].fieldInfo.Contains(tempTuple))
        {
            Tuple<String, bool> tempTuple2 = new Tuple<string, bool>(field, !fieldSelected);
            if (m_datasetList[datasetKey].fieldInfo.Contains(tempTuple2))
            {
                m_datasetList[datasetKey].fieldInfo.Remove(tempTuple2);
            }
            m_datasetList[datasetKey].fieldInfo.Add(tempTuple);
        }
    }

	//-----------------------------Communicate to server-side C++ class-------------------------------------------------//
    /// <summary>
    /// Connect to user1 using current DBUser information
    /// </summary>
    /// <returns>true if success, fail if not</returns>
    public bool connectToUser1()
    {
        bool isSuccess = m_DBComparer.connectToDB(m_currentDB, m_currentUser, m_currentVersion);
        if (!isSuccess)
        {
            return false;
        }
        String s = _m_datasetListKeywordSeparator;
        m_DBList.Add(m_currentDB+ s + m_currentUser + s + m_currentVersion);
        return true;
    }
    /// <summary>
    /// Connect to user2 using current DBUser information
    /// </summary>
    /// <returns>true if success, fail if not</returns>
    public bool connectToUser2()
    {
        bool isSuccess = m_DBComparer.connectToDB(m_currentDB2, m_currentUser2, m_currentVersion2);
        if (!isSuccess)
        {
            return false;
        }
        String s = _m_datasetListKeywordSeparator;
        m_DBList.Add(m_currentDB2 + s + m_currentUser2 + s + m_currentVersion2);
        return true;
    }
    /// <summary>
    /// Check if target DB is already connected and stored in DBList
    /// </summary>
    /// <param name="db">target db</param>
    /// <param name="user">target user</param>
    /// <param name="version">target user version</param>
    /// <returns>true if already connected, fail if not</returns>
    public bool isDBAlreadyConnected(String db, String user, String version)
    {
        String s = _m_datasetListKeywordSeparator;
        return m_DBList.Contains(db + s + user + s + version);
    }
    /// <summary>
    /// get featureclass name list via SiNDY libraries
    /// </summary>
    /// <param name="db">target db</param>
    /// <param name="user">target user</param>
    /// <param name="version">target user version</param>
    /// <returns>List of featureClass name</returns>
    public List<String> getFeatureClassList(String db, String user, String version)
    {
        List<String> datasetList = new List<String>(m_DBComparer.getFeatureClassList(db, user, version));
        return datasetList;
    }
    /// <summary>
    /// get table name list via SiNDY libraries
    /// </summary>
    /// <param name="db">target db</param>
    /// <param name="user">target user</param>
    /// <param name="version">target user version</param>
    /// <returns>List of table name</returns>
    public List<String> getTableList(String db, String user, String version)
    {
        List<String> datasetList = new List<String>(m_DBComparer.getTableList(db, user, version));
        return datasetList;
    }
    /// <summary>
    /// get field name list via SiNDY libraries
    /// </summary>
    /// <param name="db">target db</param>
    /// <param name="user">target user</param>
    /// <param name="version">target user version</param>
    /// <param name="datasetName">target dataset</param>
    /// <returns>List of field name</returns>
    public List<String> getFieldNameList(String datasetName)
    {
        String db = m_currentDB;
        String user = m_currentUser;
        String version = m_currentVersion;
        bool isTable = isDatasetTable(db , user, version, datasetName);
        List<String> fieldNameList = new List<String>(m_DBComparer.getfieldNameList(m_currentDB, m_currentUser, m_currentVersion, datasetName, isTable));
        return fieldNameList;
    }
    /// <summary>
    /// Check if search string for where clause is correct by trying to use it on current DBUser1
    /// </summary>
    /// <param name="SQLText">target search string</param>
    /// <param name="datasetName">target dataset</param>
    /// <returns>true if succes, false if not</returns>
    public bool checkSQLSyntax(String SQLText, String datasetName)
    {
        String db = m_currentDB;
        String user = m_currentUser;
        String version = m_currentVersion;
        bool isTable = isDatasetTable(db, user, version, datasetName);
        return m_DBComparer.checkSQLSyntax(SQLText, m_currentDB, m_currentUser, m_currentVersion, datasetName, isTable);
    }
    /// <summary>
    /// Get total record number of dataset using search string for where clause
    /// </summary>
    /// <param name="SQLText">target search string</param>
    /// <param name="db">target db</param>
    /// <param name="user">target user</param>
    /// <param name="version">target user version</param>
    /// <param name="datasetName">target dataset</param>
    /// <returns>Total record number</returns>
    public String getRecordNumber(String SQLText, String db, String user, String version, String datasetName)
    {
        String db1 = m_currentDB;
        String user1 = m_currentUser;
        String version1 = m_currentVersion;
        bool isTable = isDatasetTable(db1, user1, version1, datasetName);
        int num = m_DBComparer.getRecordNumber(SQLText, db, user, version, datasetName, isTable);
        if (num < 0) return "-";
        return num.ToString();
    }
    /// <summary>
    /// Get total distance or area from target dataset using search string for where clause
    /// </summary>
    /// <param name="SQLText">target search string</param>
    /// <param name="db">target db</param>
    /// <param name="user">target user</param>
    /// <param name="version">target user version</param>
    /// <param name="datasetName">target dataset</param>
    /// <returns>Total distance or area in KM unit</returns>
    public String getTotalDistArea(String SQLText, String db, String user, String version, String datasetName)
    {
        String db1 = m_currentDB;
        String user1 = m_currentUser;
        String version1 = m_currentVersion;
        bool isTable = isDatasetTable(db1, user1, version1, datasetName);
        if (isTable)
        {
            return "-";
        }
        double num = m_DBComparer.getTotalDistArea(SQLText, db, user, version, datasetName);
        if (num < 0) return "-";
        return string.Format("{0:N2}", num );
    }
    /// <summary>
    /// Check whether target field has domain property
    /// </summary>
    /// <param name="datasetName">target dataset</param>
    /// <param name="fieldName">target field name</param>
    /// <returns>0 if yes, 1 if not, -1 if error to get</returns>
    public int hasDomain(String datasetName, String fieldName)
    {
        String db1 = m_currentDB;
        String user1 = m_currentUser;
        String version1 = m_currentVersion;
        bool isTable = isDatasetTable(db1, user1, version1, datasetName);
        return m_DBComparer.hasDomain(m_currentDB, m_currentUser, m_currentVersion, datasetName, fieldName, isTable);
    }
    /// <summary>
    /// Check whether target field is nullable
    /// </summary>
    /// <param name="datasetName">target dataset</param>
    /// <param name="fieldName">target field name</param>
    /// <returns>0 if yes, 1 if not, -1 if error to get</returns>
    public int isNullable(String datasetName, String fieldName)
    {
        String db1 = m_currentDB;
        String user1 = m_currentUser;
        String version1 = m_currentVersion;
        bool isTable = isDatasetTable(db1, user1, version1, datasetName);
        return m_DBComparer.isNullable(m_currentDB, m_currentUser, m_currentVersion, datasetName, fieldName, isTable);
    }
    /// <summary>
    /// Get all domain properties from target field
    /// </summary>
    /// <param name="datasetName">target dataset</param>
    /// <param name="fieldName">target field name</param>
    /// <returns>List of domain</returns>
	public List<String> getDomainNameList(String datasetName, String fieldName)
    {
        String db1 = m_currentDB;
        String user1 = m_currentUser;
        String version1 = m_currentVersion;
        bool isTable = isDatasetTable(db1, user1, version1, datasetName);
        return new List<String>(m_DBComparer.getDomainNameList(m_currentDB, m_currentUser, m_currentVersion, datasetName, fieldName, isTable));
    }
}
