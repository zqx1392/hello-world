/*
 * Copyright (C) INCREMENT P CORP. All Rights Reserved.
 *
 * THIS SOFTWARE IS PROVIDED BY INCREMENT P CORP., WITHOUT WARRANTY OF
 * ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
 * AND NONINFRINGEMENT.
 *
 * IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDER BE LIABLE FOR ANY
 * CLAIM, DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING
 * OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
*/

#pragma once

#include "BaseUpd.h"

/**
 * @brief �W�����H�ԍ������p�N���X
 */
class CShieldRoadNo : public CBaseUpd
{
public:
	CShieldRoadNo(const CString& strPrgName, const CString& strDateTime) : CBaseUpd(strPrgName, strDateTime), m_lRoadLinkRoadNoIndex(-1)
	{
		// ���̃R�[�h�ݒ�
		m_eNameClass = sindy::schema::sj::road_name_list::name_class::kShieldRoadNo;
		// ���������ݒ�
		m_strTableName1.Format(_T("%s"), sindy::schema::road_link::kTableName);
		m_strWhere1.Format(_T("%s<>0"), sindy::schema::road_link::kRoadNo);
	}
	~CShieldRoadNo() override {};

protected:
	bool setTable1FieldIndex() override;
	bool checkStoredRecord(const _IRowPtr& ipRow, CRoadNameRecord& cRoadNameRecord, bool& bStored) override;

private:
	long m_lRoadLinkRoadNoIndex;	//!< ���H�����N�F���H�ԍ��t�B�[���h�C���f�b�N�X

};

