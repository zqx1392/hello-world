/*
 * Copyright (C) INCREMENT P CORP. All Rights Reserved.
 *
 * THIS SOFTWARE IS PROVIDED BY INCREMENT P CORP., WITHOUT WARRANTY OF
 * ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
 * AND NONINFRINGEMENT.
 *
 * IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDER BE LIABLE FOR ANY
 * CLAIM, DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING
 * OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
*/

#include "StdAfx.h"
#include "Arguments.h"
#include <WinLib/VersionInfo.h>
#include <iostream>

using namespace std;
using namespace uh;
namespace po = boost::program_options;

const char * const k_road_db = "road_db";
const char * const k_road_owner = "road_owner";
const char * const k_name_db = "name_db";
const char * const k_run_log = "run_log";
const char * const k_err_log = "err_log";

// �R�}���h���C�������̉��
bool Arguments::parse(int argc, _TCHAR* argv[])
{
	po::options_description desc("How to use");

	try{
		desc.add_options()
			(k_road_db,				tvalue<tstring>(&m_road_db),			"[�K�{]���HDB�ڑ����")
			(k_road_owner,			tvalue<tstring>(&m_road_owner),			"[�C��]���HDB�̃I�[�i�[��")
			(k_name_db,				tvalue<tstring>(&m_name_db),			"[�K�{]���H����DB�ڑ����")
			(k_run_log,				tvalue<tstring>(&m_run_log),			"[�K�{]���s���O")
			(k_err_log,				tvalue<tstring>(&m_err_log),			"[�K�{]�G���[���O")
			;

		po::store(po::parse_command_line(argc, argv, desc), m_vm);
		po::notify(m_vm);

		// �K�{�p�����[�^�̃`�F�b�N
		bool good = true;
		if(m_road_db.empty() ||
			m_name_db.empty() ||
			m_run_log.empty() ||
			m_err_log.empty()){
				std::cerr << "�K�{�I�v�V�������w�肳��Ă��܂���" << std::endl;
				good = false;
		} else {
			// ���O������
			if(good){
				if(!initLog(m_run_log.c_str(), m_err_log.c_str())){
					good = false;
				}
			}
		}
		if(! good)
		{
			cerr << desc << endl;
			return false;
		}
	}
	catch(const std::exception& e)
	{
		cerr << e.what() << endl;
		cerr << desc << endl;
		return false;
	}
	return true;
}


CString Arguments::GetOption() const
{
	CString strOption = _T("[option]\n");
	for(const auto& op : m_vm){
		CString strOptionLine;
		strOptionLine.Format(_T("   --%s %s\n"), CString(op.first.c_str()), CString(op.second.as<uh::tstring>().c_str()));
		strOption += strOptionLine;
	}

	return strOption;
}

bool Arguments::initLog(const CString& strRunLog, const CString& strErrLog)
{
	// ���O�t�@�C���쐬
	if(!CLog::GetInstance().SetRunLog(strRunLog) || 
		!CLog::GetInstance().SetErrLog(strErrLog)){
		return false;
	}
	CLog::GetInstance().PrintLog(false, false, false, true,_T("#FREESTYLELOG"));
	CLog::GetInstance().PrintLog(false, false, false, true,_T("ERROR_TYPE\tTABLE_NAME\tOBJECTID\tERROR_CODE\tERROR_MSG\t"));

	CVersion cVer;
	CString strMsg;
	strMsg.Format(_T("%s FILEVERSION:%s  PRODUCTVERSION:%s"), cVer.GetOriginalFilename(), cVer.GetFileVersion(), cVer.GetProductVersion());
	CLog::GetInstance().PrintLog(true, false, true, false, strMsg);
	CLog::GetInstance().PrintLog(true, false, true, false, GetOption());

	strMsg.Format(_T("Start : %s\n"), getNowTime());
	CLog::GetInstance().PrintLog(true, false, true, false, strMsg);

	return true;
}

