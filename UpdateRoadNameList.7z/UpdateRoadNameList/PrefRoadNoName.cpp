/*
 * Copyright (C) INCREMENT P CORP. All Rights Reserved.
 *
 * THIS SOFTWARE IS PROVIDED BY INCREMENT P CORP., WITHOUT WARRANTY OF
 * ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
 * AND NONINFRINGEMENT.
 *
 * IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDER BE LIABLE FOR ANY
 * CLAIM, DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING
 * OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
*/

#include "stdafx.h"
#include "PrefRoadNoName.h"


bool CPrefRoadNoName::setTable1FieldIndex()
{
	// m_ipTable1�i���H�����N�j�̃t�B�[���h�C���f�b�N�X�擾
	if(S_OK != m_ipTable1->FindField(CComBSTR(sindy::schema::road_link::kRoadClass), &m_lRoadLinkRoadClassIndex) || 0 > m_lRoadLinkRoadClassIndex ||
		S_OK != m_ipTable1->FindField(CComBSTR(sindy::schema::road_link::kRoadNo), &m_lRoadLinkRoadNoIndex) || 0 > m_lRoadLinkRoadNoIndex ||
		S_OK != m_ipTable1->FindField(CComBSTR(sindy::schema::road_link::kPrefCode), &m_lRoadLinkPrefCodeIndex) || 0 > m_lRoadLinkPrefCodeIndex){
		CLog::GetInstance().PrintLog1(false, true, false, true, err_type::error, err_code::NgFindField, m_strTableName1);
		return false;
	}
	return true;
}

bool CPrefRoadNoName::setTable2FieldIndex()
{
	// m_ipTable2�i�������̃e�[�u���j�̃t�B�[���h�C���f�b�N�X�擾
	if(S_OK != m_ipTable2->FindField(CComBSTR(sindy::schema::pref_road_list::kNameKanji), &m_lPrefRoadNameKanjiIndex) || 0 > m_lPrefRoadNameKanjiIndex ||
		S_OK != m_ipTable2->FindField(CComBSTR(sindy::schema::pref_road_list::kNameYomi), &m_lPrefRoadNameYomiIndex) || 0 > m_lPrefRoadNameYomiIndex ||
		S_OK != m_ipTable2->FindField(CComBSTR(sindy::schema::pref_road_list::kRoadClass), &m_lPrefRoadRoadClassIndex) || 0 > m_lPrefRoadRoadClassIndex ||
		S_OK != m_ipTable2->FindField(CComBSTR(sindy::schema::pref_road_list::kRoadNo), &m_lPrefRoadRoadNoIndex) || 0 > m_lPrefRoadRoadNoIndex ||
		S_OK != m_ipTable2->FindField(CComBSTR(sindy::schema::pref_road_list::kPrefCode), &m_lPrefRoadPrefCodeIndex) || 0 > m_lPrefRoadPrefCodeIndex){
		CLog::GetInstance().PrintLog1(false, true, false, true, err_type::error, err_code::NgFindField, m_strTableName2);
		return false;
	}
	return true;
}

bool CPrefRoadNoName::loadTable2()
{
	// m_ipTable2�i�������̃e�[�u���j�̃��R�[�h�S�擾
	_ICursorPtr ipCursor;
	if(S_OK != m_ipTable2->Search(NULL, VARIANT_FALSE, &ipCursor)){
		CLog::GetInstance().PrintLog1(false, true, false, true, err_type::error, err_code::NgGetCursor, m_strTableName2);
		return false;
	}

	_IRowPtr ipRow;
	while(S_OK == ipCursor->NextRow(&ipRow) && ipRow){
		// ���H�ԍ��A���H�\����ʁA���R�[�h�擾
		CComVariant vaRoadNo, vaRoadClass, vaPrefCode;
		if(S_OK != ipRow->get_Value(m_lPrefRoadRoadNoIndex, &vaRoadNo) ||
			S_OK != ipRow->get_Value(m_lPrefRoadRoadClassIndex, &vaRoadClass) ||
			S_OK != ipRow->get_Value(m_lPrefRoadPrefCodeIndex, &vaPrefCode)){
				CLog::GetInstance().PrintLog1(false, true, false, true, err_type::error, err_code::NgGetValue, m_strTableName2, getID(ipRow));
				return false;
		}
		// �Ȃ��͂������A�������̂��d������ꍇ�̓G���[
		if(!m_mapPrefCodeList.insert(std::make_pair(CPrefCodeRecord(vaRoadNo.lVal, vaRoadClass.lVal, vaPrefCode.lVal), ipRow)).second){
			CLog::GetInstance().PrintLog2(false, true, true, true, err_type::error, err_code::DuplicateData, m_strTableName2, getID(ipRow));
			return false;
		}
	}

	return true;
}

bool CPrefRoadNoName::checkStoredRecord(const _IRowPtr& ipRow, CRoadNameRecord& cRoadNameRecord, bool& bStored)
{
	// ���H�ԍ��A���R�[�h�A���́A�ǂݎ擾
	CComVariant vaRoadNo, vaPrefCode, vaNameKanji, vaNameYomi;
	if(S_OK != ipRow->get_Value(m_lPrefRoadRoadNoIndex, &vaRoadNo) ||
		S_OK != ipRow->get_Value(m_lPrefRoadPrefCodeIndex, &vaPrefCode) ||
		S_OK != ipRow->get_Value(m_lPrefRoadNameKanjiIndex, &vaNameKanji) ||
		S_OK != ipRow->get_Value(m_lPrefRoadNameYomiIndex, &vaNameYomi)){
			CLog::GetInstance().PrintLog1(false, true, false, true, err_type::error, err_code::NgGetValue, m_strTableName2, getID(ipRow));
			return false;
	}

	// ���́A�ǂݐݒ�
	CString strNameKanji;
	CString strNameYomi;
	strNameKanji.Format(_T("%s��%s��%s"), prefCode2PrefName(vaPrefCode.lVal), num2ZenStr(vaRoadNo.lVal), vaNameKanji.bstrVal);
	strNameYomi.Format(_T("%s�h�E%s�S�E%s"), prefCode2PrefYomi(vaPrefCode.lVal), num2YomiStr(vaRoadNo.lVal), vaNameYomi.bstrVal);

	// �o�^���Z�b�g
	setStoreInfo(strNameKanji, strNameYomi, cRoadNameRecord, bStored);

	return true;
}

bool CPrefRoadNoName::checkProcRecord(const _IRowPtr& ipRow, _IRowPtr& ipRetRow, bool& bCheck)
{
	bCheck = false;

	// ipRow�i���H�����N�j���瓹�H�ԍ��A���H�\����ʁA���R�[�h�擾
	CComVariant vaRoadNo, vaRoadClass, vaPrefCode;
	if(S_OK != ipRow->get_Value(m_lRoadLinkRoadNoIndex, &vaRoadNo) ||
		S_OK != ipRow->get_Value(m_lRoadLinkRoadClassIndex, &vaRoadClass) ||
		S_OK != ipRow->get_Value(m_lRoadLinkPrefCodeIndex, &vaPrefCode)){
			CLog::GetInstance().PrintLog1(false, true, false, true, err_type::error, err_code::NgGetValue, m_strTableName1, getID(ipRow));
			return false;
	}
	// �s���{�������R�[�h���ɓ��H�����N����擾������ԃR�[�h�ɑΉ����郌�R�[�h�����݂��邩�`�F�b�N
	const auto& it = m_mapPrefCodeList.find(CPrefCodeRecord(vaRoadNo.lVal, vaRoadClass.lVal, vaPrefCode.lVal));
	if(m_mapPrefCodeList.cend() == it){
		// ���݂��Ȃ���ΏI��
		return true;
	}

	ipRetRow = it->second;
	bCheck = true;

	return true;
}
