/*
 * Copyright (C) INCREMENT P CORP. All Rights Reserved.
 *
 * THIS SOFTWARE IS PROVIDED BY INCREMENT P CORP., WITHOUT WARRANTY OF
 * ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
 * AND NONINFRINGEMENT.
 *
 * IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDER BE LIABLE FOR ANY
 * CLAIM, DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING
 * OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
*/

#include "stdafx.h"
#include "RoadCityHwyAbbr.h"


bool CRoadCityHwyAbbr::setTable1FieldIndex()
{
	// m_ipTable1�iROAD_CODE_LIST�j�̃t�B�[���h�C���f�b�N�X�擾
	if(S_OK != m_ipTable1->FindField(CComBSTR(sindy::schema::road_code_list::kDisplayKanji), &m_lRoadCodeDisplayKanjiIndex) || 0 > m_lRoadCodeDisplayKanjiIndex ||
		S_OK != m_ipTable1->FindField(CComBSTR(sindy::schema::road_code_list::kDisplayYomi), &m_lRoadCodeDisplayYomiIndex) || 0 > m_lRoadCodeDisplayYomiIndex){
		CLog::GetInstance().PrintLog1(false, true, false, true, err_type::error, err_code::NgFindField, m_strTableName1);
		return false;
	}
	return true;
}

bool CRoadCityHwyAbbr::checkStoredRecord(const _IRowPtr& ipRow, CRoadNameRecord& cRoadNameRecord, bool& bStored)
{
	// �\���p���́A�\���p�ǂ݂��擾
	CComVariant vaDisplayKanji, vaDisplayYomi;
	if(S_OK != ipRow->get_Value(m_lRoadCodeDisplayKanjiIndex, &vaDisplayKanji) ||
		S_OK != ipRow->get_Value(m_lRoadCodeDisplayYomiIndex, &vaDisplayYomi)){
		CLog::GetInstance().PrintLog1(false, true, false, true, err_type::error, err_code::NgGetValue, m_strTableName1, getID(ipRow));
		return false;
	}

	// �ړ������폜�������́A�ǂݐݒ�
	CString strNameKanji = delPostfix(vaDisplayKanji.bstrVal, m_vecDelPostfixKanji);
	CString strNameYomi = delPostfix(vaDisplayYomi.bstrVal, m_vecDelPostfixYomi);

	// �o�^���Z�b�g
	setStoreInfo(strNameKanji, strNameYomi, cRoadNameRecord, bStored);

	return true;
}

CString CRoadCityHwyAbbr::delPostfix(CString strName, const std::vector<CString>& m_vecDelPostfix)
{
	for(const auto& delSuffix : m_vecDelPostfix){
		if(0 <= strName.Find(delSuffix)){
			// �폜������I��
			strName.Delete(0, delSuffix.GetLength());
			break;
		}
	}
	return strName;
}