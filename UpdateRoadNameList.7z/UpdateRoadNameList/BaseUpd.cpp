/*
 * Copyright (C) INCREMENT P CORP. All Rights Reserved.
 *
 * THIS SOFTWARE IS PROVIDED BY INCREMENT P CORP., WITHOUT WARRANTY OF
 * ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
 * AND NONINFRINGEMENT.
 *
 * IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDER BE LIABLE FOR ANY
 * CLAIM, DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING
 * OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
*/

#include "stdafx.h"
#include "BaseUpd.h"

bool CBaseUpd::run(const ITablePtr& ipRoadNameList, const ITablePtr& ipTable1, const ITablePtr& ipTable2)
{
	// ������
	if(!init(ipRoadNameList, ipTable1, ipTable2)){
		return false;
	}

	// �擾�Ώۃe�[�u��1��Where��w��
	IQueryFilterPtr ipQFilter(CLSID_QueryFilter);
	if(S_OK != ipQFilter->put_WhereClause(CComBSTR(m_strWhere1))){
		CLog::GetInstance().PrintLog1(false, true, false, true, err_type::error, err_code::NgSetFilter, m_strTableName1);
		return false;
	}
	// �擾�Ώۃe�[�u��1���猏���{�J�[�\���擾
	long size = 0;
	if(S_OK != m_ipTable1->RowCount(ipQFilter, &size)){
		CLog::GetInstance().PrintLog1(false, true, false, true, err_type::error, err_code::NgGetRowCount, m_strTableName1);
		return false;
	}
	_ICursorPtr ipCursor;
	if(S_OK != m_ipTable1->Search(ipQFilter, VARIANT_FALSE, &ipCursor)){
		CLog::GetInstance().PrintLog1(false, true, false, true, err_type::error, err_code::NgGetCursor, m_strTableName1);
		return false;
	}

	long counter = 0;

	// �擾�Ώۃe�[�u��1�̃��R�[�h�擾
	_IRowPtr ipRow;
	while(S_OK == ipCursor->NextRow(&ipRow) && ipRow){
		
		++counter;
		if(counter%107 == 0){
			std::cout << "  " << counter << " / " << size << " ��\r";
		}

		// ����`�F�b�N
		bool bCheck = false;
		_IRowPtr ipRetRow;
		if(!checkProcRecord(ipRow, ipRetRow, bCheck)){
			return false;
		}
		if(!bCheck){
			continue;
		}

		// �o�^�ς݃��R�[�h���`�F�b�N
		bool bStored = false;
		CRoadNameRecord cRoadNameRecord;
		if(!checkStoredRecord(ipRetRow, cRoadNameRecord, bStored)){
			return false;
		}
		// �o�^�ς݃��R�[�h�ł���Ώ����X���[
		if(bStored){
			continue;
		}

		// �f�[�^�C���|�[�g
		if(!importNameRecord(cRoadNameRecord)){
			return false;
		}
	}
	std::cout << "  " << counter << " / " << size << " ��\n";

	// �Ō�ɃJ�[�\��flush
	if(FAILED(m_ipRoadNameCursor->Flush())){
		CLog::GetInstance().PrintLog1(false, true, true, true, err_type::error, err_code::NgCursorFlush, sindy::schema::sj::road_name_list::kTableName);
		return false;
	}

	return true;
}

bool CBaseUpd::init(const ITablePtr& ipRoadNameList, const ITablePtr& ipTable1, const ITablePtr& ipTable2)
{
	m_ipRoadNameList = ipRoadNameList;
	m_ipTable1 = ipTable1;
	m_ipTable2 = ipTable2;

	// ���H���̃��R�[�h�C���|�[�g�p�̃J�[�\���擾
	if(S_OK != m_ipRoadNameList->Insert(VARIANT_FALSE, &m_ipRoadNameCursor)){
		CLog::GetInstance().PrintLog1(false, true, true, true, err_type::error, err_code::NgInsert, sindy::schema::sj::road_name_list::kTableName);
		return false;
	}

	// �e�e�[�u���̃t�B�[���h�C���f�b�N�X�擾
	if(!setRoadNameFieldIndex() || !setTable1FieldIndex() || !setTable2FieldIndex()){
		return false;
	}

	// ���H���̃��R�[�h�擾
	if(!loadRoadNameList()){
		return false;
	}

	// �f�[�^�擾�Ώۃe�[�u��2����f�[�^�擾
	if(!loadTable2()){
		return false;
	}

	return true;
}
bool CBaseUpd::setRoadNameFieldIndex()
{
	// ���H���̃e�[�u���̃t�B�[���h�C���f�b�N�X�擾
	if(S_OK != m_ipRoadNameList->FindField(CComBSTR(sindy::schema::sj::road_name_list::kProgModifyDate), &m_lPrgModifyDateIndex) || 0 > m_lPrgModifyDateIndex ||
		S_OK != m_ipRoadNameList->FindField(CComBSTR(sindy::schema::sj::road_name_list::kModifyProgName), &m_lModifyPrgNameIndex) || 0 > m_lModifyPrgNameIndex ||
		S_OK != m_ipRoadNameList->FindField(CComBSTR(sindy::schema::sj::road_name_list::kUpdateType), &m_lUpdateTypeIndex) || 0 > m_lUpdateTypeIndex ||
		S_OK != m_ipRoadNameList->FindField(CComBSTR(sindy::schema::sj::road_name_list::kNameClass), &m_lNameClassIndex) || 0 > m_lNameClassIndex ||
		S_OK != m_ipRoadNameList->FindField(CComBSTR(sindy::schema::sj::road_name_list::kNameKanji), &m_lNameKanjiIndex) || 0 > m_lNameKanjiIndex ||
		S_OK != m_ipRoadNameList->FindField(CComBSTR(sindy::schema::sj::road_name_list::kNameYomi), &m_lNameYomiIndex) || 0 > m_lNameYomiIndex){
			CLog::GetInstance().PrintLog1(false, true, false, true, err_type::error, err_code::NgFindField, sindy::schema::sj::road_name_list::kTableName);
		return false;
	}
	return true;
}

bool CBaseUpd::loadRoadNameList()
{
	// ���̎�ʒP�ʂŃ��R�[�h�擾���錟���t�B���^�쐬
	CString strWhere;
	strWhere.Format(_T("%s=%ld"), sindy::schema::sj::road_name_list::kNameClass, m_eNameClass);
	IQueryFilterPtr ipQFilter(CLSID_QueryFilter);
	if(S_OK != ipQFilter->put_WhereClause(CComBSTR(strWhere))){
		CLog::GetInstance().PrintLog1(false, true, false, true, err_type::error, err_code::NgSetFilter, sindy::schema::sj::road_name_list::kTableName);
		return false;
	}

	// �J�[�\���擾
	_ICursorPtr ipCursor;
	if(S_OK != m_ipRoadNameList->Search(ipQFilter, VARIANT_FALSE, &ipCursor)){
		CLog::GetInstance().PrintLog1(false, true, false, true, err_type::error, err_code::NgGetCursor, sindy::schema::sj::road_name_list::kTableName);
		return false;
	}

	_IRowPtr ipRow;
	while(S_OK == ipCursor->NextRow(&ipRow) && ipRow){
		// ���́A�ǂݎ擾
		CComVariant vaNameKanji, vaNameYomi;
		if(S_OK != ipRow->get_Value(m_lNameKanjiIndex, &vaNameKanji) ||
			S_OK != ipRow->get_Value(m_lNameYomiIndex, &vaNameYomi)){
				CLog::GetInstance().PrintLog1(false, true, false, true, err_type::error, err_code::NgGetValue, sindy::schema::sj::road_name_list::kTableName, getID(ipRow));
				return false;
		}
		// �Ȃ��͂������A���ꖼ�̎�ʓ��Ŗ��́A�ǂ݂��������R�[�h�����݂���ꍇ�̓G���[
		if(!m_setKanjiYomi.insert(std::make_pair(vaNameKanji.bstrVal, vaNameYomi.bstrVal)).second){
			CLog::GetInstance().PrintLog2(false, true, true, true, err_type::error, err_code::DuplicateData, sindy::schema::sj::road_name_list::kTableName, getID(ipRow));
			return false;
		}
	}

	return true;
}

bool CBaseUpd::loadTable2()
{
	// �K�v�ł���Όp����Œ�`

	return true;
}

bool CBaseUpd::checkProcRecord(const _IRowPtr& ipRow, _IRowPtr& ipRetRow, bool& bCheck)
{
	// �K�v�ł���Όp����Œ�`
	ipRetRow = ipRow;
	bCheck = true;

	return true;
}

bool CBaseUpd::importNameRecord(const CRoadNameRecord& cRoadNameRecord)
{
	IRowBufferPtr ipRowBuffer;
	if(S_OK != m_ipRoadNameList->CreateRowBuffer(&ipRowBuffer)){
		CLog::GetInstance().PrintLog1(false, true, true, true, err_type::error, err_code::NgCreateBuffer, sindy::schema::sj::road_name_list::kTableName);
		return false;
	}

	// ���R�[�h�ɑ����l�t�^
	if(S_OK != ipRowBuffer->put_Value(m_lPrgModifyDateIndex, CComVariant(m_strDateTime)) ||
		S_OK != ipRowBuffer->put_Value(m_lModifyPrgNameIndex, CComVariant(m_strPrgName)) ||
		S_OK != ipRowBuffer->put_Value(m_lUpdateTypeIndex, CComVariant(sindy::schema::sj::road_name_list::update_type::kCreated)) ||
		S_OK != ipRowBuffer->put_Value(m_lNameClassIndex, CComVariant(m_eNameClass)) ||
		S_OK != ipRowBuffer->put_Value(m_lNameKanjiIndex, CComVariant(cRoadNameRecord.m_strNameKanji)) ||
		S_OK != ipRowBuffer->put_Value(m_lNameYomiIndex, CComVariant(cRoadNameRecord.m_strNameYomi))){
			CLog::GetInstance().PrintLog2(false, true, true, true, err_type::error, err_code::NgPutValue, sindy::schema::sj::road_name_list::kTableName, _T(""));
			return false;
	}

	CComVariant vaOID;
	if(S_OK != m_ipRoadNameCursor->InsertRow(ipRowBuffer, &vaOID)){
		CLog::GetInstance().PrintLog2(false, true, true, true, err_type::error, err_code::NgInsertRow, sindy::schema::sj::road_name_list::kTableName, _T(""));
		return false;
	}

	// ������x���܂�����J�[�\��flush
	++m_flushCounter;
	if(FLUSHCOUNT < m_flushCounter){
		if(FAILED(m_ipRoadNameCursor->Flush())){
			CLog::GetInstance().PrintLog1(false, true, true, true, err_type::error, err_code::NgCursorFlush, sindy::schema::sj::road_name_list::kTableName);
			return false;
		}
		m_flushCounter = 0;
	}
	return true;
}

void CBaseUpd::setStoreInfo(const CString& strNameKanji, const CString& strNameYomi, CRoadNameRecord& cRoadNameRecord, bool& bStored)
{
	std::pair<CString,CString> pairName = std::make_pair(strNameKanji, strNameYomi);
	if(m_setKanjiYomi.cend() != m_setKanjiYomi.find(pairName)){
		// �o�^�ς݃��R�[�h
		bStored = true;
	} else {
		// ���o�^���R�[�h
		m_setKanjiYomi.insert(pairName);
		bStored = false;
		cRoadNameRecord.m_strNameKanji = strNameKanji;
		cRoadNameRecord.m_strNameYomi = strNameYomi;
	}
}

bool CBaseUpd::setTable2FieldIndex()
{
	// �K�v�ł���Όp����Œ�`

	return true;
}