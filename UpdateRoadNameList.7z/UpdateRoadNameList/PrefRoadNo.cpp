/*
 * Copyright (C) INCREMENT P CORP. All Rights Reserved.
 *
 * THIS SOFTWARE IS PROVIDED BY INCREMENT P CORP., WITHOUT WARRANTY OF
 * ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
 * AND NONINFRINGEMENT.
 *
 * IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDER BE LIABLE FOR ANY
 * CLAIM, DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING
 * OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
*/

#include "stdafx.h"
#include "PrefRoadNo.h"


bool CPrefRoadNo::setTable1FieldIndex()
{
	// m_ipTable1�i���H�����N�j�̃t�B�[���h�C���f�b�N�X�擾
	if(S_OK != m_ipTable1->FindField(CComBSTR(sindy::schema::road_link::kRoadClass), &m_lRoadLinkRoadClassIndex) || 0 > m_lRoadLinkRoadClassIndex ||
		S_OK != m_ipTable1->FindField(CComBSTR(sindy::schema::road_link::kRoadNo), &m_lRoadLinkRoadNoIndex) || 0 > m_lRoadLinkRoadNoIndex ||
		S_OK != m_ipTable1->FindField(CComBSTR(sindy::schema::road_link::kPrefCode), &m_lRoadLinkPrefCodeIndex) || 0 > m_lRoadLinkPrefCodeIndex){
		CLog::GetInstance().PrintLog1(false, true, false, true, err_type::error, err_code::NgFindField, m_strTableName1);
		return false;
	}
	return true;
}

bool CPrefRoadNo::checkStoredRecord(const _IRowPtr& ipRow, CRoadNameRecord& cRoadNameRecord, bool& bStored)
{
	// ���H�ԍ��A���R�[�h�擾
	CComVariant vaRoadNo, vaPrefCode;
	if(S_OK != ipRow->get_Value(m_lRoadLinkRoadNoIndex, &vaRoadNo) ||
		S_OK != ipRow->get_Value(m_lRoadLinkPrefCodeIndex, &vaPrefCode)){
			CLog::GetInstance().PrintLog1(false, true, false, true, err_type::error, err_code::NgGetValue, m_strTableName1, getID(ipRow));
			return false;
	}

	// ���H�ԍ��A���R�[�h���疼�́A�ǂݐݒ�
	CString strNameKanji;
	CString strNameYomi;
	strNameKanji.Format(_T("%s��%s��"), prefCode2PrefName(vaPrefCode.lVal), num2ZenStr(vaRoadNo.lVal));
	strNameYomi.Format(_T("%s�h�E%s�S�E"), prefCode2PrefYomi(vaPrefCode.lVal), num2YomiStr(vaRoadNo.lVal));

	// �o�^���Z�b�g
	setStoreInfo(strNameKanji, strNameYomi, cRoadNameRecord, bStored);

	return true;
}

