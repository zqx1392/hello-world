/*
 * Copyright (C) INCREMENT P CORP. All Rights Reserved.
 *
 * THIS SOFTWARE IS PROVIDED BY INCREMENT P CORP., WITHOUT WARRANTY OF
 * ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
 * AND NONINFRINGEMENT.
 *
 * IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDER BE LIABLE FOR ANY
 * CLAIM, DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING
 * OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
*/

#include "stdafx.h"
#include "ShieldRoadNo.h"


bool CShieldRoadNo::setTable1FieldIndex()
{
	// m_ipTable1�i���H�����N�j�̃t�B�[���h�C���f�b�N�X�擾
	if(S_OK != m_ipTable1->FindField(CComBSTR(sindy::schema::road_link::kRoadNo), &m_lRoadLinkRoadNoIndex) || 0 > m_lRoadLinkRoadNoIndex){
		CLog::GetInstance().PrintLog1(false, true, false, true, err_type::error, err_code::NgFindField, m_strTableName1);
		return false;
	}
	return true;
}

bool CShieldRoadNo::checkStoredRecord(const _IRowPtr& ipRow, CRoadNameRecord& cRoadNameRecord, bool& bStored)
{
	CComVariant vaRoadNo;
	if(S_OK != ipRow->get_Value(m_lRoadLinkRoadNoIndex, &vaRoadNo)){
		CLog::GetInstance().PrintLog1(false, true, false, true, err_type::error, err_code::NgGetValue, m_strTableName1, getID(ipRow));
		return false;
	}
	CString strNameKanji;
	strNameKanji.Format(_T("%ld"), vaRoadNo.lVal);
	CString strNameYomi(_T(""));

	setStoreInfo(strNameKanji, strNameYomi, cRoadNameRecord, bStored);

	return true;
}
