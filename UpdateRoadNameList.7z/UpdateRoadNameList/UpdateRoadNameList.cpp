/*
 * Copyright (C) INCREMENT P CORP. All Rights Reserved.
 *
 * THIS SOFTWARE IS PROVIDED BY INCREMENT P CORP., WITHOUT WARRANTY OF
 * ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
 * AND NONINFRINGEMENT.
 *
 * IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDER BE LIABLE FOR ANY
 * CLAIM, DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING
 * OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
*/

#include "stdafx.h"
#include <WinLib/VersionInfo.h>
#include "UpdateRoadNameList.h"
#include "BaseUpd.h"
#include "ShieldRoadNo.h"
#include "ShieldHwyNo.h"
#include "NationalRoadNo.h"
#include "PrefRoadNoName.h"
#include "PrefRoadNo.h"
#include "PrefRoadNoAbbr.h"
#include "PrefRoadName.h"
#include "RoadName.h"
#include "RoadHwyAbbr.h"
#include "RoadCityHwyAbbr.h"
#include "RoadCityHwyAbbr2.h"
#include "SectionName.h"

bool CUpdateRoadNameList::init(const Arguments& args)
{
	// ���HDB�ڑ�
	m_ipRoadWork = sindy::create_workspace(args.m_road_db.c_str());
	if(!m_ipRoadWork){
		CLog::GetInstance().PrintLog1(false, true, false, true, err_type::fatal, err_code::NgDBConnect, CString(args.m_road_db.c_str()));
		return false;
	}
	// ���HDB�p�̃I�[�i�[��
	m_strRoadOwner = args.m_road_owner.c_str();

	// ���H����DB�ڑ�
	m_ipNameWork = sindy::create_workspace(args.m_name_db.c_str());
	if(!m_ipNameWork){
		CLog::GetInstance().PrintLog1(false, true, false, true, err_type::fatal, err_code::NgDBConnect, CString(args.m_name_db.c_str()));
		return false;
	}
	// ���H���̃e�[�u���擾
	if(S_OK != m_ipNameWork->OpenTable(CComBSTR(sindy::schema::sj::road_name_list::kTableName), &m_ipRoadNameList)){
		CLog::GetInstance().PrintLog1(false, true, false, true, err_type::fatal, err_code::NgOpenTable, sindy::schema::sj::road_name_list::kTableName);
		return false;
	}
	// ���H�����N�e�[�u���擾
	CString strRoadLinkTableName = sindy::schema::road_link::kTableName;
	if(!m_strRoadOwner.IsEmpty()){
		strRoadLinkTableName = m_strRoadOwner + _T(".") + strRoadLinkTableName;
	}
	if(S_OK != m_ipRoadWork->OpenTable(CComBSTR(strRoadLinkTableName), &m_ipRoadLink)){
		CLog::GetInstance().PrintLog1(false, true, false, true, err_type::fatal, err_code::NgOpenTable, sindy::schema::road_link::kTableName);
		return false;
	}
	// ROAD_CODE_LIST�e�[�u���擾
	CString strRoadCodeListTableName = sindy::schema::road_code_list::kTableName;
	if (!m_strRoadOwner.IsEmpty()) {
		strRoadCodeListTableName = m_strRoadOwner + _T(".") + strRoadCodeListTableName;
	}
	if(S_OK != m_ipRoadWork->OpenTable(CComBSTR(strRoadCodeListTableName), &m_ipRoadCodeList)){
		CLog::GetInstance().PrintLog1(false, true, false, true, err_type::fatal, err_code::NgOpenTable, sindy::schema::road_code_list::kTableName);
		return false;
	}
	// �������̃e�[�u���擾
	CString strPrefRoadListTableName = sindy::schema::pref_road_list::kTableName;
	if (!m_strRoadOwner.IsEmpty()) {
		strPrefRoadListTableName = m_strRoadOwner + _T(".") + strPrefRoadListTableName;
	}
	if(S_OK != m_ipRoadWork->OpenTable(CComBSTR(strPrefRoadListTableName), &m_ipPrefRoadList)){
		CLog::GetInstance().PrintLog1(false, true, false, true, err_type::fatal, err_code::NgOpenTable, sindy::schema::pref_road_list::kTableName);
		return false;
	}
	CString strSectionCodeListTableName = sindy::schema::section_code_list::kTableName;
	if (!m_strRoadOwner.IsEmpty()) {
		strSectionCodeListTableName = m_strRoadOwner + _T(".") + strSectionCodeListTableName;
	}
	// ��Ԗ��̃e�[�u���擾
	if(S_OK != m_ipRoadWork->OpenTable(CComBSTR(strSectionCodeListTableName), &m_ipSectionCodeList)){
		CLog::GetInstance().PrintLog1(false, true, false, true, err_type::fatal, err_code::NgOpenTable, sindy::schema::section_code_list::kTableName);
		return false;
	}

	return true;
}

bool CUpdateRoadNameList::run()
{
	// �ҏW�J�n
	CLog::GetInstance().PrintLog(true, false, true, false, _T("---�ҏW�J�n---"));
	if(!startEdit()){
		return false;
	}

	// �X�V����
	bool bSucceeded = updateData();

	// �ҏW�I��
	if(!bSucceeded){
		// �G���[������ꍇ�͕ҏW�j��
		CLog::GetInstance().PrintLog(true, false, true, false, _T("---�ҏW�j��---"));
		if(!abortEdit()){
			return false;
		}
		return false;
	} else {
		// �G���[���Ȃ���ΕҏW�ۑ�
		CLog::GetInstance().PrintLog(true, false, true, false, _T("---�ҏW�I��---\n"));
		if(!stopEdit()){
			return false;
		}
	}

	return true;
}

bool CUpdateRoadNameList::updateData()
{
	CVersion cVer;
	CString strPrgName = cVer.GetOriginalFilename();
	CString strDateTime = getNowTime();

	// �W�����H�ԍ�
	CLog::GetInstance().PrintLog(true, false, true, false, _T("�� �W�����H�ԍ�"));
	CShieldRoadNo cShieldRoadNo(strPrgName, strDateTime);
	if (!cShieldRoadNo.run(m_ipRoadNameList, m_ipRoadLink, nullptr)) {
		return false;
	}

	// �W�������ԍ�
	CLog::GetInstance().PrintLog(true, false, true, false, _T("�� �W�������ԍ�"));
	CShieldHwyNo cShieldHwyNo(strPrgName, strDateTime);
	if (!cShieldHwyNo.run(m_ipRoadNameList, m_ipRoadCodeList, nullptr)) {
		return false;
	}

	// �����ԍ�
	CLog::GetInstance().PrintLog(true, false, true, false, _T("�� �����ԍ�"));
	CNationalRoadNo cNationalRoadNo(strPrgName, strDateTime);
	if (!cNationalRoadNo.run(m_ipRoadNameList, m_ipRoadLink, nullptr)) {
		return false;
	}

	// �����ԍ��E����
	CLog::GetInstance().PrintLog(true, false, true, false, _T("�� �����ԍ��E����"));
	CPrefRoadNoName cPrefRoadNoName(strPrgName, strDateTime);
	if (!cPrefRoadNoName.run(m_ipRoadNameList, m_ipRoadLink, m_ipPrefRoadList)) {
		return false;
	}

	// �����ԍ�
	CLog::GetInstance().PrintLog(true, false, true, false, _T("�� �����ԍ�"));
	CPrefRoadNo cPrefRoadNo(strPrgName, strDateTime);
	if (!cPrefRoadNo.run(m_ipRoadNameList, m_ipRoadLink, nullptr)) {
		return false;
	}

	// �����ԍ��E����
	CLog::GetInstance().PrintLog(true, false, true, false, _T("�� �����ԍ��E����"));
	CPrefRoadNoAbbr cPrefRoadNoAbbr(strPrgName, strDateTime);
	if (!cPrefRoadNoAbbr.run(m_ipRoadNameList, m_ipRoadLink, nullptr)) {
		return false;
	}

	// ��������
	CLog::GetInstance().PrintLog(true, false, true, false, _T("�� ��������"));
	CPrefRoadName cPrefRoadName(strPrgName, strDateTime);
	if (!cPrefRoadName.run(m_ipRoadNameList, m_ipRoadLink, m_ipPrefRoadList)) {
		return false;
	}

	// �H������
	CLog::GetInstance().PrintLog(true, false, true, false, _T("�� �H������"));
	CRoadName cRoadName(strPrgName, strDateTime);
	if (!cRoadName.run(m_ipRoadNameList, m_ipRoadCodeList, nullptr)) {
		return false;
	}

	// �������H����
	CLog::GetInstance().PrintLog(true, false, true, false, _T("�� �������H����"));
	CRoadHwyAbbr cRoadHwyAbbr(strPrgName, strDateTime);
	if (!cRoadHwyAbbr.run(m_ipRoadNameList, m_ipRoadCodeList, nullptr)) {
		return false;
	}

	// �s�s��������
	CLog::GetInstance().PrintLog(true, false, true, false, _T("�� �s�s��������"));
	CRoadCityHwyAbbr cRoadCityHwyAbbr(strPrgName, strDateTime);
	if (!cRoadCityHwyAbbr.run(m_ipRoadNameList, m_ipRoadCodeList, nullptr)) {
		return false;
	}

	// �s�s��������2
	CLog::GetInstance().PrintLog(true, false, true, false, _T("�� �s�s��������2"));
	CRoadCityHwyAbbr2 cRoadCityHwyAbbr2(strPrgName, strDateTime);
	if (!cRoadCityHwyAbbr2.run(m_ipRoadNameList, m_ipRoadCodeList, nullptr)) {
		return false;
	}

	// ��Ԗ���
	CLog::GetInstance().PrintLog(true, false, true, false, _T("�� ��Ԗ���"));
	CSectionName cSectionName(strPrgName, strDateTime);
	if (!cSectionName.run(m_ipRoadNameList, m_ipRoadLink, m_ipSectionCodeList)) {
		return false;
	}
	return true;
}
bool CUpdateRoadNameList::startEdit()
{
	if(S_OK != IWorkspaceEdit2Ptr(m_ipNameWork)->StartEditing(VARIANT_FALSE)){
		CLog::GetInstance().PrintLog1(false, true, true, true, err_type::error, err_code::NgStartEdit);
		return false;
	}
	if(S_OK != IWorkspaceEdit2Ptr(m_ipNameWork)->StartEditOperation()){
		CLog::GetInstance().PrintLog1(false, true, true, true, err_type::error, err_code::NgStartEditOp);
		return false;
	}
	return true;
}

bool CUpdateRoadNameList::stopEdit()
{
	// �ҏW�J�n���Ă��邩�m�F
	VARIANT_BOOL vaIsBeingEdited = VARIANT_FALSE;
	if(S_OK != IWorkspaceEdit2Ptr(m_ipNameWork)->IsBeingEdited(&vaIsBeingEdited)){
		CLog::GetInstance().PrintLog1(false, true, true, true, err_type::error, err_code::NgIsBeingEdited);
		return false;
	}
	// �ҏW�J�n���Ă��Ȃ���ΏI��
	if(!vaIsBeingEdited){
		return true;
	}
	if(S_OK != IWorkspaceEdit2Ptr(m_ipNameWork)->StopEditOperation()){
		CLog::GetInstance().PrintLog1(false, true, true, true, err_type::error, err_code::NgStopEditOp);
		return false;
	}
	if(S_OK != IWorkspaceEdit2Ptr(m_ipNameWork)->StopEditing(VARIANT_TRUE)){
		CLog::GetInstance().PrintLog1(false, true, true, true, err_type::error, err_code::NgStopEdit);
		return false;
	}
	return true;
}

bool CUpdateRoadNameList::abortEdit()
{
	// StartEditOperation���Ă��邩�m�F
	VARIANT_BOOL vaIsStartEditOp = VARIANT_FALSE;
	if(S_OK != IWorkspaceEdit2Ptr(m_ipNameWork)->get_IsInEditOperation(&vaIsStartEditOp)){
		CLog::GetInstance().PrintLog1(false, true, true, true, err_type::error, err_code::NgIsInEditOp);
		return false;
	}
	// �ҏW�J�n���m�F�ł��Ă���Abort
	if(S_OK != IWorkspaceEdit2Ptr(m_ipNameWork)->AbortEditOperation()){
		CLog::GetInstance().PrintLog1(false, true, true, true, err_type::error, err_code::NgAbortEditOp);
		return false;
	}
	// Abort������StopEdit
	if(S_OK != IWorkspaceEdit2Ptr(m_ipNameWork)->StopEditing(VARIANT_TRUE)){
		CLog::GetInstance().PrintLog1(false, true, true, true, err_type::error, err_code::NgStopEdit);
		return false;
	}
	return true;
}
