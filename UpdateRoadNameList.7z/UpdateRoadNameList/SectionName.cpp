/*
 * Copyright (C) INCREMENT P CORP. All Rights Reserved.
 *
 * THIS SOFTWARE IS PROVIDED BY INCREMENT P CORP., WITHOUT WARRANTY OF
 * ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
 * AND NONINFRINGEMENT.
 *
 * IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDER BE LIABLE FOR ANY
 * CLAIM, DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING
 * OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
*/

#include "stdafx.h"
#include "SectionName.h"


bool CSectionName::setTable1FieldIndex()
{
	// m_ipTable1�i���H�����N�j�̃t�B�[���h�C���f�b�N�X�擾
	if(S_OK != m_ipTable1->FindField(CComBSTR(sindy::schema::road_link::kSectionCode), &m_lRoadLinkSectionCodeIndex) || 0 > m_lRoadLinkSectionCodeIndex){
		CLog::GetInstance().PrintLog1(false, true, false, true, err_type::error, err_code::NgFindField, m_strTableName1);
		return false;
	}
	return true;
}

bool CSectionName::setTable2FieldIndex()
{
	// m_ipTable2�i��Ԗ��̃e�[�u���j�̃t�B�[���h�C���f�b�N�X�擾
	if(S_OK != m_ipTable2->FindField(CComBSTR(sindy::schema::section_code_list::kNameKanji), &m_lSectionCodeNameKanjiIndex) || 0 > m_lSectionCodeNameKanjiIndex ||
		S_OK != m_ipTable2->FindField(CComBSTR(sindy::schema::section_code_list::kNameYomi), &m_lSectionCodeNameYomiIndex) || 0 > m_lSectionCodeNameYomiIndex ||
		S_OK != m_ipTable2->FindField(CComBSTR(sindy::schema::section_code_list::kSectionCode), &m_lSectionCodeSectionCodeIndex) || 0 > m_lSectionCodeSectionCodeIndex){
		CLog::GetInstance().PrintLog1(false, true, false, true, err_type::error, err_code::NgFindField, m_strTableName2);
		return false;
	}
	return true;
}

bool CSectionName::loadTable2()
{
	// m_ipTable2�i��Ԗ��̃e�[�u���j�̃��R�[�h�S�擾
	_ICursorPtr ipCursor;
	if(S_OK != m_ipTable2->Search(NULL, VARIANT_FALSE, &ipCursor)){
		CLog::GetInstance().PrintLog1(false, true, false, true, err_type::error, err_code::NgGetCursor, m_strTableName2);
		return false;
	}

	_IRowPtr ipRow;
	while(S_OK == ipCursor->NextRow(&ipRow) && ipRow){
		// ���́A�ǂݎ擾
		CComVariant vaSectionCode;
		if(S_OK != ipRow->get_Value(m_lSectionCodeSectionCodeIndex, &vaSectionCode)){
			CLog::GetInstance().PrintLog1(false, true, false, true, err_type::error, err_code::NgGetValue, m_strTableName2, getID(ipRow));
			return false;
		}
		// �Ȃ��͂������A��ԃR�[�h���d������ꍇ�̓G���[
		if(!m_mapSectionCodeList.insert(std::make_pair(vaSectionCode.lVal, ipRow)).second){
			CLog::GetInstance().PrintLog2(false, true, true, true, err_type::error, err_code::DuplicateData, m_strTableName2, getID(ipRow));
			return false;
		}
	}

	return true;
}

bool CSectionName::checkStoredRecord(const _IRowPtr& ipRow, CRoadNameRecord& cRoadNameRecord, bool& bStored)
{
	// ��Ԗ��̃��R�[�h����A���́A�ǂݎ擾
	CComVariant vaNameKanji, vaNameYomi;
	if(S_OK != ipRow->get_Value(m_lSectionCodeNameKanjiIndex, &vaNameKanji) ||
		S_OK != ipRow->get_Value(m_lSectionCodeNameYomiIndex, &vaNameYomi)){
		CLog::GetInstance().PrintLog1(false, true, false, true, err_type::error, err_code::NgGetValue, m_strTableName1, getID(ipRow));
		return false;
	}
	CString strNameKanji(vaNameKanji.bstrVal);
	CString strNameYomi(vaNameYomi.bstrVal);

	setStoreInfo(strNameKanji, strNameYomi, cRoadNameRecord, bStored);

	return true;
}

bool CSectionName::checkProcRecord(const _IRowPtr& ipRow, _IRowPtr& ipRetRow, bool& bCheck)
{
	bCheck = false;

	// ipRow�i���H�����N�j�����ԃR�[�h�擾
	CComVariant vaSectionCode;
	if(S_OK != ipRow->get_Value(m_lRoadLinkSectionCodeIndex, &vaSectionCode)){
		CLog::GetInstance().PrintLog1(false, true, false, true, err_type::error, err_code::NgGetValue, m_strTableName1, getID(ipRow));
		return false;
	}
	// ��Ԗ��̃��R�[�h���ɓ��H�����N����擾������ԃR�[�h�ɑΉ����郌�R�[�h�����݂��邩�`�F�b�N
	const auto& it = m_mapSectionCodeList.find(vaSectionCode.lVal);
	if(m_mapSectionCodeList.cend() == it){
		// ���݂��Ȃ���ΏI��
		return true;
	}

	ipRetRow = it->second;
	bCheck = true;

	return true;
}
