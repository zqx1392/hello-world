/*
 * Copyright (C) INCREMENT P CORP. All Rights Reserved.
 *
 * THIS SOFTWARE IS PROVIDED BY INCREMENT P CORP., WITHOUT WARRANTY OF
 * ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
 * AND NONINFRINGEMENT.
 *
 * IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDER BE LIABLE FOR ANY
 * CLAIM, DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING
 * OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
*/

#pragma once

#include "BaseUpd.h"

/**
 * @brief �W�������ԍ������p�N���X
 */
class CShieldHwyNo : public CBaseUpd
{
public:
	CShieldHwyNo(const CString& strPrgName, const CString& strDateTime) : CBaseUpd(strPrgName, strDateTime), m_lRoadCodeShielNoIndex(-1)
	{
		// ���̃R�[�h�ݒ�
		m_eNameClass = sindy::schema::sj::road_name_list::name_class::kShieldHwyNo;
		// ���������ݒ�
		m_strTableName1.Format(_T("%s"), sindy::schema::road_code_list::kTableName);
		m_strWhere1.Format(_T("%s IS NOT NULL"), sindy::schema::road_code_list::kShieldNoStr);
	}
	~CShieldHwyNo() override {};

protected:
	bool setTable1FieldIndex() override;
	bool checkStoredRecord(const _IRowPtr& ipRow, CRoadNameRecord& cRoadNameRecord, bool& bStored) override;

private:
	long m_lRoadCodeShielNoIndex;	//!< ROAD_CODE_LIST�F�W���ԍ��E�L���t�B�[���h�C���f�b�N�X

};

