/*
 * Copyright (C) INCREMENT P CORP. All Rights Reserved.
 *
 * THIS SOFTWARE IS PROVIDED BY INCREMENT P CORP., WITHOUT WARRANTY OF
 * ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
 * AND NONINFRINGEMENT.
 *
 * IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDER BE LIABLE FOR ANY
 * CLAIM, DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING
 * OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
*/

#include "stdafx.h"
#include "NationalRoadNo.h"


bool CNationalRoadNo::setTable1FieldIndex()
{
	// m_ipTable1�i���H�����N�j�̃t�B�[���h�C���f�b�N�X�擾
	if(S_OK != m_ipTable1->FindField(CComBSTR(sindy::schema::road_link::kRoadClass), &m_lRoadLinkRoadClassIndex) || 0 > m_lRoadLinkRoadClassIndex ||
		S_OK != m_ipTable1->FindField(CComBSTR(sindy::schema::road_link::kRoadNo), &m_lRoadLinkRoadNoIndex) || 0 > m_lRoadLinkRoadNoIndex){
		CLog::GetInstance().PrintLog1(false, true, false, true, err_type::error, err_code::NgFindField, m_strTableName1);
		return false;
	}
	return true;
}

bool CNationalRoadNo::checkStoredRecord(const _IRowPtr& ipRow, CRoadNameRecord& cRoadNameRecord, bool& bStored)
{
	// ���H�ԍ��擾
	CComVariant vaRoadNo;
	if(S_OK != ipRow->get_Value(m_lRoadLinkRoadNoIndex, &vaRoadNo)){
		CLog::GetInstance().PrintLog1(false, true, false, true, err_type::error, err_code::NgGetValue, m_strTableName1, getID(ipRow));
		return false;
	}
	// ���́A�ǂݐݒ�
	CString strNameKanji;
	CString strNameYomi;
	strNameKanji.Format(_T("����%s��"), num2ZenStr(vaRoadNo.lVal));
	strNameYomi.Format(_T("�R�N�h�E%s�S�E"), num2YomiStr(vaRoadNo.lVal));

	// �o�^���Z�b�g
	setStoreInfo(strNameKanji, strNameYomi, cRoadNameRecord, bStored);

	return true;
}
