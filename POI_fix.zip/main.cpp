#pragma once
#include "stdafx.h"
#include <arctl/coinitializer.h>
#include "POILocationImprover.h"

int _tmain(int argc, _TCHAR* argv[])
{
	arctl::coinitializer aCoInitializer;
	POILocationImprover cPOILocationImprover;
	return cPOILocationImprover.start(argc,argv);
}