#pragma once
#include "stdafx.h"

#include "POILocationImprover.h"



POILocationImprover::POILocationImprover() {
}

POILocationImprover::~POILocationImprover() {

}
void POILocationImprover::setIOManager(IOManager * _IOManager) {
	m_IOManager = _IOManager;
}
void POILocationImprover::setSVManager(AccessSV * _accessSV) {
	m_accessSV = _accessSV;
}
void POILocationImprover::setErrorManager(ErrorManager * _errorManager) {
	m_errorManager = _errorManager;
}
void POILocationImprover::setOptionManager(OptionManager * _OptionManager) {
	m_OptionManager = _OptionManager;
}
void POILocationImprover::setDataManager(DataManager * _dataManager) {
	m_dataManager = _dataManager;
}

int POILocationImprover::printSuccessfulEnd() {
	m_IOManager->print_run(_T("Program ends successfully"));
	m_IOManager->print_no_timestamp_run(_T(""));
	m_IOManager->print_total_execution_time();
	m_IOManager->closeFile();
	std::cout << "Press any key to continue...";
	std::cin.get();
	return ErrorManager::RCode::R_SUCCESS;
}
int POILocationImprover::endProgramWithError(CString errorPoint) {
	CString errorDesc = "An error occured during " + errorPoint;
	m_IOManager->print_run(errorDesc);
	CString errorType;
	if (!_tcscmp(errorPoint, (CString)"Com Error")) {
		errorType = "Exception Error";
	}
	else {
		errorType = "Unsuccessful Termination";
	}
	m_IOManager->print_no_timestamp_run(errorType);
	m_IOManager->print_no_timestamp_run("");
	m_IOManager->closeFile();
	return ErrorManager::RCode::R_FAILED_FATAL_ERROR;
}

bool POILocationImprover::is_number(const std::wstring& s)
{
	return !s.empty() && std::find_if(s.begin(),
		s.end(), [](char c) { return !std::iswdigit(c); }) == s.end();
}

int POILocationImprover::setNewOption(){
	bool doEdit = true;
	bool isPOI_FGDB = false;
	bool isPP_FGDB = false;
	//get option argument from OptionManager
	std::wstring POIServerName = m_OptionManager->getOptionArgument(OptionManager::OptionName::POI_INFO_DB);
	std::wstring PPServerName = m_OptionManager->getOptionArgument(OptionManager::OptionName::POSTALPOINT_DB);
	std::wstring errFileName = m_OptionManager->getOptionArgument(OptionManager::OptionName::ERR_LOG);
	std::wstring runFileName = m_OptionManager->getOptionArgument(OptionManager::OptionName::RUN_LOG);
	std::wstring PPLayerName = m_OptionManager->getOptionArgument(OptionManager::OptionName::POSTALPOINT_LAYER);
	std::wstring POILayerName = m_OptionManager->getOptionArgument(OptionManager::OptionName::POI_INFO_LAYER);
	std::wstring PPFieldName = m_OptionManager->getOptionArgument(OptionManager::OptionName::POSTALPOINT_FIELD);
	std::wstring POIFieldName = m_OptionManager->getOptionArgument(OptionManager::OptionName::POI_INFO_FIELD);
	std::wstring SQLText = m_OptionManager->getOptionArgument(OptionManager::OptionName::SQL);

	//check if the input is FGDB 
	if (POIServerName.find(L"@") == std::string::npos && POIServerName.find(L".gdb") != std::string::npos) isPOI_FGDB = true;
	if (PPServerName.find(L"@") == std::string::npos && PPServerName.find(L".gdb") != std::string::npos) isPP_FGDB = true;

	//since boost can't define default value for wstring. Define the default value here
	if (SQLText.empty()) {
		SQLText = L"PRODUCT_C=1";
	}
	if (errFileName.empty()) {
		errFileName = L"err.log";
	}
	if (runFileName.empty()) {
		runFileName = L"run.log";
	}
	//parse to data manager
	try{
		std::string ERR_LOG = m_OptionManager->getOptionName(OptionManager::OptionName::ERR_LOG);
		std::string RUN_LOG = m_OptionManager->getOptionName(OptionManager::OptionName::RUN_LOG);
		std::string POSTALPOINT_DB = m_OptionManager->getOptionName(OptionManager::OptionName::POSTALPOINT_DB);
		std::string POI_INFO_DB = m_OptionManager->getOptionName(OptionManager::OptionName::POI_INFO_DB);
		std::string POSTALPOINT_LAYER = m_OptionManager->getOptionName(OptionManager::OptionName::POSTALPOINT_LAYER);
		std::string POI_INFO_LAYER = m_OptionManager->getOptionName(OptionManager::OptionName::POI_INFO_LAYER);
		std::string POSTALPOINT_FIELD = m_OptionManager->getOptionName(OptionManager::OptionName::POSTALPOINT_FIELD);
		std::string POI_INFO_FIELD = m_OptionManager->getOptionName(OptionManager::OptionName::POI_INFO_FIELD);
		m_dataManager->setNewFile(ERR_LOG, errFileName, IOManager::FileType::ERR);
		m_dataManager->setNewFile(RUN_LOG, runFileName, IOManager::FileType::RUN);
		m_dataManager->setNewDB(POSTALPOINT_DB, PPServerName, isPP_FGDB, !doEdit);
		m_dataManager->setNewDB(POI_INFO_DB, POIServerName, isPOI_FGDB, doEdit);
		m_dataManager->setNewFeatureClass(POSTALPOINT_DB, POSTALPOINT_LAYER, PPServerName, PPLayerName, isPP_FGDB);
		m_dataManager->setNewFeatureClass(POI_INFO_DB, POI_INFO_LAYER, POIServerName, POILayerName, isPOI_FGDB);
		m_dataManager->setNewFieldName(POSTALPOINT_FIELD, PPFieldName);
		m_dataManager->setNewFieldName(POI_INFO_FIELD, POIFieldName);
		m_dataManager->setSQL(SQLText);
	}
	catch (const _com_error e) {
		ErrorManager::RCode::R_FAILED_FATAL_ERROR;
	}
	return ErrorManager::RCode::R_SUCCESS;
}

int POILocationImprover::findPPPostalCode(std::map<_bstr_t, std::pair<double, double> > * PPCoordinates) {
	
	IQueryFilterPtr PPipQueryFilter(CLSID_QueryFilter);
	//set Postal Code as search target field
	_bstr_t columnFilter =  m_PPFIELD + "," + sindy::schema::global::postal_point::kShape;
	if (S_OK != PPipQueryFilter->put_SubFields(columnFilter)) {
		m_IOManager->print_error(ErrorManager::ECode::E_FAILED_TO_SET_DATA, _T("Search field"));
		return ErrorManager::RCode::R_FAILED_FATAL_ERROR;
	}
	//set all condition into query variable
	IFeatureCursorPtr ipPPCursor;
	if (S_OK != m_PPFeatureClass->Search(PPipQueryFilter, VARIANT_FALSE, &ipPPCursor)) {
		m_IOManager->print_error(ErrorManager::ECode::E_FAILED_TO_SEARCH, m_PPFeatureClassName);
		return ErrorManager::RCode::R_FAILED_FATAL_ERROR;
	}
	// get column index
	long postalCodeIndex;
	if (S_OK != ipPPCursor->Fields->FindField(m_PPFIELD, &postalCodeIndex)) {
		CString errorMsg = "Postal Code field index";
		m_IOManager->print_error(ErrorManager::ECode::E_FAILED_TO_GET_DATA, errorMsg);
		return ErrorManager::RCode::R_FAILED_FATAL_ERROR;
	}
	CString msg = (LPCTSTR)m_PPFIELD + (CString)" field has been acquired successfully";
	m_IOManager->print_run(msg);
	//get target postal code
	IFeaturePtr ipPPFeature;
	while (ipPPCursor->NextFeature(&ipPPFeature) == S_OK && ipPPFeature) {
			// get postal code data
			_variant_t postalCode;
			if (S_OK != ipPPFeature->get_Value(postalCodeIndex, &postalCode)) {
				CString errorMsg = "Postal Code";
				m_IOManager->print_error(ErrorManager::ECode::E_FAILED_TO_GET_DATA, errorMsg);
				return ErrorManager::RCode::R_FAILED_FATAL_ERROR;
			}
			// get shape
			IGeometryPtr ipPPGeom;
			if (S_OK != ipPPFeature->get_ShapeCopy(&ipPPGeom)) {
				CString errorMsg = (CString)"Postal Code : " + postalCode.bstrVal;
				m_IOManager->print_error(ErrorManager::ECode::E_FAILED_TO_GET_DATA, errorMsg);
				return ErrorManager::RCode::R_FAILED_FATAL_ERROR;
			}

			// get PP coordinates
			double orgX = 0.0, orgY = 0.0;
			if (S_OK != IPointPtr(ipPPGeom)->QueryCoords(&orgX, &orgY) || orgX == 0 || orgY == 0) {
				CString errorMsg = (CString)"Postal Code : " + postalCode.bstrVal + " coordinates";
				m_IOManager->print_error(ErrorManager::ECode::E_FAILED_TO_GET_DATA, errorMsg);
				continue;
			}

			// store coordinates in map
			std::pair<std::map<_bstr_t, std::pair<double, double> >::iterator, bool> isSuccess;
			isSuccess = PPCoordinates->insert(std::make_pair((_bstr_t)postalCode.bstrVal,std::make_pair(orgX,orgY)));
			// if postal code is already stored
			if (isSuccess.second == false) {
				CString errorMsg = (CString)"Postal Code : " + postalCode.bstrVal + " has more than 1 record in POSTALPOINT,";
				m_IOManager->print_error(ErrorManager::ECode::E_FAILED_TO_GET_DATA, errorMsg);
				return ErrorManager::RCode::R_FAILED_FATAL_ERROR;
			}
		}
	return ErrorManager::RCode::R_SUCCESS;
}

int POILocationImprover::copyPostalPointCoordinates(CString objectID, _bstr_t postalCode, IGeometryPtr & ipPOIGeom, std::map<_bstr_t, std::pair<double, double> > * PPCoordinates) {

	double bakX = 0.0, bakY = 0.0;
	// if not found match postal code
	if (PPCoordinates->find(postalCode) == PPCoordinates->end()) {
		CString errorMsg = (CString)"POI_INFO OBJECTID " + objectID + " Postal Code : " + (BSTR)postalCode + " is not found in POSTALPOINT,";
		m_IOManager->print_error(ErrorManager::ECode::E_FAILED_TO_GET_DATA, errorMsg);
		return ErrorManager::RCode::R_FAILED_FATAL_ERROR;
	}
	// get POI coordinates
	if (S_OK != IPointPtr(ipPOIGeom)->QueryCoords(&bakX, &bakY) || bakX == 0 || bakY == 0) {
		CString errorMsg = (CString)"POI_INFO OBJECTID : " + objectID + " coordinates";
		m_IOManager->print_error(ErrorManager::ECode::E_FAILED_TO_GET_DATA, errorMsg);
		return ErrorManager::RCode::R_FAILED_FATAL_ERROR;
	}
	double newX = PPCoordinates->find(postalCode)->second.first;
	double newY = PPCoordinates->find(postalCode)->second.second;
	// compare coordinates if it already copied
	if (newX == bakX && newY == bakY) {
		m_IOManager->print_run_no_cout((CString)"POI_INFO OBJECTID = " + objectID + " : Coordinates are already accurate.");
		return ErrorManager::RCode::R_FAILED_FATAL_ERROR;
	}
	// edit POI coordinates
	// STILL NOT UPDATE TO DATABASE YET!
	if (S_OK != IPointPtr(ipPOIGeom)->PutCoords(newX, newY)) {
		CString errorMsg = (CString)"POI_INFO OBJECTID : " + objectID + " new coordinates";
		m_IOManager->print_error(ErrorManager::ECode::E_FAILED_TO_SET_DATA, errorMsg);

		return ErrorManager::RCode::R_FAILED_FATAL_ERROR;
	}
	return ErrorManager::RCode::R_SUCCESS;
}

int POILocationImprover::setPOISearchCondition(IQueryFilterPtr POIipQueryFilter){
	//set search (where) condition
	_bstr_t queryFilter = m_dataManager->getSQL().c_str();
	if (S_OK != POIipQueryFilter->put_WhereClause(queryFilter)) {
		m_IOManager->print_error(ErrorManager::ECode::E_FAILED_TO_SET_DATA, _T("Set search query"));
		return ErrorManager::RCode::R_FAILED_FATAL_ERROR;
	}
	
	//set Object ID, actual address, shape as search target fields
	_bstr_t columnFilter = sindy::schema::global::poi_info::kObjectID + (_bstr_t)"," + m_POIFIELD + "," + sindy::schema::global::poi_info::kShape;
	if (S_OK != POIipQueryFilter->put_SubFields(columnFilter)) {
		m_IOManager->print_error(ErrorManager::ECode::E_FAILED_TO_SET_DATA, _T("Set search field"));
		return ErrorManager::RCode::R_FAILED_FATAL_ERROR;
	}

	//set all condition into query variable
	if (S_OK != m_POIFeatureClass->Search(POIipQueryFilter, VARIANT_FALSE, &m_ipPOICursor)) {
		m_IOManager->print_error(ErrorManager::ECode::E_FAILED_TO_SEARCH, m_POIFeatureClassName);
		return ErrorManager::RCode::R_FAILED_FATAL_ERROR;
	}
	return ErrorManager::RCode::R_SUCCESS;
}

int POILocationImprover::countTotalPOIRecord(IQueryFilterPtr POIipQueryFilter){
	long progressCount = 0;
	if (S_OK != m_POIFeatureClass->FeatureCount(POIipQueryFilter, &progressCount)) {
		m_IOManager->print_error(ErrorManager::ECode::E_FAILED_TO_SEARCH, m_POIFeatureClassName);
		return ErrorManager::RCode::R_FAILED_FATAL_ERROR;
	}
	CString progressCountString;
	progressCountString.Format(L"%ld", progressCount);
	m_IOManager->print_run((CString)"Total target record : " + progressCountString);
	return ErrorManager::RCode::R_SUCCESS;
}

int POILocationImprover::getTargetPOIRecord(std::map<_bstr_t, std::pair<double, double> > * PPCoordinates, IQueryFilterPtr POIipQueryFilter, std::set<CString> * updateTargetPOI){
	// get column index
	long actualAddressIndex;
	if (S_OK != m_ipPOICursor->Fields->FindField(m_POIFIELD, &actualAddressIndex)) {
		CString errorMsg = "Actual Address field index";
		m_IOManager->print_error(ErrorManager::ECode::E_FAILED_TO_GET_DATA, errorMsg);
		return endProgramWithError("get Actual Address field index");
	}
	// get objectID index
	long objectIDIndex;
	if (S_OK != m_ipPOICursor->Fields->FindField((_bstr_t)sindy::schema::global::poi_info::kObjectID, &objectIDIndex)) {
		CString errorMsg = "ObjectID field index";
		m_IOManager->print_error(ErrorManager::ECode::E_FAILED_TO_GET_DATA, errorMsg);
		return endProgramWithError("get ObjectID field index");
	}
	CString msg = (LPCTSTR)m_POIFIELD + (CString)" field has been acquired successfully";
	m_IOManager->print_run(msg);
	IFeaturePtr ipPOIFeature;
	while (m_ipPOICursor->NextFeature(&ipPOIFeature) == S_OK && ipPOIFeature) {
		// get objectID
		_variant_t objectID;
		if (S_OK != ipPOIFeature->get_Value(objectIDIndex, &objectID)) {
			CString errorMsg = (CString)"POI_INFO OBJECTID";
			m_IOManager->print_error(ErrorManager::ECode::E_FAILED_TO_GET_DATA, errorMsg);
			continue;
		}
		CString objID;
		objID.Format(L"%ld", objectID.lVal);
		// get actual address data
		_variant_t actualAddress;
		if (S_OK != ipPOIFeature->get_Value(actualAddressIndex, &actualAddress)) {
			CString errorMsg = "Actual Address";
			m_IOManager->print_error(ErrorManager::ECode::E_FAILED_TO_GET_DATA, errorMsg);
			continue;
		}
		// if actual address data is empty
		if (actualAddress.bstrVal == NULL) {
			m_IOManager->print_run((CString)"Skip POI_INFO OBJECTID = " +  objID +" : Doesn't contain actual address.");
			continue;
		}
		//get 6-digit postal code
		std::wstring convertedAddress(actualAddress.bstrVal,SysStringLen(actualAddress.bstrVal));
		if (convertedAddress.length() < 6) {
			m_IOManager->print_run((CString)"Skip POI_INFO OBJECTID = " + objID + " : Doesn't contain valid 6-digit postal code at the end of address.");
			continue;
		}
		std::wstring postalCode = convertedAddress.substr(convertedAddress.length() - 6);
		// check if postalcode is valid 6-digit number
		if (!is_number(postalCode)) {
			m_IOManager->print_run((CString)"Skip POI_INFO OBJECTID = " + objID + " : Doesn't contain valid 6-digit postal code at the end of address.");
			continue;
		}
		_bstr_t convertedPostalCode = SysAllocStringLen(postalCode.data(), postalCode.size());

		// get POI shape
		IGeometryPtr ipPOIGeom;
		if (S_OK != ipPOIFeature->get_Shape(&ipPOIGeom)) {
			CString errorMsg = (CString)"OBJECTID : " + objID + " shape";
			m_IOManager->print_error(ErrorManager::ECode::E_FAILED_TO_GET_DATA, errorMsg);
			continue;
		}
		//START COPYING SHAPE (test if pre copy has no problem)
		int returnStatus = copyPostalPointCoordinates(objID, convertedPostalCode, ipPOIGeom, PPCoordinates);
		if (ErrorManager::RCode::R_SUCCESS != returnStatus ) {
			continue;
		}
		updateTargetPOI->insert(objID);
	}
	//reset POICursor
	if (S_OK != m_POIFeatureClass->Search(POIipQueryFilter, VARIANT_FALSE, &m_ipPOICursor)) {
		m_IOManager->print_error(ErrorManager::ECode::E_FAILED_TO_SEARCH, m_POIFeatureClassName);
		return ErrorManager::RCode::R_FAILED_FATAL_ERROR;
	}
	return ErrorManager::RCode::R_SUCCESS;
}
int POILocationImprover::editing(std::map<_bstr_t, std::pair<double, double> > * PPCoordinates, std::set<CString> * updateTargetPOI) {
	// start editing
	m_IOManager->print_run((CString)"Successfully acquired all target records. Editing target database�c");
	if (!startEdit()) {
		return endProgramWithError("start editing");
	}
	// update
	int updateResult = updateToDatabase(PPCoordinates, updateTargetPOI);
	// finish editing
	if (updateResult != 0) {
		m_IOManager->print_run((CString)"Failed to edit");
		if (!abortEdit()) {
			return endProgramWithError("abort editing");
		}
		return endProgramWithError("editing");
	}
	else {
		m_IOManager->print_run((CString)"Finished editing");
		if (!stopEdit()) {
			return endProgramWithError("stop editing");
		}
	}
	return updateResult;
}
bool POILocationImprover::startEdit()
{
	if (S_OK != IWorkspaceEdit2Ptr(m_POIFeatureWorkspace)->StartEditing(VARIANT_FALSE)) {
		return false;
	}
	if (S_OK != IWorkspaceEdit2Ptr(m_POIFeatureWorkspace)->StartEditOperation()) {
		return false;
	}
	return true;
}

bool POILocationImprover::stopEdit()
{
	// �ҏW�J�n���Ă��邩�m�F
	VARIANT_BOOL vaIsBeingEdited = VARIANT_FALSE;
	if (S_OK != IWorkspaceEdit2Ptr(m_POIFeatureWorkspace)->IsBeingEdited(&vaIsBeingEdited)) {
		return false;
	}
	// �ҏW�J�n���Ă��Ȃ���ΏI��
	if (!vaIsBeingEdited) {
		return true;
	}
	if (S_OK != IWorkspaceEdit2Ptr(m_POIFeatureWorkspace)->StopEditOperation()) {
		return false;
	}
	if (S_OK != IWorkspaceEdit2Ptr(m_POIFeatureWorkspace)->StopEditing(VARIANT_TRUE)) {
		return false;
	}
	return true;
}

bool POILocationImprover::abortEdit()
{
	// StartEditOperation���Ă��邩�m�F
	VARIANT_BOOL vaIsStartEditOp = VARIANT_FALSE;
	if (S_OK != IWorkspaceEdit2Ptr(m_POIFeatureWorkspace)->get_IsInEditOperation(&vaIsStartEditOp)) {
		return false;
	}
	// �ҏW�J�n���m�F�ł��Ă���Abort
	if (S_OK != IWorkspaceEdit2Ptr(m_POIFeatureWorkspace)->AbortEditOperation()) {
		return false;
	}
	// Abort������StopEdit
	if (S_OK != IWorkspaceEdit2Ptr(m_POIFeatureWorkspace)->StopEditing(VARIANT_TRUE)) {
		return false;
	}
	return true;
}


int POILocationImprover::updateToDatabase(std::map<_bstr_t, std::pair<double, double> > * PPCoordinates, std::set<CString> * updateTargetPOI) {
	long successShapeCopyCount = 0;	//count total successfully update records
	// get column index
	long actualAddressIndex;
	if (S_OK != m_ipPOICursor->Fields->FindField(m_POIFIELD, &actualAddressIndex)) {
		CString errorMsg = "Actual Address field index";
		m_IOManager->print_error(ErrorManager::ECode::E_FAILED_TO_GET_DATA, errorMsg);
		return endProgramWithError("get Actual Address field index");
	}
	// get objectID index
	long objectIDIndex;
	if (S_OK != m_ipPOICursor->Fields->FindField((_bstr_t)sindy::schema::global::poi_info::kObjectID, &objectIDIndex)) {
		CString errorMsg = "ObjectID field index";
		m_IOManager->print_error(ErrorManager::ECode::E_FAILED_TO_GET_DATA, errorMsg);
		return endProgramWithError("get ObjectID field index");
	}
	IFeaturePtr ipPOIFeature;
	while (m_ipPOICursor->NextFeature(&ipPOIFeature) == S_OK && ipPOIFeature) {
		// get objectID
		_variant_t objectID;
		if (S_OK != ipPOIFeature->get_Value(objectIDIndex, &objectID)) {
			CString errorMsg = (CString)"POI_INFO OBJECTID";
			m_IOManager->print_error(ErrorManager::ECode::E_FAILED_TO_GET_DATA, errorMsg);
			continue;
		}
		CString objID;
		objID.Format(L"%ld", objectID.lVal);
		// if not target record, skip
		if (updateTargetPOI->find(objID) == updateTargetPOI->end())
			continue;
		// get actual address data
		_variant_t actualAddress;
		if (S_OK != ipPOIFeature->get_Value(actualAddressIndex, &actualAddress)) {
			CString errorMsg = "Actual Address";
			m_IOManager->print_error(ErrorManager::ECode::E_FAILED_TO_GET_DATA, errorMsg);
			continue;
		}
		//get 6-digit postal code
		std::wstring convertedAddress(actualAddress.bstrVal, SysStringLen(actualAddress.bstrVal));
		std::wstring postalCode = convertedAddress.substr(convertedAddress.length() - 6);
		_bstr_t convertedPostalCode = SysAllocStringLen(postalCode.data(), postalCode.size());
		// get POI shape
		IGeometryPtr ipPOIGeom;
		if (S_OK != ipPOIFeature->get_Shape(&ipPOIGeom)) {
			CString errorMsg = (CString)"OBJECTID : " + objID + " shape";
			m_IOManager->print_error(ErrorManager::ECode::E_FAILED_TO_GET_DATA, errorMsg);
			continue;
		}
		//START COPYING SHAPE
		int returnStatus = copyPostalPointCoordinates(objID, convertedPostalCode, ipPOIGeom, PPCoordinates);
		if (ErrorManager::RCode::R_SUCCESS != returnStatus) {
			continue;
		}
		///CAUTION!!! UPDATE THE MODIFIED COORDINATES TO DATABASE
		///CAUTION!!! UPDATE THE MODIFIED COORDINATES TO DATABASE
		if (S_OK != ipPOIFeature->Store()) {
			CString errorMsg = (CString)"OBJECTID : " + objID + " shape";
			m_IOManager->print_error(ErrorManager::ECode::E_FAILED_TO_GET_DATA, errorMsg);
			continue;
		}
		///CAUTION!!! UPDATE THE MODIFIED COORDINATES TO DATABASE
		///CAUTION!!! UPDATE THE MODIFIED COORDINATES TO DATABASE
		m_IOManager->print_run_no_cout((CString)"POI_INFO OBJECTID = " + objID + " : has been updated successfully.");
		successShapeCopyCount++;
	}
	// print total updated POI_INFO shape
	CString successShapeCopyCountString;
	successShapeCopyCountString.Format(L"%ld", successShapeCopyCount);
	m_IOManager->print_run((CString)"Successfully updated : " + successShapeCopyCountString + " target record(s)");
	return ErrorManager::RCode::R_SUCCESS;
}

int POILocationImprover::run() {
	//setting variables
	std::string POSTALPOINT_LAYER = m_OptionManager->getOptionName(OptionManager::OptionName::POSTALPOINT_LAYER);
	std::string POI_INFO_LAYER = m_OptionManager->getOptionName(OptionManager::OptionName::POI_INFO_LAYER);
	std::string POSTALPOINT_FIELD = m_OptionManager->getOptionName(OptionManager::OptionName::POSTALPOINT_FIELD);
	std::string POI_INFO_FIELD = m_OptionManager->getOptionName(OptionManager::OptionName::POI_INFO_FIELD);
	m_DBList = m_dataManager->getDBList();
	m_featureClassList = m_dataManager->getFeatureClassList();
	m_fieldNameList = m_dataManager->getFieldNameList();
	m_PPFeatureClassName = m_featureClassList[POSTALPOINT_LAYER].fullFeatureClassName;
	m_POIFeatureClassName = m_featureClassList[POI_INFO_LAYER].fullFeatureClassName;
	m_PPFeatureClass = m_accessSV->getFeatureClass( m_DBList[m_featureClassList[POSTALPOINT_LAYER].serverLabelName].fullDBName, m_PPFeatureClassName);
	m_POIFeatureClass = m_accessSV->getFeatureClass(m_DBList[m_featureClassList[POI_INFO_LAYER].serverLabelName].fullDBName, m_POIFeatureClassName);
	m_PPFIELD = m_fieldNameList[POSTALPOINT_FIELD];
	m_POIFIELD = m_fieldNameList[POI_INFO_FIELD];
	IQueryFilterPtr POIipQueryFilter(CLSID_QueryFilter);
	IDatasetPtr POIDataSet;
	POIDataSet = (IDatasetPtr)m_POIFeatureClass;
	if (S_OK != POIDataSet->get_Workspace(&m_POIFeatureWorkspace)) {
		return endProgramWithError("get POI INFO workspace");
	}
	
	//Get all avaliable postal codes with their coordinates
	std::map<_bstr_t, std::pair<double, double> > PPCoordinates;
	if (is_success != findPPPostalCode(&PPCoordinates)) {
		return endProgramWithError("get postal code coordinates list");
	}
	m_IOManager->print_run((CString)"Postal code coordinates list has been acquired successfully");
	
	//Set all search condition for POI_INFO (column, where clause) 
	if (is_success != setPOISearchCondition(POIipQueryFilter)){
		return endProgramWithError("setting POI INFO search condition");
	}
	m_IOManager->print_run((CString)"POI_INFO search condition has been set successfully");
	
	//Count total POI_INFO records
	if (is_success != countTotalPOIRecord(POIipQueryFilter)){
		return endProgramWithError("get POI INFO total record");
	}
	m_IOManager->print_run((CString)"POI_INFO total record number has been acquired successfully");

	//loop all POI_INFO records to get target record
	std::set<CString> updateTargetPOI;
	if (is_success != getTargetPOIRecord(&PPCoordinates, POIipQueryFilter, &updateTargetPOI)) {
		return endProgramWithError("get POI INFO target records");
	}
	//update to target database
	if (is_success != editing(&PPCoordinates, &updateTargetPOI)) {
		return endProgramWithError("database editing");
	}
	return ErrorManager::RCode::R_SUCCESS;

}
int POILocationImprover::start(int argc, _TCHAR* argv[])
{
	try {
		//Initialize utility classes
		ErrorManager _errorManager;
		IOManager _IOManager;
		OptionManager _OptionManager;
		DataManager _dataManager;
		setErrorManager(&_errorManager);
		setIOManager(&_IOManager);
		setOptionManager(&_OptionManager);
		setDataManager(&_dataManager);
		
		m_errorManager->initErrorMessage();
		m_IOManager->setErrorManager(m_errorManager);
		m_OptionManager->setLogger(m_IOManager);
		m_dataManager->setLogger(m_IOManager);
		//Init option
		if (is_success != m_OptionManager->initOption()) {
			return endProgramWithError("init options");
		}
		//Get option list from console
		if (is_success != m_OptionManager->getOption(argc, argv)) {
			return endProgramWithError("getting options");
		}
		//Parse all option into data manager 
		if (is_success != setNewOption()) {
			return endProgramWithError("setting options");
		}
		//Create files specified in option
		if (is_success != m_dataManager->createFiles()) {
			return endProgramWithError("create files");
		}
		//Print specified option into run log 
		m_OptionManager->printDescription();
		//Initialize connection to server
		
		AccessSV _accessSV;
		setSVManager(&_accessSV);
		m_dataManager->setAccSV(m_accessSV);
		//Initialize DBs
		if (is_success != m_dataManager->initDBs()) {
			return endProgramWithError("initialize DB");
		}

		//Initialize featureclasses
		if (is_success != m_dataManager->initFeatureClasses()) {
			return endProgramWithError("initialize featureclass");
		}
		//Initialize the tool
		if (is_success != run()) {
			return ErrorManager::RCode::R_FAILED_FATAL_ERROR;
		}
	}
	catch (const _com_error e) {
		std::cout << std::endl;
		m_IOManager->print_error(ErrorManager::ECode::E_COM_ERROR_IS_CATCHED, (CString)e.ErrorMessage());
		return endProgramWithError("Com Error");
		std::cout << "Press any key to continue...";
		std::cin.get();
	}
	return printSuccessfulEnd();
}


