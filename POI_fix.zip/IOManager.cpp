#pragma once
#include "stdafx.h"
#include "ErrorManager.h"
#include "IOManager.h"

IOManager::IOManager(void)
{ 
}

IOManager::~IOManager(void)
{
}
void IOManager::setErrorManager(ErrorManager * errCtrl)
{ 
	m_errorManager = errCtrl;
	m_errorMessageGroup = m_errorManager->getErrorMessageFormat();
}

int IOManager::initFile(CString filePath,FileType fileType){
	if (!_tcscmp(filePath,_T(""))){
		print_error(ErrorManager::ECode::E_FAILED_TO_OPEN_FILE_PATH);
		return ErrorManager::RCode::R_FAILED_FATAL_ERROR;
	}
	if (fileType == FileType::ERR){
		m_errLog.open(filePath,std::ios_base::app);
		if (!m_errLog.is_open()){
			print_error(ErrorManager::ECode::E_FAILED_TO_OPEN_FILE_PATH,filePath);
			return ErrorManager::RCode::R_FAILED_FATAL_ERROR;
		}
		m_errLog.seekg (0, m_errLog.end);
		//If error log is empty, add error header to the log
		if (!m_errLog.tellg()){
			m_errLog << "ERROR_TYPE" << "\t" << "TIME" << "\t" << "ERROR_CODE" << "\t" << "ERROR_MSG" << std::endl;
		}
		m_errLog.seekg (0, m_errLog.beg);
	}
	else if (fileType == FileType::RUN) {
		m_runLog.open(filePath, std::ios_base::app);
		if (!m_runLog.is_open()){
			print_error(ErrorManager::ECode::E_FAILED_TO_OPEN_FILE_PATH,filePath);
			return ErrorManager::RCode::R_FAILED_FATAL_ERROR;
		}
	}
	//TODO make map that support multiple output file
	else if (fileType == FileType::OUTPUT) {
		m_outputFile.open(filePath);
		if (!m_outputFile.is_open()){
			print_error(ErrorManager::ECode::E_FAILED_TO_OPEN_FILE_PATH,filePath);
			return ErrorManager::RCode::R_FAILED_FATAL_ERROR;
		}
	}
	else {
		return ErrorManager::RCode::R_FAILED_FATAL_ERROR;
	}
	return ErrorManager::RCode::R_SUCCESS;
}

void IOManager::closeFile(){
	if (m_runLog.is_open()){
		m_runLog.close();
	}
	if (m_errLog.is_open()){
		m_errLog.close();
	}
	if (m_outputFile.is_open()){
		m_outputFile.close();
	}
}

void IOManager::print_error(ErrorManager::ECode errorCode, CString errorSource){
	if (m_errLog.is_open())
		m_errLog << CT2A(m_errorMessageGroup[errorCode].errorType) << "\t" << get_current_time().c_str() << "\t" << errorCode  << "\t" << CT2A(errorSource) << " " << CT2A(m_errorMessageGroup[errorCode].errorDesc) << std::endl;
	std::cerr << CT2A(errorSource) << " " << CT2A(m_errorMessageGroup[errorCode].errorDesc) <<   std::endl;
}

void IOManager::print_run(CString runMsg){
	if (m_runLog.is_open()){
		m_runLog << get_current_time() << "\t" << CT2A(runMsg) << std::endl;
	}
	std::cout << get_current_time() << "\t" << CT2A(runMsg) << std::endl;
}
void IOManager::print_run_no_cout(CString runMsg) {
	if (m_runLog.is_open()) {
		m_runLog << get_current_time() << "\t" << CT2A(runMsg) << std::endl;
	}
}


void IOManager::print_no_timestamp_run(CString runMsg){
	if (m_runLog.is_open()){
		m_runLog << CT2A(runMsg) << std::endl;
	}
	std::cout << CT2A(runMsg) << std::endl;
}

std::string IOManager::get_current_time(){
	time_t rawtime;
	struct tm * timeinfo;
	char buffer[80];
	time (&rawtime);
	timeinfo = localtime(&rawtime);
	strftime(buffer,80,"%Y-%m-%d %I:%M:%S",timeinfo);
	std::string str(buffer);
	return str;
}

void IOManager::print_start(){
	time(&m_start_time);
	m_runLog << "Start: " << get_current_time()  << std::endl << std::endl;
	std::cout <<  "Start: " << get_current_time() << std::endl << std::endl;
}

void IOManager::print_total_execution_time(){
	double total_time;
	time_t end_time;
	time(&end_time);
	total_time = difftime(end_time,m_start_time);
	m_runLog << "Total execution time: " << total_time << "s" << std::endl;
	std::cout << "Total execution time: " << total_time << "s" << std::endl;
}

template <typename T> void IOManager::print_output(T output){
	m_outputFile << output << std::endl;
}
template void IOManager::print_output<int>(int output);