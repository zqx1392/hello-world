#pragma once

/**
* @brief Manage server connection and store ArcGIS-related variable.
*/
class AccessSV
{
public:
	AccessSV(void);
	~AccessSV(void);

	/**
	* @brief Create new workspace
	* @param workspaceName		[in]	workspace full name [ex. TEST2017@gaia(SDE.DEFAULT)]
	* @return	success��0�Afailure��1
	*/
	int setWorkspace(const CString workspaceName);
	/**
	* @brief Get created workspace
	* @param workspaceName		[in]	workspace full name [ex. TEST2017@gaia(SDE.DEFAULT)]
	* @return	workspace variable
	*/
	IWorkspacePtr getWorkspace(const CString workspaceName);
	/**
	* @brief Get created featureClass
	* @param workspaceName		[in]	workspace full name [ex. TEST2017@gaia(SDE.DEFAULT)]
	* @param featureClassName	[in]	featureclass full name [ex. TEST2017.ROAD_LINK]
	* @return	featureClass variable
	*/
	IFeatureClassPtr getFeatureClass(const CString workspaceName, const  CString featureClassName);
	/**
	* @brief Create new featureClass
	* @param workspaceName		[in]	workspace full name [ex. TEST2017@gaia(SDE.DEFAULT)]
	* @param featureClassName	[in]	featureclass full name [ex. TEST2017.ROAD_LINK]
	* @return	success��0�Afailure��1
	*/
	int setFeatureClass(const CString workspaceName, const  CString featureClassName);

private:
	std::map<CString,IWorkspacePtr> m_workspaceMap;			//Record DB list
	std::map<CString,IFeatureClassPtr>  m_featureClassMap;	//Record current DB's featureclass list 

};