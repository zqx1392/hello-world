#pragma once
#include "stdafx.h"
#include "errorManager.h"
#include "IOManager.h"
#include "OptionManager.h"
#include <conio.h>


OptionManager::OptionManager() {
	
}

OptionManager::~OptionManager() {
}
void OptionManager::setLogger(IOManager * IOCtrl) {
	_IOCtrl = IOCtrl;
}

int OptionManager::initOption() {
	optionNames[OptionName::POSTALPOINT_DB] = "inputPP";
	optionNames[OptionName::POSTALPOINT_LAYER] = "layerPP";
	optionNames[OptionName::POSTALPOINT_FIELD] = "fieldPP";
	optionNames[OptionName::POI_INFO_DB] = "inputPOI";
	optionNames[OptionName::POI_INFO_LAYER] = "layerPOI";
	optionNames[OptionName::POI_INFO_FIELD] = "fieldPOI";
	optionNames[OptionName::SQL] = "SQL";
	optionNames[OptionName::RUN_LOG] = "run_log";
	optionNames[OptionName::ERR_LOG] = "err_log";
	optionNames[OptionName::DB] = "DB";
	optionNames[OptionName::OWNER] = "owner";
	optionNames[OptionName::VERSION] = "version";
	return ErrorManager::RCode::R_SUCCESS;
}
std::string OptionManager::getOptionName(OptionName optionName) {
	return optionNames[optionName];
}
int OptionManager::getOption(int argc, _TCHAR* argv[]) {
	using namespace boost::program_options;
	options_description desc("Options");
	try {
		desc.add_options()
			("help,h", "Help screen")
			(getOptionName(OptionName::POSTALPOINT_DB).c_str(), wvalue<std::wstring>()->required(), "POSTALPOINT DB User")
			(getOptionName(OptionName::POI_INFO_DB).c_str(), wvalue<std::wstring>()->required(), "POI DB User")
			(getOptionName(OptionName::POSTALPOINT_LAYER).c_str(), wvalue<std::wstring>()->required(), "POSTALPOINT LAYER Name")
			(getOptionName(OptionName::POI_INFO_LAYER).c_str(), wvalue<std::wstring>()->required(), "POI Info LAYER Name")
			(getOptionName(OptionName::POSTALPOINT_FIELD).c_str(), wvalue<std::wstring>()->required(), "Postalcode FIELD Name")
			(getOptionName(OptionName::POI_INFO_FIELD).c_str(), wvalue<std::wstring>()->required(), "Actual Address FIELD Name")
			(getOptionName(OptionName::SQL).c_str(), wvalue<std::wstring>(), "SQL search query for POI Info")
			(getOptionName(OptionName::RUN_LOG).c_str(), wvalue<std::wstring>(), "Run log file path")
			(getOptionName(OptionName::ERR_LOG).c_str(), wvalue<std::wstring>(), "Error log file path");
		//END OF SETTING
		m_vm.clear();
		store(parse_command_line(argc, argv, desc), m_vm);
		notify(m_vm);
	}
	catch (const error &ex)
	{
		std::cerr << ex.what() << std::endl;
		std::cout << desc << std::endl;
		_IOCtrl->print_error(ErrorManager::ECode::E_INVALID_OPTION, "Option setting");
		return ErrorManager::RCode::R_FAILED_FATAL_ERROR;
	}
	return ErrorManager::RCode::R_SUCCESS;
}
void OptionManager::printDescription() {
	//SETTING HERE
	_IOCtrl->print_no_timestamp_run(_T("POILocationImprover.exe FILEVERSION:1.0.0.0  PRODUCTVERSION:1.0.0.0"));
	_IOCtrl->print_no_timestamp_run(_T("[option]"));
	_IOCtrl->print_no_timestamp_run(_T(""));
	print_all_option();
	_IOCtrl->print_start();
	//END OF SETTING
}

void OptionManager::print_all_option() {
	using namespace boost::program_options;
	for (const auto& it : m_vm) {
		CString tmpString = "--" + (CString)it.first.c_str() + ": ";
		auto value = it.second.value();
		if (auto v = boost::any_cast<std::wstring>(&value)) {
			tmpString += v->c_str();
		}
		_IOCtrl->print_no_timestamp_run(tmpString);
	}
	_IOCtrl->print_no_timestamp_run("");
}
std::wstring OptionManager::getOptionArgument(OptionManager::OptionName opt){
	if (m_vm[getOptionName(opt)].empty())
		return L"";
	else
		return m_vm[getOptionName(opt)].as<std::wstring>();
}

