#pragma once
/**
* @brief	Manage input option for console application
*/

class OptionManager
{
public:

	IOManager * _IOCtrl;					//Control IO
	
	OptionManager();
	~OptionManager();
	
	/**
	* @brief�@specific option name for this tool
	*/
	enum OptionName : int {
	POSTALPOINT_DB,
	POSTALPOINT_LAYER,
	POSTALPOINT_FIELD,
	POI_INFO_DB,
	POI_INFO_LAYER,
	POI_INFO_FIELD,
	SQL,
	RUN_LOG,
	ERR_LOG,
	DB,
	OWNER,
	VERSION
	};
	
	/**
	* @brief Set output management class
	* @param IOCtrl				[in]	Target output management class object
	*/
	void setLogger(IOManager * IOCtrl);
	/**
	* @brief Initialize option name and link the name to OptionName enum
	* @return	RCode value [ex�FR_SUCCESS=0�AR_FAILED_FATAL_ERROR=1�A...]
	*/
	int initOption();
	/**
	* @brief Get std::string option name mapped in optionNames
	* @param optionName				[in]	option name in OptionName enum format
	* @return	option name in string format
	*/
	std::string getOptionName(OptionName optionName);
	/**
	* @brief Get all option from console 
	* @param argc				[in]	total argument number
	* @param argv				[in]	arguments
	* @return	RCode value [ex�FR_SUCCESS=0�AR_FAILED_FATAL_ERROR=1�A...]
	*/
	int getOption(int argc, _TCHAR* argv[]);
	/**
	* @brief Print file description before start the program
	*/
	void printDescription();
	/**
	* @brief Print all option details
	* @param vm				[in]	boost's object list
	*/
	void print_all_option();
	/**
	* @brief Get variable map
	* @return	variable map (m_vm)
	*/
	std::wstring getOptionArgument(OptionName opt);

private:
	boost::program_options::variables_map m_vm;		//Record option content
	std::map<int, std::string> optionNames;
};