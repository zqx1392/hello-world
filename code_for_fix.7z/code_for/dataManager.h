#pragma once
/**
* @brief	Manage data and act as middleman between server, file, and core process who store all necessary data.
*/

class dataManager
{
public:

	IOManager * _IOCtrl;				//Control IO
	AccessSV * _AccSV;					//Control Server Access

	dataManager();
	~dataManager();
	//File Structure
	struct fileDesc {
		CString fileName;				//ex.  C:/HAHA/THISWAY.txt
		CString fileType;				//ex.  ERR,RUN,OUT
	};
	//DB Structure
	struct DBDesc {
		CString serverName;				//ex.  yakumo, arion
		CString ownerName;				//ex.  REFERENCE,THA201701
		CString versionName;			//ex.  SDE.DEFAULT
		CString fullDBName;				//ex.  RONLY@yakumo(SDE.DEFAULT)
	};
	//Featureclass Structure
	struct featureClassDesc {
		CString featureClassName;				//ex.  sindy::schema::citymesh::kfeatureClassName
		CString ownerName;				//ex.  REFERENCE,THA201701
		CString fullfeatureClassName;			//ex.  REFRENCE.MESHCITY
	};
	/**
	* @brief Set output management class
	* @param IOCtrl				[in]	Target IOManager class object
	*/
	void setLogger(IOManager * IOCtrl);
	/**
	* @brief Set server management class
	* @param AccSV				[in]	Target AccessSV class object
	*/
	void setAccSV(AccessSV * AccSV);
	/**
	* @brief Add new file into fileList for creation
	* @param labelName			[in]	Label name for calling a file data with m_fileList[labelName]
	* @param fileName			[in]	target file name aka file path
	* @param fileType			[in]	File type[ERR,RUN,OUT]
	*/
	void setNewFile(std::string labelName, std::wstring fileName, CString fileType);
	/**
	* @brief Add new DB into DBList for creation
	* @param labelName			[in]	Label name for calling a DB data with m_DBList[labelName]
	* @param serverName			[in]	full SiNDY username [ex. TEST2017A@sindympa(SDE.DEFAULT)]
	* @param isFGDB				[in]	Is the target DB is FGDB
	* @param doEdit				[in]	If target db need to be edited
	*/
	void setNewDB(std::string labelName, std::wstring serverName, bool isFGDB, bool doEdit);
	/**
	* @brief Add new Database. Username, DB, version input are separate
	* @param labelName			[in]	Label name for calling a DB data with m_DBList[labelName]
	* @param serverName			[in]	target DB server name [ex. sindympa]
	* @param ownerName			[in]	target DB owner name [ex. TEST2017A]
	* @param versionName		[in]	target DB server name [ex. SDE.DEFAULT]
	* @param isFGDB				[in]	Is the target DB is FGDB
	* @param doEdit				[in]	If target db need to be edited
	*/
	void setNewDB_divideUserDBVersion(std::string labelName, std::wstring serverName, std::wstring ownerName, std::wstring versionName, bool isFGDB, bool doEdit);
	/**
	* @brief Add new featureclass for creation 
	* @param labelName			[in]	Label name for calling a featureclass data with m_featureClassList[labelName]
	* @param featureClassName	[in]	target featureClass name [ex. sindy::schema::example:kfeatureClassName, "ROAD_LINK"]
	* @param isFGDB				[in]	Is the target DB is FGDB
	*/
	void setNewFeatureClass(std::string labelName, std::wstring serverName, std::wstring featureClassName, bool isFGDB);
	/**
	* @brief Add new featureclass. Username, DB, version input are separate
	* @param labelName			[in]	Label name for calling a featureclass data with m_featureClassList[labelName]
	* @param serverOwner		[in]	target DB owner name [ex. TEST2017A]
	* @param featureClassName	[in]	target featureClass name [ex. sindy::schema::example:kfeatureClassName, "ROAD_LINK"]
	* @param isFGDB				[in]	Is the target DB is FGDB
	*/
	void setNewFeatureClass_divideUserDBVersion(std::string labelName, std::wstring serverOwner, std::wstring featureClassName, bool isFGDB);
	/**
	* @brief Add new field name for usage 
	* @param labelName			[in]	Label name for calling a field name with m_fieldNameList[labelName]
	* @param fieldName			[in]	target field Name [ex. POSTAL_CODE, OBJECTID]
	*/
	void setNewFieldName(std::string labelName, std::wstring fieldName);
	/**
	* @brief Create all files that have been set from 'setNewFile' function
	* @return	RCode value [ex�FR_SUCCESS=0�AR_FAILED_FATAL_ERROR=1�A...]
	*/
	int createFiles();
	/**
	* @brief Initialize all DBs that have been set from 'setNewDB' and 'setNewDB_divideUserDBVersion' function
	* @return	RCode value [ex�FR_SUCCESS=0�AR_FAILED_FATAL_ERROR=1�A...]
	*/
	int initDBs();
	/**
	* @brief Initialize all featureclasses that have been set from 'setNewFeatureClass' and 'setNewFeatureClass_divideUserDBVersion' function
	* @return	RCode value [ex�FR_SUCCESS=0�AR_FAILED_FATAL_ERROR=1�A...]
	*/
	int initFeatureClasses();
	/**
	* @brief Get featureclass list
	* @return	List of featureclass
	*/
	std::map<std::string, featureClassDesc> getFeatureClassList();
	/**
	* @brief Get PostalPoint field (POSTAL_CODE)
	* @return	POSTAL_CODE field name
	*/
	std::map<std::string, _bstr_t> getFieldNameList);
	
	/// FOR THIS TOOL ONLY
	/**
	* @brief Get input SQL
	* @return	SQL string
	*/
	void setSQL(std::wstring SQL);
	/**
	* @brief Get input SQL
	* @return	SQL string
	*/
	std::wstring getSQL();
private:
	std::map<std::string, DBDesc> m_DBList;			//Store all set DB list
	std::map<std::string, fileDesc> m_fileList;		//Store all set file list
	std::map<std::string, featureClassDesc> m_featureClassList;	//Store all set featureClass list
	std::map<std::string, _bstr_t> m_fieldNameList;	//Store all set field name such as ACTUALADDRESS, POSTAL_CODE 
	std::wstring SQLText;							//Store SQL text used for where clause

};