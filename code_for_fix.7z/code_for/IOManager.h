#pragma once

/**
* @brief Manage Input/Output file and control output print
*/
class IOManager
{
public:

	errorManager * _errorManager;		//Control error message format and code
	
	IOManager();
	~IOManager();
	/**
	* @brief�@specific file type into error, run, output type.
	*/
	enum FileType : std::string {
	ERR						= "error",
	RUN						= "run",
	OUT						= "output"	
	};
	/**
	* @brief Set error management class
	* @param errCtrl		[in]	Target error management class object
	*/
	void setErrorManager(errorManager * errCtrl);
	/**
	* @brief Initialize selected file 
	* @param filePath		[in]	File path
	* @param fileType		[in]	run�Aerror�Aoutput file
	* @return	True if success�Afalse if error
	*/
	int initFile(CString filePath,CString fileType);
	/**
	* @brief Close all file stream
	*/
	void closeFile();
	/**
	* @brief Print error message into error log and cerr
	* @param errorCode		[in]	errorManager::ECode
	* @param errorSource	[in]	Description of error(Source of error such as file path, DB, field setting)
	*/
	void print_error(errorManager::ECode errorCode, CString errorSource = _T(""));
	/**
	* @brief Print run message into run log and cout
	* @param runDesc		[in]	Message to print
	*/
	void print_run(CString runDesc);
	/**
	* @brief Print run message without timestamp
	* @param runDesc		[in]	Message to print
	*/
	void print_no_timestamp_run(CString runMsg);
	/**
	* @brief Get current time
	* @return	String of current time (HH::mm:ss)
	*/
	std::string get_current_time();
	/**
	* @brief Print start line (timestamp + "Start :" messsage) into run log and cout
	*/
	void print_start();
	/**
	* @brief Print total execution time into run log and cout
	*/
	void print_total_execution_time();
	/**
	* @brief Print result into output file
	* @param output			[in]	Message to print
	*/
	template <typename T> void print_output(T output);

private:
	std::fstream m_runLog,m_errLog;					//filestream for log
	std::m_ofstream m_outputFile;					//filestream for output file
	std::map<errorManager::ECode,errorManager::errorMsg> m_errorMessageGroup;
	time_t m_start_time;
};