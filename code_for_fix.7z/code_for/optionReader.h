#pragma once
/**
* @brief	Manage input option for console application
*/

class optionManager
{
public:

	IOManager * _IOCtrl;					//Control IO
	
	optionManager();
	~optionManager();
	
	/**
	* @brief�@specific option name for this tool
	*/
	enum OptionName : std::string {
	POSTALPOINT_DB					= "inputPP",
	POSTALPOINT_LAYER				= "layerPP",
	POSTALPOINT_FIELD				= "fieldPP",
	POI_INFO_DB						= "inputPOI",
	POI_INFO_LAYER					= "layerPOI",
	POI_INFO_FIELD					= "fieldPOI",
	SQL								= "SQL",
	RUN_LOG							= "run_log",
	ERR_LOG							= "err_log",
	DB								= "DB",
	OWNER							= "owner",
	VERSION							= "version"
	};
	
	/**
	* @brief Set output management class
	* @param IOCtrl				[in]	Target output management class object
	*/
	void setLogger(IOManager * IOCtrl);
	/**
	* @brief Get all option from console 
	* @param argc				[in]	total argument number
	* @param argv				[in]	arguments
	* @return	RCode value [ex�FR_SUCCESS=0�AR_FAILED_FATAL_ERROR=1�A...]
	*/
	int getOption(int argc, _TCHAR* argv[]);
	/**
	* @brief Print file description before start the program
	*/
	void printDescription();
	/**
	* @brief Print all option details
	* @param vm				[in]	boost's object list
	*/
	void print_all_option();
	/**
	* @brief Get variable map
	* @return	variable map (m_vm)
	*/
	boost::program_options::variables_map getVM();

private:
	boost::program_options::variables_map m_vm;		//Record option content
};