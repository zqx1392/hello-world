#pragma once
#include "stdafx.h"
#include "IOManager.h"
#include "errorManager.h"
#include "AccessSV.h"
#include "dataManager.h"
#include <conio.h>

dataManager:dataManager() {
}

dataManager::~dataManager() {
}

void dataManager::setLogger(IOManager * IOCtrl) {
	_IOCtrl = IOCtrl;
}
void dataManager::setAccSV(AccessSV * AccSV) {
	_AccSV = AccSV;
}

void dataManager::setNewFile(std::string labelName, std::wstring fileName, CString fileType) {
	CString convertedfileName = fileName.c_str();
	if (!strcmp(convertedfileName,"")) {
		fileName = fileType + ".log";
	}
	fileDesc tempFileDesc = { convertedfileName,fileType };
	m_fileList[labelName] = tempFileDesc;
}
void dataManager::setNewDB(std::string labelName, std::wstring serverName, bool isFGDB, bool doEdit) {
	std::wstring DBName = L"";
	std::wstring versionName = L"";
	if (!isFGDB) {
		size_t startDBName = serverName.find(L"@");
		size_t startVersionName = serverName.find(L"(");
		DBName = serverName.substr(startDBName + 1, startVersionName - startDBName - 1);
		versionName = serverName.substr(startVersionName + 1, serverName.length() - startVersionName - 2);
	}
	CString convertedServerName = serverName.c_str();
	CString convertedOwnerName = DBName.c_str();
	CString convertedVersionName = versionName.c_str();
	CString fullDBName = "";
	if (doEdit) fullDBName = convertedOwnerName + "@" +  convertedServerName + "(" + convertedVersionName + ")";
	else fullDBName = "RONLY@" + convertedServerName + "(" + convertedVersionName + ")";
	if (isFGDB) fullDBName = convertedServerName;
	DBDesc tempDBDesc = { 
		convertedServerName,
		convertedOwnerName,
		convertedVersionName,
		fullDBName
	};
	m_DBList[labelName] = tempDBDesc;
}
void dataManager::setNewDB_divideUserDBVersion(std::string labelName, std::wstring serverName, std::wstring ownerName, std::wstring versionName, bool isFGDB, bool doEdit) {
	CString convertedServerName = serverName.c_str();
	CString convertedOwnerName = ownerName.c_str();
	CString convertedVersionName = versionName.c_str();
	CString fullDBName = "";
	if (doEdit) fullDBName = convertedOwnerName + "@" + convertedServerName + "(" + convertedVersionName + ")";
	else fullDBName = "RONLY@" + convertedServerName + "(" + convertedVersionName + ")";
	if (isFGDB) fullDBName = convertedServerName;
	DBDesc tempDBDesc = { 
		convertedServerName,
		convertedOwnerName,
		convertedVersionName,
		fullDBName
	};
	m_DBList[labelName] = tempDBDesc;
}

void dataManager::setNewFeatureClass(std::string labelName, std::wstring serverName, std::wstring featureClassName, bool isFGDB) {
	CString convertedFeatureClassName = featureClassName.c_str();
	std::wstring ownerName = L"";
	if (!isFGDB) {
		size_t startDBName = serverName.find(L"@");
		ownerName = serverName.substr(0, startDBName);
	}
	CString convertedOwnerName = ownerName.c_str();
	CString convertedfullFeatureClassName = convertedOwnerName + "." + convertedFeatureClassName;
	if (isFGDB) convertedfullFeatureClassName = convertedFeatureClassName;
	featureClassDesc tempTableDesc = {
		convertedFeatureClassName,
		convertedOwnerName,
		convertedfullFeatureClassName
	};
	m_featureClassList[labelName] = tempTableDesc;
}
void dataManager::setNewFeatureClass_divideUserDBVersion(std::string labelName, std::wstring serverOwner, std::wstring featureClassName, bool isFGDB) {
	CString convertedFeatureClassName = featureClassName.c_str();
	CString convertedOwnerName = serverOwner.c_str();
	CString convertedfullFeatureClassName = convertedOwnerName + "." + convertedFeatureClassName;
	if (isFGDB) convertedfullFeatureClassName = convertedFeatureClassName;
	featureClassDesc tempTableDesc = { 
		convertedFeatureClassName,
		convertedOwnerName,
		convertedfullFeatureClassName 
	};
	m_featureClassList[labelName] = tempTableDesc;
}
void dataManager::setNewFieldName(std::string labelName, std::wstring fieldName) {
	_bstr_t convertedFieldName = fieldName.c_str();
	m_fieldNameList[labelName] = convertedFieldName;
}
int dataManager::createFiles() {
	std::vector<CString> fileNameList;
	for (std::pair<std::string, fileDesc> eachFile : m_fileList) {
		if (errorManager::RCode::R_SUCCESS != _IOCtrl->initFile(eachFile.second.fileName, eachFile.second.fileType)) {
			return errorManager::RCode::R_FAILED_FATAL_ERROR;
		}
		else {
			fileNameList.push_back(eachFile.second.fileName);
		}
	}
	for (auto eachFile : fileNameList) {
		_IOCtrl->print_run(eachFile + " has been created successfully");
	}
	return errorManager::RCode::R_SUCCESS;
}

int dataManager::initDBs() {
	for (std::pair<std::string, DBDesc> eachDB : m_DBList) {
		if (!_AccSV->setWorkspace(eachDB.second.fullDBName)) {
			_IOCtrl->print_error(errorManager::ECode::E_FAILED_TO_OPEN_WORKSPACE, eachDB.second.fullDBName);
			return errorManager::RCode::R_FAILED_FATAL_ERROR;
		}
		else {
			CString successMsg = " has been connected successfully";
			CString printMsg = eachDB.second.fullDBName + successMsg;
			_IOCtrl->print_run(printMsg);
		}
	}
	return errorManager::RCode::R_SUCCESS;
}

int dataManager::initFeatureClasses() {
	for (std::pair<std::string, featureClassDesc> eachTable : m_featureClassList) {
		CString fullDBName = m_DBList[eachTable.second.labelName].fullDBName;
		if (!_AccSV->setFeatureClass(_AccSV->getWorkspace(fullDBName), eachTable.second.fullFeatureClassName)) {
			_IOCtrl->print_error(errorManager::ECode::E_FAILED_TO_OPEN_FEATURECLASS, eachTable.second.fullFeatureClassName);
			return errorManager::RCode::R_FAILED_FATAL_ERROR;
		}
		else {
			CString successMsg = " featureclass has been connected successfully";
			CString printMsg = eachTable.second.fullFeatureClassName + successMsg;
			_IOCtrl->print_run(printMsg);
		}
	}
	return errorManager::RCode::R_SUCCESS;
}
std::map<std::string, featureClassDesc> dataManager::getFeatureClassList() {
	return m_featureClassList;
}
std::map<std::string, _bstr_t> dataManager::getFieldNameList() {
	return  m_fieldNameList;
}

//for this tool only
void dataManager::setSQL(std::wstring SQL){
	SQLText = SQL;
}
std::wstring dataManager::getSQL() {
	if (SQLText.empty()) {
		return L"PRODUCT_C=1";
	}
	return SQLtext;
}

