#pragma once
#include "stdafx.h"
#include "errorManager.h"
#include "IOManager.h"
#include "optionManager.h"
#include <conio.h>


optionManager:optionManager() {
}

optionManager::~optionManager() {
}
void optionManager::setLogger(IOManager * IOCtrl) {
	_IOCtrl = IOCtrl;
}

int optionManager::getOption(int argc, _TCHAR* argv[]) {
	using namespace boost::program_options;
	options_description desc("Options");
	try {
		desc.add_options()
			("help,h", "Help screen")
			((OptionName::POSTALPOINT_DB).c_str(), wvalue<std::wstring>()->required(), "POSTALPOINT DB User")
			((OptionName::POI_INFO_DB).c_str(), wvalue<std::wstring>()->required(), "POI DB User")
			((OptionName::POSTALPOINT_LAYER).c_str(), wvalue<std::wstring>()->required(), "POSTALPOINT LAYER Name")
			((OptionName::POI_INFO_LAYER).c_str(), wvalue<std::wstring>()->required(), "POI Info LAYER Name")
			((OptionName::POSTALPOINT_FIELD).c_str(), wvalue<std::wstring>()->required(), "Postalcode FIELD Name")
			((OptionName::POI_INFO_FIELD).c_str(), wvalue<std::wstring>()->required(), "Actual Address FIELD Name")
			(OptionName::SQL.c_str(), wvalue<std::wstring>(), "SQL search query for POI Info")
			(OptionName::RUN_LOG.c_str(), wvalue<std::wstring>(), "Run log file path")
			(OptionName::ERR_LOG.c_str(), wvalue<std::wstring>(), "Error log file path");
		//END OF SETTING
		store(parse_command_line(argc, argv, desc), m_vm);
		notify(m_vm);
	}
	catch (const error &ex)
	{
		std::cerr << ex.what() << std::endl;
		std::cout << desc << std::endl;
		_IOCtrl->print_error(errorManager::ECode::E_INVALID_OPTION, "Option setting");
		return errorManager::RCode::R_FAILED_FATAL_ERROR;
	}
	return errorManager::RCode::R_SUCCESS;
}
void optionManager::printDescription() {
	//SETTING HERE
	_IOCtrl->print_no_timestamp_run(_T("POILocationImprover.exe FILEVERSION:1.0.0.0  PRODUCTVERSION:1.0.0.0"));
	_IOCtrl->print_no_timestamp_run(_T("[option]"));
	_IOCtrl->print_no_timestamp_run(_T(""));
	print_all_option();
	_IOCtrl->print_start();
	//END OF SETTING
}

void optionManager::print_all_option() {
	using namespace boost::program_options;
	for (const auto& it : m_vm) {
		CString tmpString = "--" + (CString)it.first.c_str() + ": ";
		auto value = it.second.value();
		if (auto v = boost::any_cast<std::wstring>(&value)) {
			tmpString += v->c_str();
		}
		_IOCtrl->print_no_timestamp_run(tmpString);
	}
	_IOCtrl->print_no_timestamp_run("");
}
boost::program_options::variables_map optionManager::getVM(){
	return m_vm;
}

