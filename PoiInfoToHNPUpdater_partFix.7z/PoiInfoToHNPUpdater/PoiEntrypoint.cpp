#include "stdafx.h"
#include "PoiEntrypoint.h"

using namespace sindy::schema::global;

PoiEntrypoint::PoiEntrypoint(const CString&  poiEntryFeatureClassName, IFeatureClassPtr& poiEntryFeatureClass) {
	featureClassName = poiEntryFeatureClassName;
	ipFeatureClass = poiEntryFeatureClass;
	//get field index value
	AccessSV::getFeatureClassColumnIndex(ipFeatureClass, poi_entry_point::kOperator, &m_operatorIndex);
	AccessSV::getFeatureClassColumnIndex(ipFeatureClass, poi_entry_point::kPurpose, &m_purposeCIndex);
	AccessSV::getFeatureClassColumnIndex(ipFeatureClass, poi_entry_point::kModifyDate, &m_modifyDateIndex);
	AccessSV::getFeatureClassColumnIndex(ipFeatureClass, poi_entry_point::kUpdateType, &m_updateTypeCIndex);
	AccessSV::getFeatureClassColumnIndex(ipFeatureClass, poi_entry_point::kProgModifyDate, &m_progModifyDateIndex);
	AccessSV::getFeatureClassColumnIndex(ipFeatureClass, poi_entry_point::kModifyProgName, &m_modifyProgNameIndex);
	AccessSV::getFeatureClassColumnIndex(ipFeatureClass, poi_entry_point::kUserClaim, &m_userClaimFIndex);
	AccessSV::getFeatureClassColumnIndex(ipFeatureClass, poi_entry_point::kSource, &m_sourceIndex);
	AccessSV::getFeatureClassColumnIndex(ipFeatureClass, poi_entry_point::kPoiInfoID, &m_PoiInfoIDIndex);
	AccessSV::getFeatureClassColumnIndex(ipFeatureClass, poi_entry_point::kPriorityF, &m_priorityFIndex);
	AccessSV::getFeatureClassColumnIndex(ipFeatureClass, poi_entry_point::kEntryPointCode, &m_entryPointCIndex);
	AccessSV::getFeatureClassColumnIndex(ipFeatureClass, poi_entry_point::kAccuracyCode, &m_accuracyCIndex);
}

PoiEntrypoint::~PoiEntrypoint() {
}

int PoiEntrypoint::presetPoiEntryFeatureCursor(const CComBSTR & queryFilter, IFeatureCursorPtr& ipPoiEntryCursor) {
	//create condition to get only childID column
	IQueryFilterPtr poiEntryIpQueryFilter(CLSID_QueryFilter);
	CString columnFilter;
	columnFilter.Format(_T("%s,%s,%s,%s"), poi_entry_point::kObjectID, poi_entry_point::kPoiInfoID, poi_entry_point::kAccuracyCode, poi_entry_point::kShape);
	if (S_OK != poiEntryIpQueryFilter->put_SubFields((CComBSTR)columnFilter)) {
		IOManager::getInstance().print_error(IOManager::ECode::E_FAILED_TO_SET_DATA, true, featureClassName, _T(""), _T("Failed to set search column for POIINFOID column"));
		return IOManager::RCode::R_FAILED_FATAL_ERROR;
	}

	//search only records with user input condition
	if (S_OK != poiEntryIpQueryFilter->put_WhereClause(queryFilter)) {
		IOManager::getInstance().print_error(IOManager::ECode::E_FAILED_TO_SET_DATA, true, featureClassName, _T(""), _T("Failed to set search query"));
		return IOManager::RCode::R_FAILED_FATAL_ERROR;
	}

	//set all condition into query variable
	if (S_OK != ipFeatureClass->Search(poiEntryIpQueryFilter, VARIANT_FALSE, &ipPoiEntryCursor)) {
		IOManager::getInstance().print_error(IOManager::ECode::E_FAILED_TO_GET_DATA, true, featureClassName, _T(""), _T("Failed to get all records"));
		return IOManager::RCode::R_FAILED_FATAL_ERROR;
	}
}

int PoiEntrypoint::getPoiInfoID(const CComBSTR & queryFilter, std::set<long> * poiEntrypointList) {

	IFeatureCursorPtr ipPoiEntryCursor;
	if (S_OK != presetPoiEntryFeatureCursor(queryFilter, ipPoiEntryCursor)) {
		return IOManager::RCode::R_FAILED_FATAL_ERROR;
	}

	//set to store childID list
	//get target postal code
	IFeaturePtr ipPoiEntryFeature;
	while (ipPoiEntryCursor->NextFeature(&ipPoiEntryFeature) == S_OK && ipPoiEntryFeature) {
		// get postal point OID
		long OIDNum;
		if (S_OK != ipPoiEntryFeature->get_OID(&OIDNum)) {
			IOManager::getInstance().print_error(IOManager::ECode::E_FAILED_TO_GET_DATA, true,featureClassName, _T(""), _T("Failed to get OBJECTID of one ") +featureClassName);
			return IOManager::RCode::R_FAILED_FATAL_ERROR;
		}
		//convert OID from long to CString
		CString OID;
		OID.Format(L"%ld", OIDNum);
		// get child id data
		CComVariant poiInfoID;
		if (S_OK != ipPoiEntryFeature->get_Value(m_PoiInfoIDIndex, &poiInfoID)) {
			IOManager::getInstance().print_error(IOManager::ECode::E_FAILED_TO_GET_DATA, true,featureClassName + _T(" OBJECTID"), OID, _T("Failed to get POIINFOID value"));
			return IOManager::RCode::R_FAILED_FATAL_ERROR;
		}
		poiEntrypointList->insert(poiInfoID.intVal);
	}
	return IOManager::RCode::R_SUCCESS;
}

int PoiEntrypoint::getDataForNewHnpEntryRecord(IFeaturePtr& ipPoiEntryFeature, long * OIDNum, long * PoiInfoID, long * accuracyC, IGeometryPtr& ipGeom) {
	// get OID
	long l_OIDNum;
	if (S_OK != ipPoiEntryFeature->get_OID(&l_OIDNum)) {
		IOManager::getInstance().print_error(IOManager::ECode::E_FAILED_TO_GET_DATA, true, featureClassName, _T(""), _T("Failed to get OBJECTID of one ") + featureClassName);
		return IOManager::RCode::R_FAILED_FATAL_ERROR;
	}
	//convert OID from long to CString
	CString OID;
	OID.Format(L"%ld", l_OIDNum);
	// get POI_INFO_ID data
	CComVariant l_poiInfoID;
	if (S_OK != ipPoiEntryFeature->get_Value(m_PoiInfoIDIndex, &l_poiInfoID)) {
		IOManager::getInstance().print_error(IOManager::ECode::E_FAILED_TO_GET_DATA, true, featureClassName + _T(" OBJECTID"), OID, _T("Failed to get POIINFOID value"));
		return IOManager::RCode::R_FAILED_FATAL_ERROR;
	}
	long convertedPoiInfoID = l_poiInfoID.lVal;
	// get accuracy_c data
	CComVariant l_accuracyC;
	if (S_OK != ipPoiEntryFeature->get_Value(m_accuracyCIndex, &l_accuracyC)) {
		IOManager::getInstance().print_error(IOManager::ECode::E_FAILED_TO_GET_DATA, true, featureClassName + _T(" OBJECTID"), OID, _T("Failed to get ACCURACY_C value"));
		return IOManager::RCode::R_FAILED_FATAL_ERROR;
	}
	long convertedAccuracyC = l_accuracyC.lVal;
	// get shape
	IGeometryPtr l_ipGeom;
	if (S_OK != ipPoiEntryFeature->get_ShapeCopy(&l_ipGeom)) {
		IOManager::getInstance().print_error(IOManager::ECode::E_FAILED_TO_GET_DATA, true, featureClassName + _T(" OBJECTID"), OID, _T("Failed to get shape"));
		return IOManager::RCode::R_FAILED_FATAL_ERROR;
	}
	*OIDNum = l_OIDNum;
	*PoiInfoID = convertedPoiInfoID;
	*accuracyC = convertedAccuracyC;
	ipGeom = l_ipGeom;

	return IOManager::RCode::R_SUCCESS;
}