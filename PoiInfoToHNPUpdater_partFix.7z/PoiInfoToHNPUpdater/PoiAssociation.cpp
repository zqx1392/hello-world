

#include "stdafx.h"
#include "PoiAssociation.h"

using namespace sindy::schema::global;

PoiAssociation::PoiAssociation(const CString& poiAssoTableName, ITablePtr& poiAssoTable) {
	tableName = poiAssoTableName;
	ipTable = poiAssoTable;
	//get field index value
	AccessSV::getTableColumnIndex(ipTable,  poi_association::kOperator, &m_operatorIndex);
	AccessSV::getTableColumnIndex(ipTable,  poi_association::kPurpose, &m_purposeCIndex);
	AccessSV::getTableColumnIndex(ipTable,  poi_association::kModifyDate, &m_modifyDateIndex);
	AccessSV::getTableColumnIndex(ipTable,  poi_association::kUpdateType, &m_updateTypeCIndex);
	AccessSV::getTableColumnIndex(ipTable,  poi_association::kProgModifyDate, &m_progModifyDateIndex);
	AccessSV::getTableColumnIndex(ipTable,  poi_association::kModifyProgName, &m_modifyProgNameIndex);
	AccessSV::getTableColumnIndex(ipTable,  poi_association::kUserClaim, &m_userClaimFIndex);
	AccessSV::getTableColumnIndex(ipTable,  poi_association::kSource, &m_sourceIndex);
	AccessSV::getTableColumnIndex(ipTable,  poi_association::kChildID, &m_childIDIndex);
	AccessSV::getTableColumnIndex(ipTable,  poi_association::kParentID, &m_parentIDIndex);
}

PoiAssociation::~PoiAssociation() {
}

int PoiAssociation::getChildPOI(std::set<long> * childPOIList) {

	//create condition to get only childID column
	IQueryFilterPtr PoiAssoIpQueryFilter(CLSID_QueryFilter);
	CString columnFilter;
	columnFilter.Format(_T("%s,%s"), poi_association::kObjectID, poi_association::kChildID);
	if (S_OK != PoiAssoIpQueryFilter->put_SubFields((CComBSTR)columnFilter)) {
		IOManager::getInstance().print_error(IOManager::ECode::E_FAILED_TO_SET_DATA, true, tableName, _T(""), _T("Failed to set search column for CHILDID column"));
		return IOManager::RCode::R_FAILED_FATAL_ERROR;
	}
	//set all condition into query variable
	_ICursorPtr ipPoiAssoCursor;

	if (S_OK != ipTable->Search(PoiAssoIpQueryFilter, VARIANT_FALSE, &ipPoiAssoCursor)) {
		IOManager::getInstance().print_error(IOManager::ECode::E_FAILED_TO_GET_DATA, true, tableName, _T(""), _T("Failed to get all records"));
		return IOManager::RCode::R_FAILED_FATAL_ERROR;
	}

	//set to store childID list
	//get target postal code
	_IRowPtr ipPoiAssoRow;
	while (ipPoiAssoCursor->NextRow(&ipPoiAssoRow) == S_OK && ipPoiAssoRow) {
		// get postal point OID
		long OIDNum;
		if (S_OK != ipPoiAssoRow->get_OID(&OIDNum)) {
			IOManager::getInstance().print_error(IOManager::ECode::E_FAILED_TO_GET_DATA, true, tableName, _T(""), _T("Failed to get OBJECTID of one ") + tableName);
			return IOManager::RCode::R_FAILED_FATAL_ERROR;
		}
		//convert OID from long to CString
		CString OID;
		OID.Format(L"%ld", OIDNum);
		// get child id data
		CComVariant childID;
		if (S_OK != ipPoiAssoRow->get_Value(m_childIDIndex, &childID)) {
			IOManager::getInstance().print_error(IOManager::ECode::E_FAILED_TO_GET_DATA, true, tableName + _T(" OBJECTID"), OID, _T("Failed to get CHILDID value"));
			return IOManager::RCode::R_FAILED_FATAL_ERROR;
		}
		childPOIList->insert(childID.intVal);
	}
	return IOManager::RCode::R_SUCCESS;
}