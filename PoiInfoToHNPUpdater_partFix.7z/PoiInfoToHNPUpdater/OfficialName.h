#pragma once

#include "table.h"
#include "PoiInfo.h"

class OfficialName : public table  {
public:

	OfficialName(const CString& officialTableName, ITablePtr& officialTable, Hnp * cHnp);
	~OfficialName();
	/**
	* @brief start the tool
	* @return	RCode value [ex�FR_SUCCESS=0�AR_FAILED_FATAL_ERROR=1�A...]
	*/
	int getOfficalName(std::map<long, CString> * officialNameList);
	/**
	* @brief start the tool
	* @return	RCode value [ex�FR_SUCCESS=0�AR_FAILED_FATAL_ERROR=1�A...]
	*/
	int insertNewRecordToHNPAndOfficial(IWorkspacePtr& workspace, std::vector<PoiInfo::poiInfo> * uniquePoiInfoList, std::map<long, long> * updatedPoiHnpList, std::map<long, long> * translationList);

	int putValueIntoFields(_IRowPtr& ipOfficialRow, const CString& OID);

	int createNewBuffer();

	int insertNewRow(CComVariant * newHnpOID);

	int startAndInsertCursor(IWorkspacePtr& workspace);

	int flushAndStopEdit(IWorkspacePtr& workspace);


private:
	Hnp * cHnp;
	//OFFICIAL_NAME field index
	long m_objectIDIndex;
	long m_operatorIndex;
	long m_purposeCIndex;
	long m_modifyDateIndex;
	long m_updateTypeCIndex;
	long m_progModifyDateIndex;
	long m_modifyProgNameIndex;
	long m_userClaimFIndex;
	long m_sourceIndex;
	long m_layerCIndex;
	long m_nameIndex;
	long m_languageCIndex;
};
