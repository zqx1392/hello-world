#pragma once
#include "stdafx.h"
#include "AccessSV.h"

namespace AccessSV {

	int getWorkspace(const CString& workspaceName, IWorkspacePtr & ipWorkspace) {
		ipWorkspace = sindy::create_workspace(workspaceName);
		if (ipWorkspace == NULL) {
			return IOManager::RCode::R_FAILED_FATAL_ERROR;
		}
		return IOManager::RCode::R_SUCCESS;
	}

	int getFeatureClass(const CString& workspaceName, const CString& featureClassName, IFeatureClassPtr & ipFeatureClass) {
		IWorkspacePtr targetWorkspace;
		if (IOManager::RCode::R_FAILED_FATAL_ERROR == getWorkspace(workspaceName, targetWorkspace)) {
			return IOManager::RCode::R_FAILED_FATAL_ERROR;
		}
		if (S_OK != IFeatureWorkspacePtr(targetWorkspace)->OpenFeatureClass(featureClassName.AllocSysString(), &ipFeatureClass)) {
			return IOManager::RCode::R_FAILED_FATAL_ERROR;
		}
		return IOManager::RCode::R_SUCCESS;
	}

	int getTable(const CString& workspaceName, const CString& tableName, ITablePtr & ipTable) {
		IWorkspacePtr targetWorkspace;
		if (IOManager::RCode::R_FAILED_FATAL_ERROR == getWorkspace(workspaceName, targetWorkspace)) {
			return IOManager::RCode::R_FAILED_FATAL_ERROR;
		}
		if (S_OK != IFeatureWorkspacePtr(targetWorkspace)->OpenTable(tableName.AllocSysString(), &ipTable)) {
			return IOManager::RCode::R_FAILED_FATAL_ERROR;
		}
		return IOManager::RCode::R_SUCCESS;
	}


	int getField(const CString& workspaceName, const CString& datasetName, const CString& fieldName, const bool& isTable, IFieldPtr & ipField) {
		long fieldIndex;
		//if this dataset is table
		if (isTable) {
			ITablePtr targetTable;
			if (IOManager::RCode::R_FAILED_FATAL_ERROR == getTable(workspaceName, datasetName, targetTable)) {
				return IOManager::RCode::R_FAILED_FATAL_ERROR;
			}
			targetTable->FindField(fieldName.AllocSysString(), &fieldIndex);
			if (S_OK != targetTable->GetFields()->get_Field(fieldIndex, &ipField)) {
				return IOManager::RCode::R_FAILED_FATAL_ERROR;
			}
		}
		//if this dataset is layer
		else {
			IFeatureClassPtr targetFeatureClass;
			if (IOManager::RCode::R_FAILED_FATAL_ERROR == getFeatureClass(workspaceName, datasetName, targetFeatureClass)) {
				return IOManager::RCode::R_FAILED_FATAL_ERROR;
			}
			targetFeatureClass->FindField(fieldName.AllocSysString(), &fieldIndex);
			if (S_OK != targetFeatureClass->GetFields()->get_Field(fieldIndex, &ipField)) {
				return IOManager::RCode::R_FAILED_FATAL_ERROR;
			}
		}
		return IOManager::RCode::R_SUCCESS;
	}

	int getFeatureClassColumnIndex(const IFeatureClassPtr& ipFeatureClass, const CComBSTR& fieldName, long * index) {
		if (S_OK != ipFeatureClass->FindField(fieldName, index)) {
			IOManager::getInstance().print_error(IOManager::ECode::E_FAILED_TO_GET_DATA, true, (LPCTSTR)fieldName, _T("FIELD INDEX"), _T("Failed to get field index"));
			return IOManager::RCode::R_FAILED_FATAL_ERROR;
		}
		return IOManager::RCode::R_SUCCESS;
	}

	int getTableColumnIndex(const ITablePtr& ipTable, const CComBSTR& fieldName, long * index) {
		if (S_OK != ipTable->FindField(fieldName, index)) {
			IOManager::getInstance().print_error(IOManager::ECode::E_FAILED_TO_GET_DATA, true, (LPCTSTR)fieldName, _T("FIELD INDEX"), _T("Failed to get field index"));
			return IOManager::RCode::R_FAILED_FATAL_ERROR;
		}
		return IOManager::RCode::R_SUCCESS;
	}

	int putFeatureClassColumnValue(const CString& featureClassName, IFeatureBufferPtr featureBuffer, const long& index, CComVariant value) {
		if (S_OK != featureBuffer->put_Value(index, value)) {
			IOManager::getInstance().print_error(IOManager::ECode::E_FAILED_TO_GET_DATA, true, featureClassName, _T(""), _T("Set new field values"));
			return IOManager::RCode::R_FAILED_FATAL_ERROR;
		}
		return IOManager::RCode::R_SUCCESS;
	}

	int putTableColumnValue(const CString& tableName, IRowBufferPtr rowBuffer, const long& index, CComVariant value) {
		if (S_OK != rowBuffer->put_Value(index, value)) {
			IOManager::getInstance().print_error(IOManager::ECode::E_FAILED_TO_GET_DATA, true, tableName, _T(""), _T("Set new field values"));
			return IOManager::RCode::R_FAILED_FATAL_ERROR;
		}
		return IOManager::RCode::R_SUCCESS;
	}

	bool isVersionedFeatureClass(IFeatureClassPtr& ipFeatureClass)
	{
		VARIANT_BOOL vbIsVersioned = VARIANT_FALSE;
		IVersionedObjectPtr(ipFeatureClass)->get_IsRegisteredAsVersioned(&vbIsVersioned);
		return vbIsVersioned ? true : false;
	}
	bool isVersionedTable(ITablePtr& ipTable)
	{
		VARIANT_BOOL vbIsVersioned = VARIANT_FALSE;
		IVersionedObjectPtr(ipTable)->get_IsRegisteredAsVersioned(&vbIsVersioned);
		return vbIsVersioned ? true : false;
	}

	bool startEditFeatureClass(IWorkspacePtr& ipWorkspace, IFeatureClassPtr& ipFeatureClass)
	{
		IMultiuserWorkspaceEditPtr ipMultiuserWorkspace(ipWorkspace);
		if (ipMultiuserWorkspace)
		{
			// �Ԑ������N�̃o�[�W�����Ή����\�Ƃ��Č��Ă���
			esriMultiuserEditSessionMode mode = isVersionedFeatureClass(ipFeatureClass) ? esriMESMVersioned : esriMESMNonVersioned;
			if (FAILED(ipMultiuserWorkspace->StartMultiuserEditing(mode)))
			{
				IOManager::getInstance().print_error(IOManager::ECode::E_FAILED_TO_PROCESS, true, _T("EDITING"), _T(""), _T("Failed to start database editing for MultiUserWorkspace"));
				return false;
			}
			if (mode == esriMESMVersioned)
			{
				if (FAILED(IWorkspaceEditPtr(ipWorkspace)->StartEditOperation()))
				{
					CString errorMsg = _T("Start editing");
					IOManager::getInstance().print_error(IOManager::ECode::E_FAILED_TO_PROCESS, true, _T("EDITING"), _T(""), _T("Failed to start database editing for esriMESMVersioned"));
					return false;
				}
			}
		}
		else
		{
			if (FAILED(IWorkspaceEditPtr(ipWorkspace)->StartEditing(VARIANT_FALSE)))
			{
				CString errorMsg = _T("Start editing");
				IOManager::getInstance().print_error(IOManager::ECode::E_FAILED_TO_PROCESS, true, _T("EDITING"), _T(""), _T("Failed to start database editing"));
				return false;
			}
		}
		return true;
	}
	bool startEditTable(IWorkspacePtr& ipWorkspace, ITablePtr& ipTable)
	{

		IMultiuserWorkspaceEditPtr ipMultiuserWorkspace(ipWorkspace);
		if (ipMultiuserWorkspace)
		{
			// �Ԑ������N�̃o�[�W�����Ή����\�Ƃ��Č��Ă���
			esriMultiuserEditSessionMode mode = isVersionedTable(ipTable) ? esriMESMVersioned : esriMESMNonVersioned;
			if (FAILED(ipMultiuserWorkspace->StartMultiuserEditing(mode)))
			{
				IOManager::getInstance().print_error(IOManager::ECode::E_FAILED_TO_PROCESS, true, _T("EDITING"), _T(""), _T("Failed to start database editing for MultiUserWorkspace"));
				return false;
			}
			if (mode == esriMESMVersioned)
			{
				if (FAILED(IWorkspaceEditPtr(ipWorkspace)->StartEditOperation()))
				{
					CString errorMsg = _T("Start editing");
					IOManager::getInstance().print_error(IOManager::ECode::E_FAILED_TO_PROCESS, true, _T("EDITING"), _T(""), _T("Failed to start database editing for esriMESMVersioned"));
					return false;
				}
			}
		}
		else
		{
			if (FAILED(IWorkspaceEditPtr(ipWorkspace)->StartEditing(VARIANT_FALSE)))
			{
				CString errorMsg = _T("Start editing");
				IOManager::getInstance().print_error(IOManager::ECode::E_FAILED_TO_PROCESS, true, _T("EDITING"), _T(""), _T("Failed to start database editing"));
				return false;
			}
		}
		return true;
	}

	bool stopEditFeatureClass(IWorkspacePtr& ipWorkspace, IFeatureClassPtr& ipFeatureClass)
	{
		IMultiuserWorkspaceEditPtr ipMultiuserWorkspace(ipWorkspace);
		if (ipMultiuserWorkspace && isVersionedFeatureClass(ipFeatureClass))
		{
			if (FAILED(IWorkspaceEditPtr(ipWorkspace)->StopEditOperation()))
			{
				CString errorMsg = _T("Stop editing");
				IOManager::getInstance().print_error(IOManager::ECode::E_FAILED_TO_PROCESS, true, _T("EDITING"), _T(""), _T("Failed to stop database editing for MultiUserWorkspace"));
				abortEdit(ipWorkspace);
				return false;
			}
		}
		if (FAILED(IWorkspaceEditPtr(ipWorkspace)->StopEditing(VARIANT_TRUE)))
		{
			CString errorMsg = _T("Stop editing");
			IOManager::getInstance().print_error(IOManager::ECode::E_FAILED_TO_PROCESS, true, _T("EDITING"), _T(""), _T("Failed to stop database editing"));
			abortEdit(ipWorkspace);
			return false;
		}
		return true;
	}
	bool stopEditTable(IWorkspacePtr& ipWorkspace, ITablePtr& ipTable)
	{
		IMultiuserWorkspaceEditPtr ipMultiuserWorkspace(ipWorkspace);
		if (ipMultiuserWorkspace && isVersionedTable(ipTable))
		{
			if (FAILED(IWorkspaceEditPtr(ipWorkspace)->StopEditOperation()))
			{
				CString errorMsg = _T("Stop editing");
				IOManager::getInstance().print_error(IOManager::ECode::E_FAILED_TO_PROCESS, true, _T("EDITING"), _T(""), _T("Failed to stop database editing for MultiUserWorkspace"));
				abortEdit(ipWorkspace);
				return false;
			}
		}
		if (FAILED(IWorkspaceEditPtr(ipWorkspace)->StopEditing(VARIANT_TRUE)))
		{
			CString errorMsg = _T("Stop editing");
			IOManager::getInstance().print_error(IOManager::ECode::E_FAILED_TO_PROCESS, true, _T("EDITING"), _T(""), _T("Failed to stop database editing"));
			abortEdit(ipWorkspace);
			return false;
		}
		return true;
	}

	void abortEdit(IWorkspacePtr& ipWorkspace)
	{
		VARIANT_BOOL vb = VARIANT_FALSE;
		IWorkspaceEditPtr(ipWorkspace)->IsBeingEdited(&vb);
		if (!vb)
			return;
		if (FAILED(IWorkspaceEditPtr(ipWorkspace)->AbortEditOperation()) ||
			FAILED(IWorkspaceEditPtr(ipWorkspace)->StopEditing(VARIANT_FALSE))) {
			CString errorMsg = _T("Abort editing");
			IOManager::getInstance().print_error(IOManager::ECode::E_FAILED_TO_PROCESS, true, _T("EDITING"), _T(""), _T("Failed to abort database editing"));
		}
	}
}



