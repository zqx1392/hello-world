#pragma once
/**
* @brief	Manage input option for console application
*/

class OptionManager
{
public:

	IOManager * m_IOCtrl;					//Control IO
	
	OptionManager();
	~OptionManager();
	
	/**
	* @brief Get all option from console 
	* @param argc				[in]	total argument number
	* @param argv				[in]	arguments
	* @return	RCode value [ex�FR_SUCCESS=0�AR_FAILED_FATAL_ERROR=1�A...]
	*/
	int getOption(const int& argc, _TCHAR* argv[]);
	/**
	* @brief Set all optional options with default values
	*/
	int presetOption();
	/**
	* @brief Print file description before start the program
	*/
	void printDescription();
	/**
	* @brief Print all option details
	* @param vm				[in]	boost's object list
	*/
	void print_all_option();

	boost::program_options::variables_map m_vm;		//Record option content
	bool is_FGDB;
	std::wstring m_db;
	std::wstring m_hnp;
	std::wstring m_hnp_entrypoint;
	std::wstring m_poi_info;
	std::wstring m_poi_entrypoint;
	std::wstring m_poi_asso;
	std::wstring m_official;
	std::wstring m_translation;
	std::wstring m_sql_poiinfo;
	std::wstring m_sql_poientry;
	std::wstring m_buffer_size;
	std::wstring m_run_log;
	std::wstring m_err_log;
	const char * k_db;
	const char * k_hnp;
	const char * k_hnp_entrypoint;
	const char * k_poi_info;
	const char * k_poi_entrypoint;
	const char * k_poi_asso;
	const char * k_official;
	const char * k_translation;
	const char * k_sql_poiinfo;
	const char * k_sql_poientry;
	const char * k_buffer_size;
	const char * k_run_log;
	const char * k_err_log;
};