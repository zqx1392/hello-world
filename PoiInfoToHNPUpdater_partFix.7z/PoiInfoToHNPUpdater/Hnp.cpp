#include "stdafx.h"
#include "Hnp.h"


using namespace sindy::schema::global;

Hnp::Hnp(const CString& HnpFeatureClassName, IFeatureClassPtr& HnpFeatureClass) {
	featureClassName = HnpFeatureClassName;
	ipFeatureClass = HnpFeatureClass;
	//get field index value
	AccessSV::getFeatureClassColumnIndex(ipFeatureClass, hnp::kOperator, &m_operatorIndex);
	AccessSV::getFeatureClassColumnIndex(ipFeatureClass, hnp::kPurpose, &m_purposeCIndex);
	AccessSV::getFeatureClassColumnIndex(ipFeatureClass, hnp::kModifyDate, &m_modifyDateIndex);
	AccessSV::getFeatureClassColumnIndex(ipFeatureClass, hnp::kUpdateType, &m_updateTypeCIndex);
	AccessSV::getFeatureClassColumnIndex(ipFeatureClass, hnp::kProgModifyDate, &m_progModifyDateIndex);
	AccessSV::getFeatureClassColumnIndex(ipFeatureClass, hnp::kModifyProgName, &m_modifyProgNameIndex);
	AccessSV::getFeatureClassColumnIndex(ipFeatureClass, hnp::kUserClaim, &m_userClaimFIndex);
	AccessSV::getFeatureClassColumnIndex(ipFeatureClass, hnp::kSource, &m_sourceIndex);
	AccessSV::getFeatureClassColumnIndex(ipFeatureClass, hnp::kHn, &m_HNIndex);
	AccessSV::getFeatureClassColumnIndex(ipFeatureClass, hnp::kHnType, &m_HNTypeIndex);
	AccessSV::getFeatureClassColumnIndex(ipFeatureClass, hnp::kLinkID, &m_linkIDIndex);
	AccessSV::getFeatureClassColumnIndex(ipFeatureClass, hnp::kRoadNameID, &m_roadNameIDIndex);
}

Hnp::~Hnp() {
}

int Hnp::insertNewRecordToHNP(IWorkspacePtr& workspace, std::vector<PoiInfo::poiInfo> * uniquePoiInfoList, std::map<long, long> * updatedPoiHnpList) {

	long successUpdateCount = 0;	//count total successfully update records

	if (IOManager::RCode::R_SUCCESS != createNewBuffer()) {
		return IOManager::RCode::R_FAILED_FATAL_ERROR;
	}
	
	//update HNP with POI_INFO where ROADNAMEID = NULL
	for (int i = 0; i<uniquePoiInfoList->size(); i++) {
		//skip not null ROADNAMEID
		if (uniquePoiInfoList->operator[](i).roadNameID != 0) {
			continue;
		}
		//start editing (restart every 10000 records to flush records in memory)
		if (successUpdateCount % 10000 == 0) {
			if (IOManager::RCode::R_SUCCESS != startAndInsertCursor(workspace)) {
				return IOManager::RCode::R_FAILED_FATAL_ERROR;
			}
		}

		double x = uniquePoiInfoList->operator[](i).x;
		double y = uniquePoiInfoList->operator[](i).y;
		long poiInfoObjectID = uniquePoiInfoList->operator[](i).OBJECTID;
		CString hn = uniquePoiInfoList->operator[](i).houseNumber;
		if (IOManager::RCode::R_SUCCESS != putValueIntoFields(poiInfoObjectID, hn, 0, x, y)) {
			return IOManager::RCode::R_FAILED_FATAL_ERROR;
		}

		CComVariant newHnpOID;
		if (IOManager::RCode::R_SUCCESS != insertNewFeature(&newHnpOID)) {
			return IOManager::RCode::R_FAILED_FATAL_ERROR;
		}
		

		//insert into updatedPoiHnpList map to create new records on HNP_ENTRYPOINT later
		if (!updatedPoiHnpList->insert(std::make_pair(uniquePoiInfoList->operator[](i).OBJECTID, newHnpOID.intVal)).second) {
			IOManager::getInstance().print_error(IOManager::ECode::E_FAILED_TO_PROCESS, true, _T("Unexpected error occured while creating updatedPoiHnpList variable"));
			return IOManager::RCode::R_FAILED_FATAL_ERROR;
		}
		
		successUpdateCount++;

		//flush to database every 10000 new records
		if (successUpdateCount % 10000 == 0 && successUpdateCount > 0) {
			if (IOManager::RCode::R_SUCCESS != flushAndStopEdit(workspace)) {
				return IOManager::RCode::R_FAILED_FATAL_ERROR;
			}
		}
	}
	//flush last group of new records
	if (successUpdateCount % 10000 != 0 || successUpdateCount == 0) {
		if (IOManager::RCode::R_SUCCESS != flushAndStopEdit(workspace)) {
			return IOManager::RCode::R_FAILED_FATAL_ERROR;
		}
	}

	//print total update count
	IOManager::getInstance().print_run(true, true, _T("Successfully updated HNP where ROADNAMEID is NULL"));
	CString updateCount = std::to_string(successUpdateCount).c_str();
	IOManager::getInstance().print_run(true, true, _T("Total updated record : ") + updateCount);
	return IOManager::RCode::R_SUCCESS;
}


int Hnp::putValueIntoFields(const long& poiInfoObjectID, const CString& hn, const long& roadNameID, const double& x, const double& y) {
	//create new HNP record
	int returnStatus = 0;
	returnStatus += AccessSV::putFeatureClassColumnValue(featureClassName, featureBuffer, m_operatorIndex, CComVariant(CommonData::getInstance().getOperator()));
	returnStatus += AccessSV::putFeatureClassColumnValue(featureClassName, featureBuffer, m_purposeCIndex, CComVariant(CommonData::getInstance().getPurpose()));
	returnStatus += AccessSV::putFeatureClassColumnValue(featureClassName, featureBuffer, m_updateTypeCIndex, CComVariant(CommonData::getInstance().getUpdateType()));
	returnStatus += AccessSV::putFeatureClassColumnValue(featureClassName, featureBuffer, m_progModifyDateIndex, CComVariant(CommonData::getInstance().getCurrentDateTime()));
	returnStatus += AccessSV::putFeatureClassColumnValue(featureClassName, featureBuffer, m_modifyProgNameIndex, CComVariant(CommonData::getInstance().getModifyProgName()));
	returnStatus += AccessSV::putFeatureClassColumnValue(featureClassName, featureBuffer, m_userClaimFIndex, CComVariant(CommonData::getInstance().getUserClaim()));
	//set message for source column
	CString objectID = _T("POI_INFO OBJECTID: ");
	objectID += std::to_string(poiInfoObjectID).c_str();
	returnStatus += AccessSV::putFeatureClassColumnValue(featureClassName, featureBuffer, m_sourceIndex, CComVariant(objectID));
	returnStatus += AccessSV::putFeatureClassColumnValue(featureClassName, featureBuffer, m_HNIndex, CComVariant(hn));
	returnStatus += AccessSV::putFeatureClassColumnValue(featureClassName, featureBuffer, m_HNTypeIndex, CComVariant(CommonData::getInstance().getHNType()));
	returnStatus += AccessSV::putFeatureClassColumnValue(featureClassName, featureBuffer, m_linkIDIndex, CComVariant(CommonData::getInstance().getLinkID()));
	returnStatus += AccessSV::putFeatureClassColumnValue(featureClassName, featureBuffer, m_roadNameIDIndex, CComVariant(roadNameID));
	if (returnStatus != IOManager::RCode::R_SUCCESS) {
		return IOManager::RCode::R_FAILED_FATAL_ERROR;
	}
	//set new coordinates to base shape
	IGeometryPtr ipGeom = CommonData::getInstance().getExamplePointShape();
	if (S_OK != IPointPtr(ipGeom)->PutCoords(x, y)) {
		IOManager::getInstance().print_error(IOManager::ECode::E_FAILED_TO_SET_DATA, true, featureClassName, _T(""), _T("Failed to set coordinates for a new HNP record"));
		return IOManager::RCode::R_FAILED_FATAL_ERROR;
	}

	//add edited shape to this new record
	if (S_OK != featureBuffer->putref_Shape(ipGeom)) {
		IOManager::getInstance().print_error(IOManager::ECode::E_FAILED_TO_SET_DATA, true, featureClassName, _T(""), _T("Failed to input new shape"));
		return IOManager::RCode::R_FAILED_FATAL_ERROR;
	}
	return IOManager::RCode::R_SUCCESS;
}

int Hnp::createNewBuffer() {
	return featureClass::createNewBuffer();
}

int Hnp::insertNewFeature(CComVariant * newHnpOID) {
	return featureClass::insertNewFeature(newHnpOID);
}

int Hnp::startAndInsertCursor(IWorkspacePtr& workspace) {
	return featureClass::startAndInsertCursor(workspace);
}

int Hnp::flushAndStopEdit(IWorkspacePtr& workspace) {
	return featureClass::flushAndStopEdit(workspace);
}


