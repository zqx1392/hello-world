#include "stdafx.h"

#include "Translation.h"

using namespace sindy::schema::global;

Translation::Translation(const CString& translationTableName, ITablePtr& translationTable) {
	tableName = translationTableName;
	ipTable = translationTable;

	//get field index value
	AccessSV::getTableColumnIndex(ipTable, translation::kObjectID, &m_objectIDIndex);
	AccessSV::getTableColumnIndex(ipTable, translation::kOperator, &m_operatorIndex);
	AccessSV::getTableColumnIndex(ipTable, translation::kPurpose, &m_purposeCIndex);
	AccessSV::getTableColumnIndex(ipTable, translation::kModifyDate, &m_modifyDateIndex);
	AccessSV::getTableColumnIndex(ipTable, translation::kUpdateType, &m_updateTypeCIndex);
	AccessSV::getTableColumnIndex(ipTable, translation::kProgModifyDate, &m_progModifyDateIndex);
	AccessSV::getTableColumnIndex(ipTable, translation::kModifyProgName, &m_modifyProgNameIndex);
	AccessSV::getTableColumnIndex(ipTable, translation::kUserClaim, &m_userClaimFIndex);
	AccessSV::getTableColumnIndex(ipTable, translation::kSource, &m_sourceIndex);
	AccessSV::getTableColumnIndex(ipTable, translation::kTypeF, &m_typeFIndex);
	AccessSV::getTableColumnIndex(ipTable, translation::kID, &m_transIDIndex);
	AccessSV::getTableColumnIndex(ipTable, translation::kName, &m_nameIndex);
	AccessSV::getTableColumnIndex(ipTable, translation::kLanguageCode, &m_languageCIndex);
}

Translation::~Translation() {
}

int Translation::insertNewRecordToTranslation(IWorkspacePtr& workspace, std::map<long, long> * translationList) {

	long successUpdateCount = 0;	//count total successfully update records

	//set all condition into query variable
	_ICursorPtr ipTranslationCursor;
	IQueryFilterPtr translationIpQueryFilter(CLSID_QueryFilter);
	if (S_OK != ipTable->Search(translationIpQueryFilter, VARIANT_FALSE, &ipTranslationCursor)) {
		IOManager::getInstance().print_error(IOManager::ECode::E_FAILED_TO_GET_DATA, true, tableName, _T(""), _T("Failed to get all records"));
		return IOManager::RCode::R_FAILED_FATAL_ERROR;
	}


	//setup cursor and buffer for inputting new TRANSLATION records
	if (IOManager::RCode::R_SUCCESS != createNewBuffer()) {
		return IOManager::RCode::R_FAILED_FATAL_ERROR;
	}

	//create new records
	_IRowPtr ipTranslationRow;
	while (ipTranslationCursor->NextRow(&ipTranslationRow) == S_OK && ipTranslationRow) {
		// get postal point OID
		long OIDNum;
		if (S_OK != ipTranslationRow->get_OID(&OIDNum)) {
			IOManager::getInstance().print_error(IOManager::ECode::E_FAILED_TO_GET_DATA, true, tableName, _T(""), _T("Failed to get OBJECTID of one ") + tableName);
			return IOManager::RCode::R_FAILED_FATAL_ERROR;
		}
		//convert OID from long to CString
		CString OID;
		OID.Format(L"%ld", OIDNum);
		//get TRANS_ID
		CComVariant transID;
		if (S_OK != ipTranslationRow->get_Value(m_transIDIndex, &transID)) {
			IOManager::getInstance().print_error(IOManager::ECode::E_FAILED_TO_GET_DATA, true, tableName + _T(" OBJECTID"), OID, _T("Failed to get POIINFOID value"));
			return IOManager::RCode::R_FAILED_FATAL_ERROR;
		}
		long convertedTransID = transID.lVal;
		//if found this TRANSLATION TRANS_ID in target translationList
		if (translationList->find(convertedTransID) != translationList->end()) {
			//start editing
			if (successUpdateCount % 10000 == 0) {
				if (IOManager::RCode::R_SUCCESS != startAndInsertCursor(workspace)) {
					return IOManager::RCode::R_FAILED_FATAL_ERROR;
				}
			}
			//if not found this OIDNum in target translationList
			if (translationList->find(OIDNum) == translationList->end()) {
				IOManager::getInstance().print_error(IOManager::ECode::E_FAILED_TO_GET_DATA, true, tableName + _T(" OBJECTID"), OID, _T("Not found in translationList"));
				return IOManager::RCode::R_FAILED_FATAL_ERROR;
			}
			long newTransID = translationList->find(OIDNum)->second;
			//put all field value into new record
			if (IOManager::RCode::R_SUCCESS != putValueIntoFields(ipTranslationRow, OID, newTransID)) {
				return IOManager::RCode::R_FAILED_FATAL_ERROR;
			}

			//insert new row into TRANSLATION
			CComVariant newTranslationOID;
			if (IOManager::RCode::R_SUCCESS != insertNewRow(&newTranslationOID)) {
				return IOManager::RCode::R_FAILED_FATAL_ERROR;
			}

			successUpdateCount++;
		}
		//flush to database every 10000 new records
		if (successUpdateCount % 10000 == 0 && successUpdateCount > 0) {
			if (IOManager::RCode::R_SUCCESS != flushAndStopEdit(workspace)) {
				return IOManager::RCode::R_FAILED_FATAL_ERROR;
			}
		}
	}
	//flush last group of new records
	if (successUpdateCount % 10000 != 0 || successUpdateCount == 0) {
		if (IOManager::RCode::R_SUCCESS != flushAndStopEdit(workspace)) {
			return IOManager::RCode::R_FAILED_FATAL_ERROR;
		}
	}
	//print total update count
	IOManager::getInstance().print_run(true, true, _T("Successfully updated TRANSLATION"));
	CString updateCount = std::to_string(successUpdateCount).c_str();
	IOManager::getInstance().print_run(true, true, _T("Total updated record : ") + updateCount);
	return IOManager::RCode::R_SUCCESS;
}

int Translation::putValueIntoFields(_IRowPtr& ipTranslationRow, const CString& OID, const long& transID) {
	//create new HNP_ENTRYPOINT record
	for (int i = 0; i<ipTable->Fields->FieldCount; i++) {
		//discard index and transID
		if (i == m_objectIDIndex) {
			continue;
		}
		//get value on old record
		CComVariant tempValue;
		if (S_OK != ipTranslationRow->get_Value(i, &tempValue)) {
			CComBSTR columnName = "";
			//get field name to print description error
			if (S_OK != ipTable->Fields->GetField(i)->get_Name(&columnName)) {
				IOManager::getInstance().print_error(IOManager::ECode::E_FAILED_TO_GET_DATA, true, tableName + _T(" OBJECTID"), OID, _T("Failed to get field name and value"));
				return IOManager::RCode::R_FAILED_FATAL_ERROR;
			}
			//print error with field name
			CString msg = "Failed to get ";
			msg += columnName;
			msg += " value";
			IOManager::getInstance().print_error(IOManager::ECode::E_FAILED_TO_GET_DATA, true, tableName + _T(" OBJECTID"), OID, msg);
			return IOManager::RCode::R_FAILED_FATAL_ERROR;
		}
		//set value on new record
		//set value for TRANS_ID
		if (i == m_transIDIndex) {
			
			if (S_OK != rowBuffer->put_Value(i, CComVariant(transID))) {
				IOManager::getInstance().print_error(IOManager::ECode::E_FAILED_TO_GET_DATA, true, tableName + _T(" OBJECTID"), OID, _T("Failed to set TRANS_ID field value"));
				return IOManager::RCode::R_FAILED_FATAL_ERROR;
			}
		}
		//operator = sindy
		else if (i == m_operatorIndex) {
			if (S_OK != rowBuffer->put_Value(i, CComVariant(CommonData::getInstance().getOperator()))) {
				IOManager::getInstance().print_error(IOManager::ECode::E_FAILED_TO_GET_DATA, true, tableName + _T(" OBJECTID"), OID, _T("Failed to set OPERATOR value"));
				return IOManager::RCode::R_FAILED_FATAL_ERROR;
			}
		}
		//updatetypeC = 6
		else if (i == m_updateTypeCIndex) {
			if (S_OK != rowBuffer->put_Value(i, CComVariant(CommonData::getInstance().getUpdateType()))) {
				IOManager::getInstance().print_error(IOManager::ECode::E_FAILED_TO_GET_DATA, true, tableName + _T(" OBJECTID"), OID, _T("Failed to set UPDATETYPE_C value"));
				return IOManager::RCode::R_FAILED_FATAL_ERROR;
			}
		}
		//prog modify date = now
		else if (i == m_progModifyDateIndex) {
			if (S_OK != rowBuffer->put_Value(i, CComVariant(CommonData::getInstance().getCurrentDateTime()))) {
				IOManager::getInstance().print_error(IOManager::ECode::E_FAILED_TO_GET_DATA, true, tableName + _T(" OBJECTID"), OID, _T("Failed to set PROGMODIFYDATE value"));
				return IOManager::RCode::R_FAILED_FATAL_ERROR;
			}
		}
		//modify prog name = "PoiInfoToHnpUpdater.exe"
		else if (i == m_modifyProgNameIndex) {
			if (S_OK != rowBuffer->put_Value(i, CComVariant(CommonData::getInstance().getModifyProgName()))) {
				IOManager::getInstance().print_error(IOManager::ECode::E_FAILED_TO_GET_DATA, true, tableName + _T(" OBJECTID"), OID, _T("Failed to set MODIFYPROGNAME value"));
				return IOManager::RCode::R_FAILED_FATAL_ERROR;
			}
		}
		else {
			if (S_OK != rowBuffer->put_Value(i, tempValue)) {
				IOManager::getInstance().print_error(IOManager::ECode::E_FAILED_TO_GET_DATA, true, tableName + _T(" OBJECTID"), OID, _T("Failed to set field value"));
				return IOManager::RCode::R_FAILED_FATAL_ERROR;
			}
		}
	}
}

int Translation::createNewBuffer() {
	return table::createNewBuffer();
}

int Translation::insertNewRow(CComVariant * newHnpOID) {
	return table::insertNewRow(newHnpOID);
}

int Translation::startAndInsertCursor(IWorkspacePtr& workspace) {
	return table::startAndInsertCursor(workspace);
}

int Translation::flushAndStopEdit(IWorkspacePtr& workspace) {
	return table::flushAndStopEdit(workspace);
}