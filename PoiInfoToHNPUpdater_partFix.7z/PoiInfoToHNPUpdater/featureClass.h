#pragma once

/**
* @brief Base class for other layer classes. Contain layer-related information and edit-related functions
*/
class featureClass {
public:
	/**
	* @brief Initialize new buffer on featureBuffer for new records
	* @return	IOManager::RCode
	*/
	int createNewBuffer();
	/**
	* @brief Insert new feature into featureBuffer
	* @param newOID			[out]	new record objectID
	* @return	IOManager::RCode
	*/
	int insertNewFeature(CComVariant * newOID);
	/**
	* @brief start new edit process on this featureClass, and create new insertCusor
	* @param ipWorkspace		[in]	target workspace
	* @return	IOManager::RCode
	*/
	int startAndInsertCursor(IWorkspacePtr& ipWorkspace);
	/**
	* @brief stop edit process on this featureClass, and flush new records to database
	* @param ipWorkspace		[in]	target workspace
	* @return	IOManager::RCode
	*/
	int flushAndStopEdit(IWorkspacePtr& ipWorkspace);

protected:
	CString featureClassName;
	IFeatureClassPtr ipFeatureClass;
	IFeatureCursorPtr insertCursor;
	IFeatureBufferPtr featureBuffer;

};

