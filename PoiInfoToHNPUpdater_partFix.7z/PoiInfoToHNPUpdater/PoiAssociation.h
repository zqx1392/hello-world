#pragma once

#include "table.h"

class PoiAssociation : public table {
public:

	PoiAssociation(const CString& poiAssoTableName, ITablePtr& poiAssoTable);
	~PoiAssociation();
	/**
	* @brief start the tool
	* @return	RCode value [ex�FR_SUCCESS=0�AR_FAILED_FATAL_ERROR=1�A...]
	*/
	int getChildPOI(std::set<long> * childPOIList);

private:
	//POI_ASSOCIATION field index
	long m_operatorIndex;
	long m_purposeCIndex;
	long m_modifyDateIndex;
	long m_updateTypeCIndex;
	long m_progModifyDateIndex;
	long m_modifyProgNameIndex;
	long m_userClaimFIndex;
	long m_sourceIndex;
	long m_parentIDIndex;
	long m_childIDIndex;
};
