#pragma once

#include "table.h"

class Translation : public table {
public:

	Translation(const CString& translationTableName, ITablePtr& translationTable);
	~Translation();

	/**
	* @brief start the tool
	* @return	RCode value [ex�FR_SUCCESS=0�AR_FAILED_FATAL_ERROR=1�A...]
	*/
	int insertNewRecordToTranslation(IWorkspacePtr& workspace, std::map<long, long> * translationList);

	int putValueIntoFields(_IRowPtr& ipTranslationRow, const CString& OID, const long& transID);

	int createNewBuffer();

	int insertNewRow(CComVariant * newHnpOID);

	int startAndInsertCursor(IWorkspacePtr& workspace);

	int flushAndStopEdit(IWorkspacePtr& workspace);


private:
	//TRANSLATION field index
	long m_objectIDIndex;
	long m_operatorIndex;
	long m_purposeCIndex;
	long m_modifyDateIndex;
	long m_updateTypeCIndex;
	long m_progModifyDateIndex;
	long m_modifyProgNameIndex;
	long m_userClaimFIndex;
	long m_sourceIndex;
	long m_typeFIndex;
	long m_transIDIndex;
	long m_nameIndex;
	long m_languageCIndex;
};