#include "stdafx.h"
#include "featureClass.h"


using namespace sindy::schema::global;


int featureClass::createNewBuffer() {
	if (S_OK != ipFeatureClass->CreateFeatureBuffer(&featureBuffer)) {
		IOManager::getInstance().print_error(IOManager::ECode::E_FAILED_TO_GET_DATA, true, featureClassName, _T(""), _T("Failed to create buffer"));
		return IOManager::RCode::R_FAILED_FATAL_ERROR;
	}
	return IOManager::RCode::R_SUCCESS;
}

int featureClass::insertNewFeature(CComVariant * newOID) {
	if (S_OK != insertCursor->InsertFeature(featureBuffer, newOID)) {
		IOManager::getInstance().print_error(IOManager::ECode::E_FAILED_TO_SET_DATA, true, featureClassName, _T(""), _T("Failed to insert new record into cursor"));
		return IOManager::RCode::R_FAILED_FATAL_ERROR;
	}
	IOManager::getInstance().print_run(true, false, featureClassName + _T(" OBJECTID"), *newOID, _T("Record has been created successfully"));
	return IOManager::RCode::R_SUCCESS;
}

int featureClass::startAndInsertCursor(IWorkspacePtr& ipWorkspace) {
	if (!AccessSV::startEditFeatureClass(ipWorkspace, ipFeatureClass)) {
		IOManager::getInstance().print_error(IOManager::ECode::E_FAILED_TO_GET_DATA, true, featureClassName, _T(""), _T("Start Editing"));
		return IOManager::RCode::R_FAILED_FATAL_ERROR;
	}
	//insert cursor for creating records
	if (S_OK != ipFeatureClass->Insert(VARIANT_TRUE, &insertCursor)) {
		IOManager::getInstance().print_error(IOManager::ECode::E_FAILED_TO_GET_DATA, true, featureClassName, _T(""), _T("Create new cursor for new records"));
		return IOManager::RCode::R_FAILED_FATAL_ERROR;
	}
	return IOManager::RCode::R_SUCCESS;
}

int featureClass::flushAndStopEdit(IWorkspacePtr& ipWorkspace) {
	///CAUTION!!! UPDATE NEW RECORDS TO DATABASE
	///CAUTION!!! UPDATE NEW RECORDS TO DATABASE
	if (S_OK != insertCursor->Flush()) {
		IOManager::getInstance().print_error(IOManager::ECode::E_FAILED_TO_GET_DATA, true, featureClassName, _T(""), _T("Failed to insert new record into database"));
		return IOManager::RCode::R_FAILED_FATAL_ERROR;
	}
	///CAUTION!!! UPDATE NEW RECORDS TO DATABASE
	///CAUTION!!! UPDATE NEW RECORDS TO DATABASE
	if (!AccessSV::stopEditFeatureClass(ipWorkspace, ipFeatureClass)) {
		IOManager::getInstance().print_error(IOManager::ECode::E_FAILED_TO_GET_DATA, true, _T("Abort Editing"));
		return IOManager::RCode::R_FAILED_FATAL_ERROR;
	}
	return IOManager::RCode::R_SUCCESS;
}