#include "stdafx.h"
#include "PoiEntrypoint.h"
#include "HnpEntrypoint.h"



using namespace sindy::schema::global;

HnpEntrypoint::HnpEntrypoint(const CString& HnpEntryfeatureClassName, IFeatureClassPtr& HnpEntryFeatureClass, PoiEntrypoint * cPoiEntrypoint) {
	featureClassName = HnpEntryfeatureClassName;
	ipFeatureClass = HnpEntryFeatureClass;
	this->cPoiEntrypoint = cPoiEntrypoint;
	//get field index value
	AccessSV::getFeatureClassColumnIndex(ipFeatureClass, hnp_entry_point::kOperator, &m_operatorIndex);
	AccessSV::getFeatureClassColumnIndex(ipFeatureClass, hnp_entry_point::kPurpose, &m_purposeCIndex);
	AccessSV::getFeatureClassColumnIndex(ipFeatureClass, hnp_entry_point::kModifyDate, &m_modifyDateIndex);
	AccessSV::getFeatureClassColumnIndex(ipFeatureClass, hnp_entry_point::kUpdateType, &m_updateTypeCIndex);
	AccessSV::getFeatureClassColumnIndex(ipFeatureClass, hnp_entry_point::kProgModifyDate, &m_progModifyDateIndex);
	AccessSV::getFeatureClassColumnIndex(ipFeatureClass, hnp_entry_point::kModifyProgName, &m_modifyProgNameIndex);
	AccessSV::getFeatureClassColumnIndex(ipFeatureClass, hnp_entry_point::kUserClaim, &m_userClaimFIndex);
	AccessSV::getFeatureClassColumnIndex(ipFeatureClass, hnp_entry_point::kSource, &m_sourceIndex);
	AccessSV::getFeatureClassColumnIndex(ipFeatureClass, hnp_entry_point::kAccuracyCode, &m_accuracyCIndex);
	AccessSV::getFeatureClassColumnIndex(ipFeatureClass, hnp_entry_point::kHnpPointID, &m_HnpPointIDIndex);
}

HnpEntrypoint::~HnpEntrypoint() {
}

int HnpEntrypoint::insertNewRecordToHNPEntrypoint(IWorkspacePtr& workspace, const CComBSTR & queryFilter, std::map<long, long> * updatedPoiHnpList) {
	long successUpdateCount = 0;	//count total successfully update records

	//setup cursor and buffer for inputting new POI_ENTRYPOINT records
	IFeatureCursorPtr ipPoiEntryCursor;
	if (S_OK != cPoiEntrypoint->presetPoiEntryFeatureCursor(queryFilter, ipPoiEntryCursor)) {
		return IOManager::RCode::R_FAILED_FATAL_ERROR;
	}
	if (IOManager::RCode::R_SUCCESS != createNewBuffer()) {
		return IOManager::RCode::R_FAILED_FATAL_ERROR;
	}

	//loop POI_ENTRYPOINT
	IFeaturePtr ipPoiEntryFeature;
	while (ipPoiEntryCursor->NextFeature(&ipPoiEntryFeature) == S_OK && ipPoiEntryFeature) {
		long OIDNum;
		long PoiInfoID;
		long accuracyC;
		IGeometryPtr ipPoiEntryGeom;
		cPoiEntrypoint->getDataForNewHnpEntryRecord(ipPoiEntryFeature, &OIDNum, &PoiInfoID, &accuracyC, ipPoiEntryGeom);
		//find if this POI_ENTRYPOINT's parent is target
		if (updatedPoiHnpList->find(PoiInfoID) != updatedPoiHnpList->end()) {
			//start editing
			if (successUpdateCount % 10000 == 0) {
				if (IOManager::RCode::R_SUCCESS != startAndInsertCursor(workspace)) {
					return IOManager::RCode::R_FAILED_FATAL_ERROR;
				}
			}
			CComBSTR hnpObjectID = std::to_string(updatedPoiHnpList->find(PoiInfoID)->second).c_str();
			if (IOManager::RCode::R_SUCCESS != putValueIntoFields(OIDNum, accuracyC, hnpObjectID, ipPoiEntryGeom)) {
				return IOManager::RCode::R_FAILED_FATAL_ERROR;
			}

			//insert new row into HNP_ENTRYPOINT
			CComVariant newHnpEntryOID;
			if (IOManager::RCode::R_SUCCESS != insertNewFeature(&newHnpEntryOID)) {
				return IOManager::RCode::R_FAILED_FATAL_ERROR;
			}

			successUpdateCount++;
		}
		//flush to database every 10000 new records
		if (successUpdateCount % 10000 == 0 && successUpdateCount > 0) {
			if (IOManager::RCode::R_SUCCESS != flushAndStopEdit(workspace)) {
				return IOManager::RCode::R_FAILED_FATAL_ERROR;
			}
		}
	}
	//flush last group of new records
	if (successUpdateCount % 10000 != 0 || successUpdateCount == 0) {
		if (IOManager::RCode::R_SUCCESS != flushAndStopEdit(workspace)) {
			return IOManager::RCode::R_FAILED_FATAL_ERROR;
		}
	}
	//print total updated count
	IOManager::getInstance().print_run(true, true, _T("Successfully updated HNP_ENTRYPOINT"));
	CString updateCount = std::to_string(successUpdateCount).c_str();
	IOManager::getInstance().print_run(true, true, _T("Total updated record : ") + updateCount);
	return IOManager::RCode::R_SUCCESS;
}


int HnpEntrypoint::putValueIntoFields(const long& poiEntryObjectID, const long& accuracyC, const CComBSTR& HnpPointID, IGeometryPtr& ipGeom) {
	//create new HNP record
	int returnStatus = 0;
	returnStatus += AccessSV::putFeatureClassColumnValue(featureClassName, featureBuffer, m_operatorIndex, CComVariant(CommonData::getInstance().getOperator()));
	returnStatus += AccessSV::putFeatureClassColumnValue(featureClassName, featureBuffer, m_purposeCIndex, CComVariant(CommonData::getInstance().getPurpose()));
	returnStatus += AccessSV::putFeatureClassColumnValue(featureClassName, featureBuffer, m_updateTypeCIndex, CComVariant(CommonData::getInstance().getUpdateType()));
	returnStatus += AccessSV::putFeatureClassColumnValue(featureClassName, featureBuffer, m_progModifyDateIndex, CComVariant(CommonData::getInstance().getCurrentDateTime()));
	returnStatus += AccessSV::putFeatureClassColumnValue(featureClassName, featureBuffer, m_modifyProgNameIndex, CComVariant(CommonData::getInstance().getModifyProgName()));
	returnStatus += AccessSV::putFeatureClassColumnValue(featureClassName, featureBuffer, m_userClaimFIndex, CComVariant(CommonData::getInstance().getUserClaim()));
	//set message for source column
	CString objectID = _T("POI_INFO OBJECTID: ");
	objectID += std::to_string(poiEntryObjectID).c_str();
	returnStatus += AccessSV::putFeatureClassColumnValue(featureClassName, featureBuffer, m_sourceIndex, CComVariant(objectID));
	returnStatus += AccessSV::putFeatureClassColumnValue(featureClassName, featureBuffer, m_accuracyCIndex, CComVariant(accuracyC));
	returnStatus += AccessSV::putFeatureClassColumnValue(featureClassName, featureBuffer, m_HnpPointIDIndex, CComVariant(HnpPointID));
	if (returnStatus != IOManager::RCode::R_SUCCESS) {
		return IOManager::RCode::R_FAILED_FATAL_ERROR;
	}

	//add edited shape to this new record
	if (S_OK != featureBuffer->putref_Shape(ipGeom)) {
		IOManager::getInstance().print_error(IOManager::ECode::E_FAILED_TO_SET_DATA, true, featureClassName, _T(""), _T("Failed to input new shape"));
		return IOManager::RCode::R_FAILED_FATAL_ERROR;
	}
	return IOManager::RCode::R_SUCCESS;
}

int HnpEntrypoint::createNewBuffer() {
	return featureClass::createNewBuffer();
}

int HnpEntrypoint::insertNewFeature(CComVariant * newHnpOID) {
	return featureClass::insertNewFeature(newHnpOID);
}

int HnpEntrypoint::startAndInsertCursor(IWorkspacePtr& workspace) {
	return featureClass::startAndInsertCursor(workspace);
}

int HnpEntrypoint::flushAndStopEdit(IWorkspacePtr& workspace) {
	return featureClass::flushAndStopEdit(workspace);
}


