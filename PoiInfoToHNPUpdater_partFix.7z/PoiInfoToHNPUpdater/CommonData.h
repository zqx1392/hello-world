#pragma once

/**
* @brief Contain common data: default field value for new record
*/
class CommonData
{
public:
	/* static access method */
	static CommonData & getInstance();

	~CommonData();

	
	//get default variable value functions
	CString getOperator();
	int getPurpose();
	int getUpdateType();
	CString getModifyProgName();
	int getUserClaim();
	int getHNType();
	int getLinkID();
	int getHnpLayerC();
	double getCurrentDateTime();

	IGeometryPtr& getExamplePointShape();


private:
	CommonData(CommonData const&);
	CommonData();
	//copy shape from POI_INFO/POI_ENTRYPOINT to HNP/HNP_ENTRYPOINT so we don't need to create new one
	IGeometryPtr ipGeom;
	//constant value for new record field value
	CString m_operator;
	int m_purpose;
	int m_updateType;
	CString m_modifyProgName;
	int m_userClaim;
	int m_hntype;
	int m_linkID;
	int m_HNP_layerC;
};