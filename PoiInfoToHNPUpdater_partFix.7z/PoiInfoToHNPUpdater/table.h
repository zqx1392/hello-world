#pragma once

/**
* @brief Base class for other table classes. Contain table-related information and edit-related functions
*/
class table {
public:

	/**
	* @brief Initialize new buffer on rowBuffer for new records
	* @return	IOManager::RCode
	*/
	int createNewBuffer();
	/**
	* @brief Insert new row into rowBuffer
	* @param newOID			[out]	new record objectID
	* @return	IOManager::RCode
	*/
	int insertNewRow(CComVariant * newOID);
	/**
	* @brief start new edit process on this table, and create new insertCusor
	* @param ipWorkspace		[in]	target workspace
	* @return	IOManager::RCode
	*/
	int startAndInsertCursor(IWorkspacePtr& ipWorkspace);
	/**
	* @brief stop edit process on this table, and flush new records to database
	* @param ipWorkspace		[in]	target workspace
	* @return	IOManager::RCode
	*/
	int flushAndStopEdit(IWorkspacePtr& ipWorkspace);

protected:
	CString tableName;
	ITablePtr ipTable;
	_ICursorPtr insertCursor;
	IRowBufferPtr rowBuffer;

};