#pragma once

#include "featureClass.h"

class PoiEntrypoint : public featureClass {
public:

	PoiEntrypoint(const CString& poiEntryFeatureClassName, IFeatureClassPtr& poiEntryFeatureClass);
	~PoiEntrypoint();
	/**
	* @brief start the tool
	* @return	RCode value [ex�FR_SUCCESS=0�AR_FAILED_FATAL_ERROR=1�A...]
	*/
	int getPoiInfoID(const CComBSTR & queryFilter, std::set<long> * poiEntrypointList);
	/**
	* @brief start the tool
	* @return	RCode value [ex�FR_SUCCESS=0�AR_FAILED_FATAL_ERROR=1�A...]
	*/
	int presetPoiEntryFeatureCursor(const CComBSTR & queryFilter, IFeatureCursorPtr& ipEntryCursor);

	int getDataForNewHnpEntryRecord(IFeaturePtr& ipPoiEntryFeature, long * OIDNum, long * PoiInfoID, long * accuracyC, IGeometryPtr& ipGeom);

private:

	//POI_ENTRYPOINT field index
	long m_operatorIndex;
	long m_purposeCIndex;
	long m_modifyDateIndex;
	long m_updateTypeCIndex;
	long m_progModifyDateIndex;
	long m_modifyProgNameIndex;
	long m_userClaimFIndex;
	long m_sourceIndex;
	long m_PoiInfoIDIndex;
	long m_priorityFIndex;
	long m_entryPointCIndex;
	long m_accuracyCIndex;
};

