#include "stdafx.h"

#include "Hnp.h"
#include "OfficialName.h"


using namespace sindy::schema::global;

OfficialName::OfficialName(const CString& officialTableName, ITablePtr& officialTable, Hnp * cHnp) {
	tableName = officialTableName;
	ipTable = officialTable;
	this->cHnp = cHnp;
	//get field index value
	AccessSV::getTableColumnIndex(ipTable, official_name::kObjectID, &m_objectIDIndex);
	AccessSV::getTableColumnIndex(ipTable, official_name::kOperator, &m_operatorIndex);
	AccessSV::getTableColumnIndex(ipTable, official_name::kPurpose, &m_purposeCIndex);
	AccessSV::getTableColumnIndex(ipTable, official_name::kModifyDate, &m_modifyDateIndex);
	AccessSV::getTableColumnIndex(ipTable, official_name::kUpdateType, &m_updateTypeCIndex);
	AccessSV::getTableColumnIndex(ipTable, official_name::kProgModifyDate, &m_progModifyDateIndex);
	AccessSV::getTableColumnIndex(ipTable, official_name::kModifyProgName, &m_modifyProgNameIndex);
	AccessSV::getTableColumnIndex(ipTable, official_name::kUserClaim, &m_userClaimFIndex);
	AccessSV::getTableColumnIndex(ipTable, official_name::kSource, &m_sourceIndex);
	AccessSV::getTableColumnIndex(ipTable, official_name::kLayerCode, &m_layerCIndex);
	AccessSV::getTableColumnIndex(ipTable, official_name::kName, &m_nameIndex);
	AccessSV::getTableColumnIndex(ipTable, official_name::kLanguageCode, &m_languageCIndex);
}

OfficialName::~OfficialName() {
}

int OfficialName::getOfficalName(std::map<long, CString> * officialNameList) {

	//create condition to get only childID column
	IQueryFilterPtr officialIpQueryFilter(CLSID_QueryFilter);
	CString columnFilter;
	columnFilter.Format(_T("%s,%s"), official_name::kObjectID, official_name::kName);
	if (S_OK != officialIpQueryFilter->put_SubFields((CComBSTR)columnFilter)) {
		IOManager::getInstance().print_error(IOManager::ECode::E_FAILED_TO_SET_DATA, true, tableName, _T(""), _T("Failed to set search column for NAME column"));
		return IOManager::RCode::R_FAILED_FATAL_ERROR;
	}
	//set all condition into query variable
	_ICursorPtr ipOfficialCursor;
	//search only records with layer=33 (POI_INFO)
	CComBSTR queryFilter = _T("LAYER_C = 33");
	if (S_OK != officialIpQueryFilter->put_WhereClause(queryFilter)) {
		IOManager::getInstance().print_error(IOManager::ECode::E_FAILED_TO_SET_DATA, true, tableName, _T(""), _T("Failed to set search query"));
		return IOManager::RCode::R_FAILED_FATAL_ERROR;
	}
	if (S_OK != ipTable->Search(officialIpQueryFilter, VARIANT_FALSE, &ipOfficialCursor)) {
		IOManager::getInstance().print_error(IOManager::ECode::E_FAILED_TO_GET_DATA, true, tableName, _T(""), _T("Failed to get all records"));
		return IOManager::RCode::R_FAILED_FATAL_ERROR;
	}

	//set to store childID list
	//get target postal code
	_IRowPtr ipOfficialRow;
	while (ipOfficialCursor->NextRow(&ipOfficialRow) == S_OK && ipOfficialRow) {
		// get postal point OID
		long OIDNum;
		if (S_OK != ipOfficialRow->get_OID(&OIDNum)) {
			IOManager::getInstance().print_error(IOManager::ECode::E_FAILED_TO_GET_DATA, true, tableName, _T(""), _T("Failed to get OBJECTID of one ") + ipOfficialRow);
			return IOManager::RCode::R_FAILED_FATAL_ERROR;
		}
		//convert OID from long to CString
		CString OID;
		OID.Format(L"%ld", OIDNum);
		// get child id data
		CComVariant name;
		if (S_OK != ipOfficialRow->get_Value(m_nameIndex, &name)) {
			IOManager::getInstance().print_error(IOManager::ECode::E_FAILED_TO_GET_DATA, true, tableName + _T(" OBJECTID"), OID, _T("Failed to get NAME value"));
			return IOManager::RCode::R_FAILED_FATAL_ERROR;
		}
		CString convertedName = name.bstrVal;
		convertedName = convertedName.Trim();
		if (!officialNameList->insert(std::make_pair(OIDNum, name.bstrVal)).second) {
			IOManager::getInstance().print_error(IOManager::ECode::E_FAILED_TO_PROCESS, true, tableName + _T(" OBJECTID"), OID, _T("Unexpected error occured while storing OFFICIAL_NAME data"));
			return IOManager::RCode::R_FAILED_FATAL_ERROR;
		}
	}
	return IOManager::RCode::R_SUCCESS;
}

int OfficialName::insertNewRecordToHNPAndOfficial(IWorkspacePtr& workspace, std::vector<PoiInfo::poiInfo> * uniquePoiInfoList, std::map<long, long> * updatedPoiHnpList, std::map<long, long> * translationList) {
	long successUpdateCount = 0;	//count total successfully update records

	IQueryFilterPtr officialIpQueryFilter(CLSID_QueryFilter);

	//set all condition into query variable
	_ICursorPtr ipOfficialCursor;
	//search only records with layer=33 (POI_INFO)
	CComBSTR queryFilter = _T("LAYER_C = 33");
	if (S_OK != officialIpQueryFilter->put_WhereClause(queryFilter)) {
		IOManager::getInstance().print_error(IOManager::ECode::E_FAILED_TO_SET_DATA, true, tableName, _T(""), _T("Failed to set search query"));
		return IOManager::RCode::R_FAILED_FATAL_ERROR;
	}
	if (S_OK != ipTable->Search(officialIpQueryFilter, VARIANT_FALSE, &ipOfficialCursor)) {
		IOManager::getInstance().print_error(IOManager::ECode::E_FAILED_TO_GET_DATA, true, tableName, _T(""), _T("Failed to get all records"));
		return IOManager::RCode::R_FAILED_FATAL_ERROR;
	}

	//create new map for <POI_INFO.ROADNAMEID, position in uniquePoiInfoList> to reduce query time
	std::map<long, int> roadNameMap;
	for (int i = 0; i < uniquePoiInfoList->size(); i++) {
		//skip null ROADNAMEID
		if (uniquePoiInfoList->operator[](i).roadNameID == 0) {
			continue;
		}
		if (!roadNameMap.insert(std::make_pair(uniquePoiInfoList->operator[](i).roadNameID, i)).second) {
			IOManager::getInstance().print_error(IOManager::ECode::E_FAILED_TO_PROCESS, true, tableName, _T(""), _T("Unexpected error occured while creating roadNameMap variable"));
			return IOManager::RCode::R_FAILED_FATAL_ERROR;
		}
	}


	//setup cursor and buffer for inputting new OFFICIAL_NAME records
	if (IOManager::RCode::R_SUCCESS != createNewBuffer()) {
		return IOManager::RCode::R_FAILED_FATAL_ERROR;
	}

	//setup cursor and buffer for inputting new HNP records
	if (IOManager::RCode::R_SUCCESS != cHnp->createNewBuffer()) {
		return IOManager::RCode::R_FAILED_FATAL_ERROR;
	}

	//create new records
	_IRowPtr ipOfficialRow;
	while (ipOfficialCursor->NextRow(&ipOfficialRow) == S_OK && ipOfficialRow) {
		// get postal point OID
		long OIDNum;
		if (S_OK != ipOfficialRow->get_OID(&OIDNum)) {
			IOManager::getInstance().print_error(IOManager::ECode::E_FAILED_TO_GET_DATA, true, tableName, _T(""), _T("Failed to get OBJECTID of one ") + tableName);
			return IOManager::RCode::R_FAILED_FATAL_ERROR;
		}
		//convert OID from long to CString
		CString OID;
		OID.Format(L"%ld", OIDNum);
		//if found this OFFICIAL_NAME OBJECTID record in target POI_INFO
		if (roadNameMap.find(OIDNum) != roadNameMap.end()) {
			//start editing
			if (successUpdateCount % 10000 == 0) {
				if (IOManager::RCode::R_SUCCESS != startAndInsertCursor(workspace)) {
					return IOManager::RCode::R_FAILED_FATAL_ERROR;
				}
				if (IOManager::RCode::R_SUCCESS != cHnp->startAndInsertCursor(workspace)) {
					return IOManager::RCode::R_FAILED_FATAL_ERROR;
				}
			}
			//put all field value into new record
			if (IOManager::RCode::R_SUCCESS != putValueIntoFields(ipOfficialRow, OID)) {
				return IOManager::RCode::R_FAILED_FATAL_ERROR;
			}
			//insert new row into OFFICIAL_NAME
			CComVariant newOfficialOID;
			if (IOManager::RCode::R_SUCCESS != insertNewRow(&newOfficialOID)) {
				return IOManager::RCode::R_FAILED_FATAL_ERROR;
			}

			//get index value from uniquePoiInfoList
			int uniqIndex = roadNameMap[OIDNum];
			double x = uniquePoiInfoList->operator[](uniqIndex).x;
			double y = uniquePoiInfoList->operator[](uniqIndex).y;
			long poiInfoObjectID = uniquePoiInfoList->operator[](uniqIndex).OBJECTID;
			CString hn = uniquePoiInfoList->operator[](uniqIndex).houseNumber;
			if (IOManager::RCode::R_SUCCESS != cHnp->putValueIntoFields(poiInfoObjectID, hn, newOfficialOID.lVal, x, y)) {
				return IOManager::RCode::R_FAILED_FATAL_ERROR;
			}
			
			CComVariant newHnpOID;
			if (IOManager::RCode::R_SUCCESS != cHnp->insertNewFeature(&newHnpOID)) {
				return IOManager::RCode::R_FAILED_FATAL_ERROR;
			}

			//insert into updatedPoiHnpList map to create new records on HNP_ENTRYPOINT later
			if (!updatedPoiHnpList->insert(std::make_pair(uniquePoiInfoList->operator[](uniqIndex).OBJECTID, newHnpOID.intVal)).second) {
				IOManager::getInstance().print_error(IOManager::ECode::E_FAILED_TO_PROCESS, true, _T("Unexpected error occured while creating updatedPoiHnpList variable"));
				return IOManager::RCode::R_FAILED_FATAL_ERROR;
			}
			//insert into translationList map to create new records on TRANSLATION later
			if (!translationList->insert(std::make_pair(OIDNum, newOfficialOID.intVal)).second) {
				IOManager::getInstance().print_error(IOManager::ECode::E_FAILED_TO_PROCESS, true, tableName + _T(" OBJECTID"), OID, _T("Unexpected error occured while storing OFFICIAL_NAME data"));
				return IOManager::RCode::R_FAILED_FATAL_ERROR;
			}

			successUpdateCount++;
		}
		//flush to database every 10000 new records
		if (successUpdateCount % 10000 == 0 && successUpdateCount > 0) {
			if (IOManager::RCode::R_SUCCESS != flushAndStopEdit(workspace)) {
				return IOManager::RCode::R_FAILED_FATAL_ERROR;
			}
			if (IOManager::RCode::R_SUCCESS != cHnp->flushAndStopEdit(workspace)) {
				return IOManager::RCode::R_FAILED_FATAL_ERROR;
			}
		}
	}
	//flush last group of new records
	if (successUpdateCount % 10000 != 0 || successUpdateCount == 0) {
		if (IOManager::RCode::R_SUCCESS != flushAndStopEdit(workspace)) {
			return IOManager::RCode::R_FAILED_FATAL_ERROR;
		}
		if (IOManager::RCode::R_SUCCESS != cHnp->flushAndStopEdit(workspace)) {
			return IOManager::RCode::R_FAILED_FATAL_ERROR;
		}
	}
	//print total update count
	IOManager::getInstance().print_run(true, true, _T("Successfully updated HNP and OFFICIAL_NAME"));
	CString updateCount = std::to_string(successUpdateCount).c_str();
	IOManager::getInstance().print_run(true, true, _T("Total updated record : ") + updateCount);
	return IOManager::RCode::R_SUCCESS;
}

int OfficialName::putValueIntoFields(_IRowPtr& ipOfficialRow, const CString& OID) {
	for (int i = 0; i < ipTable->Fields->FieldCount; i++) {
		//ignore objectID
		if (i == m_objectIDIndex) {
			continue;
		}
		//get value on old record
		CComVariant tempValue;
		if (S_OK != ipOfficialRow->get_Value(i, &tempValue)) {
			CComBSTR columnName = "";
			//get field name to print description error
			if (S_OK != ipTable->Fields->GetField(i)->get_Name(&columnName)) {
				IOManager::getInstance().print_error(IOManager::ECode::E_FAILED_TO_GET_DATA, true, tableName + _T(" OBJECTID"), OID, _T("Failed to get field name and value"));
				return IOManager::RCode::R_FAILED_FATAL_ERROR;
			}
			//print error with field name
			CString msg = "Failed to get ";
			msg += columnName;
			msg += " value";
			IOManager::getInstance().print_error(IOManager::ECode::E_FAILED_TO_GET_DATA, true, tableName + _T(" OBJECTID"), OID, msg);
			return IOManager::RCode::R_FAILED_FATAL_ERROR;
		}
		//set layer_c = 34 value on new record
		if (i == m_layerCIndex) {
			if (S_OK != rowBuffer->put_Value(i, CComVariant(CommonData::getInstance().getHnpLayerC()))) {
				IOManager::getInstance().print_error(IOManager::ECode::E_FAILED_TO_GET_DATA, true, tableName + _T(" OBJECTID"), OID, _T("Failed to set LAYER_C field value"));
				return IOManager::RCode::R_FAILED_FATAL_ERROR;
			}
		}
		//operator = sindy
		else if (i == m_operatorIndex) {
			if (S_OK != rowBuffer->put_Value(i, CComVariant(CommonData::getInstance().getOperator()))) {
				IOManager::getInstance().print_error(IOManager::ECode::E_FAILED_TO_GET_DATA, true, tableName + _T(" OBJECTID"), OID, _T("Failed to set OPERATOR value"));
				return IOManager::RCode::R_FAILED_FATAL_ERROR;
			}
		}
		//updatetypeC = 6
		else if (i == m_updateTypeCIndex) {
			if (S_OK != rowBuffer->put_Value(i, CComVariant(CommonData::getInstance().getUpdateType()))) {
				IOManager::getInstance().print_error(IOManager::ECode::E_FAILED_TO_GET_DATA, true, tableName + _T(" OBJECTID"), OID, _T("Failed to set UPDATETYPE_C value"));
				return IOManager::RCode::R_FAILED_FATAL_ERROR;
			}
		}
		//prog modify date = now
		else if (i == m_progModifyDateIndex) {
			if (S_OK != rowBuffer->put_Value(i, CComVariant(CommonData::getInstance().getCurrentDateTime()))) {
				IOManager::getInstance().print_error(IOManager::ECode::E_FAILED_TO_GET_DATA, true, tableName + _T(" OBJECTID"), OID, _T("Failed to set PROGMODIFYDATE value"));
				return IOManager::RCode::R_FAILED_FATAL_ERROR;
			}
		}
		//modify prog name = "PoiInfoToHnpUpdater.exe"
		else if (i == m_modifyProgNameIndex) {
			if (S_OK != rowBuffer->put_Value(i, CComVariant(CommonData::getInstance().getModifyProgName()))) {
				IOManager::getInstance().print_error(IOManager::ECode::E_FAILED_TO_GET_DATA, true, tableName + _T(" OBJECTID"), OID, _T("Failed to set MODIFYPROGNAME value"));
				return IOManager::RCode::R_FAILED_FATAL_ERROR;
			}
		}
		//copy other value from POI_INFO's to HNP's on new record
		else {
			if (S_OK != rowBuffer->put_Value(i, CComVariant(tempValue))) {
				IOManager::getInstance().print_error(IOManager::ECode::E_FAILED_TO_GET_DATA, true, tableName + _T(" OBJECTID"), OID, _T("Failed to set field value"));
				return IOManager::RCode::R_FAILED_FATAL_ERROR;
			}
		}
	}
}

int OfficialName::createNewBuffer() {
	return table::createNewBuffer();
}

int OfficialName::insertNewRow(CComVariant * newHnpOID) {
	return table::insertNewRow(newHnpOID);
}

int OfficialName::startAndInsertCursor(IWorkspacePtr& workspace) {
	return table::startAndInsertCursor(workspace);
}

int OfficialName::flushAndStopEdit(IWorkspacePtr& workspace) {
	return table::flushAndStopEdit(workspace);
}