#pragma once

/**
* @brief Manage server connection and ARCGIS-related function.
*/
namespace AccessSV
{

	/**
	* @brief Get workspace pointer
	* @param workspaceName			[in]	workspace full name [ex. TEST2017@gaia(SDE.DEFAULT)]
	* @param ipWorkspace			[out]	IWorkspace variable
	* @return	IOManager::RCode
	*/
	int getWorkspace(const CString& workspaceName, IWorkspacePtr & ipWorkspace);
		
	/**
	* @brief Get featureClass pointer
	* @param workspaceName			[in]	workspace full name [ex. TEST2017@gaia(SDE.DEFAULT)]
	* @param featureClassName		[in]	featureclass full name [ex. TEST2017.ROAD_LINK]
	* @param ipFeatureClass			[out]	IFeatureClass variable
	* @return	IOManager::RCode
	*/
	int getFeatureClass (const CString& workspaceName,const CString& featureClassName, IFeatureClassPtr & ipFeatureClass);
	
	/**
	* @brief Get table pointer
	* @param workspaceName			[in]	workspace full name [ex. TEST2017@gaia(SDE.DEFAULT)]
	* @param tableName				[in]	table full name [ex. TEST2017.ALTERNATIVE_NAME]
	* @param ipTable				[out]	ITable variable
	* @return	IOManager::RCode
	*/
	int getTable(const CString& workspaceName, const CString& tablesName, ITablePtr & ipTable);
	
	/**
	* @brief Get field pointer
	* @param workspaceName			[in]	workspace full name [ex. TEST2017@gaia(SDE.DEFAULT)]
	* @param datasetName			[in]	target dataset name [ex. sindy::schema::example:kfeatureClassName, "ROAD_LINK", "ALTERNATIVE_NAME"]
	* @param fieldName				[in]	field name [ex. OBJECTID]
	* @param isTable				[in]	Is input dataset name table name or featureClass name
	* @param field					[out]	IField variable
	* @return	IOManager::RCode
	*/
	int getField(const CString& workspaceName, const CString& datasetName, const CString& fieldName, const bool& isTable, IFieldPtr & field);
	/**
	* @brief Get specific column index for featureclass
	* @param ipFeatureClass			[in]	target IFeatureClass variable
	* @param fieldName				[in]	target field name [ex. sindy::schema::example:kfeatureClassName::kfieldName, "OPERATOR"]
	* @param index					[out]	Field index
	* @return	IOManager::RCode
	*/
	int getFeatureClassColumnIndex(const IFeatureClassPtr& ipFeatureClass, const CComBSTR& fieldName, long * index);
	/**
	* @brief Get specific column index for table
	* @param ipTable				[in]	target ITablePtr variable
	* @param fieldName				[in]	target field name [ex. sindy::schema::example:kfeatureClassName::kfieldName, "OPERATOR"]
	* @param index					[out]	Field index
	* @return	IOManager::RCode
	*/
	int getTableColumnIndex(const ITablePtr& ipTable, const CComBSTR& fieldName, long * index);
	/**
	* @brief put value into specified field index on new record for featureClass
	* @param featureClassName		[in]	name of target featureClass
	* @param featureBuffer			[in]	buffer variable of feature
	* @param index					[in]	Field index
	* @param value					[in]	value to input into field of new record
	* @return	IOManager::RCode
	*/
	int putFeatureClassColumnValue(const CString& featureClassName, IFeatureBufferPtr featureBuffer, const long& index, CComVariant value);
	/**
	* @brief put value into specified field index on new record for table
	* @param tableName				[in]	name of target table
	* @param rowBuffer				[in]	buffer variable of row
	* @param index					[in]	Field index
	* @param value					[in]	value to input into field of new record
	* @return	IOManager::RCode
	*/
	int putTableColumnValue(const CString& tableName, IRowBufferPtr rowBuffer, const long& index, CComVariant value);

	/**
	* @brief   �o�[�W�����Ή����C��(featureClass)
	* @param   ipFeatureClass  [in] �t�B�[�`���N���X
	* @retval  true  �o�[�W�����Ή�
	* @retval  false �o�[�W������Ή�
	*/
	bool isVersionedFeatureClass( IFeatureClassPtr& ipFeatureClass);
	/**
	* @brief   �o�[�W�����Ή����C��(table)
	* @param   ipTable  [in] �e�[�u��
	* @retval  true  �o�[�W�����Ή�
	* @retval  false �o�[�W������Ή�
	*/
	bool isVersionedTable(ITablePtr& ipTable);

	/**
	* @brief   �ҏW�J�n
	* @param   ipWorkspace 	 [in] ���[�N�X�y�[�X
	* @param   ipFeatureClass  	[in] �t�B�[�`���N���X
	* @retval  true  ����
	* @retval  false ���s
	*/
	bool startEditFeatureClass(IWorkspacePtr& ipWorkspace, IFeatureClassPtr& ipFeatureClass);
	/**
	* @brief   �ҏW�J�n
	* @param   ipWorkspace 	 [in] ���[�N�X�y�[�X
	* @param   ipTable 		 [in] �e�[�u��
	* @retval  true  ����
	* @retval  false ���s
	*/
	bool startEditTable(IWorkspacePtr& ipWorkspace, ITablePtr& ipTable);
	/**
	* @brief   �ҏW�I��
	* @param   ipWorkspace 	 [in] ���[�N�X�y�[�X
	* @param   ipFeatureClass  	[in] �t�B�[�`���N���X
	* @retval  true  ����
	* @retval  false ���s
	*/
	bool stopEditFeatureClass(IWorkspacePtr& ipWorkspace, IFeatureClassPtr& ipFeatureClass);
	/**
	* @brief   �ҏW�J�n
	* @param   ipWorkspace 	 [in] ���[�N�X�y�[�X
	* @param   ipTable 		 [in] �e�[�u��
	* @retval  true  ����
	* @retval  false ���s
	*/
	bool stopEditTable(IWorkspacePtr& ipWorkspace, ITablePtr& ipTable);
	/**
	* @brief   �ҏW�j��
	* @param   ipWorkspace 	 [in] ���[�N�X�y�[�X
	*/
	void abortEdit(IWorkspacePtr& ipWorkspace);

};