#include "stdafx.h"
#include "PoiInfo.h"

using namespace sindy::schema::global;

PoiInfo::PoiInfo(const CString& poiInfoFeatureClassName, IFeatureClassPtr& poiInfoFeatureClass) {
	featureClassName = poiInfoFeatureClassName;
	ipFeatureClass = poiInfoFeatureClass;

	//get field index value
	AccessSV::getFeatureClassColumnIndex(ipFeatureClass, poi_info::kOperator, &m_operatorIndex);
	AccessSV::getFeatureClassColumnIndex(ipFeatureClass, poi_info::kPurpose, &m_purposeCIndex);
	AccessSV::getFeatureClassColumnIndex(ipFeatureClass, poi_info::kModifyDate, &m_modifyDateIndex);
	AccessSV::getFeatureClassColumnIndex(ipFeatureClass, poi_info::kUpdateType, &m_updateTypeCIndex);
	AccessSV::getFeatureClassColumnIndex(ipFeatureClass, poi_info::kProgModifyDate, &m_progModifyDateIndex);
	AccessSV::getFeatureClassColumnIndex(ipFeatureClass, poi_info::kModifyProgName, &m_modifyProgNameIndex);
	AccessSV::getFeatureClassColumnIndex(ipFeatureClass, poi_info::kUserClaim, &m_userClaimFIndex);
	AccessSV::getFeatureClassColumnIndex(ipFeatureClass, poi_info::kSource, &m_sourceIndex);
	AccessSV::getFeatureClassColumnIndex(ipFeatureClass, poi_info::kRoadNameID, &m_roadNameIDIndex);
	AccessSV::getFeatureClassColumnIndex(ipFeatureClass, poi_info::kHouseNumber, &m_houseNumberIndex);
	AccessSV::getFeatureClassColumnIndex(ipFeatureClass, poi_info::kActualAddress, &m_actualAddressIndex);
}

PoiInfo::~PoiInfo() {
}

int PoiInfo::presetPoiInfoFeatureCursor(const CComBSTR & queryFilter, IFeatureCursorPtr& ipPoiInfoCursor) {
	//create condition to get specified columns
	IQueryFilterPtr PoiInfoIpQueryFilter(CLSID_QueryFilter);
	CString columnFilter;
	columnFilter.Format(_T("%s,%s,%s,%s,%s"), poi_info::kObjectID, poi_info::kHouseNumber, poi_info::kRoadNameID, poi_info::kActualAddress, poi_info::kShape);
	if (S_OK != PoiInfoIpQueryFilter->put_SubFields((CComBSTR)columnFilter)) {
		IOManager::getInstance().print_error(IOManager::ECode::E_FAILED_TO_SET_DATA, true, featureClassName, _T(""), _T("Failed to set search columns"));
		return IOManager::RCode::R_FAILED_FATAL_ERROR;
	}
	//search only records with user input condition
	if (S_OK != PoiInfoIpQueryFilter->put_WhereClause(queryFilter)) {
		IOManager::getInstance().print_error(IOManager::ECode::E_FAILED_TO_SET_DATA, true, featureClassName, _T(""), _T("Failed to set search query"));
		return IOManager::RCode::R_FAILED_FATAL_ERROR;
	}
	IQueryFilterDefinitionPtr queryFilterDefinition = (IQueryFilterDefinitionPtr)PoiInfoIpQueryFilter;
	queryFilterDefinition->put_PostfixClause(_T("ORDER BY HOUSENUMBER, ACTUALADDRESS, OBJECTID"));
	if (S_OK != ipFeatureClass->Search(PoiInfoIpQueryFilter, VARIANT_FALSE, &ipPoiInfoCursor)) {
		IOManager::getInstance().print_error(IOManager::ECode::E_FAILED_TO_GET_DATA, true, featureClassName, _T(""), _T("Failed to get all records"));
		return IOManager::RCode::R_FAILED_FATAL_ERROR;
	}
	return IOManager::RCode::R_SUCCESS;
}

int PoiInfo::getUniquePoiInfoID(const CComBSTR & queryFilter, std::wstring bufferSize, std::set<long> * childPOIList, std::set<long> * PoiInfoList, std::map<long, CString> * officialNameList, std::vector<poiInfo> * uniquePoiInfoList) {
	IFeatureCursorPtr ipPoiInfoCursor;
	if (S_OK != presetPoiInfoFeatureCursor(queryFilter, ipPoiInfoCursor)) {
		return IOManager::RCode::R_FAILED_FATAL_ERROR;
	}

	//vector to store all POI_INFO details (OBJECTID, HN, ACTUALADDRESS, ROADNAMEID, Coordinates)
	std::vector<poiInfo> poiInfoList;

	//get all details about POI_INFO
	IFeaturePtr ipPoiInfoFeature;
	while (ipPoiInfoCursor->NextFeature(&ipPoiInfoFeature) == S_OK && ipPoiInfoFeature) {
		// get postal point OID
		long OIDNum;
		if (S_OK != ipPoiInfoFeature->get_OID(&OIDNum)) {
			IOManager::getInstance().print_error(IOManager::ECode::E_FAILED_TO_GET_DATA, true, featureClassName, _T(""), _T("Failed to get OBJECTID of one ") + featureClassName);
			return IOManager::RCode::R_FAILED_FATAL_ERROR;
		}
		//if this record is child POI, skip
		if (childPOIList->find(OIDNum) != childPOIList->end()) {
			continue;
		}
		//convert OID from long to CString
		CString OID;
		OID.Format(L"%ld", OIDNum);
		// get actualaddress data
		CComVariant actualAddress;
		if (S_OK != ipPoiInfoFeature->get_Value(m_actualAddressIndex, &actualAddress)) {
			IOManager::getInstance().print_error(IOManager::ECode::E_FAILED_TO_GET_DATA, true, featureClassName + _T(" OBJECTID"), OID, _T("Failed to get ACTUALADDRESS value"));
			return IOManager::RCode::R_FAILED_FATAL_ERROR;
		}
		CString convertedActualAddress = actualAddress.bstrVal;
		convertedActualAddress = convertedActualAddress.Trim();
		// get house number data
		CComVariant houseNumber;
		if (S_OK != ipPoiInfoFeature->get_Value(m_houseNumberIndex, &houseNumber)) {
			IOManager::getInstance().print_error(IOManager::ECode::E_FAILED_TO_GET_DATA, true, featureClassName + _T(" OBJECTID"), OID, _T("Failed to get HOUSENUMBER value"));
			return IOManager::RCode::R_FAILED_FATAL_ERROR;
		}
		CString convertedHouseNumber = houseNumber.bstrVal;
		convertedHouseNumber = convertedHouseNumber.Trim();
		// get road name ID data
		CComVariant roadNameID;
		if (S_OK != ipPoiInfoFeature->get_Value(m_roadNameIDIndex, &roadNameID)) {
			IOManager::getInstance().print_error(IOManager::ECode::E_FAILED_TO_GET_DATA, true, featureClassName + _T(" OBJECTID"), OID, _T("Failed to get ROADNAMEID value"));
			return IOManager::RCode::R_FAILED_FATAL_ERROR;
		}
		long convertedRoadNameID = roadNameID.lVal;
		// get shape
		IGeometryPtr ipPoiGeom = CommonData::getInstance().getExamplePointShape();
		if (S_OK != ipPoiInfoFeature->get_ShapeCopy(&ipPoiGeom)) {
			IOManager::getInstance().print_error(IOManager::ECode::E_FAILED_TO_GET_DATA, true, featureClassName + _T(" OBJECTID"), OID, _T("Failed to get shape"));
			return IOManager::RCode::R_FAILED_FATAL_ERROR;
		}
		// get PP coordinates
		double orgX = 0.0, orgY = 0.0;
		if (S_OK != IPointPtr(ipPoiGeom)->QueryCoords(&orgX, &orgY) || orgX == 0 || orgY == 0) {
			IOManager::getInstance().print_error(IOManager::ECode::E_FAILED_TO_GET_DATA, true, featureClassName + _T(" OBJECTID"), OID, _T("Failed to get shape's coordinates"));
			return IOManager::RCode::R_FAILED_FATAL_ERROR;
		}

		//detect complex condition, (HN must always equal)
		int indexToDelete = -1;
		bool isIgnoreThisRecord = false;
		//compare using actual address
		if (convertedActualAddress != "") {
			for (int i = poiInfoList.size() - 1; i >= 0; i--) {
				//if actual address is equal, skip comparing
				if (!convertedActualAddress.Compare(poiInfoList[i].actualAddress)) {
					break;
				}
				//compare housenumber and actual address
				else if ((!convertedHouseNumber.Compare(poiInfoList[i].houseNumber)) && (!convertedActualAddress.Compare(poiInfoList[i].actualAddress))) {
					//if this one has entrypoint data but the old one not
					if (PoiInfoList->find(OIDNum) != PoiInfoList->end() && PoiInfoList->find(poiInfoList[i].OBJECTID) == PoiInfoList->end()) {
						indexToDelete = i;
						break;
					}
					else {
						isIgnoreThisRecord = true;
						break;
					}
				}
			}
		}
		//compare using road name ID
		if (!isIgnoreThisRecord && indexToDelete == -1 && convertedRoadNameID != 0) {
			for (int i = poiInfoList.size() - 1; i >= 0; i--) {
				if (!convertedHouseNumber.Compare(poiInfoList[i].houseNumber)) {
					break;
				}
				else if (poiInfoList[i].roadNameID == 0) {
					continue;
				}
				//compare road name
				CString thisRoadNameID = officialNameList->operator[](convertedRoadNameID);
				CString previousRoadNameID = officialNameList->operator[](poiInfoList[i].roadNameID);
				if (!thisRoadNameID.Compare(previousRoadNameID)) {
					//if this one has entrypoint data but the old one not
					if (PoiInfoList->find(OIDNum) != PoiInfoList->end() && PoiInfoList->find(poiInfoList[i].OBJECTID) == PoiInfoList->end()) {
						indexToDelete = i;
						break;
					}
					else {
						isIgnoreThisRecord = true;
						break;
					}
				}

			}
		}
		if (!isIgnoreThisRecord && indexToDelete == -1) {
			for (int i = poiInfoList.size() - 1; i >= 0; i--) {
				if (!convertedHouseNumber.Compare(poiInfoList[i].houseNumber)) {
					break;
				}
				//compare distance using our x y
				else if (GetDist(orgX, orgY, poiInfoList[i].x, poiInfoList[i].y) < std::stoi(bufferSize)) {
					//if this one has entrypoint data but the old one not
					if (PoiInfoList->find(OIDNum) != PoiInfoList->end() && PoiInfoList->find(poiInfoList[i].OBJECTID) == PoiInfoList->end()) {
						indexToDelete = i;
						break;
					}
					else {
						isIgnoreThisRecord = true;
						break;
					}
				}
			}
		}

		//skip this record
		if (isIgnoreThisRecord) {
			continue;
		}
		//delete old and add new one into target list
		if (indexToDelete != -1) {
			poiInfoList.erase(poiInfoList.begin() + indexToDelete);
			poiInfoList.push_back(poiInfo(OIDNum, convertedHouseNumber, convertedActualAddress, convertedRoadNameID, orgX, orgY));
			continue;
		}
		//simply add new one
		else {
			poiInfoList.push_back(poiInfo(OIDNum, convertedHouseNumber, convertedActualAddress, convertedRoadNameID, orgX, orgY));
		}
	}
	//store target ID into uniquePoiInfoID
	uniquePoiInfoList->assign(poiInfoList.begin(), poiInfoList.end());
	return IOManager::RCode::R_SUCCESS;
}

double	PoiInfo::
GetDist(double		eLon1,
	double		eLat1,
	double		eLon2,
	double		eLat2)
{
	double		aFaiRad;
	double		aDeltaX;
	double		aDeltaY;
	double		aSinVal;
	double		aCosVal;
	double		D;
	double		M;
	double		N;
	double		aDistX;
	double		aDistY;

	aFaiRad = (eLat2 + eLat1) * M_PI / 180.0 / 2.0;
	aDeltaX = (eLon2 - eLon1) * M_PI / 180.0;
	aDeltaY = (eLat2 - eLat1) * M_PI / 180.0;

	aSinVal = sin(aFaiRad);
	aCosVal = cos(aFaiRad);

	D = 1.0 - 0.00669437999019758 * aSinVal * aSinVal;
	M = 6334834.0 / sqrt(D * D * D);
	N = 6377397.0 / sqrt(D);

	aDistY = M * aDeltaY;
	aDistX = N * aCosVal * aDeltaX;

	return sqrt(aDistX * aDistX + aDistY * aDistY);
}