#pragma once
#include "AccessSV.h"
#include "ErrorManager.h"
#include "IOManager.h"
#include "DataManager.h"
#include <crd_cnv/crd_cnv.h>


/**
* @brief	Get all SiNDY-related data using SiNDY libraries and send to C# to compare the data 
*/

class DBComparer
{
public:
	AccessSV * m_accessSV;
	ErrorManager *  m_errorManager;
	IOManager * m_IOManager;
	DataManager * m_dataManager;
	crd_cnv * m_crd_cnv;

	DBComparer();
	~DBComparer();
	/**
	* @brief Set all management class
	* @param arg				[in]	Target management class object
	*/
	void setIOManager(IOManager * _IOManager);
	void setSVManager(AccessSV * _accessSV);
	void setErrorManager(ErrorManager * _errorManager);
	void setDataManager(DataManager * _dataManager);
	/**
	* @brief initialize projected coordinate system value.
	* @return	0 is success, 1 if fail
	*/
	void initProjectedCS();
	/**
	* @brief initialize all input and output such as log files before start ArcGIS-related process
	* @return	0 is success, 1 if fail
	*/
	int init();
	/**
	* @brief Print fix messsage when the tool ends successfully
	* @return	RCode value [ex�FR_SUCCESS=0�AR_FAILED_FATAL_ERROR=1�A...]
	*/
	int printSuccessfulEnd();
	/**
	* @brief when error occured, print error details and ends program
	* @param errorPoint			[in]	String that describe the place when an error occured
	* @return	RCode value [ex�FR_SUCCESS=0�AR_FAILED_FATAL_ERROR=1�A...]
	*/
	int endProgramWithError(const CString errorPoint);
	/**
	* @brief Connect to target SiNDY userDB 
	* @param DBname				[in]	target DB server name [ex. sindympa]
	* @param username			[in]	target DB owner name [ex. TEST2017A]
	* @param versionName		[in]	target DB server name [ex. SDE.DEFAULT]
	* @return	RCode value [ex�FR_SUCCESS=0�AR_FAILED_FATAL_ERROR=1�A...]
	*/
	int connectToDB(const CString DBname, const CString username, const CString versionName);
	/**
	* @brief get target featureclass's dataset name
	* @param DBname				[in]	target DB server name [ex. sindympa]
	* @param username			[in]	target DB owner name [ex. TEST2017A]
	* @param versionName		[in]	target DB server name [ex. SDE.DEFAULT]
	* @param featureClassName	[in]	target featureClass name [ex. sindy::schema::example:kfeatureClassName, "ROAD_LINK"]
	* @return	dataset name
	*/
	CString getFeatureClassDataSetName(const CString DBname, const CString username, const CString versionName, const CString featureClassName);
	/**
	* @brief get target SiNDY userDB's all featureClass names and their total record numbers
	* @param DBname				[in]	target DB server name [ex. sindympa]
	* @param username			[in]	target DB owner name [ex. TEST2017A]
	* @param versionName		[in]	target DB server name [ex. SDE.DEFAULT]
	* @return	list of featureClass details ["name1","total count1","name2","total count2",...]
	* @return	list that only contains -1 if the process failed
	*/
	std::vector<CString> getFeatureClassAndCount(const CString DBname, const CString username, const CString versionName);
	/**
	* @brief get target SiNDY userDB's all ftable names and their total record numbers
	* @param DBname				[in]	target DB server name [ex. sindympa]
	* @param username			[in]	target DB owner name [ex. TEST2017A]
	* @param versionName		[in]	target DB server name [ex. SDE.DEFAULT]
	* @return	list of table details ["name1","total count1","name2","total count2",...]
	* @return	list that only contains -1 if the process failed
	*/
	std::vector<CString> getTableAndCount(const CString DBname, const CString username, const CString versionName);
	/**
	* @brief get target featureClass's all field name 
	* @param DBname				[in]	target DB server name [ex. sindympa]
	* @param username			[in]	target DB owner name [ex. TEST2017A]
	* @param versionName		[in]	target DB server name [ex. SDE.DEFAULT]
	* @param datasetName		[in]	target dataset name [ex. sindy::schema::example:kfeatureClassName, "ROAD_LINK", "ALTERNATIVE_NAME"]
	* @param isTable			[in]	Is input dataset name table name or featureClass name
	* @return	list of field name ["name1","name2","name3",...]
	*/
	std::vector<CString> getfieldNameList(const CString DBname, const CString username, const CString versionName, const CString datasetName, const bool isTable);
	/**
	* @brief Check if target field contains a domain
	* @param DBname				[in]	target DB server name [ex. sindympa]
	* @param username			[in]	target DB owner name [ex. TEST2017A]
	* @param versionName		[in]	target DB server name [ex. SDE.DEFAULT]
	* @param datasetName		[in]	target dataset name [ex. sindy::schema::example:kfeatureClassName, "ROAD_LINK", "ALTERNATIVE_NAME"]
	* @param fieldName			[in]	target field name [ex. OBJECTID]
	* @param isTable			[in]	Is input dataset name table name or featureClass name
	* @return	true if exist, false if not
	*/
	bool hasDomain(const CString DBname, const CString username, const CString versionName, const CString datasetName, const CString fieldName, const bool isTable);
	/**
	* @brief get target field's domain name and its codes
	* @param DBname				[in]	target DB server name [ex. sindympa]
	* @param username			[in]	target DB owner name [ex. TEST2017A]
	* @param versionName		[in]	target DB server name [ex. SDE.DEFAULT]
	* @param datasetName		[in]	target dataset name [ex. sindy::schema::example:kfeatureClassName, "ROAD_LINK", "ALTERNATIVE_NAME"]
	* @param fieldName			[in]	target field name [ex. OBJECTID]
	* @param isTable			[in]	Is input dataset name table name or featureClass name
	* @return	domain name and list of code value and code name ["domain name","code value 1","code name 1","code value 2","code name 2",...]
	*/
	std::vector<CString> getDomainNameList(const CString DBname, const CString username, const CString versionName, const CString datasetName, const CString fieldName, const bool isTable);
	/**
	* @brief test SQL text for where clause whether it has correct format, variable or not 
	* @param SQLText			[in]	SQL text to test [ex. 'OBJECTID > 10']
	* @param DBname				[in]	target DB server name [ex. sindympa]
	* @param username			[in]	target DB owner name [ex. TEST2017A]
	* @param versionName		[in]	target DB server name [ex. SDE.DEFAULT]
	* @param datasetName		[in]	target dataset name [ex. sindy::schema::example:kfeatureClassName, "ROAD_LINK", "ALTERNATIVE_NAME"]
	* @param isTable			[in]	Is input dataset name table name or featureClass name
	* @return	true if correct, false if not
	*/
	bool checkSQLSyntax(const CString SQLText, const CString DBname, const CString username, const CString versionName, const CString datasetName, const bool isTable);
	/**
	* @brief get record number from target featureClass with specific where clause SQL text
	* @param SQLText			[in]	SQL text to test [ex. 'OBJECTID > 10']
	* @param DBname				[in]	target DB server name [ex. sindympa]
	* @param username			[in]	target DB owner name [ex. TEST2017A]
	* @param versionName		[in]	target DB server name [ex. SDE.DEFAULT]
	* @param datasetName		[in]	target dataset name [ex. sindy::schema::example:kfeatureClassName, "ROAD_LINK", "ALTERNATIVE_NAME"]
	* @param isTable			[in]	Is input dataset name table name or featureClass name
	* @return	total distance or area, depending on type of data
	*/
	long getRecordNumber(const CString SQLText, const CString DBname, const CString username, const CString versionName, const CString datasetName, const bool isTable);
	/**
	* @brief get total distance or area from target featureClass with specific where clause SQL text
	* @param SQLText			[in]	SQL text to test [ex. 'OBJECTID > 10']
	* @param DBname				[in]	target DB server name [ex. sindympa]
	* @param username			[in]	target DB owner name [ex. TEST2017A]
	* @param versionName		[in]	target DB server name [ex. SDE.DEFAULT]
	* @param featureClassName	[in]	target featureClass name [ex. sindy::schema::example:kfeatureClassName, "ROAD_LINK"]
	* @return	total distance or area, depending on type of data
	*/
	double getTotalDistArea(const CString SQLText, const CString DBname, const CString username, const CString versionName, const CString featureClassName);
	/**
	* @brief get area from input shape
	* @param ipFeature			[in]	target record
	* @return	value of area
	*/
	double getArea(IFeaturePtr & ipFeature);
	/**
	* @brief get distance from input shape
	* @param ipFeature			[in]	target record
	* @return	value of distance
	*/
	double getDist(IFeaturePtr & ipFeature);
	/**
	* @brief get distance from each line from Ipolyline
	* @param eLon1			[in]	longtitude 1
	* @param eLat1			[in]	latitude 1
	* @param eLon2			[in]	longtitude 2
	* @param eLat2			[in]	latitude 2
	* @return	value of distance
	*/
	double GetEachLineDistance(double eLon1, double eLat1, double eLon2, double eLat2);
	/**
	* @brief get most accurate spatial reference depending on country name
	* @param x			[in]	x coordinate
	* @param y			[in]	y coordinate
	* @return	spatial reference in EPSG value
	*/
	IProjectedCoordinateSystemPtr getCoordinateSystem(const double x, const double y);

private:
	static const int is_success = ErrorManager::RCode::R_SUCCESS;
	IProjectedCoordinateSystemPtr m_46N, m_47N, m_48N, m_49N, m_50N, m_51N, m_52N, m_53N, m_54N;
	IProjectedCoordinateSystemPtr m_46S, m_47S, m_48S, m_49S, m_50S, m_51S, m_52S, m_53S, m_54S;
};