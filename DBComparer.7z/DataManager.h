#pragma once
/**
* @brief	Manage data and act as middleman between server, file, and core process who store all necessary data.
			All datas are stored in m_***list and require key to get correspond data
			For example, m_DBList["ROAD_LINK_DB"] will take "ROAD_LINK_DB" as a key and find DBDesc struct that link to the key.
			You can set key value to your own convenience by input keyName when using setNew***() function.
*/

class DataManager
{
public:

	IOManager * m_IOCtrl;				//Control IO
	AccessSV * m_AccSV;					//Control Server Access

	DataManager();
	~DataManager();
	//File Structure
	struct fileDesc {
		fileDesc() :fileName(""), fileType(IOManager::FileType::UNDEFINED) {}
		fileDesc(CString fileName, IOManager::FileType fileType):
			fileName(fileName), 
			fileType(fileType) {}
		CString fileName;					//ex.  C:/HAHA/THISWAY.txt
		IOManager::FileType fileType;		//ex.  ERR,RUN,OUT
	};
	//DB Structure
	struct DBDesc {
		DBDesc() :serverName(""), ownerName(""), versionName(""), fullDBName(""), workspace(NULL) {}
		DBDesc(CString serverName, CString ownerName, CString versionName, CString fullDBName, IWorkspacePtr workspace):
			serverName(serverName),
			ownerName(ownerName),
			versionName(versionName),
			fullDBName(fullDBName),
			workspace(workspace) {}
		CString serverName;					//ex.  yakumo, arion
		CString ownerName;					//ex.  REFERENCE,THA201701
		CString versionName;				//ex.  SDE.DEFAULT
		CString fullDBName;					//ex.  RONLY@yakumo(SDE.DEFAULT)
		IWorkspacePtr workspace;			//variable to access data
	};
	//Featureclass Structure
	struct featureClassDesc {
		featureClassDesc() : serverKeyName(""), featureClassName(""), ownerName(""), fullFeatureClassName(""), datasetName(""), featureClass(NULL) {}
		featureClassDesc(CString serverKeyName, CString featureClassName, CString ownerName, CString fullFeatureClassName, CString datasetName, IFeatureClassPtr featureClass):
			serverKeyName(serverKeyName), 
			featureClassName(featureClassName), 
			ownerName(ownerName), 
			fullFeatureClassName(fullFeatureClassName), 
			datasetName(datasetName), 
			featureClass(featureClass) {}
		CString serverKeyName;			//ex.  --'inputPP'
		CString featureClassName;			//ex.  sindy::schema::citymesh::kfeatureClassName
		CString ownerName;					//ex.  REFERENCE,THA201701
		CString fullFeatureClassName;		//ex.  REFRENCE.MESHCITY
		CString datasetName;				//ex.  ADDR
		IFeatureClassPtr featureClass;		//variable to access data
	};
	//Table Structure
	struct tableDesc {
		tableDesc() : serverKeyName(""), tableName(""), ownerName(""), fullTableName(""), table(NULL) {}
		tableDesc(CString serverKeyName, CString tableName, CString ownerName, CString fullTableName, ITablePtr table) :
			serverKeyName(serverKeyName),
			tableName(tableName),
			ownerName(ownerName),
			fullTableName(fullTableName),
			table(table) {}
		CString serverKeyName;		//ex.  --'inputPP'
		CString tableName;					//ex.  ALTERNATIVE_NAME
		CString ownerName;					//ex.  REFERENCE,THA201701
		CString fullTableName;				//ex.  REFRENCE.MESHCITY
		ITablePtr table;					//variable to access data
	};
	//Field structure
	struct fieldDesc {
		fieldDesc() :datasetKeyName(""), fieldName(""), isDatasetTable(false), field(NULL) {}
		fieldDesc(CString datasetKeyName, CString fieldName, bool isDatasetTable, IFieldPtr field):
			datasetKeyName(datasetKeyName),
			fieldName(fieldName),
			isDatasetTable(isDatasetTable),
			field(field) {}
		CString datasetKeyName;	//ex. --'layerPP'
		CString fieldName;					//ex. OBJECTID
		bool isDatasetTable;				//Check whether a dataset that contains this field is table or not.
		IFieldPtr field;					//variable to access data
	};
	/**
	* @brief Set output management class
	* @param IOCtrl				[in]	Target IOManager class object
	*/
	void setLogger(IOManager * IOCtrl);
	/**
	* @brief Set server management class
	* @param AccSV				[in]	Target AccessSV class object
	*/
	void setAccSV(AccessSV * AccSV);
	/**
	* @brief Add new file into fileList for creation
	* @param keyName			[in]	Key name for calling a file data with m_fileList[keyName]
	* @param fileName			[in]	target file name aka file path
	* @param fileType			[in]	File type[ERR,RUN,OUT]
	*/
	void setNewFile(const CString keyName, const CString fileName, const IOManager::FileType fileType);
	/**
	* @brief Add new DB into DBList for creation
	* @param keyName			[in]	Key name for calling a DB data with m_DBList[keyName]
	* @param serverName			[in]	full SiNDY username [ex. TEST2017A@sindympa(SDE.DEFAULT)]
	* @param isFGDB				[in]	Is the target DB is FGDB
	* @param doEdit				[in]	If target db need to be edited
	*/
	void setNewDB(const CString keyName, const CString serverName, const bool isFGDB, const bool doEdit);
	/**
	* @brief Add new Database. Username, DB, version input are separate
	* @param keyName			[in]	Key name for calling a DB data with m_DBList[keyName]
	* @param serverName			[in]	target DB server name [ex. sindympa]
	* @param ownerName			[in]	target DB owner name [ex. TEST2017A]
	* @param versionName		[in]	target DB server name [ex. SDE.DEFAULT]
	* @param isFGDB				[in]	Is the target DB is FGDB
	* @param doEdit				[in]	If target db need to be edited
	*/
	void setNewDB_divideUserDBVersion(const CString keyName, const CString serverName, const CString ownerName, const CString versionName, const bool isFGDB, const bool doEdit);
	/**
	* @brief Add new featureclass for creation 
	* @param keyName			[in]	Key name for calling a featureclass data with m_featureClassList[keyName]
	* @param featureClassName	[in]	target featureClass name [ex. sindy::schema::example:kfeatureClassName, "ROAD_LINK"]
	* @param isFGDB				[in]	Is the target DB is FGDB
	*/
	void setNewFeatureClass(const CString serverKeyName, const CString keyName, const CString serverName, const CString featureClassName, const bool isFGDB);
	/**
	* @brief Add new featureclass. Username, DB, version input are separate
	* @param keyName			[in]	Key name for calling a featureclass data with m_featureClassList[keyName]
	* @param ownerName			[in]	target DB owner name [ex. TEST2017A]
	* @param featureClassName	[in]	target featureClass name [ex. sindy::schema::example:kfeatureClassName, "ROAD_LINK"]
	* @param isFGDB				[in]	Is the target DB is FGDB
	*/
	void setNewFeatureClass_divideUserDBVersion(const CString serverKeyName, const CString keyName, const CString ownerName, const CString featureClassName, const bool isFGDB);
	/**
	* @brief Add new table for creation
	* @param keyName			[in]	Key name for calling a featureclass data with m_featureClassList[keyName]
	* @param tableName			[in]	target table name [ex. ALTERNATIVE_NAME]
	* @param isFGDB				[in]	Is the target DB is FGDB
	*/
	void setNewTable(const CString serverKeyName, const CString keyName, const CString serverName, const CString tableName, const bool isFGDB);
	/**
	* @brief Add new featureclass. Username, DB, version input are separate
	* @param keyName			[in]	Key name for calling a featureclass data with m_featureClassList[keyName]
	* @param ownerName			[in]	target DB owner name [ex. TEST2017A]
	* @param tableName			[in]	target table name [ex. ALTERNATIVE_NAME]
	* @param isFGDB				[in]	Is the target DB is FGDB
	*/
	void setNewTable_divideUserDBVersion(const CString serverKeyName, const CString keyName, const CString ownerName, const CString tableName, const bool isFGDB);
	/**
	* @brief Add new field name for usage 
	* @param datasetKeyName			[in]	Key name for calling a dataset data
	* @param keyName			[in]	Key name for calling a field data with m_fieldList[keyName]
	* @param fieldName			[in]	target field Name [ex. POSTAL_CODE, OBJECTID]
	* @param isTable			[in]	Is input dataset name table name or featureClass name
	*/
	void DataManager::setNewField(const CString datasetKeyName, const CString keyName, const CString fieldName, const bool isTable);
	/**
	* @brief Create all files that have been set from 'setNewFile' function
	* @return	RCode value [ex�FR_SUCCESS=0�AR_FAILED_FATAL_ERROR=1�A...]
	*/
	int createFiles();
	/**
	* @brief Initialize all DBs that have been set from 'setNewDB' and 'setNewDB_divideUserDBVersion' function
	* @return	RCode value [ex�FR_SUCCESS=0�AR_FAILED_FATAL_ERROR=1�A...]
	*/
	int initDBs();
	/**
	* @brief Initialize a selected DB that has been set from 'setNewDB' and 'setNewDB_divideUserDBVersion' function
	* @param keyName			[in]	Key name for calling a DB data with m_DBList[keyName]
	* @return	RCode value [ex�FR_SUCCESS=0�AR_FAILED_FATAL_ERROR=1�A...]
	*/
	int initDB(const CString keyName);
	/**
	* @brief Initialize all featureclasses that have been set from 'setNewFeatureClass' and 'setNewFeatureClass_divideUserDBVersion' function
	* @return	RCode value [ex�FR_SUCCESS=0�AR_FAILED_FATAL_ERROR=1�A...]
	*/
	int initFeatureClasses();
	/**
	* @brief Initialize a selected featureclass that has been set from 'setNewFeatureClass' and 'setNewFeatureClass_divideUserDBVersion' function
	* @param keyName			[in]	Key name for calling a featureclass data with m_featureClassList[keyName]
	* @return	RCode value [ex�FR_SUCCESS=0�AR_FAILED_FATAL_ERROR=1�A...]
	*/
	int initFeatureClass(const CString keyName);
	/**
	* @brief Initialize all table that have been set from 'setNewTable' and 'setNewTable_divideUserDBVersion' function
	* @return	RCode value [ex�FR_SUCCESS=0�AR_FAILED_FATAL_ERROR=1�A...]
	*/
	int initTables();
	/**
	* @brief Initialize a selected table that has been set from 'setNewTable' and 'setNewTable_divideUserDBVersion' function
	* @param keyName			[in]	Key name for calling a table data with m_tableList[keyName]
	* @return	RCode value [ex�FR_SUCCESS=0�AR_FAILED_FATAL_ERROR=1�A...]
	*/
	int initTable(const CString keyName);
	/**
	* @brief Initialize all fields that have been set from 'setNewField' function
	* @return	RCode value [ex�FR_SUCCESS=0�AR_FAILED_FATAL_ERROR=1�A...]
	*/
	int initFields();
	/**
	* @brief Initialize all fields that have been set from 'setNewField' function
	* @param keyName			[in]	Key name for calling a field data with m_fieldList[keyName]
	* @return	RCode value [ex�FR_SUCCESS=0�AR_FAILED_FATAL_ERROR=1�A...]
	*/
	int initField(const CString keyName);
	/**
	* @brief Get DB list
	* @return	List of DB
	*/
	std::map<CString, DBDesc> getDBList();
	/**
	* @brief Get a DB
	* @param keyName			[in]	Key name for calling a DB data with m_DBList[keyName]
	* @return	A DB
	*/
	DBDesc getDB(const CString keyName);
	/**
	* @brief Get featureclass list
	* @return	List of featureclass
	*/
	std::map<CString, featureClassDesc> getFeatureClassList();
	/**
	* @brief Get a featureClass
	* @param keyName			[in]	Key name for calling a featureclass data with m_featureClassList[keyName]
	* @return	A featureClass
	*/
	featureClassDesc getFeatureClass(const CString keyName);
	/**
	* @brief Get table list
	* @return	List of table
	*/
	std::map<CString, tableDesc> getTableList();
	/**
	* @brief Get a table
	* @param keyName			[in]	Key name for calling a table data with m_TableList[keyName]
	* @return	A table
	*/
	tableDesc getTable(const CString keyName);
	/**
	* @brief Get field list
	* @return	List of field
	*/
	std::map<CString, fieldDesc> getFieldList();
	/**
	* @brief Get a field
	* @param keyName			[in]	Key name for calling a field data with m_fieldList[keyName]
	* @return	A field
	*/
	fieldDesc getField(const CString keyName);


	
private:
	std::map<CString, DBDesc> m_DBList;			//Store all set DB list
	std::map<CString, fileDesc> m_fileList;		//Store all set file list
	std::map<CString, featureClassDesc> m_featureClassList;	//Store all set featureClass list
	std::map<CString, tableDesc> m_tableList;	//Store all set table list
	std::map<CString, fieldDesc> m_fieldList;	//Store all set field name such as ACTUALADDRESS, POSTAL_CODE 
	static const int HAS_ERROR = 1;
};