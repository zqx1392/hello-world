#pragma once
#include "stdafx.h"
#include "AccessSV.h"
#include "ErrorManager.h"
#include "IOManager.h"
#include "DataManager.h"
#include <conio.h>

DataManager::DataManager() {
}

DataManager::~DataManager() {
}

void DataManager::setLogger(IOManager * IOCtrl) {
	m_IOCtrl = IOCtrl;
}
void DataManager::setAccSV(AccessSV * AccSV) {
	m_AccSV = AccSV;
}

void DataManager::setNewFile(const CString keyName, const CString fileName,const IOManager::FileType fileType) {
	CString convertedFileName = fileName;
	if (fileName == L"") {
		if (fileType == IOManager::FileType::ERR) {
			convertedFileName = L"err.log";
		}
		else if (fileType == IOManager::FileType::RUN) {
			convertedFileName = L"run.log";
		}
		else if (fileType == IOManager::FileType::OUTPUT) {
			convertedFileName = L"out.log";
		}
	}
	fileDesc tempFileDesc (convertedFileName,fileType);
	m_fileList[keyName] = tempFileDesc;
}
void DataManager::setNewDB(const CString keyName, const CString serverName, const bool isFGDB, const bool doEdit) {
	CString convertedServerName = L"";
	CString convertedOwnerName =L"";
	CString convertedVersionName = L"";
	if (!isFGDB) {
		int startServerName = serverName.Find(L"@");
		int startVersionName = serverName.Find(L"(");
		if (startServerName == -1 || startVersionName == -1) {
			return;
		}
		convertedOwnerName = serverName.Mid(0, startServerName);
		convertedServerName = serverName.Mid(startServerName + 1, startVersionName - startServerName - 1);
		convertedVersionName = serverName.Mid(startVersionName + 1, serverName.GetLength() - startVersionName - 2);
	}
	CString fullDBName = "";
	if (doEdit) fullDBName = convertedOwnerName + "@" + convertedServerName + "(" + convertedVersionName + ")";
	else fullDBName = "RONLY@" + convertedServerName + "(" + convertedVersionName + ")";
	if (isFGDB) fullDBName = serverName;
	DBDesc tempDBDesc (
		convertedServerName,
		convertedOwnerName,
		convertedVersionName,
		fullDBName,
		NULL
	);
	m_DBList[keyName] = tempDBDesc;
}
void DataManager::setNewDB_divideUserDBVersion(const CString keyName, const CString serverName, const CString ownerName, const CString versionName, const bool isFGDB, const bool doEdit) {
	CString fullDBName = "";
	if (doEdit) fullDBName = ownerName + "@" + serverName + "(" + versionName + ")";
	else fullDBName = "RONLY@" + serverName + "(" + versionName + ")";
	if (isFGDB) fullDBName = serverName;
	DBDesc tempDBDesc (
		serverName,
		ownerName,
		versionName,
		fullDBName,
		NULL
	);
	m_DBList[keyName] = tempDBDesc;
}

void DataManager::setNewFeatureClass(const CString serverKeyName, const CString keyName, const CString serverName, const CString featureClassName, const bool isFGDB) {
	CString ownerName = L"";
	if (!isFGDB) {
		int startDBName = serverName.Find(L"@");
		ownerName = serverName.Mid(0, startDBName);
	}
	CString fullFeatureClassName = ownerName + "." + featureClassName;
	if (isFGDB) fullFeatureClassName = featureClassName;
	featureClassDesc tempTableDesc (
		serverKeyName,
		featureClassName,
		ownerName,
		fullFeatureClassName,
		L"",
		NULL
	);
	m_featureClassList[keyName] = tempTableDesc;
}
void DataManager::setNewFeatureClass_divideUserDBVersion(const CString serverKeyName, const CString keyName, const CString ownerName, const CString featureClassName, const bool isFGDB) {
	CString fullFeatureClassName = ownerName + "." + featureClassName;
	if (isFGDB) fullFeatureClassName = featureClassName;
	featureClassDesc tempTableDesc (
		serverKeyName,
		featureClassName,
		ownerName,
		fullFeatureClassName,
		L"",
		NULL
	);
	m_featureClassList[keyName] = tempTableDesc;
}

void DataManager::setNewTable(const CString serverKeyName, const CString keyName, const CString serverName, const CString tableName, const bool isFGDB){
	CString ownerName = L"";
	if (!isFGDB) {
		int startDBName = serverName.Find(L"@");
		ownerName = serverName.Mid(0, startDBName);
	}
	CString fullTableName = ownerName + "." + tableName;
	if (isFGDB) fullTableName = tableName;
	tableDesc tempTableDesc(
		serverKeyName,
		tableName,
		ownerName,
		fullTableName,
		NULL
	);
	m_tableList[keyName] = tempTableDesc;
}
void DataManager::setNewTable_divideUserDBVersion(const CString serverKeyName, const CString keyName, const CString ownerName, const CString tableName, const bool isFGDB){
	CString fullTableName = ownerName + "." + tableName;
	if (isFGDB) fullTableName = tableName;
	tableDesc tempTableDesc(
		serverKeyName,
		tableName,
		ownerName,
		fullTableName,
		NULL
	);
	m_tableList[keyName] = tempTableDesc;
}

void DataManager::setNewField(const CString datasetKeyName, const CString keyName, const CString fieldName, const bool isTable) {
	fieldDesc tempFieldDesc (
		datasetKeyName,
		fieldName,
		isTable,
		NULL
	);
	m_fieldList[keyName] = tempFieldDesc;
}

int DataManager::createFiles() {
	std::vector<CString> fileNameList;
	for (std::pair<CString, fileDesc> eachFile : m_fileList) {
		if (ErrorManager::RCode::R_SUCCESS != m_IOCtrl->initFile(eachFile.second.fileName, eachFile.second.fileType)) {
			return ErrorManager::RCode::R_FAILED_FATAL_ERROR;
		}
		else {
			fileNameList.push_back(eachFile.second.fileName);
		}
	}
	for (auto eachFile : fileNameList) {
		m_IOCtrl->print_run(eachFile + " has been created successfully");
	}
	return ErrorManager::RCode::R_SUCCESS;
}

int DataManager::initDBs() {
	for (std::pair<CString, DBDesc> eachDB : m_DBList) {
		if (HAS_ERROR == m_AccSV->setWorkspace(eachDB.second.fullDBName)) {
			m_IOCtrl->print_error(ErrorManager::ECode::E_FAILED_TO_OPEN_WORKSPACE, eachDB.second.fullDBName);
			return ErrorManager::RCode::R_FAILED_FATAL_ERROR;
		}
		else {
			if (eachDB.second.fullDBName.Find(L"RONLY") != -1) {
				CString tempFullDBName = eachDB.second.ownerName + "@" + eachDB.second.serverName + "(" + eachDB.second.versionName + ")";
				if (HAS_ERROR == m_AccSV->setWorkspace(tempFullDBName)) {
					m_IOCtrl->print_error(ErrorManager::ECode::E_FAILED_TO_OPEN_WORKSPACE, tempFullDBName);
					return ErrorManager::RCode::R_FAILED_FATAL_ERROR;
				}
			}
			eachDB.second.workspace = m_AccSV->getWorkspace(eachDB.second.fullDBName);
			CString successMsg = " has been connected successfully";
			CString printMsg = eachDB.second.fullDBName + successMsg;
			m_IOCtrl->print_run(printMsg);
		}
	}
	return ErrorManager::RCode::R_SUCCESS;
}
int DataManager::initDB(const CString keyName) {
	if (HAS_ERROR == m_AccSV->setWorkspace(m_DBList[keyName].fullDBName)) {
		m_IOCtrl->print_error(ErrorManager::ECode::E_FAILED_TO_OPEN_WORKSPACE, m_DBList[keyName].fullDBName);
		return ErrorManager::RCode::R_FAILED_FATAL_ERROR;
	}
	else {
		CString successMsg = " has been connected successfully";
		CString printMsg = m_DBList[keyName].fullDBName + successMsg;
		if (m_DBList[keyName].fullDBName.Find(L"RONLY") != -1) {
			CString tempFullDBName = m_DBList[keyName].ownerName + "@" + m_DBList[keyName].serverName + "(" + m_DBList[keyName].versionName + ")";
			if (HAS_ERROR == m_AccSV->setWorkspace(tempFullDBName)) {
				m_IOCtrl->print_error(ErrorManager::ECode::E_FAILED_TO_OPEN_WORKSPACE, tempFullDBName);
				return ErrorManager::RCode::R_FAILED_FATAL_ERROR;
			}
			printMsg = tempFullDBName + successMsg;
		}
		m_DBList[keyName].workspace = m_AccSV->getWorkspace(m_DBList[keyName].fullDBName);
		m_IOCtrl->print_run(printMsg);
	}
	return ErrorManager::RCode::R_SUCCESS;
}

int DataManager::initFeatureClasses() {
	for (std::pair<CString, featureClassDesc> eachFeatureClass : m_featureClassList) {
		CString fullDBName = m_DBList[eachFeatureClass.second.serverKeyName].fullDBName;
		if (HAS_ERROR == m_AccSV->setFeatureClass(fullDBName, eachFeatureClass.second.fullFeatureClassName)) {
			m_IOCtrl->print_error(ErrorManager::ECode::E_FAILED_TO_OPEN_FEATURECLASS, eachFeatureClass.second.fullFeatureClassName);
			return ErrorManager::RCode::R_FAILED_FATAL_ERROR;
		}
		else {
			IFeatureClassPtr featureClass = m_AccSV->getFeatureClass(fullDBName, eachFeatureClass.second.fullFeatureClassName);
			eachFeatureClass.second.featureClass = m_AccSV->getFeatureClass(fullDBName, eachFeatureClass.second.fullFeatureClassName);
			IFeatureDatasetPtr featureDataset;
			if (S_OK != featureClass->get_FeatureDataset(&featureDataset)) {
				m_IOCtrl->print_error(ErrorManager::ECode::E_FAILED_TO_GET_DATA, eachFeatureClass.second.fullFeatureClassName + " featureDataset");
				return ErrorManager::RCode::R_FAILED_FATAL_ERROR;
			}
			CComBSTR datasetName;
			if (S_OK != featureDataset->get_Name(&datasetName)) {
				m_IOCtrl->print_error(ErrorManager::ECode::E_FAILED_TO_GET_DATA, eachFeatureClass.second.fullFeatureClassName + " dataset name");
				return ErrorManager::RCode::R_FAILED_FATAL_ERROR;
			}
			eachFeatureClass.second.datasetName = datasetName;
			CString successMsg = " featureclass has been connected successfully";
			CString printMsg = eachFeatureClass.second.fullFeatureClassName + successMsg;
			m_IOCtrl->print_run(printMsg);
		}
	}
	return ErrorManager::RCode::R_SUCCESS;
}
int DataManager::initFeatureClass(const CString keyName) {
	CString fullDBName = m_DBList[m_featureClassList[keyName].serverKeyName].fullDBName;
	if (HAS_ERROR == m_AccSV->setFeatureClass(fullDBName, m_featureClassList[keyName].fullFeatureClassName)) {
		m_IOCtrl->print_error(ErrorManager::ECode::E_FAILED_TO_OPEN_FEATURECLASS, m_featureClassList[keyName].fullFeatureClassName);
		return ErrorManager::RCode::R_FAILED_FATAL_ERROR;
	}
	else {
		IFeatureClassPtr featureClass = m_AccSV->getFeatureClass(fullDBName, m_featureClassList[keyName].fullFeatureClassName);
		m_featureClassList[keyName].featureClass = featureClass;
		IFeatureDatasetPtr featureDataset;
		if (S_OK != featureClass->get_FeatureDataset(&featureDataset)) {
			m_IOCtrl->print_error(ErrorManager::ECode::E_FAILED_TO_GET_DATA, m_featureClassList[keyName].fullFeatureClassName + " featureDataset");
			return ErrorManager::RCode::R_FAILED_FATAL_ERROR;
		}
		CComBSTR datasetName;
		if (S_OK != featureDataset->get_Name(&datasetName)) {
			m_IOCtrl->print_error(ErrorManager::ECode::E_FAILED_TO_GET_DATA, m_featureClassList[keyName].fullFeatureClassName + " dataset name");
			return ErrorManager::RCode::R_FAILED_FATAL_ERROR;
		}
		m_featureClassList[keyName].datasetName = datasetName;
		CString successMsg = " featureclass has been connected successfully";
		CString printMsg = m_featureClassList[keyName].fullFeatureClassName + successMsg;
		m_IOCtrl->print_run(printMsg);
	}
	return ErrorManager::RCode::R_SUCCESS;
}

int DataManager::initTables() {
	for (std::pair<CString, tableDesc> eachTable : m_tableList) {
		CString fullDBName = m_DBList[eachTable.second.serverKeyName].fullDBName;
		if (HAS_ERROR == m_AccSV->setTable(fullDBName, eachTable.second.fullTableName)) {
			m_IOCtrl->print_error(ErrorManager::ECode::E_FAILED_TO_OPEN_TABLE, eachTable.second.fullTableName);
			return ErrorManager::RCode::R_FAILED_FATAL_ERROR;
		}
		else {
			ITablePtr table = m_AccSV->getTable(fullDBName, eachTable.second.fullTableName);
			eachTable.second.table = m_AccSV->getTable(fullDBName, eachTable.second.fullTableName);
			CString successMsg = " table has been connected successfully";
			CString printMsg = eachTable.second.fullTableName + successMsg;
			m_IOCtrl->print_run(printMsg);
		}
	}
	return ErrorManager::RCode::R_SUCCESS;
}
int DataManager::initTable(const CString keyName) {
	CString fullDBName = m_DBList[m_tableList[keyName].serverKeyName].fullDBName;
	if (HAS_ERROR == m_AccSV->setTable(fullDBName, m_tableList[keyName].fullTableName)) {
		m_IOCtrl->print_error(ErrorManager::ECode::E_FAILED_TO_OPEN_TABLE, m_tableList[keyName].fullTableName);
		return ErrorManager::RCode::R_FAILED_FATAL_ERROR;
	}
	else {
		ITablePtr table = m_AccSV->getTable(fullDBName, m_tableList[keyName].fullTableName);
		m_tableList[keyName].table = table;
		CString successMsg = " table has been connected successfully";
		CString printMsg = m_tableList[keyName].fullTableName + successMsg;
		m_IOCtrl->print_run(printMsg);
	}
	return ErrorManager::RCode::R_SUCCESS;
}

int DataManager::initFields() {
	for (std::pair<CString, fieldDesc> eachField : m_fieldList) {
		CString fullDBName = m_DBList[m_featureClassList[eachField.second.datasetKeyName].serverKeyName].fullDBName;
		if (fullDBName == "") {
			fullDBName = m_DBList[m_tableList[eachField.second.datasetKeyName].serverKeyName].fullDBName;
		}
		CString fullDatasetName = m_featureClassList[eachField.second.datasetKeyName].fullFeatureClassName;
		if (fullDatasetName == "") {
			fullDatasetName = m_tableList[eachField.second.datasetKeyName].fullTableName;
		}
		if (HAS_ERROR == m_AccSV->setField(fullDBName, fullDatasetName, eachField.second.fieldName, eachField.second.isDatasetTable)) {
			m_IOCtrl->print_error(ErrorManager::ECode::E_FAILED_TO_OPEN_FIELD, eachField.second.fieldName);
			return ErrorManager::RCode::R_FAILED_FATAL_ERROR;
		}
		else {
			eachField.second.field = m_AccSV->getField(fullDBName, fullDatasetName, eachField.second.fieldName);
			CString successMsg = " field has been connected successfully";
			CString printMsg = fullDatasetName + "." + eachField.second.fieldName + successMsg;
			m_IOCtrl->print_run(printMsg);
		}
	}
	return ErrorManager::RCode::R_SUCCESS;
}

int DataManager::initField(const CString keyName) {
	CString fullDBName = m_DBList[m_featureClassList[m_fieldList[keyName].datasetKeyName].serverKeyName].fullDBName;
	if (fullDBName == "") {
		fullDBName = m_DBList[m_tableList[m_fieldList[keyName].datasetKeyName].serverKeyName].fullDBName;
	}
	CString fullDatasetName = m_featureClassList[m_fieldList[keyName].datasetKeyName].fullFeatureClassName;
	if (fullDatasetName == "") {
		fullDatasetName = m_tableList[m_fieldList[keyName].datasetKeyName].fullTableName;
	}
	if (HAS_ERROR == m_AccSV->setField(fullDBName, fullDatasetName, m_fieldList[keyName].fieldName, m_fieldList[keyName].isDatasetTable)) {
		m_IOCtrl->print_error(ErrorManager::ECode::E_FAILED_TO_OPEN_FIELD, m_fieldList[keyName].fieldName);
		return ErrorManager::RCode::R_FAILED_FATAL_ERROR;
	}
	else {
		m_fieldList[keyName].field = m_AccSV->getField(fullDBName, fullDatasetName, m_fieldList[keyName].fieldName);
		CString successMsg = " field has been connected successfully";
		CString printMsg = fullDatasetName + "." + m_fieldList[keyName].fieldName + successMsg;
		m_IOCtrl->print_run(printMsg);
	}
	return ErrorManager::RCode::R_SUCCESS;
	
}

std::map<CString, DataManager::DBDesc> DataManager::getDBList() {
	return m_DBList;
}
DataManager::DBDesc DataManager::getDB(const CString keyName) {
	return m_DBList[keyName];
}

std::map<CString, DataManager::featureClassDesc> DataManager::getFeatureClassList() {
	return m_featureClassList;
}
DataManager::featureClassDesc DataManager::getFeatureClass(const CString keyName) {
	return m_featureClassList[keyName];
}
std::map<CString, DataManager::tableDesc> DataManager::getTableList(){
	return m_tableList;
}
DataManager::tableDesc DataManager::getTable(const CString keyName) {
	return m_tableList[keyName];
}
std::map<CString, DataManager::fieldDesc> DataManager::getFieldList() {
	return  m_fieldList;
}
DataManager::fieldDesc DataManager::getField(const CString keyName) {
	return m_fieldList[keyName];
}


