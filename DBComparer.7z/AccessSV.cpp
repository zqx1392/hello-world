#pragma once
#include "stdafx.h"
#include "AccessSV.h"

AccessSV::AccessSV(void)
{
}

AccessSV::~AccessSV(void)
{
	m_featureClassMap.empty();
}


int AccessSV::setWorkspace(const CString workspaceName){
	IWorkspacePtr tempWorkspace (sindy::create_workspace(workspaceName));
	if (tempWorkspace == NULL){
		return 1;
	}
	m_workspaceMap.insert(std::make_pair(workspaceName,tempWorkspace));
	return 0;
}

IWorkspacePtr AccessSV::getWorkspace(const CString workspaceName) {
	return m_workspaceMap[workspaceName];
}
void AccessSV::clearWorkspaceList() {
	m_workspaceMap.clear();
}

int AccessSV::setFeatureClass (const CString workspaceName, const CString featureClassName){
	IWorkspacePtr targetWorkspace = getWorkspace(workspaceName);
	IFeatureClassPtr tempClass = NULL;
	if (S_OK != IFeatureWorkspacePtr(targetWorkspace)->OpenFeatureClass(featureClassName.AllocSysString(), &tempClass)){
		return 1;
	}
	m_featureClassMap.insert(std::make_pair(workspaceName + "." + featureClassName,tempClass));
	return 0;
}
IFeatureClassPtr AccessSV::getFeatureClass(const CString workspaceName, const CString featureClassName) {
	return m_featureClassMap[workspaceName + "." + featureClassName];
}
void AccessSV::clearFeatureClassList() {
	m_featureClassMap.clear();
}

int AccessSV::setTable(const CString workspaceName, const CString tableName) {
	IWorkspacePtr targetWorkspace = getWorkspace(workspaceName);
	ITablePtr tempClass = NULL;
	if (S_OK != IFeatureWorkspacePtr(targetWorkspace)->OpenTable(tableName.AllocSysString(), &tempClass)) {
		return 1;
	}
	m_tableMap.insert(std::make_pair(workspaceName + "." + tableName, tempClass));
	return 0;
}
ITablePtr AccessSV::getTable(const CString workspaceName, const CString tableName) {
	return m_tableMap[workspaceName + "." + tableName];
}
void AccessSV::clearTableList() {
	m_tableMap.clear();
}

int AccessSV::setField(const CString workspaceName, const CString datasetName, const CString fieldName, bool isTable) {
	long fieldIndex;
	IFieldPtr tempField;
	if (isTable) {
		ITablePtr targetTable = getTable(workspaceName, datasetName);
		targetTable->FindField(fieldName.AllocSysString(), &fieldIndex);
		if (S_OK != targetTable->GetFields()->get_Field(fieldIndex, &tempField)) {
			return 1;
		}
	}
	else {
		IFeatureClassPtr targetFeatureClass = getFeatureClass(workspaceName, datasetName);
		targetFeatureClass->FindField(fieldName.AllocSysString(), &fieldIndex);
		if (S_OK != targetFeatureClass->GetFields()->get_Field(fieldIndex, &tempField)) {
			return 1;
		}
	}
	m_fieldMap.insert(std::make_pair(workspaceName + "." + datasetName + "." + fieldName,tempField));
	return 0;
}

IFieldPtr AccessSV::getField(const CString workspaceName, const CString datasetName, const CString fieldName) {
	return m_fieldMap[workspaceName + "." + datasetName + "." + fieldName];
}

void AccessSV::clearFieldList() {
	m_fieldMap.clear();
}

