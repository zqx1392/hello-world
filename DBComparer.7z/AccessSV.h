#pragma once

/**
* @brief Manage server connection and store ArcGIS-related variable.
*/
class AccessSV
{
public:
	AccessSV(void);
	~AccessSV(void);

	/**
	* @brief Create new workspace
	* @param workspaceName		[in]	workspace full name [ex. TEST2017@gaia(SDE.DEFAULT)]
	* @return	success��0�Afailure��1
	*/
	int setWorkspace(const CString workspaceName);
	/**
	* @brief Get created workspace
	* @param workspaceName		[in]	workspace full name [ex. TEST2017@gaia(SDE.DEFAULT)]
	* @return	workspace variable
	*/
	IWorkspacePtr getWorkspace(const CString workspaceName);
	/**
	* @brief Clear workspace list
	*/
	void clearWorkspaceList();
	/**
	* @brief Create new featureClass
	* @param workspaceName		[in]	workspace full name [ex. TEST2017@gaia(SDE.DEFAULT)]
	* @param featureClassName	[in]	featureclass full name [ex. TEST2017.ROAD_LINK]
	* @return	success��0�Afailure��1
	*/
	int setFeatureClass (const CString workspaceName,const CString featureClassName);
	/**
	* @brief Get created featureClass
	* @param workspaceName		[in]	workspace full name [ex. TEST2017@gaia(SDE.DEFAULT)]
	* @param featureClassName	[in]	featureclass full name [ex. TEST2017.ROAD_LINK]
	* @return	featureClass variable
	*/
	IFeatureClassPtr getFeatureClass(const CString workspaceName, const CString featureClassName);
	/**
	* @brief Clear featureClass list
	*/
	void clearFeatureClassList();
	/**
	* @brief Create new table
	* @param workspaceName		[in]	workspace full name [ex. TEST2017@gaia(SDE.DEFAULT)]
	* @param tableName			[in]	table full name [ex. TEST2017.ALTERNATIVE_NAME]
	* @return	success��0�Afailure��1
	*/
	int setTable(const CString workspaceName, const CString tablesName);
	/**
	* @brief Get created table
	* @param workspaceName		[in]	workspace full name [ex. TEST2017@gaia(SDE.DEFAULT)]
	* @param tableName			[in]	table full name [ex. TEST2017.ALTERNATIVE_NAME]
	* @return	table variable
	*/
	ITablePtr getTable(const CString workspaceName, const CString tableName);
	/**
	* @brief Clear table list
	*/
	void clearTableList();
	/**
	* @brief Create new field
	* @param workspaceName		[in]	workspace full name [ex. TEST2017@gaia(SDE.DEFAULT)]
	* @param datasetName		[in]	target dataset name [ex. sindy::schema::example:kfeatureClassName, "ROAD_LINK", "ALTERNATIVE_NAME"]
	* @param fieldName			[in]	field name [ex. OBJECTID]
	* @param isTable			[in]	Is input dataset name table name or featureClass name
	* @return	success��0�Afailure��1
	*/
	int setField(const CString workspaceName, const CString featureClassName, const CString fieldName, bool isTable);
	/**
	* @brief Get created featureClass
	* @param workspaceName		[in]	workspace full name [ex. TEST2017@gaia(SDE.DEFAULT)]
	* @param datasetName		[in]	target dataset name [ex. sindy::schema::example:kfeatureClassName, "ROAD_LINK", "ALTERNATIVE_NAME"]
	* @param fieldName			[in]	field name [ex. OBJECTID]
	* @return	field variable
	*/
	IFieldPtr getField(const CString workspaceName, const CString datasetName, const CString fieldName);
	/**
	* @brief Clear field list
	*/
	void clearFieldList();

private:
	std::map<CString,IWorkspacePtr> m_workspaceMap;			//Record DB list
	std::map<CString,IFeatureClassPtr>  m_featureClassMap;	//Record current DB's featureclass list 
	std::map<CString, ITablePtr>  m_tableMap;					//Record current DB's table list
	std::map<CString, IFieldPtr> m_fieldMap;					//Record current featureclass's field list 

};