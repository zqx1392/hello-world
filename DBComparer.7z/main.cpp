#pragma once
#include "stdafx.h"
#include "DBComparer.h"

int _tmain(int argc, _TCHAR* argv[])
{
	DBComparer * d = new DBComparer();
	int a = d->init();

	if (0 != d->connectToDB(L"gaia", L"SGP2017A", L"SDE.DEFAULT")){
		std::cout << "connect error" << std::endl;
		std::cin >> a;
	}
	
	else {
		d->getfieldNameList(L"gaia", L"SGP2017A", L"SDE.DEFAULT", L"ROAD_LINK", false);
		d->getDomainNameList(L"gaia", L"SGP2017A", L"SDE.DEFAULT",L"ROAD_LINK",L"LANE_COUNT",false);
		//double c = d->getTotalDistArea("", L"sindympa", L"THA2017A", L"SDE.DEFAULT", L"BUILDING");
		std::cin >> a;
	}
	return 0;
}