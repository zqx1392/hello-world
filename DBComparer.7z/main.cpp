#pragma once
#include "stdafx.h"
#include "DBComparer.h"

int _tmain(int argc, _TCHAR* argv[])
{
	//DBComparer * d = new DBComparer();
	//int a = d->init();
	int a;
	LPCTSTR test_server = L"SGP2017A/SGP2017A/SDE.DEFAULT/5151/gaia";
	IWorkspacePtr tempWorkspace(sindy::create_workspace(test_server));
	if (NULL == tempWorkspace ) {
		std::cout << "connect error" << std::endl;
		std::cin >> a;
	}
	else {
		std::cout << "success" << std::endl;
		std::cin >> a;
	}
	/*if (0 != d->connectToDB(L"sindympa", L"THA2017A", L"SDE.DEFAULT")){
		std::cout << "connect error" << std::endl;
		std::cin >> a;
	}*/
	
	//else {
	//	d->getFeatureClassAndCount( L"sindympa", L"THA2017A", L"SDE.DEFAULT");
	//	//double c = d->getTotalDistArea("", L"sindympa", L"THA2017A", L"SDE.DEFAULT", L"BUILDING");
	//	std::cin >> a;
	//}
	return 0;
}