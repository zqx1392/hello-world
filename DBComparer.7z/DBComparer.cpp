#pragma once
#include "stdafx.h"
#include "DBComparer.h"
#include <arctl/coinitializer.h>
#include <crd_cnv/crd_cnv.cpp>
arctl::coinitializer aCoInitializer;

DBComparer::DBComparer() {
	//Initialize utility classes
	ErrorManager * _errorManager = new ErrorManager();
	IOManager * _IOManager = IOManager::getInstance();
	DataManager * _dataManager = new DataManager();
	m_crd_cnv = new crd_cnv();
	//add into global variable
	setErrorManager(_errorManager);
	setIOManager(_IOManager);
	setDataManager(_dataManager);
	//start class setup
	m_errorManager->initErrorMessage();
	m_IOManager->setErrorManager(m_errorManager);
	m_dataManager->setLogger(m_IOManager);
	//Initialize spatial reference
	initProjectedCS();
}

DBComparer::~DBComparer() {
}

void DBComparer::initProjectedCS() {
	ISpatialReferenceFactoryPtr srFactory(CLSID_SpatialReferenceEnvironment);
	IProjectedCoordinateSystemPtr pcs;
	ISpatialReferencePtr sr;
	srFactory->CreateProjectedCoordinateSystem(esriSRProjCSType::esriSRProjCS_WGS1984UTM_46N, &pcs);
	m_46N = pcs;
	srFactory->CreateProjectedCoordinateSystem(esriSRProjCSType::esriSRProjCS_WGS1984UTM_47N, &pcs);
	m_47N = pcs;
	srFactory->CreateProjectedCoordinateSystem(esriSRProjCSType::esriSRProjCS_WGS1984UTM_48N, &pcs);
	m_48N = pcs;
	srFactory->CreateProjectedCoordinateSystem(esriSRProjCSType::esriSRProjCS_WGS1984UTM_49N, &pcs);
	m_49N = pcs;
	srFactory->CreateProjectedCoordinateSystem(esriSRProjCSType::esriSRProjCS_WGS1984UTM_50N, &pcs);
	m_50N = pcs;
	srFactory->CreateProjectedCoordinateSystem(esriSRProjCSType::esriSRProjCS_WGS1984UTM_51N, &pcs);
	m_51N = pcs;
	srFactory->CreateProjectedCoordinateSystem(esriSRProjCSType::esriSRProjCS_WGS1984UTM_52N, &pcs);
	m_52N = pcs;
	srFactory->CreateProjectedCoordinateSystem(esriSRProjCSType::esriSRProjCS_WGS1984UTM_53N, &pcs);
	m_53N = pcs;
	srFactory->CreateProjectedCoordinateSystem(esriSRProjCSType::esriSRProjCS_WGS1984UTM_54N, &pcs);
	m_54N= pcs;
	srFactory->CreateProjectedCoordinateSystem(esriSRProjCSType::esriSRProjCS_WGS1984UTM_46S, &pcs);
	m_46S = pcs;
	srFactory->CreateProjectedCoordinateSystem(esriSRProjCSType::esriSRProjCS_WGS1984UTM_47S, &pcs);
	m_47S = pcs;
	srFactory->CreateProjectedCoordinateSystem(esriSRProjCSType::esriSRProjCS_WGS1984UTM_48S, &pcs);
	m_48S = pcs;
	srFactory->CreateProjectedCoordinateSystem(esriSRProjCSType::esriSRProjCS_WGS1984UTM_49S, &pcs);
	m_49S = pcs;
	srFactory->CreateProjectedCoordinateSystem(esriSRProjCSType::esriSRProjCS_WGS1984UTM_50S, &pcs);
	m_50S = pcs;
	srFactory->CreateProjectedCoordinateSystem(esriSRProjCSType::esriSRProjCS_WGS1984UTM_51S, &pcs);
	m_51S = pcs;
	srFactory->CreateProjectedCoordinateSystem(esriSRProjCSType::esriSRProjCS_WGS1984UTM_52S, &pcs);
	m_52S = pcs;
	srFactory->CreateProjectedCoordinateSystem(esriSRProjCSType::esriSRProjCS_WGS1984UTM_53S, &pcs);
	m_53S = pcs;
	srFactory->CreateProjectedCoordinateSystem(esriSRProjCSType::esriSRProjCS_WGS1984UTM_54S, &pcs);
	m_54S = pcs;
}
void DBComparer::setIOManager(IOManager * _IOManager) {
	m_IOManager = _IOManager;
}
void DBComparer::setSVManager(AccessSV * _accessSV) {
	m_accessSV = _accessSV;
}
void DBComparer::setErrorManager(ErrorManager * _errorManager) {
	m_errorManager = _errorManager;
}
void DBComparer::setDataManager(DataManager * _dataManager) {
	m_dataManager = _dataManager;
}
int DBComparer::init()
{
	try {
		m_dataManager->setNewFile("ERR", L"", IOManager::FileType::ERR);
		m_dataManager->setNewFile("RUN", L"", IOManager::FileType::RUN);
		//Create files specified in option
		if (is_success != m_dataManager->createFiles()) {
			return endProgramWithError("create files");
		}

		//Initialize connection to server
		AccessSV * _accessSV = new AccessSV();
		setSVManager(_accessSV);
		m_dataManager->setAccSV(m_accessSV);
	}
	catch (const _com_error e) {
		std::cout << std::endl;
		m_IOManager->print_error(ErrorManager::ECode::E_COM_ERROR_IS_CATCHED, (CString)e.ErrorMessage());
		return endProgramWithError("Com Error");
	}
	return 0;
}
int DBComparer::printSuccessfulEnd() {
	m_IOManager->print_run_no_cout("Program ends successfully");
	m_IOManager->print_no_timestamp_run("");
	m_IOManager->print_total_execution_time();
	m_IOManager->closeFile();
	return ErrorManager::RCode::R_SUCCESS;
}
int DBComparer::endProgramWithError(const CString& errorPoint) {
	CString errorDesc = "An error occured during " + errorPoint;
	m_IOManager->print_run(errorDesc);
	CString errorType;
	if (!_tcscmp(errorPoint, (CString)"Com Error")) {
		errorType = "Exception Error";
	}
	else {
		errorType = "Unsuccessful Termination";
	}
	m_IOManager->print_no_timestamp_run(errorType);
	m_IOManager->print_no_timestamp_run("");
	m_IOManager->closeFile();
	return ErrorManager::RCode::R_FAILED_FATAL_ERROR;
}

int DBComparer::connectToDB(const CString& DBname, const CString& username, const CString& versionName) {
	CString keyName(username + L"." + DBname + L"."  + versionName);
	m_dataManager->setNewDB_divideUserDBVersion(keyName,DBname,username,versionName,false,false);
	return m_dataManager->initDB(keyName);
	
}
CString DBComparer::getFeatureClassDataSetName(const CString& DBname, const CString& username, const CString& versionName, const CString& featureClassName) {
	//set key
	CString DBKeyName(username + L"." + DBname + L"." + versionName);
	CString featureClassKeyName(DBKeyName + L"." + featureClassName);
	//get dataset name
	CString datasetName = m_dataManager->getFeatureClass(featureClassKeyName).datasetName;
	//if empty, try to init featureclass and get the value again
	if (datasetName == "") {
		m_dataManager->setNewFeatureClass_divideUserDBVersion(DBKeyName, featureClassKeyName, username, featureClassName, false);
		m_dataManager->initFeatureClass(featureClassKeyName);
		datasetName = m_dataManager->getFeatureClass(featureClassKeyName).datasetName;
	}
	return datasetName;
}
std::vector<CString> DBComparer::getFeatureClassList(const CString& DBname, const CString& username, const CString& versionName) {
	//set list
	std::vector<CString> featureClassList;
	std::vector<CString> emptyList;
	emptyList.push_back(L"-1");
	//set key
	CString keyName(username + L"." + DBname + L"." + versionName);
	//get featureclass workspace
	IWorkspacePtr targetWorkspace = m_dataManager->getDB(keyName).workspace;
	//get feaatureworkspace
	IFeatureWorkspacePtr fw = (IFeatureWorkspacePtr)targetWorkspace;
	//get set of featureclass
	IEnumDatasetNamePtr datasets;
	if (S_OK != targetWorkspace->get_DatasetNames(esriDatasetType::esriDTFeatureDataset, &datasets)) {
		m_IOManager->print_error(ErrorManager::ECode::E_FAILED_TO_SEARCH, "featureclasses' parent dataset");
		return emptyList;
	}
	IDatasetNamePtr dataset = NULL;
	//search featureClass
	while ((S_OK == datasets->Next(&dataset)) && dataset)
	{ 		//get set name
			CComBSTR featureDatasetName;
			if (S_OK != dataset->get_Name(&featureDatasetName)) {
				m_IOManager->print_error(ErrorManager::ECode::E_FAILED_TO_GET_DATA, "featureclasses' parent dataset name");
				return emptyList;
			}
			//check if the set is the user's dataset
			CString convertedName(featureDatasetName, SysStringLen(featureDatasetName));
			CString convertedUserName = convertedName.Mid(0,convertedName.Find(L"."));
			if (convertedUserName.CompareNoCase(username) == 0) {
				//open feature dataset
				IFeatureDatasetPtr targetDataset;
				if (S_OK != fw->OpenFeatureDataset(featureDatasetName, &targetDataset)) {
					m_IOManager->print_error(ErrorManager::ECode::E_FAILED_TO_OPEN_FEATURECLASS, "Dataset of");
					return emptyList;
				}
				//open feature dataset
				IEnumDatasetPtr targetSubset;
				if (S_OK != targetDataset->get_Subsets(&targetSubset)) {
					m_IOManager->print_error(ErrorManager::ECode::E_FAILED_TO_OPEN_FEATURECLASS, "");
					return emptyList;
				}
				//get featureclass
				IDatasetPtr target;
				while ((S_OK == targetSubset->Next(&target)) && target) {
					//get featureclass name
					CComBSTR featureClassName;
					if (S_OK != target->get_Name(&featureClassName)) {
						m_IOManager->print_error(ErrorManager::ECode::E_FAILED_TO_GET_DATA, "FeatureClass name");
						return emptyList;
					}
					CString convertedFeatureClassName(featureClassName, SysStringLen(featureClassName));
					//convert name into CString and store into list
					//get only featureclass name, not username
					convertedFeatureClassName = convertedFeatureClassName.Mid(convertedFeatureClassName.Find(L".") + 1);
					featureClassList.push_back(convertedFeatureClassName);
				}
			}
	}
	return featureClassList;
}
std::vector<CString> DBComparer::getTableList(const CString& DBname, const CString& username, const CString& versionName) {
	//set list
	std::vector<CString> tableList;
	std::vector<CString> emptyList;
	emptyList.push_back(L"-1");
	//set key
	CString keyName(username + L"." + DBname + L"." + versionName);
	//get workspace
	IWorkspacePtr targetWorkspace = m_dataManager->getDB(keyName).workspace;
	//get feature workspace
	IFeatureWorkspacePtr fw = (IFeatureWorkspacePtr)targetWorkspace;
	IEnumDatasetNamePtr datasets;
	IDatasetNamePtr dataset = NULL;
	//set as search table
	if (S_OK != targetWorkspace->get_DatasetNames(esriDatasetType::esriDTTable, &datasets)) {
		m_IOManager->print_error(ErrorManager::ECode::E_FAILED_TO_SEARCH, " table datasets");
		return emptyList;
	}
	//search table
	while ((S_OK == datasets->Next(&dataset)) && dataset)
	{
		//get table name
		CComBSTR tableName;
		if (S_OK != dataset->get_Name(&tableName)) {
			m_IOManager->print_error(ErrorManager::ECode::E_FAILED_TO_GET_DATA, "Table name");
			return emptyList;
		}
		//check if the table is the user's table
		CString convertedTableName(tableName, SysStringLen(tableName));
		CString convertedUserName = convertedTableName.Mid(0, convertedTableName.Find(L"."));
		if (convertedUserName.CompareNoCase(username) == 0) {
			//convert name and record count into CString and store into list
			//get only table name, not username
			convertedTableName = convertedTableName.Mid(convertedTableName.Find(L".") + 1);			
			tableList.push_back(convertedTableName);
		}
	}
	return tableList;
}

std::vector<CString> DBComparer::getfieldNameList(const CString& DBname, const CString& username, const CString& versionName, const CString& datasetName, const bool& isTable) {
	//set key
	CString DBKeyName(username + L"." + DBname + L"." + versionName);
	CString datasetKeyName(DBKeyName + L"." + datasetName);
	//set list
	std::vector<CString> fieldNameList;
	std::vector<CString> emptyList;
	IFieldsPtr fieldList;
	//get target table
	if (isTable){
		ITablePtr targetTable = m_dataManager->getTable(datasetKeyName).table;
		//if null, initialize the table
		if (targetTable == NULL){
			m_dataManager->setNewTable_divideUserDBVersion(DBKeyName, datasetKeyName, username, datasetName, false);
			m_dataManager->initTable(datasetKeyName);
			targetTable = m_dataManager->getTable(datasetKeyName).table;
		}
		//get fields
		if (S_OK != targetTable->get_Fields(&fieldList)) {
			m_IOManager->print_error(ErrorManager::ECode::E_FAILED_TO_GET_DATA, datasetName + " field list");
			return emptyList;
		}
	}
	//get target featureclass
	else{
		IFeatureClassPtr targetFeatureClass = m_dataManager->getFeatureClass(datasetKeyName).featureClass;
		//if null, initialize the featureclass
		if (targetFeatureClass == NULL) {
			m_dataManager->setNewFeatureClass_divideUserDBVersion(DBKeyName, datasetKeyName, username, datasetName, false);
			m_dataManager->initFeatureClass(datasetKeyName);
			targetFeatureClass = m_dataManager->getFeatureClass(datasetKeyName).featureClass;
		}
		//get fields
		if (S_OK != targetFeatureClass->get_Fields(&fieldList)) {
			m_IOManager->print_error(ErrorManager::ECode::E_FAILED_TO_GET_DATA, datasetName + " field list");
			return emptyList;
		}
	}
	//get total field count
	long fieldCount;
	if (S_OK != fieldList->get_FieldCount(&fieldCount)) {
		m_IOManager->print_error(ErrorManager::ECode::E_FAILED_TO_GET_DATA, datasetName + " total field number");
		return emptyList;
	}
	//get field one by one
	for (int i = 0; i < fieldCount; i++) {
		//open field
		IFieldPtr field;
		if (S_OK != fieldList->get_Field(i, &field)) {
			m_IOManager->print_error(ErrorManager::ECode::E_FAILED_TO_GET_DATA, datasetName + " 's field");
			return emptyList;
		}
		//get field name
		CComBSTR fieldName;
		if (S_OK != field->get_Name(&fieldName)) {
			m_IOManager->print_error(ErrorManager::ECode::E_FAILED_TO_GET_DATA, datasetName + " 's field name");
			return emptyList;
		}
		//store all field name into list
		CString convertedFieldName(fieldName, SysStringLen(fieldName));
		fieldNameList.push_back(convertedFieldName);
		m_dataManager->setNewField(datasetKeyName,datasetKeyName + "." + convertedFieldName, convertedFieldName, isTable);
		m_dataManager->initField(datasetKeyName + "." + convertedFieldName);
	}
	return fieldNameList;
}

int DBComparer::hasDomain(const CString& DBname, const CString& username, const CString& versionName, const CString& datasetName, const CString& fieldName, const bool& isTable) {
	//set key
	CString DBKeyName(username + L"." + DBname + L"." + versionName);
	CString datasetKeyName(DBKeyName + L"." + datasetName);
	CString fieldKeyName(datasetKeyName + L"." + fieldName);
	//get target field
	IFieldPtr targetField = m_dataManager->getField(fieldKeyName).field;
	//if null, initialize field
	if (targetField == NULL) {
		m_dataManager->setNewField(datasetKeyName, fieldKeyName, fieldName, isTable);
		m_dataManager->initField(fieldKeyName);
		targetField = m_dataManager->getField(fieldKeyName).field;
	}
	//get domain details
	IDomainPtr domain;
	if (S_OK != targetField->get_Domain(&domain)) {
		return 1;
	}
	if (domain == NULL) {
		return 1;
	}
	return 0;
}
int DBComparer::isNullable(const CString& DBname, const CString& username, const CString& versionName, const CString& datasetName, const CString& fieldName, const bool& isTable) {
	//set key
	CString DBKeyName(username + L"." + DBname + L"." + versionName);
	CString datasetKeyName(DBKeyName + L"." + datasetName);
	CString fieldKeyName(datasetKeyName + L"." + fieldName);
	//get target field
	IFieldPtr targetField = m_dataManager->getField(fieldKeyName).field;
	//if null, initialize field
	if (targetField == NULL) {
		m_dataManager->setNewField(datasetKeyName, fieldKeyName, fieldName, isTable);
		m_dataManager->initField(fieldKeyName);
		targetField = m_dataManager->getField(fieldKeyName).field;
	}
	VARIANT_BOOL isNull;
	if (S_OK != targetField->get_IsNullable(&isNull)) {
		m_IOManager->print_error(ErrorManager::ECode::E_FAILED_TO_GET_DATA, fieldName + " 's nullable status");
		return -1;
	}
	if (isNull == VARIANT_FALSE) {
		return 1;
	}
	return 0;

}
std::vector<CString> DBComparer::getDomainNameList(const CString& DBname, const CString& username, const CString& versionName, const CString& datasetName, const CString& fieldName, const bool& isTable ) {
	//set key
	CString DBKeyName(username + L"." + DBname + L"." + versionName);
	CString datasetKeyName(DBKeyName + L"." + datasetName);
	CString fieldKeyName(datasetKeyName + L"." + fieldName);
	//set target field
	IFieldPtr targetField = m_dataManager->getField(fieldKeyName).field;
	//if null, initialize field
	if (targetField == NULL) {
		m_dataManager->setNewField(datasetKeyName, fieldKeyName, fieldName, isTable);
		m_dataManager->initField(fieldKeyName);
		targetField = m_dataManager->getField(fieldKeyName).field;
	}
	//set list
	std::vector<CString> domainNameList;
	std::vector<CString> emptyList;
	//get domain
	IDomainPtr domain;
	if (S_OK != targetField->get_Domain(&domain)) {
		m_IOManager->print_error(ErrorManager::ECode::E_FAILED_TO_GET_DATA, fieldName + " 's domain");
		return emptyList;
	}
	//get domain name and store into list
	CComBSTR domainName;
	if (S_OK != domain->get_Name(&domainName)) {
		m_IOManager->print_error(ErrorManager::ECode::E_FAILED_TO_GET_DATA, fieldName + " 's domain name");
		return emptyList;
	}
	CString convertedDomainName(domainName, SysStringLen(domainName));
	domainNameList.push_back(convertedDomainName);
	//if domain type is coded value, get all possible coded value and name
	if (domain->Type == esriDomainType::esriDTCodedValue) {
		domainNameList.push_back("Coded Value");
		ICodedValueDomainPtr codedValueDomain = (ICodedValueDomainPtr) domain;	
		//get total coded value
		long totalCode;
		if (S_OK != codedValueDomain->get_CodeCount(&totalCode)) {
			m_IOManager->print_error(ErrorManager::ECode::E_FAILED_TO_GET_DATA, fieldName + " 's domain total code");
			return emptyList;
		}
		//get coded value one by one
		for (int i = 0; i < totalCode; i++) {
			//get coded value integer
			CComVariant value;
			if (S_OK != codedValueDomain->get_Value(i, &value)) {
				m_IOManager->print_error(ErrorManager::ECode::E_FAILED_TO_GET_DATA, fieldName + " 's domain code");
				return emptyList;
			}
			//get coded value name
			CComBSTR codedValueName;
			if (S_OK != codedValueDomain->get_Name(i, &codedValueName)) {
				m_IOManager->print_error(ErrorManager::ECode::E_FAILED_TO_GET_DATA, fieldName + " 's domain name");
				return emptyList;
			}
			//store coded value interger and name into list
			CString convertedCodedValueName(codedValueName, SysStringLen(codedValueName));
			CString convertedValue;
			convertedValue.Format(L"%d", value.intVal);
			domainNameList.push_back(convertedValue);
			domainNameList.push_back(convertedCodedValueName);
		}
	}
	//if domain type is range, get min and max value
	else if (domain->Type == esriDomainType::esriDTRange) {
		domainNameList.push_back("Range");
		IRangeDomainPtr rangeDomain = (IRangeDomainPtr) domain;
		CComVariant min, max;
		//get min
		if (S_OK != rangeDomain->get_MinValue(&min)) {
			m_IOManager->print_error(ErrorManager::ECode::E_FAILED_TO_GET_DATA, fieldName + " 's domain min value");
			return emptyList;
		}
		//get max
		if (S_OK != rangeDomain->get_MaxValue(&max)) {
			m_IOManager->print_error(ErrorManager::ECode::E_FAILED_TO_GET_DATA, fieldName + " 's domain max value");
			return emptyList;
		}
		//store range min max value into list
		CString convertedMinValue; 
		convertedMinValue.Format(L"%lf", min.dblVal);
		CString convertedMaxValue;
		convertedMaxValue.Format(L"%lf", max.dblVal);
		domainNameList.push_back(convertedMinValue);
		domainNameList.push_back(convertedMaxValue);
	}
	return domainNameList;
}

bool DBComparer::checkSQLSyntax(const CString& SQLText, const CString& DBname, const CString& username, const CString& versionName, const CString& datasetName, const bool& isTable) {
	//set search condition
	IQueryFilterPtr ipQueryFilter(CLSID_QueryFilter);
	CComBSTR queryFilter = SQLText;
	if (S_OK != ipQueryFilter->put_WhereClause(queryFilter)) {
		m_IOManager->print_error(ErrorManager::ECode::E_FAILED_TO_SET_DATA, _T("Set search query"));
		return false;
	}
	//set key
	CString DBKeyName(username + L"." + DBname + L"." + versionName);
	CString datasetKeyName(DBKeyName + L"." + datasetName);
	//if table, get target table
	if (isTable){
		ITablePtr targetTable = m_dataManager->getTable(datasetKeyName).table;
		//if null, initialize table
		if (targetTable == NULL){
			m_dataManager->setNewTable_divideUserDBVersion(DBKeyName, datasetKeyName, username, datasetName, false);
			m_dataManager->initTable(datasetKeyName);
			targetTable = m_dataManager->getTable(datasetKeyName).table;
		}
		_ICursorPtr ipCursor;
		//set search condition into cursor and try searching
		if (S_OK != targetTable->Search(ipQueryFilter, VARIANT_FALSE, &ipCursor)) {
			m_IOManager->print_error(ErrorManager::ECode::E_FAILED_TO_SEARCH, m_dataManager->getTable(datasetKeyName).tableName);
			return false;
		}
	}
	//if featureclass, get target featureclass
	else {
		IFeatureClassPtr targetFeatureClass = m_dataManager->getFeatureClass(datasetKeyName).featureClass;
		//if null, initialize featureclass
		if (targetFeatureClass == NULL) {
			m_dataManager->setNewFeatureClass_divideUserDBVersion(DBKeyName, datasetKeyName, username, datasetName, false);
			m_dataManager->initFeatureClass(datasetKeyName);
			targetFeatureClass = m_dataManager->getFeatureClass(datasetKeyName).featureClass;
		}
		IFeatureCursorPtr ipCursor;
		//set search condition into cursor and try searching
		if (S_OK != targetFeatureClass->Search(ipQueryFilter, VARIANT_FALSE, &ipCursor)) {
			m_IOManager->print_error(ErrorManager::ECode::E_FAILED_TO_SEARCH, m_dataManager->getFeatureClass(datasetKeyName).featureClassName);
			return false;
		}
	}
	return true;
}
long DBComparer::getRecordNumber(const CString& SQLText, const CString& DBname, const CString& username, const CString& versionName, const CString& datasetName, const bool& isTable) {
	//set search condition
	IQueryFilterPtr ipQueryFilter(CLSID_QueryFilter);
	CComBSTR queryFilter = SQLText;
	if (S_OK != ipQueryFilter->put_WhereClause(queryFilter)) {
		m_IOManager->print_error(ErrorManager::ECode::E_FAILED_TO_SET_DATA, _T("Set search query"));
		return -1;
	}
	//set key
	CString DBKeyName(username + L"." + DBname + L"." + versionName);
	CString datasetKeyName(DBKeyName + L"." + datasetName);
	long dataCount = 0;
	//if table, get target table
	if (isTable){
		ITablePtr targetTable = m_dataManager->getTable(datasetKeyName).table;
		//if null, initialize table
		if (targetTable == NULL){
			m_dataManager->setNewTable_divideUserDBVersion(DBKeyName, datasetKeyName, username, datasetName, false);
			m_dataManager->initTable(datasetKeyName);
			targetTable = m_dataManager->getTable(datasetKeyName).table;
		}
		//get total record in accord to search condition
		if (S_OK != targetTable->RowCount(ipQueryFilter, &dataCount)) {
			m_IOManager->print_error(ErrorManager::ECode::E_FAILED_TO_GET_DATA, datasetName + " total record number");
			return -1;
		}
	}
	//if featureclass, get target featureclass
	else{
		IFeatureClassPtr targetFeatureClass = m_dataManager->getFeatureClass(datasetKeyName).featureClass;
		//if null, initialize featureclass
		if (targetFeatureClass == NULL) {
			m_dataManager->setNewFeatureClass_divideUserDBVersion(DBKeyName, datasetKeyName, username, datasetName, false);
			m_dataManager->initFeatureClass(datasetKeyName);
			targetFeatureClass = m_dataManager->getFeatureClass(datasetKeyName).featureClass;
		}
		//get total record in accord to search condition
		if (S_OK != targetFeatureClass->FeatureCount(ipQueryFilter, &dataCount)) {
			m_IOManager->print_error(ErrorManager::ECode::E_FAILED_TO_GET_DATA, datasetName + " total record number");
			return -1;
		}
	}
	return dataCount;
}

double DBComparer::getTotalDistArea(const CString& SQLText, const CString& DBname, const CString& username, const CString& versionName, const CString& featureClassName) {
	//set search condition
	IQueryFilterPtr ipQueryFilter(CLSID_QueryFilter);
	CComBSTR queryFilter = SQLText;
	if (S_OK != ipQueryFilter->put_WhereClause(queryFilter)) {
		m_IOManager->print_error(ErrorManager::ECode::E_FAILED_TO_SET_DATA, _T("Set search query"));
		return -1;
	}
	//set key
	CString DBKeyName(username + L"." + DBname + L"." + versionName);
	CString featureClassKeyName(DBKeyName + L"." + featureClassName);
	//get target featureclass
	IFeatureClassPtr targetFeatureClass = m_dataManager->getFeatureClass(featureClassKeyName).featureClass;
	//if null, initialize featureclass
	if (targetFeatureClass == NULL) {
		m_dataManager->setNewFeatureClass_divideUserDBVersion(DBKeyName, featureClassKeyName, username, featureClassName, false);
		m_dataManager->initFeatureClass(featureClassKeyName);
		targetFeatureClass = m_dataManager->getFeatureClass(featureClassKeyName).featureClass;
	}
	IFeatureCursorPtr ipCursor;
	//set search condition into cursor and try searching
	if (S_OK != targetFeatureClass->Search(ipQueryFilter, VARIANT_FALSE, &ipCursor)) {
		m_IOManager->print_error(ErrorManager::ECode::E_FAILED_TO_SEARCH, m_dataManager->getFeatureClass(featureClassKeyName).featureClassName);
		return -1;
	}
	//get distance or area from each shape one by one
	double distArea;
	double totalDistArea = 0;
	IFeaturePtr ipFeature;
	while (ipCursor->NextFeature(&ipFeature) == S_OK && ipFeature) {
		// get shape
		IGeometryPtr ipGeom;
		if (S_OK != ipFeature->get_ShapeCopy(&ipGeom)) {
			CString errorMsg = featureClassKeyName + (CString)"shape";
			m_IOManager->print_error(ErrorManager::ECode::E_FAILED_TO_GET_DATA, errorMsg);
			return -1;
		}
		//get shape type (polygon or polyline)
		esriGeometryType shapeType;
		if (S_OK != ipGeom->get_GeometryType(&shapeType)) {
			CString errorMsg = featureClassKeyName + (CString)"shape type";
			m_IOManager->print_error(ErrorManager::ECode::E_FAILED_TO_GET_DATA, errorMsg);
			return -1;
		}
		//if polyline, get distance
		if (shapeType == esriGeometryType::esriGeometryPolyline) {
			distArea = getDist(ipFeature);
			if (distArea == -1) {
				CString errorMsg = featureClassKeyName + (CString)"distance value";
				m_IOManager->print_error(ErrorManager::ECode::E_FAILED_TO_GET_DATA, errorMsg);
				return -1;
			}
			totalDistArea += distArea;
		}
		//if polygon, get area
		else if (shapeType == esriGeometryType::esriGeometryPolygon) {
			distArea = getArea(ipFeature);
			if (distArea == -1) {
				CString errorMsg = featureClassKeyName + (CString)"distance value";
				m_IOManager->print_error(ErrorManager::ECode::E_FAILED_TO_GET_DATA, errorMsg);
				return -1;
			}
			totalDistArea += distArea;
		}
		//if point, return 0
		else if (shapeType == esriGeometryType::esriGeometryPoint) {
			return 0;
		}
		//other than that, not standard SiNDY DB
		else {
			CString errorMsg = featureClassKeyName + (CString)"shape type is not point, polyline, or polygon";
			m_IOManager->print_error(ErrorManager::ECode::E_FAILED_TO_GET_DATA, errorMsg);
			return -1;
		}
	}
	return totalDistArea;
}
double DBComparer::getArea(IFeaturePtr & ipFeature) {
	//set spatialreference variable
	ISpatialReferencePtr sr;
	//set geometry variable
	IGeometryPtr ipGeomCoor;
	ipFeature->get_ShapeCopy(&ipGeomCoor);
	double totalArea = 0;
	//set WGS84 north and south latitude
	double y1 = 0, y2 = 84, y3 = -80, y4 = 0;
	//get min and max coordinate from target shape
	double a1, b1, a2, b2;
	ipGeomCoor->Envelope->QueryCoords(&a1, &b1, &a2, &b2);
	//get longtitude between which the shape exists
	double x1 = 90;
	while (x1 <= a1) {
		x1 += 6;
	}
	x1 -= 6;
	double x2 = x1;
	while (x2 < a2) {
		x2 += 6;
	}
	//for N side
	if (b2 > y1) {
		for (double x = x1; x < x2; x += 6) {
			sr = getCoordinateSystem(x, y1);
			//set envelope to cut the target shape into found spatial reference
			IEnvelopePtr ipEnv(CLSID_Envelope);
			if (S_OK != ipEnv->PutCoords(x, y1, x + 6, y2)) {
				return -1;
			}
			IGeometryPtr ipGeom;
			ipFeature->get_ShapeCopy(&ipGeom);
			//cut the target shape
			ITopologicalOperatorPtr ipTopo = ipGeom;
			if (S_OK != ipTopo->QueryClipped(ipEnv, ipGeom)) {
				continue;
			}
			//get the area
			IPolygonPtr ipPoly = ipTopo;
			ipPoly->Project(sr);
			IAreaPtr area = ipPoly;
			double value;
			if (S_OK != area->get_Area(&value)) {
				return -1;
			}
			totalArea += value;
		}
	}
	//for S side
	if (b1 < y1) {
		for (double x = x1; x < x2; x += 6) {
			sr = getCoordinateSystem(x, y3);
			//set envelope to cut the target shape into found spatial reference
			IEnvelopePtr ipEnv(CLSID_Envelope);
			if (S_OK != ipEnv->PutCoords(x, y3, x + 6, y4)) {
			return -1;
			}
			IGeometryPtr ipGeom;
			ipFeature->get_ShapeCopy(&ipGeom);
			//cut the target shape
			ITopologicalOperatorPtr ipTopo = ipGeom;
			if (S_OK != ipTopo->QueryClipped(ipEnv, ipGeom)) {
				continue;
			}
			//get the area
			IPolygonPtr ipPoly = ipTopo;
			ipPoly->Project(sr);
			IAreaPtr area = ipPoly;
			double value;
			if (S_OK != area->get_Area(&value)) {
				return -1;
			}
			totalArea += value;
		}
	}
	return totalArea / 1000000; //KM^2
}

double DBComparer::getDist(IFeaturePtr & ipFeature) {
	//set target geometry
	IGeometryPtr ipGeom;
	ipFeature->get_ShapeCopy(&ipGeom);
	double dDist = 0;
	//get all points in polyline
	IPointCollectionPtr	ipPointCol(ipGeom);
	long lCount = ipPointCol->GetPointCount();
	WKSPoint* lpWKS = new WKSPoint[lCount];
	ipPointCol->QueryWKSPoints(0, lCount, &lpWKS[0]);
	//use TDC library to get total distance from polyline
	for (int i = 0; i < lCount - 1; i++)
	{
		dDist += m_crd_cnv->GetDist_JGD2000(lpWKS[i].X, lpWKS[i].Y, lpWKS[i + 1].X, lpWKS[i + 1].Y);


	}
	delete[] lpWKS;
	return dDist / 1000; //KM
}

double DBComparer::GetEachLineDistance(const double&	eLon1,		// �o�x�P
	const double&	eLat1,		// �ܓx�P
	const double&	eLon2,		// �o�x�Q
	const double&	eLat2)		// �ܓx�Q
{
	double		aFaiRad;
	double		aDeltaX;
	double		aDeltaY;
	double		aSinVal;
	double		aCosVal;
	double		D;
	double		M;
	double		N;
	double		aDistX;
	double		aDistY;

	aFaiRad = (eLat2 + eLat1) * M_PI / 180.0 / 2.0;
	aDeltaX = (eLon2 - eLon1) * M_PI / 180.0;
	aDeltaY = (eLat2 - eLat1) * M_PI / 180.0;

	aSinVal = sin(aFaiRad);
	aCosVal = cos(aFaiRad);

	D = 1.0 - 0.00669437999019758 * aSinVal * aSinVal;
	M = 6335439.32729246 / sqrt(D * D * D);	// �q�ߐ��ȗ����a
	N = 6378137.0 / sqrt(D);			// �K�ѐ��ȗ����a

	aDistY = M * aDeltaY;
	aDistX = N * aCosVal * aDeltaX;

	return sqrt(aDistX * aDistX + aDistY * aDistY);
}
IProjectedCoordinateSystemPtr DBComparer::getCoordinateSystem(const double& x, const double& y) {
	if (y == 0) {
		if (x == 90) {
			return m_46N;
		}
		if (x == 96) {
			return m_47N;
		}
		if (x == 102) {
			return m_48N;
		}
		if (x == 108) {
			return m_49N;
		}
		if (x == 114) {
			return m_50N;
		}
		if (x == 120) {
			return m_51N;
		}
		if (x == 126) {
			return m_52N;
		}
		if (x == 132) {
			return m_53N;
		}
		if (x == 138) {
			return m_54N;
		}
	}
	else {
		if (x == 90) {
			return m_46S;
		}
		if (x == 96) {
			return m_47S;
		}
		if (x == 102) {
			return m_48S;
		}
		if (x == 108) {
			return m_49S;
		}
		if (x == 114) {
			return m_50S;
		}
		if (x == 120) {
			return m_51S;
		}
		if (x == 126) {
			return m_52S;
		}
		if (x == 132) {
			return m_53S;
		}
		if (x == 138) {
			return m_54S;
		}
	}
}




///plan/update : dynamically update value when condition has been typed 
int updatefeatureClassRecordNumber() {
	return 0;
}