#pragma once
#include "stdafx.h"
#include "DBComparer.h"
#include <arctl/coinitializer.h>
#include <crd_cnv/crd_cnv.cpp>
arctl::coinitializer aCoInitializer;

DBComparer::DBComparer() {
	//Initialize utility classes
	ErrorManager * _errorManager = new ErrorManager();
	IOManager * _IOManager = IOManager::getInstance();
	DataManager * _dataManager = new DataManager();
	m_crd_cnv = new crd_cnv();

	setErrorManager(_errorManager);
	setIOManager(_IOManager);
	setDataManager(_dataManager);

	m_errorManager->initErrorMessage();
	m_IOManager->setErrorManager(m_errorManager);
	m_dataManager->setLogger(m_IOManager);

	initProjectedCS();
}

DBComparer::~DBComparer() {

}
void DBComparer::initProjectedCS() {
	ISpatialReferenceFactoryPtr srFactory(CLSID_SpatialReferenceEnvironment);
	IProjectedCoordinateSystemPtr pcs;
	ISpatialReferencePtr sr;
	srFactory->CreateProjectedCoordinateSystem(esriSRProjCSType::esriSRProjCS_WGS1984UTM_46N, &pcs);
	m_46N = pcs;
	srFactory->CreateProjectedCoordinateSystem(esriSRProjCSType::esriSRProjCS_WGS1984UTM_47N, &pcs);
	m_47N = pcs;
	srFactory->CreateProjectedCoordinateSystem(esriSRProjCSType::esriSRProjCS_WGS1984UTM_48N, &pcs);
	m_48N = pcs;
	srFactory->CreateProjectedCoordinateSystem(esriSRProjCSType::esriSRProjCS_WGS1984UTM_49N, &pcs);
	m_49N = pcs;
	srFactory->CreateProjectedCoordinateSystem(esriSRProjCSType::esriSRProjCS_WGS1984UTM_50N, &pcs);
	m_50N = pcs;
	srFactory->CreateProjectedCoordinateSystem(esriSRProjCSType::esriSRProjCS_WGS1984UTM_51N, &pcs);
	m_51N = pcs;
	srFactory->CreateProjectedCoordinateSystem(esriSRProjCSType::esriSRProjCS_WGS1984UTM_52N, &pcs);
	m_52N = pcs;
	srFactory->CreateProjectedCoordinateSystem(esriSRProjCSType::esriSRProjCS_WGS1984UTM_53N, &pcs);
	m_53N = pcs;
	srFactory->CreateProjectedCoordinateSystem(esriSRProjCSType::esriSRProjCS_WGS1984UTM_54N, &pcs);
	m_54N= pcs;
	srFactory->CreateProjectedCoordinateSystem(esriSRProjCSType::esriSRProjCS_WGS1984UTM_46S, &pcs);
	m_46S = pcs;
	srFactory->CreateProjectedCoordinateSystem(esriSRProjCSType::esriSRProjCS_WGS1984UTM_47S, &pcs);
	m_47S = pcs;
	srFactory->CreateProjectedCoordinateSystem(esriSRProjCSType::esriSRProjCS_WGS1984UTM_48S, &pcs);
	m_48S = pcs;
	srFactory->CreateProjectedCoordinateSystem(esriSRProjCSType::esriSRProjCS_WGS1984UTM_49S, &pcs);
	m_49S = pcs;
	srFactory->CreateProjectedCoordinateSystem(esriSRProjCSType::esriSRProjCS_WGS1984UTM_50S, &pcs);
	m_50S = pcs;
	srFactory->CreateProjectedCoordinateSystem(esriSRProjCSType::esriSRProjCS_WGS1984UTM_51S, &pcs);
	m_51S = pcs;
	srFactory->CreateProjectedCoordinateSystem(esriSRProjCSType::esriSRProjCS_WGS1984UTM_52S, &pcs);
	m_52S = pcs;
	srFactory->CreateProjectedCoordinateSystem(esriSRProjCSType::esriSRProjCS_WGS1984UTM_53S, &pcs);
	m_53S = pcs;
	srFactory->CreateProjectedCoordinateSystem(esriSRProjCSType::esriSRProjCS_WGS1984UTM_54S, &pcs);
	m_54S = pcs;
}
void DBComparer::setIOManager(IOManager * _IOManager) {
	m_IOManager = _IOManager;
}
void DBComparer::setSVManager(AccessSV * _accessSV) {
	m_accessSV = _accessSV;
}
void DBComparer::setErrorManager(ErrorManager * _errorManager) {
	m_errorManager = _errorManager;
}
void DBComparer::setDataManager(DataManager * _dataManager) {
	m_dataManager = _dataManager;
}
int DBComparer::init()
{
	try {
		m_dataManager->setNewFile("ERR", L"", IOManager::FileType::ERR);
		m_dataManager->setNewFile("RUN", L"", IOManager::FileType::RUN);
		//Create files specified in option
		if (is_success != m_dataManager->createFiles()) {
			return endProgramWithError("create files");
		}

		//Initialize connection to server
		AccessSV * _accessSV = new AccessSV();
		setSVManager(_accessSV);
		m_dataManager->setAccSV(m_accessSV);
	}
	catch (const _com_error e) {
		std::cout << std::endl;
		m_IOManager->print_error(ErrorManager::ECode::E_COM_ERROR_IS_CATCHED, (CString)e.ErrorMessage());
		return endProgramWithError("Com Error");
	}
	return 0;
}
int DBComparer::printSuccessfulEnd() {
	m_IOManager->print_run_no_cout("Program ends successfully");
	m_IOManager->print_no_timestamp_run("");
	m_IOManager->print_total_execution_time();
	m_IOManager->closeFile();
	return ErrorManager::RCode::R_SUCCESS;
}
int DBComparer::endProgramWithError(CString errorPoint) {
	CString errorDesc = "An error occured during " + errorPoint;
	m_IOManager->print_run(errorDesc);
	CString errorType;
	if (!_tcscmp(errorPoint, (CString)"Com Error")) {
		errorType = "Exception Error";
	}
	else {
		errorType = "Unsuccessful Termination";
	}
	m_IOManager->print_no_timestamp_run(errorType);
	m_IOManager->print_no_timestamp_run("");
	m_IOManager->closeFile();
	return ErrorManager::RCode::R_FAILED_FATAL_ERROR;
}

int DBComparer::connectToDB(const CString DBname, const CString username, const CString versionName) {
	//setup converter
	CString labelName(username + L"." + DBname + L"."  + versionName);
	m_dataManager->setNewDB_divideUserDBVersion(labelName,DBname,username,versionName,false,false);
	return m_dataManager->initDB(labelName);
	
}
CString DBComparer::getFeatureClassDataSetName(const CString DBname, const CString username, const CString versionName, const CString featureClassName) {
	CString DBLabelName(username + L"." + DBname + L"." + versionName);
	CString featureClassLabelName(DBLabelName + L"." + featureClassName);
	CString datasetName = m_dataManager->getFeatureClass(featureClassLabelName).datasetName;
	if (datasetName == "") {
		m_dataManager->setNewFeatureClass_divideUserDBVersion(DBLabelName, featureClassLabelName, username, featureClassName, false);
		m_dataManager->initFeatureClass(featureClassLabelName);
		datasetName = m_dataManager->getFeatureClass(featureClassLabelName).datasetName;
	}
	return datasetName;
}
std::vector<CString> DBComparer::getFeatureClassAndCount(const CString DBname, const CString username, const CString versionName) {
	std::vector<CString> featureClassList;
	std::vector<CString> emptyList;
	emptyList.push_back(L"-1");
	CString labelName(username + L"." + DBname + L"." + versionName);
	IWorkspacePtr targetWorkspace = m_dataManager->getDB(labelName).workspace;
	IFeatureWorkspacePtr fw = (IFeatureWorkspacePtr)targetWorkspace;
	IEnumDatasetNamePtr datasets;
	if (S_OK != targetWorkspace->get_DatasetNames(esriDatasetType::esriDTFeatureDataset, &datasets)) {
		m_IOManager->print_error(ErrorManager::ECode::E_FAILED_TO_SEARCH, "featureclasses' parent dataset");
		return emptyList;
	}
	IDatasetNamePtr dataset = NULL;
	//search featureClass
	while ((S_OK == datasets->Next(&dataset)) && dataset)
	{ 
			CComBSTR featureDatasetName;
			if (S_OK != dataset->get_Name(&featureDatasetName)) {
				m_IOManager->print_error(ErrorManager::ECode::E_FAILED_TO_GET_DATA, "featureclasses' parent dataset name");
				return emptyList;
			}
			CString convertedName(featureDatasetName, SysStringLen(featureDatasetName));
			if (convertedName.Find(username) != -1) {
				IFeatureDatasetPtr targetDataset;
				if (S_OK != fw->OpenFeatureDataset(featureDatasetName, &targetDataset)) {
					m_IOManager->print_error(ErrorManager::ECode::E_FAILED_TO_OPEN_FEATURECLASS, "Dataset of");
					return emptyList;
				}
				IEnumDatasetPtr targetSubset;
				if (S_OK != targetDataset->get_Subsets(&targetSubset)) {
					m_IOManager->print_error(ErrorManager::ECode::E_FAILED_TO_OPEN_FEATURECLASS, "");
					return emptyList;
				}
				IDatasetPtr target;
				while ((S_OK == targetSubset->Next(&target)) && target) {
					CComBSTR featureClassName;
					if (S_OK != target->get_Name(&featureClassName)) {
						m_IOManager->print_error(ErrorManager::ECode::E_FAILED_TO_GET_DATA, "FeatureClass name");
						return emptyList;
					}
					CString convertedFeatureClassName(featureClassName, SysStringLen(featureClassName));
					IFeatureClassPtr targetFeatureClass;
					if (S_OK != fw->OpenFeatureClass(featureClassName, &targetFeatureClass)) {
						m_IOManager->print_error(ErrorManager::ECode::E_FAILED_TO_OPEN_FEATURECLASS, convertedFeatureClassName);
						return emptyList;
					}
					IQueryFilterPtr ipQueryFilter(CLSID_QueryFilter);
					long dataCount = 0;
					if (S_OK != targetFeatureClass->FeatureCount(ipQueryFilter, &dataCount)) {
						m_IOManager->print_error(ErrorManager::ECode::E_FAILED_TO_GET_DATA, convertedFeatureClassName + " total record number");
						return emptyList;
					}
					convertedFeatureClassName = convertedFeatureClassName.Mid(convertedFeatureClassName.Find(L".") + 1);
					featureClassList.push_back(convertedFeatureClassName);
					CString convertedDataCount;
					convertedDataCount.Format(L"%d", dataCount);
					featureClassList.push_back(convertedDataCount);
				}
			}
	}
	return featureClassList;
}
std::vector<CString> DBComparer::getTableAndCount(const CString DBname, const CString username, const CString versionName) {
	std::vector<CString> tableList;
	std::vector<CString> emptyList;
	emptyList.push_back(L"-1");
	CString labelName(username + L"." + DBname + L"." + versionName);
	IWorkspacePtr targetWorkspace = m_dataManager->getDB(labelName).workspace;
	IFeatureWorkspacePtr fw = (IFeatureWorkspacePtr)targetWorkspace;
	IEnumDatasetNamePtr datasets;
	IDatasetNamePtr dataset = NULL;
	//search table
	if (S_OK != targetWorkspace->get_DatasetNames(esriDatasetType::esriDTTable, &datasets)) {
		m_IOManager->print_error(ErrorManager::ECode::E_FAILED_TO_SEARCH, " table datasets");
		return emptyList;
	}
	while ((S_OK == datasets->Next(&dataset)) && dataset)
	{
		CComBSTR tableName;
		if (S_OK != dataset->get_Name(&tableName)) {
			m_IOManager->print_error(ErrorManager::ECode::E_FAILED_TO_GET_DATA, "Table name");
			return emptyList;
		}
		CString convertedTableName(tableName, SysStringLen(tableName));
		if (convertedTableName.Find(username) != -1) {
			ITablePtr targetTable;
			if (S_OK != fw->OpenTable(tableName, &targetTable)) {
				m_IOManager->print_error(ErrorManager::ECode::E_FAILED_TO_OPEN_TABLE, convertedTableName);
				return emptyList;
			}
			IQueryFilterPtr ipQueryFilter(CLSID_QueryFilter);
			long dataCount = 0;
			if (S_OK != targetTable->RowCount(ipQueryFilter, &dataCount)) {
				m_IOManager->print_error(ErrorManager::ECode::E_FAILED_TO_GET_DATA, convertedTableName + " total record number");
				return emptyList;
			}
			convertedTableName = convertedTableName.Mid(convertedTableName.Find(L".") + 1);
			//get only table name, not username
			tableList.push_back(convertedTableName);
			CString convertedDataCount;
			convertedDataCount.Format(L"%d", dataCount);
			tableList.push_back(convertedDataCount);
		}
	}
	return tableList;
}

std::vector<CString> DBComparer::getfieldNameList(const CString DBname, const CString username, const CString versionName, const CString datasetName, const bool isTable) {
	CString DBLabelName(username + L"." + DBname + L"." + versionName);
	CString datasetLabelName(DBLabelName + L"." + datasetName);
	std::vector<CString> fieldNameList;
	std::vector<CString> emptyList;
	IFieldsPtr fieldList;
	if (isTable){
		ITablePtr targetTable = m_dataManager->getTable(datasetLabelName).table;
		if (targetTable == NULL){
			m_dataManager->setNewTable_divideUserDBVersion(DBLabelName, datasetLabelName, username, datasetName, false);
			m_dataManager->initTable(datasetLabelName);
			targetTable = m_dataManager->getTable(datasetLabelName).table;
		}
		if (S_OK != targetTable->get_Fields(&fieldList)) {
			m_IOManager->print_error(ErrorManager::ECode::E_FAILED_TO_GET_DATA, datasetName + " field list");
			return emptyList;
		}
	}
	else{
		IFeatureClassPtr targetFeatureClass = m_dataManager->getFeatureClass(datasetLabelName).featureClass;
		if (targetFeatureClass == NULL) {
			m_dataManager->setNewFeatureClass_divideUserDBVersion(DBLabelName, datasetLabelName, username, datasetName, false);
			m_dataManager->initFeatureClass(datasetLabelName);
			targetFeatureClass = m_dataManager->getFeatureClass(datasetLabelName).featureClass;
		}
		if (S_OK != targetFeatureClass->get_Fields(&fieldList)) {
			m_IOManager->print_error(ErrorManager::ECode::E_FAILED_TO_GET_DATA, datasetName + " field list");
			return emptyList;
		}
	}
	long fieldCount;
	if (S_OK != fieldList->get_FieldCount(&fieldCount)) {
		m_IOManager->print_error(ErrorManager::ECode::E_FAILED_TO_GET_DATA, datasetName + " total field number");
		return emptyList;
	}
	for (int i = 0; i < fieldCount; i++) {
		IFieldPtr field;
		if (S_OK != fieldList->get_Field(i, &field)) {
			m_IOManager->print_error(ErrorManager::ECode::E_FAILED_TO_GET_DATA, datasetName + " 's field");
			return emptyList;
		}
		CComBSTR fieldName;
		if (S_OK != field->get_Name(&fieldName)) {
			m_IOManager->print_error(ErrorManager::ECode::E_FAILED_TO_GET_DATA, datasetName + " 's field name");
			return emptyList;
		}
		CString convertedFieldName(fieldName, SysStringLen(fieldName));
		fieldNameList.push_back(convertedFieldName);
		m_dataManager->setNewField(datasetLabelName,datasetLabelName + "." + convertedFieldName, convertedFieldName, isTable);
		m_dataManager->initField(datasetLabelName + "." + convertedFieldName);
	}
	return fieldNameList;
}

bool DBComparer::hasDomain(const CString DBname, const CString username, const CString versionName, const CString datasetName, const CString fieldName, const bool isTable) {
	CString DBLabelName(username + L"." + DBname + L"." + versionName);
	CString datasetLabelName(DBLabelName + L"." + datasetName);
	CString fieldLabelName(datasetLabelName + L"." + fieldName);
	IFieldPtr targetField = m_dataManager->getField(fieldLabelName).field;
	if (targetField == NULL) {
		m_dataManager->setNewField(datasetLabelName, fieldLabelName, fieldName, isTable);
		m_dataManager->initField(fieldLabelName);
		targetField = m_dataManager->getField(fieldLabelName).field;
	}
	IDomainPtr domain;
	if (S_OK != targetField->get_Domain(&domain)) {
		m_IOManager->print_error(ErrorManager::ECode::E_FAILED_TO_GET_DATA, fieldName + " 's domain");
		return false;
	}
	if (domain == NULL) {
		return false;
	}
	return true;
}

std::vector<CString> DBComparer::getDomainNameList(const CString DBname, const CString username, const CString versionName, const CString datasetName, const CString fieldName, const bool isTable ) {
	CString DBLabelName(username + L"." + DBname + L"." + versionName);
	CString datasetLabelName(DBLabelName + L"." + datasetName);
	CString fieldLabelName(datasetLabelName + L"." + fieldName);
	IFieldPtr targetField = m_dataManager->getField(fieldLabelName).field;
	if (targetField == NULL) {
		m_dataManager->setNewField(datasetLabelName, fieldLabelName, fieldName, isTable);
		m_dataManager->initField(fieldLabelName);
		targetField = m_dataManager->getField(fieldLabelName).field;
	}
	std::vector<CString> domainNameList;
	std::vector<CString> emptyList;
	IDomainPtr domain;
	if (S_OK != targetField->get_Domain(&domain)) {
		m_IOManager->print_error(ErrorManager::ECode::E_FAILED_TO_GET_DATA, fieldName + " 's domain");
		return emptyList;
	}
	CComBSTR domainName;
	if (S_OK != domain->get_Name(&domainName)) {
		m_IOManager->print_error(ErrorManager::ECode::E_FAILED_TO_GET_DATA, fieldName + " 's domain name");
		return emptyList;
	}
	CString convertedDomainName(domainName, SysStringLen(domainName));
	domainNameList.push_back(convertedDomainName);
	if (domain->Type == esriDomainType::esriDTCodedValue) {
		domainNameList.push_back("Coded Value");
		ICodedValueDomainPtr codedValueDomain = (ICodedValueDomainPtr) domain;	
		long totalCode;
		if (S_OK != codedValueDomain->get_CodeCount(&totalCode)) {
			m_IOManager->print_error(ErrorManager::ECode::E_FAILED_TO_GET_DATA, fieldName + " 's domain total code");
			return emptyList;
		}
		for (int i = 0; i < totalCode; i++) {
			_variant_t value;
			if (S_OK != codedValueDomain->get_Value(i, &value)) {
				m_IOManager->print_error(ErrorManager::ECode::E_FAILED_TO_GET_DATA, fieldName + " 's domain code");
				return emptyList;
			}
			CComBSTR codedValueName;
			if (S_OK != codedValueDomain->get_Name(i, &codedValueName)) {
				m_IOManager->print_error(ErrorManager::ECode::E_FAILED_TO_GET_DATA, fieldName + " 's domain name");
				return emptyList;
			}
			CString convertedCodedValueName(codedValueName, SysStringLen(codedValueName));
			CString convertedValue;
			convertedValue.Format(L"%d", value.intVal);
			domainNameList.push_back(convertedValue);
			domainNameList.push_back(convertedCodedValueName);
		}
	}
	else if (domain->Type == esriDomainType::esriDTRange) {
		domainNameList.push_back("Range");
		IRangeDomainPtr rangeDomain = (IRangeDomainPtr) domain;
		_variant_t min, max;
		if (S_OK != rangeDomain->get_MinValue(&min)) {
			m_IOManager->print_error(ErrorManager::ECode::E_FAILED_TO_GET_DATA, fieldName + " 's domain min value");
			return emptyList;
		}
		if (S_OK != rangeDomain->get_MaxValue(&max)) {
			m_IOManager->print_error(ErrorManager::ECode::E_FAILED_TO_GET_DATA, fieldName + " 's domain max value");
			return emptyList;
		}
		CString convertedMinValue;
		convertedMinValue.Format(L"%d", min.intVal);
		CString convertedMaxValue;
		convertedMaxValue.Format(L"%d", max.intVal);
		domainNameList.push_back(convertedMinValue);
		domainNameList.push_back(convertedMaxValue);
	}
	return domainNameList;
}

bool DBComparer::checkSQLSyntax(const CString SQLText, const CString DBname, const CString username, const CString versionName, const CString datasetName, const bool isTable) {
	IQueryFilterPtr ipQueryFilter(CLSID_QueryFilter);
	CComBSTR queryFilter = SQLText;
	if (S_OK != ipQueryFilter->put_WhereClause(queryFilter)) {
		m_IOManager->print_error(ErrorManager::ECode::E_FAILED_TO_SET_DATA, _T("Set search query"));
		return false;
	}
	CString DBLabelName(username + L"." + DBname + L"." + versionName);
	CString datasetLabelName(DBLabelName + L"." + datasetName);
	if (isTable){
		ITablePtr targetTable = m_dataManager->getTable(datasetLabelName).table;
		if (targetTable == NULL){
			m_dataManager->setNewTable_divideUserDBVersion(DBLabelName, datasetLabelName, username, datasetName, false);
			m_dataManager->initTable(datasetLabelName);
			targetTable = m_dataManager->getTable(datasetLabelName).table;
		}
		_ICursorPtr ipCursor;
		//set all condition into query variable
		if (S_OK != targetTable->Search(ipQueryFilter, VARIANT_FALSE, &ipCursor)) {
			m_IOManager->print_error(ErrorManager::ECode::E_FAILED_TO_SEARCH, m_dataManager->getTable(datasetLabelName).tableName);
			return false;
		}
	}
	else {
		IFeatureClassPtr targetFeatureClass = m_dataManager->getFeatureClass(datasetLabelName).featureClass;
		if (targetFeatureClass == NULL) {
			m_dataManager->setNewFeatureClass_divideUserDBVersion(DBLabelName, datasetLabelName, username, datasetName, false);
			m_dataManager->initFeatureClass(datasetLabelName);
			targetFeatureClass = m_dataManager->getFeatureClass(datasetLabelName).featureClass;
		}
		IFeatureCursorPtr ipCursor;
		//set all condition into query variable
		if (S_OK != targetFeatureClass->Search(ipQueryFilter, VARIANT_FALSE, &ipCursor)) {
			m_IOManager->print_error(ErrorManager::ECode::E_FAILED_TO_SEARCH, m_dataManager->getFeatureClass(datasetLabelName).featureClassName);
			return false;
		}
	}
	return true;
}
long DBComparer::getRecordNumber(const CString SQLText, const CString DBname, const CString username, const CString versionName, const CString datasetName, const bool isTable) {
	IQueryFilterPtr ipQueryFilter(CLSID_QueryFilter);
	CComBSTR queryFilter = SQLText;
	if (S_OK != ipQueryFilter->put_WhereClause(queryFilter)) {
		m_IOManager->print_error(ErrorManager::ECode::E_FAILED_TO_SET_DATA, _T("Set search query"));
		return -1;
	}
	CString DBLabelName(username + L"." + DBname + L"." + versionName);
	CString datasetLabelName(DBLabelName + L"." + datasetName);
	long dataCount = 0;
	if (isTable){
		ITablePtr targetTable = m_dataManager->getTable(datasetLabelName).table;
		if (targetTable == NULL){
			m_dataManager->setNewTable_divideUserDBVersion(DBLabelName, datasetLabelName, username, datasetName, false);
			m_dataManager->initTable(datasetLabelName);
			targetTable = m_dataManager->getTable(datasetLabelName).table;
		}
		if (targetTable == NULL) {
			m_IOManager->print_error(ErrorManager::ECode::E_FAILED_TO_GET_DATA, datasetName + " total record number");
			return -1;
		}
		if (S_OK != targetTable->RowCount(ipQueryFilter, &dataCount)) {
			m_IOManager->print_error(ErrorManager::ECode::E_FAILED_TO_GET_DATA, datasetName + " total record number");
			return -1;
		}
	}
	else{
		IFeatureClassPtr targetFeatureClass = m_dataManager->getFeatureClass(datasetLabelName).featureClass;
		if (targetFeatureClass == NULL) {
			m_dataManager->setNewFeatureClass_divideUserDBVersion(DBLabelName, datasetLabelName, username, datasetName, false);
			m_dataManager->initFeatureClass(datasetLabelName);
			targetFeatureClass = m_dataManager->getFeatureClass(datasetLabelName).featureClass;
		}
		if (targetFeatureClass == NULL) {
			m_IOManager->print_error(ErrorManager::ECode::E_FAILED_TO_GET_DATA, datasetName + " total record number");
			return -1;
		}
		if (S_OK != targetFeatureClass->FeatureCount(ipQueryFilter, &dataCount)) {
			m_IOManager->print_error(ErrorManager::ECode::E_FAILED_TO_GET_DATA, datasetName + " total record number");
			return -1;
		}
	}
	return dataCount;
}
double DBComparer::getTotalDistArea(const CString SQLText, const CString DBname, const CString username, const CString versionName, const CString featureClassName) {
	IQueryFilterPtr ipQueryFilter(CLSID_QueryFilter);
	CComBSTR queryFilter = SQLText;
	if (S_OK != ipQueryFilter->put_WhereClause(queryFilter)) {
		m_IOManager->print_error(ErrorManager::ECode::E_FAILED_TO_SET_DATA, _T("Set search query"));
		return -1;
	}
	CString DBLabelName(username + L"." + DBname + L"." + versionName);
	CString featureClassLabelName(DBLabelName + L"." + featureClassName);
	IFeatureClassPtr targetFeatureClass = m_dataManager->getFeatureClass(featureClassLabelName).featureClass;
	if (targetFeatureClass == NULL) {
		m_dataManager->setNewFeatureClass_divideUserDBVersion(DBLabelName, featureClassLabelName, username, featureClassName, false);
		m_dataManager->initFeatureClass(featureClassLabelName);
		targetFeatureClass = m_dataManager->getFeatureClass(featureClassLabelName).featureClass;
	}
	if (targetFeatureClass == NULL) {
		m_IOManager->print_error(ErrorManager::ECode::E_FAILED_TO_GET_DATA, "During get distArea, " + featureClassName);
		return -1;
	}
	IFeatureCursorPtr ipCursor;
	//set all condition into query variable
	if (S_OK != targetFeatureClass->Search(ipQueryFilter, VARIANT_FALSE, &ipCursor)) {
		m_IOManager->print_error(ErrorManager::ECode::E_FAILED_TO_SEARCH, m_dataManager->getFeatureClass(featureClassLabelName).featureClassName);
		return -1;
	}
	double distArea;
	double totalDistArea = 0;
	IFeaturePtr ipFeature;
	while (ipCursor->NextFeature(&ipFeature) == S_OK && ipFeature) {
		// get shape
		IGeometryPtr ipGeom;
		if (S_OK != ipFeature->get_ShapeCopy(&ipGeom)) {
			CString errorMsg = featureClassLabelName + (CString)"shape";
			m_IOManager->print_error(ErrorManager::ECode::E_FAILED_TO_GET_DATA, errorMsg);
			return -1;
		}
		esriGeometryType shapeType;
		if (S_OK != ipGeom->get_GeometryType(&shapeType)) {
			CString errorMsg = featureClassLabelName + (CString)"shape type";
			m_IOManager->print_error(ErrorManager::ECode::E_FAILED_TO_GET_DATA, errorMsg);
			return -1;
		}
		if (shapeType == esriGeometryType::esriGeometryPolyline) {
			distArea = getDist(ipFeature);
			if (distArea == -1) {
				CString errorMsg = featureClassLabelName + (CString)"distance value";
				m_IOManager->print_error(ErrorManager::ECode::E_FAILED_TO_GET_DATA, errorMsg);
				return -1;
			}
			totalDistArea += distArea;
		}
		else if (shapeType == esriGeometryType::esriGeometryPolygon) {
			distArea = getArea(ipFeature);
			if (distArea == -1) {
				CString errorMsg = featureClassLabelName + (CString)"distance value";
				m_IOManager->print_error(ErrorManager::ECode::E_FAILED_TO_GET_DATA, errorMsg);
				return -1;
			}
			totalDistArea += distArea;
		}
		else if (shapeType == esriGeometryType::esriGeometryPoint) {
			return 0;
		}
		else {
			CString errorMsg = featureClassLabelName + (CString)"shape type is not point, polyline, or polygon";
			m_IOManager->print_error(ErrorManager::ECode::E_FAILED_TO_GET_DATA, errorMsg);
			return -1;
		}
	}
	return totalDistArea;
}
double DBComparer::getArea(IFeaturePtr & ipFeature) {
	ISpatialReferencePtr sr;
	IGeometryPtr ipGeomCoor;
	double totalArea = 0;
	double y1 = 0, y2 = 84, y3 = -80, y4 = 0;
	ipFeature->get_ShapeCopy(&ipGeomCoor);
	double a1, b1, a2, b2;
	ipGeomCoor->Envelope->QueryCoords(&a1, &b1, &a2, &b2);
	double x1 = 90;
	while (x1 <= a1) {
		x1 += 6;
	}
	x1 -= 6;
	double x2 = x1;
	while (x2 < a2) {
		x2 += 6;
	}
	//for N side
	if (b2 > y1) {
		for (double x = x1; x < x2; x += 6) {
			sr = getCoordinateSystem(x, y1);
			IEnvelopePtr ipEnv(CLSID_Envelope);
			if (S_OK != ipEnv->PutCoords(x, y1, x + 6, y2)) {
				return -1;
			}
			IGeometryPtr ipGeom;
			ipFeature->get_ShapeCopy(&ipGeom);
			ITopologicalOperatorPtr ipTopo = ipGeom;
			if (S_OK != ipTopo->QueryClipped(ipEnv, ipGeom)) {
				continue;
			}
			IPolygonPtr ipPoly = ipTopo;
			ipPoly->Project(sr);
			IAreaPtr area = ipPoly;
			double value;
			if (S_OK != area->get_Area(&value)) {
				return -1;
			}
			totalArea += value;
		}
	}
	//for S side
	if (b1 < y1) {
		for (double x = x1; x < x2; x += 6) {
			sr = getCoordinateSystem(x, y3);
			IEnvelopePtr ipEnv(CLSID_Envelope);
			if (S_OK != ipEnv->PutCoords(x, y3, x + 6, y4)) {
			return -1;
			}
			IGeometryPtr ipGeom;
			ipFeature->get_ShapeCopy(&ipGeom);
			ITopologicalOperatorPtr ipTopo = ipGeom;
			if (S_OK != ipTopo->QueryClipped(ipEnv, ipGeom)) {
			continue;
			}
			IPolygonPtr ipPoly = ipTopo;
			ipPoly->Project(sr);
			IAreaPtr area = ipPoly;
			double value;
			if (S_OK != area->get_Area(&value)) {
				return -1;
			}
			totalArea += value;
		}
	}
	return totalArea / 1000000; //KM^2
}

double DBComparer::getDist(IFeaturePtr & ipFeature) {
	IGeometryPtr ipGeom;
	ipFeature->get_ShapeCopy(&ipGeom);
	double dDist = 0;
	IPointCollectionPtr	ipPointCol(ipGeom);
	long lCount = ipPointCol->GetPointCount();
	WKSPoint* lpWKS = new WKSPoint[lCount];
	ipPointCol->QueryWKSPoints(0, lCount, &lpWKS[0]);
	for (int i = 0; i < lCount - 1; i++)
	{
		dDist += m_crd_cnv->GetDist_JGD2000(lpWKS[i].X, lpWKS[i].Y, lpWKS[i + 1].X, lpWKS[i + 1].Y);


	}
	delete[] lpWKS;
	return dDist / 1000; //KM
}

double DBComparer::GetEachLineDistance(double		eLon1,		// �o�x�P
	double		eLat1,		// �ܓx�P
	double		eLon2,		// �o�x�Q
	double		eLat2)		// �ܓx�Q
{
	double		aFaiRad;
	double		aDeltaX;
	double		aDeltaY;
	double		aSinVal;
	double		aCosVal;
	double		D;
	double		M;
	double		N;
	double		aDistX;
	double		aDistY;

	aFaiRad = (eLat2 + eLat1) * M_PI / 180.0 / 2.0;
	aDeltaX = (eLon2 - eLon1) * M_PI / 180.0;
	aDeltaY = (eLat2 - eLat1) * M_PI / 180.0;

	aSinVal = sin(aFaiRad);
	aCosVal = cos(aFaiRad);

	D = 1.0 - 0.00669437999019758 * aSinVal * aSinVal;
	M = 6335439.32729246 / sqrt(D * D * D);	// �q�ߐ��ȗ����a
	N = 6378137.0 / sqrt(D);			// �K�ѐ��ȗ����a

	aDistY = M * aDeltaY;
	aDistX = N * aCosVal * aDeltaX;

	return sqrt(aDistX * aDistX + aDistY * aDistY);
}
IProjectedCoordinateSystemPtr DBComparer::getCoordinateSystem(double x, double y) {
	if (y == 0) {
		if (x == 90) {
			return m_46N;
		}
		if (x == 96) {
			return m_47N;
		}
		if (x == 102) {
			return m_48N;
		}
		if (x == 108) {
			return m_49N;
		}
		if (x == 114) {
			return m_50N;
		}
		if (x == 120) {
			return m_51N;
		}
		if (x == 126) {
			return m_52N;
		}
		if (x == 132) {
			return m_53N;
		}
		if (x == 138) {
			return m_54N;
		}
	}
	else {
		if (x == 90) {
			return m_46S;
		}
		if (x == 96) {
			return m_47S;
		}
		if (x == 102) {
			return m_48S;
		}
		if (x == 108) {
			return m_49S;
		}
		if (x == 114) {
			return m_50S;
		}
		if (x == 120) {
			return m_51S;
		}
		if (x == 126) {
			return m_52S;
		}
		if (x == 132) {
			return m_53S;
		}
		if (x == 138) {
			return m_54S;
		}
	}
}




///plan/update : dynamically update value when condition has been typed 
int updatefeatureClassRecordNumber() {
	return 0;
}