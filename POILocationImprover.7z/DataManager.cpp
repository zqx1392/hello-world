#pragma once
#include "stdafx.h"
#include "AccessSV.h"
#include "ErrorManager.h"
#include "IOManager.h"
#include "DataManager.h"
#include <conio.h>

DataManager::DataManager() {
}

DataManager::~DataManager() {
}

void DataManager::setLogger(IOManager * IOCtrl) {
	m_IOCtrl = IOCtrl;
}
void DataManager::setAccSV(AccessSV * AccSV) {
	m_AccSV = AccSV;
}

void DataManager::setNewFile(const CString keyName, const CString fileName,const IOManager::FileType fileType) {
	CString convertedFileName = fileName;
	if (!_tcscmp(convertedFileName,_T(""))) {
		if (fileType == IOManager::FileType::ERR) {
			convertedFileName = L"err.log";
		}
		else if (fileType == IOManager::FileType::RUN) {
			convertedFileName = L"run.log";
		}
		else if (fileType == IOManager::FileType::OUTPUT) {
			convertedFileName = L"out.log";
		}
			
	}
	fileDesc tempFileDesc = { convertedFileName,fileType };
	m_fileList[keyName] = tempFileDesc;
}
void DataManager::setNewDB(const CString keyName, const CString serverName, const bool isFGDB, const bool doEdit) {
	CString convertedServerName = L"";
	CString convertedOwnerName =L"";
	CString convertedVersionName = L"";
	if (!isFGDB) {
		int startServerName = serverName.Find(L"@");
		int startVersionName = serverName.Find(L"(");
		if (startServerName == -1 || startVersionName == -1) {
			return;
		}
		convertedOwnerName = serverName.Mid(0, startServerName);
		convertedServerName = serverName.Mid(startServerName + 1, startVersionName - startServerName - 1);
		convertedVersionName = serverName.Mid(startVersionName + 1, serverName.GetLength() - startVersionName - 2);
	}
	CString fullDBName = "";
	if (doEdit) fullDBName = convertedOwnerName + "@" + convertedServerName + "(" + convertedVersionName + ")";
	else fullDBName = "RONLY@" + convertedServerName + "(" + convertedVersionName + ")";
	if (isFGDB) fullDBName = serverName;
	DBDesc tempDBDesc = { 
		convertedServerName,
		convertedOwnerName,
		convertedVersionName,
		fullDBName
	};
	m_DBList[keyName] = tempDBDesc;
}
void DataManager::setNewDB_divideUserDBVersion(const CString keyName, const CString serverName, const CString ownerName, const CString versionName, const bool isFGDB, const bool doEdit) {
	CString fullDBName = "";
	if (doEdit) fullDBName = ownerName + "@" + serverName + "(" + versionName + ")";
	else fullDBName = "RONLY@" + serverName + "(" + versionName + ")";
	if (isFGDB) fullDBName = serverName;
	DBDesc tempDBDesc = { 
		serverName,
		ownerName,
		versionName,
		fullDBName
	};
	m_DBList[keyName] = tempDBDesc;
}

void DataManager::setNewFeatureClass(const CString serverKeyName, const CString keyName, const CString serverName, const CString featureClassName, const bool isFGDB) {
	CString ownerName = L"";
	if (!isFGDB) {
		int startDBName = serverName.Find(L"@");
		ownerName = serverName.Mid(0, startDBName);
	}
	CString fullFeatureClassName = ownerName + "." + featureClassName;
	if (isFGDB) fullFeatureClassName = featureClassName;
	featureClassDesc tempTableDesc = {
		serverKeyName,
		featureClassName,
		ownerName,
		fullFeatureClassName
	};
	m_featureClassList[keyName] = tempTableDesc;
}
void DataManager::setNewFeatureClass_divideUserDBVersion(const CString serverKeyName, const CString keyName, const CString ownerName, const CString featureClassName, const bool isFGDB) {
	CString fullFeatureClassName = ownerName + "." + featureClassName;
	if (isFGDB) fullFeatureClassName = featureClassName;
	featureClassDesc tempTableDesc = { 
		serverKeyName,
		featureClassName,
		ownerName,
		fullFeatureClassName 
	};
	m_featureClassList[keyName] = tempTableDesc;
}
void DataManager::setNewFieldName(const CString keyName, const CString fieldName) {
	m_fieldNameList[keyName] = fieldName;
}
int DataManager::createFiles() {
	std::vector<CString> fileNameList;
	for (std::pair<CString, fileDesc> eachFile : m_fileList) {
		if (ErrorManager::RCode::R_SUCCESS != m_IOCtrl->initFile(eachFile.second.fileName, eachFile.second.fileType)) {
			return ErrorManager::RCode::R_FAILED_FATAL_ERROR;
		}
		else {
			fileNameList.push_back(eachFile.second.fileName);
		}
	}
	for (auto eachFile : fileNameList) {
		m_IOCtrl->print_run(eachFile + " has been created successfully");
	}
	return ErrorManager::RCode::R_SUCCESS;
}

int DataManager::initDBs() {
	for (std::pair<CString, DBDesc> eachDB : m_DBList) {
		if (HAS_ERROR == m_AccSV->setWorkspace(eachDB.second.fullDBName)) {
			m_IOCtrl->print_error(ErrorManager::ECode::E_FAILED_TO_OPEN_WORKSPACE, eachDB.second.fullDBName);
			return ErrorManager::RCode::R_FAILED_FATAL_ERROR;
		}
		else {
			CString successMsg = " has been connected successfully";
			CString printMsg = eachDB.second.fullDBName + successMsg;
			m_IOCtrl->print_run(printMsg);
		}
	}
	return ErrorManager::RCode::R_SUCCESS;
}

int DataManager::initFeatureClasses() {
	for (std::pair<CString, featureClassDesc> eachFeatureClass : m_featureClassList) {
		CString fullDBName = m_DBList[eachFeatureClass.second.serverKeyName].fullDBName;
		if (HAS_ERROR == m_AccSV->setFeatureClass(fullDBName, eachFeatureClass.second.fullFeatureClassName)) {
			m_IOCtrl->print_error(ErrorManager::ECode::E_FAILED_TO_OPEN_FEATURECLASS, eachFeatureClass.second.fullFeatureClassName);
			return ErrorManager::RCode::R_FAILED_FATAL_ERROR;
		}
		else {
			CString successMsg = " featureclass has been connected successfully";
			CString printMsg = eachFeatureClass.second.fullFeatureClassName + successMsg;
			m_IOCtrl->print_run(printMsg);
		}
	}
	return ErrorManager::RCode::R_SUCCESS;
}

std::map<CString, DataManager::DBDesc> DataManager::getDBList() {
	return m_DBList;
}

std::map<CString, DataManager::featureClassDesc> DataManager::getFeatureClassList() {
	return m_featureClassList;
}
std::map<CString, CComBSTR> DataManager::getFieldNameList() {
	return  m_fieldNameList;
}

//for this tool only
void DataManager::setSQL(const CString SQL){
	m_SQLText = SQL;
}
CString DataManager::getSQL() {
	if (m_SQLText.IsEmpty()) {
		return L"PRODUCT_C=1";
	}
	return m_SQLText;
}

