#pragma once
/**
* @brief	Manage input option for console application
*/

class OptionManager
{
public:

	IOManager * m_IOCtrl;					//Control IO
	
	OptionManager();
	~OptionManager();
	

	/**
	* @brief Set output management class
	* @param IOCtrl				[in]	Target output management class object
	*/
	void setLogger(IOManager * IOCtrl);
	/**
	* @brief Get all option from console 
	* @param argc				[in]	total argument number
	* @param argv				[in]	arguments
	* @return	RCode value [ex�FR_SUCCESS=0�AR_FAILED_FATAL_ERROR=1�A...]
	*/
	int getOption(const int argc, _TCHAR* argv[]);
	/**
	* @brief Print file description before start the program
	*/
	void printDescription();
	/**
	* @brief Print all option details
	* @param vm				[in]	boost's object list
	*/
	void print_all_option();

	boost::program_options::variables_map m_vm;		//Record option content
	std::wstring m_postalpoint_db;
	std::wstring m_postalpoint_layer;
	std::wstring m_postalpoint_field;
	std::wstring m_poi_info_db;
	std::wstring m_poi_info_layer;
	std::wstring m_poi_info_field;
	std::wstring m_sql;
	std::wstring m_run_log;
	std::wstring m_err_log;
	std::wstring m_db;
	std::wstring m_owner;
	std::wstring m_version;
	const char * k_postalpoint_db;
	const char * k_postalpoint_layer;
	const char * k_postalpoint_field;
	const char * k_poi_info_db;
	const char * k_poi_info_layer;
	const char * k_poi_info_field;
	const char * k_sql;
	const char * k_run_log;
	const char * k_err_log;
	const char * k_db;
	const char * k_owner;
	const char * k_version;
};