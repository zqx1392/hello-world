#pragma once


/**
* @brief Manage Input/Output file and control output print
*/
class IOManager
{
public: 
	ErrorManager * m_errorManager;		//Control error message format and code
	/**
	* @brief�@specific file type into error, run, output type.
	*/
	enum FileType : int {
	RUN 					= 0,
	ERR						= 1,
	OUTPUT					= 2,
	};
	/* static access method */
	static IOManager * getInstance();
	/**
	* @brief Set error management class
	* @param errCtrl		[in]	Target error management class object
	*/
	void setErrorManager(ErrorManager * errCtrl);
	/**
	* @brief Initialize selected file 
	* @param filePath		[in]	File path
	* @param fileType		[in]	run�Aerror�Aoutput file
	* @return	True if success�Afalse if error
	*/
	int initFile(const CString filePath,const FileType fileType);
	/**
	* @brief Close all file stream
	*/
	void closeFile();
	/**
	* @brief Print error message into error log and cerr
	* @param errorCode		[in]	ErrorManager::ECode
	* @param errorSource	[in]	Description of error(Source of error such as file path, DB, field setting)
	*/
	void print_error(const ErrorManager::ECode errorCode, const CString errorSource = _T(""));
	/**
	* @brief Print run message into run log and cout
	* @param runDesc		[in]	Message to print
	*/
	void print_run(const CString runDesc);
	/**
	* @brief Print run message into run log only
	* @param runDesc		[in]	Message to print
	*/
	void print_run_no_cout(const CString runDesc);
	/**
	* @brief Print run message without timestamp
	* @param runDesc		[in]	Message to print
	*/
	void print_no_timestamp_run(const CString runMsg);
	/**
	* @brief Get current time
	* @return	String of current time (HH::mm:ss)
	*/
	CString get_current_time();
	/**
	* @brief Print start line (timestamp + "Start :" messsage) into run log and cout
	*/
	void print_start();
	/**
	* @brief Print total execution time into run log and cout
	*/
	void print_total_execution_time();
	/**
	* @brief Print result into output file
	* @param output			[in]	Message to print
	*/
	template <typename T> void print_output(const T output);

private:
	static IOManager * _IOManager;				//singleton
	IOManager();
	~IOManager();

	std::fstream m_runLog,m_errLog;				//filestream for log
	std::ofstream m_outputFile;					//filestream for output file
	std::map<ErrorManager::ECode,ErrorManager::errorMsg> m_errorMessageGroup;
	time_t m_start_time;
};