#pragma once
#include "stdafx.h"
#include <arctl/coinitializer.h>
#include "POILocationImprover.h"

int _tmain(int argc, _TCHAR* argv[])
{

	arctl::coinitializer aCoInitializer;
	POILocationImprover cPOILocationImprover;
	if (0 != cPOILocationImprover.init(argc, argv)) {
		return 1;
	}
	return cPOILocationImprover.run();
}