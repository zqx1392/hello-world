#pragma once
#include "stdafx.h"
#include "errorManager.h"
#include "IOManager.h"
#include "OptionManager.h"
#include <WinLib/VersionInfo.h>
#include <conio.h>



OptionManager::OptionManager() {
	k_postalpoint_db = "inputPP";
	k_postalpoint_layer = "layerPP";
	k_postalpoint_field = "fieldPP";
	k_poi_info_db = "inputPOI";
	k_poi_info_layer = "layerPOI";
	k_poi_info_field = "fieldPOI";
	k_sql = "SQL";
	k_run_log = "run_log";
	k_err_log = "err_log";
	k_db = "DB";
	k_owner = "owner";
	k_version = "version";
}

OptionManager::~OptionManager() {
}
void OptionManager::setLogger(IOManager * IOCtrl) {
	m_IOCtrl = IOCtrl;
}

int OptionManager::getOption(const int argc, _TCHAR* argv[]) {
	using namespace boost::program_options;
	using namespace uh;
	options_description desc("Options");
	try {
		desc.add_options()
			("help,h", "Help screen")
			(k_postalpoint_db, wvalue<std::wstring>(&m_postalpoint_db)->required(), "POSTALPOINT DB User")
			(k_poi_info_db, wvalue<std::wstring>(&m_poi_info_db)->required(), "POI DB User")
			(k_postalpoint_layer, wvalue<std::wstring>(&m_postalpoint_layer)->required(), "POSTALPOINT LAYER Name")
			(k_poi_info_layer, wvalue<std::wstring>(&m_poi_info_layer)->required(), "POI Info LAYER Name")
			(k_postalpoint_field, wvalue<std::wstring>(&m_postalpoint_field)->required(), "Postalcode FIELD Name")
			(k_poi_info_field, wvalue<std::wstring>(&m_poi_info_field)->required(), "Actual Address FIELD Name")
			(k_sql, wvalue<std::wstring>(&m_sql), "SQL search query for POI Info")
			(k_run_log, wvalue<std::wstring>(&m_run_log), "Run log file path")
			(k_err_log, wvalue<std::wstring>(&m_err_log), "Error log file path");
		//END OF SETTING
		m_vm.clear();
		store(parse_command_line(argc, argv, desc), m_vm);
		notify(m_vm);

	}
	catch (const error &ex)
	{
		std::cerr << ex.what() << std::endl;
		std::cout << desc << std::endl;
		m_IOCtrl->print_error(ErrorManager::ECode::E_INVALID_OPTION, "Option setting");
		return ErrorManager::RCode::R_FAILED_FATAL_ERROR;
	}
	return ErrorManager::RCode::R_SUCCESS;
}
void OptionManager::printDescription() {
	//SETTING HERE
	CVersion cVer;
	CString toolName = cVer.GetInternalName();
	CString fileVersion = cVer.GetFileVersion();
	CString productVersion = cVer.GetProductVersion();
	m_IOCtrl->print_no_timestamp_run(toolName + " " + fileVersion + " " + productVersion);
	m_IOCtrl->print_no_timestamp_run(_T("[option]"));
	m_IOCtrl->print_no_timestamp_run(_T(""));
	print_all_option();
	m_IOCtrl->print_start();
	//END OF SETTING
}

void OptionManager::print_all_option() {
	using namespace boost::program_options;
	for (const auto& it : m_vm) {
		CString tmpString = "--" + (CString)it.first.c_str() + ": ";
		auto value = it.second.value();
		if (auto v = boost::any_cast<std::wstring>(&value)) {
			tmpString += v->c_str();
		}
		m_IOCtrl->print_no_timestamp_run(tmpString);
	}
	m_IOCtrl->print_no_timestamp_run("");
}

