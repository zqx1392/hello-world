#pragma once
/**
* @brief	Manage data and act as middleman between server, file, and core process who store all necessary data.
			All datas are stored in m_***list and require key to get correspond data
			For example, m_DBList["ROAD_LINK_DB"] will take "ROAD_LINK_DB" as a key and find DBDesc struct that link to the key.
			You can set key value to your own convenience by input keyName when using setNew***() function.
*/

class DataManager
{
public:

	IOManager * m_IOCtrl;				//Control IO
	AccessSV * m_AccSV;					//Control Server Access

	DataManager();
	~DataManager();
	//File Structure
	struct fileDesc {
		CString fileName;				//ex.  C:/HAHA/THISWAY.txt
		IOManager::FileType fileType;	//ex.  ERR,RUN,OUT
	};
	//DB Structure
	struct DBDesc {
		CString serverName;				//ex.  yakumo, arion
		CString ownerName;				//ex.  REFERENCE,THA201701
		CString versionName;			//ex.  SDE.DEFAULT
		CString fullDBName;				//ex.  RONLY@yakumo(SDE.DEFAULT)
	};
	//Featureclass Structure
	struct featureClassDesc {
		CString serverKeyName;		//ex.  --'inputPP'
		CString featureClassName;		//ex.  sindy::schema::citymesh::kfeatureClassName
		CString ownerName;				//ex.  REFERENCE,THA201701
		CString fullFeatureClassName;	//ex.  REFRENCE.MESHCITY
	};
	/**
	* @brief Set output management class
	* @param IOCtrl				[in]	Target IOManager class object
	*/
	void setLogger(IOManager * IOCtrl);
	/**
	* @brief Set server management class
	* @param AccSV				[in]	Target AccessSV class object
	*/
	void setAccSV(AccessSV * AccSV);
	/**
	* @brief Add new file into fileList for creation
	* @param keyName			[in]	Key name for calling a file data with m_fileList[keyName]
	* @param fileName			[in]	target file name aka file path
	* @param fileType			[in]	File type[ERR,RUN,OUT]
	*/
	void setNewFile(const CString keyName, const CString fileName,const IOManager::FileType fileType);
	/**
	* @brief Add new DB into DBList for creation
	* @param keyName			[in]	Key name for calling a DB data with m_DBList[keyName]
	* @param serverName			[in]	full SiNDY username [ex. TEST2017A@sindympa(SDE.DEFAULT)]
	* @param isFGDB				[in]	Is the target DB is FGDB
	* @param doEdit				[in]	If target db need to be edited
	*/
	void setNewDB(const CString keyName, const CString serverName, const bool isFGDB, const bool doEdit);
	/**
	* @brief Add new Database. Username, DB, version input are separate
	* @param keyName			[in]	Key name for calling a DB data with m_DBList[keyName]
	* @param serverName			[in]	target DB server name [ex. sindympa]
	* @param ownerName			[in]	target DB owner name [ex. TEST2017A]
	* @param versionName		[in]	target DB server name [ex. SDE.DEFAULT]
	* @param isFGDB				[in]	Is the target DB is FGDB
	* @param doEdit				[in]	If target db need to be edited
	*/
	void setNewDB_divideUserDBVersion(const CString keyName, const CString serverName, const CString  ownerName, const CString versionName, const bool isFGDB, const bool doEdit);
	/**
	* @brief Add new featureclass for creation 
	* @param keyName			[in]	Key name for calling a featureclass data with m_featureClassList[keyName]
	* @param featureClassName	[in]	target featureClass name [ex. sindy::schema::example:kfeatureClassName, "ROAD_LINK"]
	* @param isFGDB				[in]	Is the target DB is FGDB
	*/
	void setNewFeatureClass(const CString serverKeyName, const CString keyName, const CString serverName, const CString featureClassName, const bool isFGDB);
	/**
	* @brief Add new featureclass. Username, DB, version input are separate
	* @param keyName			[in]	Key name for calling a featureclass data with m_featureClassList[keyName]
	* @param ownerName			[in]	target DB owner name [ex. TEST2017A]
	* @param featureClassName	[in]	target featureClass name [ex. sindy::schema::example:kfeatureClassName, "ROAD_LINK"]
	* @param isFGDB				[in]	Is the target DB is FGDB
	*/
	void setNewFeatureClass_divideUserDBVersion(const CString serverKeyName, const CString keyName, const CString ownerName, const CString featureClassName, const bool isFGDB);
	/**
	* @brief Add new field name for usage 
	* @param keyName			[in]	Key name for calling a field name with m_fieldNameList[keyName]
	* @param fieldName			[in]	target field Name [ex. POSTAL_CODE, OBJECTID]
	*/
	void setNewFieldName(const CString keyName, const CString fieldName);
	/**
	* @brief Create all files that have been set from 'setNewFile' function
	* @return	RCode value [ex�FR_SUCCESS=0�AR_FAILED_FATAL_ERROR=1�A...]
	*/
	int createFiles();
	/**
	* @brief Initialize all DBs that have been set from 'setNewDB' and 'setNewDB_divideUserDBVersion' function
	* @return	RCode value [ex�FR_SUCCESS=0�AR_FAILED_FATAL_ERROR=1�A...]
	*/
	int initDBs();
	/**
	* @brief Initialize all featureclasses that have been set from 'setNewFeatureClass' and 'setNewFeatureClass_divideUserDBVersion' function
	* @return	RCode value [ex�FR_SUCCESS=0�AR_FAILED_FATAL_ERROR=1�A...]
	*/
	int initFeatureClasses();
	/**
	* @brief Get DB list
	* @return	List of DB
	*/
	std::map<CString, DBDesc> getDBList();
	/**
	* @brief Get featureclass list
	* @return	List of featureclass
	*/
	std::map<CString, featureClassDesc> getFeatureClassList();
	/**
	* @brief Get PostalPoint field (POSTAL_CODE)
	* @return	POSTAL_CODE field name
	*/
	std::map<CString, CComBSTR> getFieldNameList();
	
	/// FOR THIS TOOL ONLY
	/**
	* @brief Get input SQL
	* @return	SQL string
	*/
	void setSQL(const CString SQL);
	/**
	* @brief Get input SQL
	* @return	SQL string
	*/
	CString getSQL();
private:
	std::map<CString, DBDesc> m_DBList;			//Store all set DB list
	std::map<CString, fileDesc> m_fileList;		//Store all set file list
	std::map<CString, featureClassDesc> m_featureClassList;	//Store all set featureClass list
	std::map<CString, CComBSTR> m_fieldNameList;	//Store all set field name such as ACTUALADDRESS, POSTAL_CODE 
	CString m_SQLText;							//Store SQL text used for where clause
	static const int HAS_ERROR = 1;
};