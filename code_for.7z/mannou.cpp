#pragma once
#include "stdafx.h"
#include "mannou.h"

mannou::mannou(void)
{ 
}

mannou::~mannou(void)
{
}

int mannou::initFile(CString filePath,CString fileType){
	if (!_tcscmp(filePath,_T(""))){
		print_error(ECode::E_FAILED_TO_OPEN_FILE_PATH);
		return RCode::R_FAILED_FATAL_ERROR;
	}
	if (!_tcscmp(fileType,_T("ERR"))){
		errLog.open(filePath,std::ios_base::app);
		if (!errLog.is_open()){
			print_error(ECode::E_FAILED_TO_OPEN_FILE_PATH,filePath);
			return R_FAILED_FATAL_ERROR;
		}
		errLog.seekg (0, errLog.end);
		//���̃t�@�C���͂�����ۂȂ�G���[�w�b�_�����܂��B
		if (!errLog.tellg()){
			errLog << "ERROR_TYPE" << "\t" << "TIME" << "\t" << "ERROR_CODE" << "\t" << "ERROR_MSG" << std::endl;
		}
		errLog.seekg (0, errLog.beg);
	}
	else if(!_tcscmp(fileType,_T("RUN"))){
		runLog.open(filePath, std::ios_base::app);
		if (!runLog.is_open()){
			print_error(ECode::E_FAILED_TO_OPEN_FILE_PATH,filePath);
			return R_FAILED_FATAL_ERROR;
		}
	}
	//TODO make map that support multiple output file
	else if(!_tcscmp(fileType,_T("OUT"))){
		outputFile.open(filePath);
		if (!outputFile.is_open()){
			print_error(ECode::E_FAILED_TO_OPEN_FILE_PATH,filePath);
			return R_FAILED_FATAL_ERROR;
		}
	}
	else {
		return R_FAILED_FATAL_ERROR;
	}
	return R_SUCCESS;
}

void mannou::closeFile(){
	if (runLog.is_open()){
		runLog.close();
	}
	if (errLog.is_open()){
		errLog.close();
	}
	if (outputFile.is_open()){
		outputFile.close();
	}
}

void mannou::initErrorMessage(){
	createEachMessageFormat(E_INVALID_OPTION,_T("OPTION_ERROR"),_T("is incorrect"));
	createEachMessageFormat(E_FAILED_TO_OPEN_FILE_PATH,_T("FILE_ERROR"),_T("filepath cannot be found"));
	createEachMessageFormat(E_FAILED_TO_OPEN_WORKSPACE,_T("DB_ERROR"),_T("DB cannot be opened"));
	createEachMessageFormat(E_FAILED_TO_OPEN_FEATURECLASS,_T("FEATURECLASS_ERROR"),_T("featureclass cannot be opened"));
	createEachMessageFormat(E_FAILED_TO_SEARCH,_T("PROCESS_ERROR"),_T("failed to search"));
	createEachMessageFormat(E_FAILED_TO_GET_DATA,_T("PROCESS_ERROR"),_T("cannot be acquired"));
	createEachMessageFormat(E_FAILED_TO_SET_DATA,_T("PROCESS_ERROR"),_T("cannot be set"));
	createEachMessageFormat(E_FAILED_TO_PROCESS,_T("PROCESS_ERROR"),_T("has unexpected error"));
	createEachMessageFormat(E_COM_ERROR_IS_CATCHED,_T("COM_ERROR"),_T("catch _com_error in method"));
}

void mannou::createEachMessageFormat(ECode errorCode,CString errorType,CString errorDesc){
	mannou::errorMsg tempErrorMessage = {errorCode,errorType,errorDesc};
	errorMessageGroup[errorCode] = tempErrorMessage;
}

void mannou::print_error(ECode errorCode, CString errorSource){
	if (errLog.is_open())
		errLog << CT2A(errorMessageGroup[errorCode].errorType) << "\t" << print_current_time().c_str() << "\t" << errorCode  << "\t" << CT2A(errorSource) << " " << CT2A(errorMessageGroup[errorCode].errorDesc) << std::endl;
	std::cerr << CT2A(errorSource) << " " << CT2A(errorMessageGroup[errorCode].errorDesc) <<   std::endl;
}

void mannou::print_run(CString runMsg){
	if (runLog.is_open()){
		runLog << print_current_time() << "\t" << CT2A(runMsg) << std::endl;
	}
	std::cout << print_current_time() << "\t" << CT2A(runMsg) << std::endl;
}

void mannou::print_no_timestamp_run(CString runMsg){
	if (runLog.is_open()){
		runLog << CT2A(runMsg) << std::endl;
	}
	std::cout << CT2A(runMsg) << std::endl;
}

std::string mannou::print_current_time(){
	time_t rawtime;
	struct tm * timeinfo;
	char buffer[80];
	time (&rawtime);
	timeinfo = localtime(&rawtime);
	strftime(buffer,80,"%Y-%m-%d %I:%M:%S",timeinfo);
	std::string str(buffer);
	return str;
}

void mannou::print_start(){
	time(&start_time);
	runLog << "Start: " << print_current_time()  << std::endl << std::endl;
	std::cout <<  "Start: " << print_current_time() << std::endl << std::endl;
}

void mannou::print_total_execution_time(){
	double total_time;
	time_t end_time;
	time(&end_time);
	total_time = difftime(end_time,start_time);
	runLog << "Total execution time: " << total_time << "s" << std::endl;
	std::cout << "Total execution time: " << total_time << "s" << std::endl;
}

template <typename T> void mannou::print_output(T output){
	outputFile << output << std::endl;
}
template void mannou::print_output<int>(int output);