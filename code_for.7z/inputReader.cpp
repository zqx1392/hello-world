#pragma once
#include "stdafx.h"
#include "mannou.h"
#include <conio.h>
#include "AccessSV.h"
#include "inputReader.h"


inputReader::inputReader() {
}

inputReader::~inputReader() {
}

void inputReader::setLogger(mannou * IOCtrl) {
	_IOCtrl = IOCtrl;
}
void inputReader::setAccSV(AccessSV * AccSV) {
	_AccSV = AccSV;
}

int inputReader::getOption(int argc, _TCHAR* argv[]) {
	using namespace boost::program_options;
	options_description desc("Options");
	try {
		//SETTING HERE
		POSTALPOINT = "PP";
		POI = "POI";
		INPUT = "input";
		LAYER = "layer";
		FIELD = "field";
		SQL = "SQL";
		RUN_LOG = "run_log";
		ERR_LOG = "err_log";
		std::string PPFIELD = "PPFIELD";
		std::string POIFIELD = "POIFIELD";
		desc.add_options()
			("help,h", "Help screen")
			((INPUT + POSTALPOINT).c_str(), wvalue<std::wstring>()->required(), "POSTALPOINT DB User")
			((INPUT + POI).c_str(), wvalue<std::wstring>()->required(), "POI DB User")
			((LAYER + POSTALPOINT).c_str(), wvalue<std::wstring>()->required(), "Postalpoint Layer Name")
			((LAYER + POI).c_str(), wvalue<std::wstring>()->required(), "POI Info Layer Name")
			((FIELD + POSTALPOINT).c_str(), wvalue<std::wstring>()->required(), "Postalcode Field Name")
			((FIELD + POI).c_str(), wvalue<std::wstring>()->required(), "Actual Address Field Name")
			(SQL.c_str(), wvalue<std::wstring>(), "SQL search query for POI Info")
			(RUN_LOG.c_str(), wvalue<std::wstring>(), "Run log file path")
			(ERR_LOG.c_str(), wvalue<std::wstring>(), "Error log file path");
		//END OF SETTING
		store(parse_command_line(argc, argv, desc), vm);
		notify(vm);

		//SETTING HERE
		bool doEdit = true;
		bool isPOI_FGDB = false;
		bool isPP_FGDB = false;
		if (vm[INPUT + POI].as<std::wstring>().find(L"@") == std::string::npos && vm[INPUT + POI].as<std::wstring>().find(L".gdb") != std::string::npos) isPOI_FGDB = true;
		if (vm[INPUT + POSTALPOINT].as<std::wstring>().find(L"@") == std::string::npos && vm[INPUT + POSTALPOINT].as<std::wstring>().find(L".gdb") != std::string::npos) isPP_FGDB = true;
		CString POSTALPOINT_LAYER_NAME = vm[LAYER + POSTALPOINT].as<std::wstring>().c_str();
		CString POI_LAYER_NAME = vm[LAYER + POI].as<std::wstring>().c_str();
		setNewFile(ERR_LOG, _T("ERR"));
		setNewFile(RUN_LOG, _T("RUN"));
		setNewDB(INPUT + POSTALPOINT, isPP_FGDB, !doEdit);
		setNewDB(INPUT + POI, isPOI_FGDB, doEdit);
		setNewTable(INPUT + POSTALPOINT, POSTALPOINT_LAYER_NAME, isPP_FGDB);
		setNewTable(INPUT + POI, POI_LAYER_NAME, isPOI_FGDB);
		setNewField(FIELD + POSTALPOINT, PPFIELD);
		setNewField(FIELD + POI, POIFIELD);
		//END OF SETTING

	}
	catch (const error &ex)
	{
		std::cerr << ex.what() << std::endl;
		std::cout << desc << std::endl;
		_IOCtrl->print_error(mannou::ECode::E_INVALID_OPTION, "Option setting");
		return mannou::RCode::R_FAILED_FATAL_ERROR;
	}
	return mannou::RCode::R_SUCCESS;
}
	void inputReader::printDescription() {
		//SETTING HERE
		_IOCtrl->print_no_timestamp_run(_T("POILocationImprover.exe FILEVERSION:1.0.0.0  PRODUCTVERSION:1.0.0.0"));
		_IOCtrl->print_no_timestamp_run(_T("[option]"));
		_IOCtrl->print_no_timestamp_run(_T(""));
		print_all_option();
		_IOCtrl->print_start();
		//END OF SETTING
	}
	void inputReader::setNewFile(std::string optionName, CString fileType) {
		CString fileName;
		if (vm[optionName].empty()) {
			fileName = fileType + ".log";
		}
		else {
			fileName = vm[optionName].as<std::wstring>().c_str();
		}
		fileDesc tempFileDesc = { optionName,fileName,fileType };
		fileList[optionName] = tempFileDesc;
	}
	void inputReader::setNewDB(std::string optionName, bool isFGDB, bool doEdit) {
		std::string serverName = optionName;
		std::wstring tempName = vm[serverName].as<std::wstring>();
		std::wstring DBName = L"";
		std::wstring versionName = L"";
		if (!isFGDB) {
			size_t startDBName = tempName.find(L"@");
			size_t startVersionName = tempName.find(L"(");
			DBName = tempName.substr(startDBName + 1, startVersionName - startDBName - 1);
			versionName = tempName.substr(startVersionName + 1, tempName.length() - startVersionName - 2);
		}
		CString convertedServerName = vm[serverName].as<std::wstring>().c_str();
		CString convertedOwnerName = DBName.c_str();
		CString convertedVersionName = versionName.c_str();
		CString fullDBName = "";
		if (doEdit) fullDBName = convertedOwnerName + "@" +  convertedServerName + "(" + convertedVersionName + ")";
		else fullDBName = "RONLY@" + convertedServerName + "(" + convertedVersionName + ")";
		if (isFGDB) fullDBName = convertedServerName;
		DBDesc tempDBDesc = { optionName,
			convertedServerName,
			convertedOwnerName,
			convertedVersionName,
			fullDBName
		};
		DBList[optionName] = tempDBDesc;
	}
	void inputReader::setNewDB_divideUserDBVersion(std::string optionName, bool isFGDB, bool doEdit) {
		std::string serverName = optionName + DB;
		std::string ownerName = optionName + OWNER;
		std::string versionName = optionName + VERSION;
		CString convertedServerName = vm[serverName].as<std::wstring>().c_str();
		CString convertedOwnerName = vm[ownerName].as<std::wstring>().c_str();
		CString convertedVersionName = vm[versionName].as<std::wstring>().c_str();
		CString fullDBName = "";
		if (doEdit) fullDBName = convertedOwnerName + "@" + convertedServerName + "(" + convertedVersionName + ")";
		else fullDBName = "RONLY@" + convertedServerName + "(" + convertedVersionName + ")";
		if (isFGDB) fullDBName = convertedServerName;
		DBDesc tempDBDesc = { optionName,
		convertedServerName,
		convertedOwnerName,
		convertedVersionName,
		fullDBName
		};
		DBList[optionName] = tempDBDesc;
	}

	void inputReader::setNewTable(std::string optionName, CString tableName, bool isFGDB) {
		std::string serverName = optionName;
		std::wstring tempName = vm[serverName].as<std::wstring>();
		std::wstring ownerName = L"";
		if (!isFGDB) {
			size_t startDBName = tempName.find(L"@");
			ownerName = tempName.substr(0, startDBName);
		}
		CString convertedOwnerName = ownerName.c_str();
		CString convertedFullTableName = convertedOwnerName + "." + tableName;
		if (isFGDB) convertedFullTableName = tableName;
		tableDesc tempTableDesc = {optionName,tableName,convertedOwnerName,convertedFullTableName};
		tableList[optionName] = tempTableDesc;
	}
	void inputReader::setNewTable_divideUserDBVersion(std::string optionName, CString tableName, bool isFGDB) {
		std::string ownerName = optionName + OWNER;
		CString convertedOwnerName = vm[ownerName].as<std::wstring>().c_str();
		CString convertedFullTableName = convertedOwnerName + "." + tableName;
		if (isFGDB) convertedFullTableName = tableName;
		tableDesc tempTableDesc = { optionName,tableName,convertedOwnerName,convertedFullTableName };
		tableList[optionName] = tempTableDesc;
	}
	int inputReader::setFileOption() {
		std::vector<CString> fileNameList;
		for (std::pair<std::string, fileDesc> eachFile : fileList) {
			if (mannou::RCode::R_SUCCESS_WITH_ERROR < _IOCtrl->initFile(eachFile.second.fileName, eachFile.second.fileType)) {
				return mannou::RCode::R_FAILED_FATAL_ERROR;
			}
			else {
				fileNameList.push_back(eachFile.second.fileName);
			}
		}
		for (auto eachFile : fileNameList) {
			_IOCtrl->print_run(eachFile + " has been created successfully");
		}
		return mannou::RCode::R_SUCCESS;
	}

	int inputReader::setDbOption() {
		for (std::pair<std::string, DBDesc> eachDB : DBList) {
			if (!_AccSV->setWorkspace(eachDB.second.fullDBName)) {
				_IOCtrl->print_error(mannou::ECode::E_FAILED_TO_OPEN_WORKSPACE, eachDB.second.fullDBName);
				return mannou::RCode::R_FAILED_FATAL_ERROR;
			}
			else {
				CString successMsg = " has been connected successfully";
				CString printMsg = eachDB.second.fullDBName + successMsg;
				_IOCtrl->print_run(printMsg);
			}
		}
		return mannou::RCode::R_SUCCESS;
	}

	int inputReader::setTable() {
		for (std::pair<std::string, tableDesc> eachTable : tableList) {
			CString fullDBName = DBList[eachTable.second.optionName].fullDBName;
			if (!_AccSV->setFeatureClass(_AccSV->getWorkspace(fullDBName), eachTable.second.fullTableName)) {
				_IOCtrl->print_error(mannou::ECode::E_FAILED_TO_OPEN_FEATURECLASS, eachTable.second.fullTableName);
				return mannou::RCode::R_FAILED_FATAL_ERROR;
			}
			else {
				CString successMsg = " featureclass has been connected successfully";
				CString printMsg = eachTable.second.fullTableName + successMsg;
				_IOCtrl->print_run(printMsg);
			}
		}
		return mannou::RCode::R_SUCCESS;
	}
	std::map<std::string, inputReader::tableDesc> inputReader::getTableList() {
		return tableList;
	}
	void inputReader::setNewField(std::string optionName,std::string keyword) {
		std::string fieldName = optionName; 
		std::wstring tempName = vm[fieldName].as<std::wstring>();
		_bstr_t convertedFieldName = tempName.c_str();
		fieldList[keyword] = convertedFieldName;
	}

	std::map<std::string, _bstr_t> inputReader::getFieldList() {
		return fieldList;
	}
	std::wstring inputReader::getSQL() {
		if (vm[SQL].empty()) {
			return L"PRODUCT_C=1";
		}
		std::wstring SQLtext = vm[SQL].as<std::wstring>();
		return SQLtext;
	}
	void inputReader::print_all_option() {
		using namespace boost::program_options;
		for (const auto& it : vm) {
			CString tmpString = "--" + (CString)it.first.c_str() + ": ";
			auto value = it.second.value();
			if (auto v = boost::any_cast<int>(&value)) {
				CString v2;
				if (*v == 1) {
					tmpString += "1 (���s�҃����N�̐l�ԋ��p���܂ތ������[�h)";
				}
				else {
					tmpString += "2 (���s�҃����N�̐l�ԋ��p�������������[�h)";
				}
			}
			else if (auto v = boost::any_cast<std::wstring>(&value)) {
				tmpString += v->c_str();
			}
			_IOCtrl->print_no_timestamp_run(tmpString);
		}
		_IOCtrl->print_no_timestamp_run("");
	}
