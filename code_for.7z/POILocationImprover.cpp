// POILocationImprover.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include "mannou.h"
#include "AccessSV.h"
#include "inputReader.h"
#include <arctl/coinitializer.h>


int endProgramWithError(inputReader& inputReader, CString errorPoint) {
	CString errorDesc = "An error occured during " + errorPoint;
	inputReader._IOCtrl->print_run(errorDesc);
	CString errorType;
	if (!_tcscmp(errorPoint, (CString)"Com Error")) {
		errorType = "Exception Error";
	}
	else {
		errorType = "Unsuccessful Termination";
	}
	inputReader._IOCtrl->print_no_timestamp_run(errorType);
	inputReader._IOCtrl->print_no_timestamp_run("");
	inputReader._IOCtrl->closeFile();
	return 0;
}

bool is_number(const std::wstring& s)
{
	return !s.empty() && std::find_if(s.begin(),
		s.end(), [](char c) { return !std::iswdigit(c); }) == s.end();
}
/**
* @brief Get all postal code record from POSTALPOINT and store its coordinates in std::map
* @param PPFeatureClassName		[in]	POSTALPOINT featureclass name
* @param PPFeatureClass		[in]	IFeatureClass for POSTALPOINT
* @param PPFIELD		[in]	target postal code field name
* @param inputReader		[in]	IO management class
* @param PPCoordinates		[out]	Store { postal code : coordinate X, coordinate Y } as { key : value }
* @return	RCode value [ex�FR_SUCCESS=0�AR_SUCCESS_WITH_ERROR���P�AR_FAILED_FATAL_ERROR=2�A...]
*/
int findPPPostalCode( CString PPFeatureClassName, IFeatureClassPtr & PPFeatureClass, _bstr_t PPFIELD, inputReader* inputReader, std::map<_bstr_t, std::pair<double, double> > * PPCoordinates) {
	
	IQueryFilterPtr PPipQueryFilter(CLSID_QueryFilter);
	//set Postal Code as search target field
	_bstr_t columnFilter =  PPFIELD + ",SHAPE";
	if (S_OK != PPipQueryFilter->put_SubFields(columnFilter)) {
		inputReader->_IOCtrl->print_error(mannou::ECode::E_FAILED_TO_SET_DATA, _T("Search field"));
		return mannou::RCode::R_FAILED_FATAL_ERROR;
	}
	//set all condition into query variable
	IFeatureCursorPtr ipPPCursor;
	if (S_OK != PPFeatureClass->Search(PPipQueryFilter, VARIANT_FALSE, &ipPPCursor)) {
		inputReader->_IOCtrl->print_error(mannou::ECode::E_FAILED_TO_SEARCH, PPFeatureClassName);
		return mannou::RCode::R_FAILED_FATAL_ERROR;
	}
	// get column index
	long postalCodeIndex;
	if (S_OK != ipPPCursor->Fields->FindField(PPFIELD, &postalCodeIndex)) {
		CString errorMsg = "Postal Code field index";
		inputReader->_IOCtrl->print_error(mannou::ECode::E_FAILED_TO_GET_DATA, errorMsg);
		return mannou::RCode::R_FAILED_FATAL_ERROR;
	}
	CString msg = (LPCTSTR)PPFIELD + (CString)" field has been acquired successfully";
	inputReader->_IOCtrl->print_run(msg);
	//get target postal code
	IFeaturePtr ipPPFeature;
	while (ipPPCursor->NextFeature(&ipPPFeature) == S_OK && ipPPFeature) {
			// get postal code data
			_variant_t postalCode;
			if (S_OK != ipPPFeature->get_Value(postalCodeIndex, &postalCode)) {
				CString errorMsg = "Postal Code";
				inputReader->_IOCtrl->print_error(mannou::ECode::E_FAILED_TO_GET_DATA, errorMsg);
				return mannou::RCode::R_FAILED_FATAL_ERROR;
			}
			// get shape
			IGeometryPtr ipPPGeom;
			if (S_OK != ipPPFeature->get_ShapeCopy(&ipPPGeom)) {
				CString errorMsg = (CString)"Postal Code : " + postalCode.bstrVal;
				inputReader->_IOCtrl->print_error(mannou::ECode::E_FAILED_TO_GET_DATA, errorMsg);
				return mannou::RCode::R_FAILED_FATAL_ERROR;
			}

			// get PP coordinates
			double orgX = 0.0, orgY = 0.0;
			if (S_OK != IPointPtr(ipPPGeom)->QueryCoords(&orgX, &orgY) || orgX == 0 || orgY == 0) {
				CString errorMsg = (CString)"Postal Code : " + postalCode.bstrVal + " coordinates";
				inputReader->_IOCtrl->print_error(mannou::ECode::E_FAILED_TO_GET_DATA, errorMsg);
				continue;
			}

			// store coordinates in map
			std::pair<std::map<_bstr_t, std::pair<double, double> >::iterator, bool> isSuccess;
			isSuccess = PPCoordinates->insert(std::make_pair((_bstr_t)postalCode.bstrVal,std::make_pair(orgX,orgY)));
			// if postal code is already stored
			if (isSuccess.second == false) {
				CString errorMsg = (CString)"Postal Code : " + postalCode.bstrVal + " has more than 1 record in POSTALPOINT,";
				inputReader->_IOCtrl->print_error(mannou::ECode::E_FAILED_TO_GET_DATA, errorMsg);
				return mannou::RCode::R_FAILED_FATAL_ERROR;
			}
		}
	return mannou::RCode::R_SUCCESS;
}
/**
* @brief Replace POI_INFO location coordinates with POSTALPOINT location coordinates whose postal code matched
* @param objectID		[in]	A record of POI_INFO's Object ID
* @param postalCode		[in]	A record of POI_INFO's postal code
* @param ipPOIGeom		[in]	A record of POI_INFO's shape (location which stores coordinates)
* @param inputReader		[in]	IO management class
* @param PPCoordinates		[in]	Store { postal code : coordinate X, coordinate Y } as { key : value }
* @return	RCode value [ex�FR_SUCCESS=0�AR_SUCCESS_WITH_ERROR���P�AR_FAILED_FATAL_ERROR=2�A...]
*/
int copyPostalPointCoordinates(CString objectID, _bstr_t postalCode, IGeometryPtr & ipPOIGeom, inputReader* inputReader, std::map<_bstr_t, std::pair<double, double> > * PPCoordinates) {

	double bakX = 0.0, bakY = 0.0;
	// if not found match postal code
	if (PPCoordinates->find(postalCode) == PPCoordinates->end()) {
		CString errorMsg = (CString)"POI_INFO OBJECTID " + objectID + " Postal Code : " + (BSTR)postalCode + " is not found in POSTALPOINT,";
		inputReader->_IOCtrl->print_error(mannou::ECode::E_FAILED_TO_GET_DATA, errorMsg);
		return mannou::RCode::R_FAILED_FATAL_ERROR;
	}
	// get POI coordinates
	if (S_OK != IPointPtr(ipPOIGeom)->QueryCoords(&bakX, &bakY) || bakX == 0 || bakY == 0) {
		CString errorMsg = (CString)"POI_INFO OBJECTID : " + objectID + " coordinates";
		inputReader->_IOCtrl->print_error(mannou::ECode::E_FAILED_TO_GET_DATA, errorMsg);
		return mannou::RCode::R_FAILED_FATAL_ERROR;
	}
	double newX = PPCoordinates->find(postalCode)->second.first;
	double newY = PPCoordinates->find(postalCode)->second.second;
	// compare coordinates if it already copied
	if (newX == bakX && newY == bakY) {
		inputReader->_IOCtrl->print_run((CString)"POI_INFO OBJECTID = " + objectID + " : Coordinates are already accurate.");
		return mannou::RCode::R_SUCCESS_WITH_ERROR;
	}
	// edit POI coordinates
	// STILL NOT UPDATE TO DATABASE YET!
	if (S_OK != IPointPtr(ipPOIGeom)->PutCoords(newX, newY)) {
		CString errorMsg = (CString)"POI_INFO OBJECTID : " + objectID + " new coordinates";
		inputReader->_IOCtrl->print_error(mannou::ECode::E_FAILED_TO_SET_DATA, errorMsg);

		return mannou::RCode::R_FAILED_FATAL_ERROR;
	}
	return mannou::RCode::R_SUCCESS;
}

/**
* @brief Access POI_INFO actual address field and acquire 6-digit postal code from provided address 
* @param inputReader		[in]	IO management class
* @return	RCode value [ex�FR_SUCCESS=0�AR_SUCCESS_WITH_ERROR���P�AR_FAILED_FATAL_ERROR=2�A...]
*/
int getPOIActualAddress(inputReader* inputReader) {
	//setting variables 
	int returnStatus = mannou::RCode::R_SUCCESS;
	std::map<std::string, inputReader::tableDesc> tableList = inputReader->getTableList();
	std::map<std::string, _bstr_t> fieldList = inputReader->getFieldList();
	CString PPFeatureClassName = tableList["inputPP"].fullTableName;
	CString POIFeatureClassName = tableList["inputPOI"].fullTableName;
	IFeatureClassPtr PPFeatureClass =  inputReader->_AccSV->getFeatureClass(PPFeatureClassName);
	IFeatureClassPtr POIFeatureClass = inputReader->_AccSV->getFeatureClass(POIFeatureClassName);
	IQueryFilterPtr POIipQueryFilter(CLSID_QueryFilter);
	_bstr_t PPFIELD = fieldList["PPFIELD"];
	_bstr_t POIFIELD = fieldList["POIFIELD"];


	// get all avaliable postal codes with their coordinates
	std::map<_bstr_t, std::pair<double, double> > PPCoordinates;
	if (mannou::RCode::R_SUCCESS_WITH_ERROR < findPPPostalCode(PPFeatureClassName, PPFeatureClass, PPFIELD, inputReader, &PPCoordinates)) {
		inputReader->_IOCtrl->print_error(mannou::ECode::E_FAILED_TO_GET_DATA, _T("Postal code coordinates list"));
		return mannou::RCode::R_FAILED_FATAL_ERROR;
	}
	inputReader->_IOCtrl->print_run((CString)"Postal code coordinates list has been acquired successfully");
	
	//set search (where) condition
	_bstr_t queryFilter = inputReader->getSQL().c_str();
	if (S_OK != POIipQueryFilter->put_WhereClause(queryFilter)) {
		inputReader->_IOCtrl->print_error(mannou::ECode::E_FAILED_TO_SET_DATA, _T("Set search query"));
		return mannou::RCode::R_FAILED_FATAL_ERROR;
	}
	
	//set Object ID, actual address, shape as search target fields
	_bstr_t columnFilter = "OBJECTID," + POIFIELD + ",SHAPE";
	if (S_OK != POIipQueryFilter->put_SubFields(columnFilter)) {
		inputReader->_IOCtrl->print_error(mannou::ECode::E_FAILED_TO_SET_DATA, _T("Set search field"));
		return mannou::RCode::R_FAILED_FATAL_ERROR;
	}

	//set all condition into query variable
	IFeatureCursorPtr ipPOICursor;
	if (S_OK != POIFeatureClass->Search(POIipQueryFilter, VARIANT_FALSE, &ipPOICursor)) {
		inputReader->_IOCtrl->print_error(mannou::ECode::E_FAILED_TO_SEARCH, POIFeatureClassName);
		return mannou::RCode::R_FAILED_FATAL_ERROR;
	}

	//count total target records
	long progressCount = 0;
	long successShapeCopyCount = 0;
	if (S_OK != POIFeatureClass->FeatureCount(POIipQueryFilter, &progressCount)) {
		inputReader->_IOCtrl->print_error(mannou::ECode::E_FAILED_TO_SEARCH, POIFeatureClassName);
		return mannou::RCode::R_FAILED_FATAL_ERROR;
	}
	CString progressCountString;
	progressCountString.Format(L"%ld", progressCount);
	inputReader->_IOCtrl->print_run((CString)"Total target record : " + progressCountString);

	// get column index
	IFeaturePtr ipPOIFeature;
	long actualAddressIndex;
	if (S_OK != ipPOICursor->Fields->FindField(POIFIELD, &actualAddressIndex)) {
		CString errorMsg = "Actual Address field index";
		inputReader->_IOCtrl->print_error(mannou::ECode::E_FAILED_TO_GET_DATA, errorMsg);
		return mannou::RCode::R_FAILED_FATAL_ERROR;
	}
	CString msg = (LPCTSTR)POIFIELD + (CString)" field has been acquired successfully";
	inputReader->_IOCtrl->print_run(msg);
	while (ipPOICursor->NextFeature(&ipPOIFeature) == S_OK && ipPOIFeature) {
		// get objectID
		_variant_t objectID;
		if (S_OK != ipPOIFeature->get_Value(0, &objectID)) {
			CString errorMsg = (CString)"POI_INFO OBJECTID";
			inputReader->_IOCtrl->print_error(mannou::ECode::E_FAILED_TO_GET_DATA, errorMsg);
			return mannou::RCode::R_FAILED_FATAL_ERROR;
		}
		// get actual address data
		_variant_t actualAddress;
		if (S_OK != ipPOIFeature->get_Value(actualAddressIndex, &actualAddress)) {
			CString errorMsg = "Actual Address";
			inputReader->_IOCtrl->print_error(mannou::ECode::E_FAILED_TO_GET_DATA, errorMsg);
			return mannou::RCode::R_FAILED_FATAL_ERROR;
		}

		// if actual address data is empty
		CString objID;
		objID.Format(L"%ld", objectID.lVal);
		if (actualAddress.bstrVal == NULL) {
			inputReader->_IOCtrl->print_run((CString)"Skip POI_INFO OBJECTID = " +  objID +" : Doesn't contain actual address.");
			continue;
		}
		//get 6-digit postal code
		//assert(actualAddress.bstrVal != nullptr);
		std::wstring convertedAddress(actualAddress.bstrVal,SysStringLen(actualAddress.bstrVal));
		if (convertedAddress.length() < 6) {
			inputReader->_IOCtrl->print_run((CString)"Skip POI_INFO OBJECTID = " + objID + " : Doesn't contain valid 6-digit postal code at the end of address.");
			continue;
		}
		std::wstring postalCode = convertedAddress.substr(convertedAddress.length() - 6);
		// check if postalcode is valid 6-digit number
		if (!is_number(postalCode)) {
			inputReader->_IOCtrl->print_run((CString)"Skip POI_INFO OBJECTID = " + objID + " : Doesn't contain valid 6-digit postal code at the end of address.");
			continue;
		}
		_bstr_t convertedPostalCode = SysAllocStringLen(postalCode.data(), postalCode.size());

		// get POI shape
		IGeometryPtr ipPOIGeom;
		if (S_OK != ipPOIFeature->get_Shape(&ipPOIGeom)) {
			CString errorMsg = (CString)"OBJECTID : " + objID + " shape";
			inputReader->_IOCtrl->print_error(mannou::ECode::E_FAILED_TO_GET_DATA, errorMsg);
			returnStatus = mannou::RCode::R_SUCCESS_WITH_ERROR;
			continue;
		}

		//START COPYING SHAPE
		int returnStatus = copyPostalPointCoordinates(objID, convertedPostalCode, ipPOIGeom, inputReader, &PPCoordinates);
		if (mannou::RCode::R_SUCCESS_WITH_ERROR <= returnStatus ) {
			if (mannou::RCode::R_SUCCESS_WITH_ERROR < returnStatus ) returnStatus = mannou::RCode::R_SUCCESS_WITH_ERROR;
			continue;
		}
		///CAUTION!!! UPDATE THE MODIFIED COORDINATES TO DATABASE
		///CAUTION!!! UPDATE THE MODIFIED COORDINATES TO DATABASE
		ipPOIFeature->Store();
		///CAUTION!!! UPDATE THE MODIFIED COORDINATES TO DATABASE
		///CAUTION!!! UPDATE THE MODIFIED COORDINATES TO DATABASE
		inputReader->_IOCtrl->print_run((CString)"POI_INFO OBJECTID = " + objID + " : has been updated successfully.");
		successShapeCopyCount++;
	}
	// print total updated POI_INFO shape
	CString successShapeCopyCountString;
	successShapeCopyCountString.Format(L"%ld", successShapeCopyCount);
	inputReader->_IOCtrl->print_run((CString)"Successfully updated : " + successShapeCopyCountString + " target record(s)");
	return returnStatus;
}

int _tmain(int argc, _TCHAR* argv[])
{
	inputReader inputReader;
	mannou IOCtrl;
	inputReader.setLogger(&IOCtrl);
	const int is_success = mannou::RCode::R_SUCCESS_WITH_ERROR;
	try {
		//�G���[���b�Z�[�W��ݒ�
		inputReader._IOCtrl->initErrorMessage();
		//�I�v�V���������
		if (is_success < inputReader.getOption(argc, argv)) {
			return endProgramWithError(inputReader, "getting options");
		}
		//�t�@�C���ƃ��O��ݒ�
		if (is_success < inputReader.setFileOption()) {
			return endProgramWithError(inputReader, "setting options");
		}
		//���s���O��OPTION���v�����g
		inputReader.printDescription();
		arctl::coinitializer aCoInitializer;
		AccessSV AccSV;
		inputReader.setAccSV(&AccSV);
		//DB��ݒ�
		if (is_success < inputReader.setDbOption()) {
			return endProgramWithError(inputReader, "setting database");
		}

		//�e�[�u����ݒ�
		if (is_success < inputReader.setTable()) {
			return endProgramWithError(inputReader, "Setting featureclass");
		}
		//Start searching and copying
		if (is_success < getPOIActualAddress(&inputReader)) {
			return endProgramWithError(inputReader, "Copying Shape");
		}
	}
	catch (const _com_error e) {
		std::cout << std::endl;
		inputReader._IOCtrl->print_error(mannou::ECode::E_COM_ERROR_IS_CATCHED, (CString)e.ErrorMessage());
		return endProgramWithError(inputReader, "Com Error");
		std::cout << "Press any key to continue...";
		std::cin.get();
	}
	inputReader._IOCtrl->print_run(_T("Program ends successfully"));
	inputReader._IOCtrl->print_no_timestamp_run(_T(""));
	inputReader._IOCtrl->print_total_execution_time();
	inputReader._IOCtrl->closeFile();
	std::cout << "Press any key to continue...";
	std::cin.get();
    return 0;
}

