#include "stdafx.h"
#include "table.h"

using namespace sindy::schema::global;

int table::createNewBuffer() {
	if (S_OK != ipTable->CreateRowBuffer(&rowBuffer)) {
		IOManager::getInstance().print_error(IOManager::ECode::E_FAILED_TO_GET_DATA, true, tableName, _T(""), _T("Failed to create buffer"));
		return IOManager::RCode::R_FAILED_FATAL_ERROR;
	}
	return IOManager::RCode::R_SUCCESS;
}



int table::insertNewRow(CComVariant * newOID) {
	if (S_OK != insertCursor->InsertRow(rowBuffer, newOID)) {
		IOManager::getInstance().print_error(IOManager::ECode::E_FAILED_TO_SET_DATA, true, tableName, _T(""), _T("Failed to insert new record into cursor"));
		return IOManager::RCode::R_FAILED_FATAL_ERROR;
	}
	IOManager::getInstance().print_run(true, false, tableName + _T(" OBJECTID"), *newOID, _T("Record has been created successfully"));
	return IOManager::RCode::R_SUCCESS;
}

int table::startAndInsertCursor(IWorkspacePtr& workspace) {
	if (!AccessSV::startEditTable(workspace, ipTable)) {
		IOManager::getInstance().print_error(IOManager::ECode::E_FAILED_TO_GET_DATA, true, tableName, _T(""), _T("Start Editing"));
		return IOManager::RCode::R_FAILED_FATAL_ERROR;
	}
	//insert cursor for creating records
	if (S_OK != ipTable->Insert(VARIANT_TRUE, &insertCursor)) {
		IOManager::getInstance().print_error(IOManager::ECode::E_FAILED_TO_GET_DATA, true, tableName, _T(""), _T("Create new cursor for new records"));
		return IOManager::RCode::R_FAILED_FATAL_ERROR;
	}
	return IOManager::RCode::R_SUCCESS;
}

int table::flushAndStopEdit(IWorkspacePtr& workspace) {
	///CAUTION!!! UPDATE NEW RECORDS TO DATABASE
	///CAUTION!!! UPDATE NEW RECORDS TO DATABASE
	if (S_OK != insertCursor->Flush()) {
		IOManager::getInstance().print_error(IOManager::ECode::E_FAILED_TO_GET_DATA, true, tableName, _T(""), _T("Failed to insert new record into database"));
		return IOManager::RCode::R_FAILED_FATAL_ERROR;
	}
	///CAUTION!!! UPDATE NEW RECORDS TO DATABASE
	///CAUTION!!! UPDATE NEW RECORDS TO DATABASE
	if (!AccessSV::stopEditTable(workspace, ipTable)) {
		IOManager::getInstance().print_error(IOManager::ECode::E_FAILED_TO_GET_DATA, true, _T("Abort Editing"));
		return IOManager::RCode::R_FAILED_FATAL_ERROR;
	}
	return IOManager::RCode::R_SUCCESS;
}