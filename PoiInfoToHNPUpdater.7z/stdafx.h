// stdafx.h : include file for standard system include files,
// or project specific include files that are used frequently,
// but are changed infrequently

#pragma once

#define _USE_MATH_DEFINES
#include <cmath>
#include <stdio.h>
#include <stdlib.h>
#include <tchar.h>

#include <iostream>
#include <fstream>
#include <atlstr.h>
#include <set>
#include <map>
#include <utility> 
#include <time.h>
#include <string>
#include <WinLib/arcobjects_import_highmethod.h>
#include <sindy/workspace.h>
#include <sindy/libschema.h>
#include <sindy/schema.h>
#include <boost/program_options.hpp>

#include "AccessSV.h"
#include "CommonData.h"
#include "IOManager.h"

