#pragma once

#include "featureClass.h"

class PoiInfo : public featureClass {
public:

	PoiInfo(const CString& poiInfoFeatureClassName, IFeatureClassPtr& poiInfoFeatureClass);
	~PoiInfo();

	//Structure for POI_INFO
	struct poiInfo {
		poiInfo() :OBJECTID(-1), houseNumber(_T("")), actualAddress(_T("")), roadNameID(-1), x(-1), y(-1) {}
		poiInfo(long OBJECTID, CString houseNumber, CString actualAddress, long roadNameID, double x, double y) :
			OBJECTID(OBJECTID),
			houseNumber(houseNumber),
			actualAddress(actualAddress),
			roadNameID(roadNameID),
			x(x),
			y(y) {}
		long OBJECTID;
		CString houseNumber;
		CString actualAddress;
		long roadNameID;
		double x;
		double y;
	};

	/**
	* @brief start the tool
	* @return	RCode value [ex�FR_SUCCESS=0�AR_FAILED_FATAL_ERROR=1�A...]
	*/
	int presetPoiInfoFeatureCursor(const CComBSTR & queryFilter, IFeatureCursorPtr& ipPoiInfoCursor);
	/**
	* @brief start the tool
	* @return	RCode value [ex�FR_SUCCESS=0�AR_FAILED_FATAL_ERROR=1�A...]
	*/
	int getUniquePoiInfoID(const CComBSTR & queryFilter, std::wstring bufferSize, std::set<long> * childPOIList, std::set<long> * PoiInfoList, std::map<long, CString> * officialNameList, std::vector<poiInfo> * uniquePoiInfoList);
	/**
	* @brief start the tool
	* @return	RCode value [ex�FR_SUCCESS=0�AR_FAILED_FATAL_ERROR=1�A...]
	*/
	double	GetDist(double		eLon1,
		double		eLat1,
		double		eLon2,
		double		eLat2);

private:
	//POI_INFO field index
	long m_operatorIndex;
	long m_purposeCIndex;
	long m_modifyDateIndex;
	long m_updateTypeCIndex;
	long m_progModifyDateIndex;
	long m_modifyProgNameIndex;
	long m_userClaimFIndex;
	long m_sourceIndex;
	long m_roadNameIDIndex;
	long m_houseNumberIndex;
	long m_actualAddressIndex;
};

