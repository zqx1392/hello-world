#pragma once

class featureClass {
public:

	int createNewBuffer();

	int insertNewFeature(CComVariant * newHnpOID);

	int startAndInsertCursor(IWorkspacePtr& workspace);

	int flushAndStopEdit(IWorkspacePtr& workspace);

protected:
	CString featureClassName;
	IFeatureClassPtr ipFeatureClass;
	IFeatureCursorPtr insertCursor;
	IFeatureBufferPtr featureBuffer;

};

