#pragma once

#include "featureClass.h"

class HnpEntrypoint : public featureClass {
public:

	HnpEntrypoint(const CString& HnpFeatureClassName, IFeatureClassPtr& HnpFeatureClass, PoiEntrypoint * cPoiEntrypoint);
	~HnpEntrypoint();
	
	/**
	* @brief start the tool
	* @return	RCode value [ex�FR_SUCCESS=0�AR_FAILED_FATAL_ERROR=1�A...]
	*/
	int insertNewRecordToHNPEntrypoint(IWorkspacePtr& workspace, const CComBSTR & queryFilter, std::map<long, long> * updatedPoiHnpList);

	int putValueIntoFields(const long& poiEntryObjectID, const long& accuracyC, const CComBSTR& HnpPointID, IGeometryPtr& ipGeom);

	int createNewBuffer();

	int insertNewFeature(CComVariant * newHnpOID);

	int startAndInsertCursor(IWorkspacePtr& workspace);

	int flushAndStopEdit(IWorkspacePtr& workspace);

private:
	PoiEntrypoint * cPoiEntrypoint;
	//HNP field index
	long m_operatorIndex;
	long m_purposeCIndex;
	long m_modifyDateIndex;
	long m_updateTypeCIndex;
	long m_progModifyDateIndex;
	long m_modifyProgNameIndex;
	long m_userClaimFIndex;
	long m_sourceIndex;
	long m_accuracyCIndex;
	long m_HnpPointIDIndex;

};

