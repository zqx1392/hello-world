// PoiInfoToHNPUpdater.cpp : Defines the entry point for the console application.
//

#pragma once
#include "stdafx.h"
#include "PoiInfoToHNPUpdater.h"

using namespace sindy::schema::global;

PoiInfoToHNPUpdater::PoiInfoToHNPUpdater() {
	//error class setup
	IOManager::getInstance().initErrorMessage();
	m_OptionManager = new OptionManager();

}

PoiInfoToHNPUpdater::~PoiInfoToHNPUpdater() {
}

int PoiInfoToHNPUpdater::ConnectToFileAndData() {

	OptionManager * opt = m_OptionManager;
	//set log files
	if (is_success != IOManager::getInstance().initFile(opt->m_err_log.c_str(), IOManager::FileType::ERR)) {
		IOManager::getInstance().print_error(IOManager::ECode::E_FAILED_TO_SET_DATA, true, _T("Failed to create error log file"));
		return IOManager::RCode::R_FAILED_FATAL_ERROR;
	}
	if (is_success != IOManager::getInstance().initFile(opt->m_run_log.c_str(), IOManager::FileType::RUN)) {
		IOManager::getInstance().print_error(IOManager::ECode::E_FAILED_TO_SET_DATA, true, _T("Failed to create run log file"));
		return IOManager::RCode::R_FAILED_FATAL_ERROR;
	}

	//try to connect to database
	CString serverName = opt->m_db.c_str();
	if (is_success != AccessSV::getWorkspace(serverName, m_workspace)) {
		IOManager::getInstance().print_error(IOManager::ECode::E_FAILED_TO_SET_DATA, true, _T("Failed to connect to database"));
		return IOManager::RCode::R_FAILED_FATAL_ERROR;
	}

	//set owner name if this database is not FGDB [EX. THA2017A]	
	CString ownerName = _T("");
	if (!opt->is_FGDB) {
		int startServerName = serverName.Find(_T("@"));
		if (startServerName == -1) {
			IOManager::getInstance().print_error(IOManager::ECode::E_FAILED_TO_SET_DATA, true, _T("Failed to find owner name"));
			return IOManager::RCode::R_FAILED_FATAL_ERROR;
		}
		ownerName = serverName.Mid(0, startServerName);
	}
	
	//for FGDB, just input layer/table name
	int isAllSuccess = 0;
	if (opt->is_FGDB) {
		isAllSuccess += AccessSV::getFeatureClass(serverName, opt->m_hnp.c_str(), m_layer_hnp);
		isAllSuccess += AccessSV::getFeatureClass(serverName, opt->m_poi_info.c_str(), m_layer_poi_info);
		isAllSuccess += AccessSV::getFeatureClass(serverName, opt->m_hnp_entrypoint.c_str(), m_layer_hnp_entry);
		isAllSuccess += AccessSV::getFeatureClass(serverName, opt->m_poi_entrypoint.c_str(), m_layer_poi_entry);
		isAllSuccess += AccessSV::getTable(serverName, opt->m_poi_asso.c_str(), m_table_poi_asso);
		isAllSuccess += AccessSV::getTable(serverName, opt->m_official.c_str(), m_table_official);
		isAllSuccess += AccessSV::getTable(serverName, opt->m_translation.c_str(), m_table_translation);
	}
	//for SINDY database, need to add ownerName in front of layer/table name
	else {
		isAllSuccess += AccessSV::getFeatureClass(serverName, ownerName + _T(".") + opt->m_hnp.c_str(), m_layer_hnp);
		isAllSuccess += AccessSV::getFeatureClass(serverName, ownerName + _T(".") + opt->m_poi_info.c_str(), m_layer_poi_info);
		isAllSuccess += AccessSV::getFeatureClass(serverName, ownerName + _T(".") + opt->m_hnp_entrypoint.c_str(), m_layer_hnp_entry);
		isAllSuccess += AccessSV::getFeatureClass(serverName, ownerName + _T(".") + opt->m_poi_entrypoint.c_str(), m_layer_poi_entry);
		isAllSuccess += AccessSV::getTable(serverName, ownerName + _T(".") + opt->m_poi_asso.c_str(), m_table_poi_asso);
		isAllSuccess += AccessSV::getTable(serverName, ownerName + _T(".") + opt->m_official.c_str(), m_table_official);
		isAllSuccess += AccessSV::getTable(serverName, ownerName + _T(".") + opt->m_translation.c_str(), m_table_translation);
	}
	if (isAllSuccess != is_success) {
		IOManager::getInstance().print_error(IOManager::ECode::E_FAILED_TO_SET_DATA, true, _T("Failed to connect to layer/table"));
		return IOManager::RCode::R_FAILED_FATAL_ERROR;
	}
	return IOManager::RCode::R_SUCCESS;
}

int PoiInfoToHNPUpdater::presetData(const int& argc, _TCHAR* argv[])
{
	try {
		//Get option list from console
		if (is_success != m_OptionManager->getOption(argc, argv)) {
			return IOManager::getInstance().endProgramWithError(_T("getting options"));
		}
		//Preset default value for optional arguments
		if (is_success != m_OptionManager->presetOption()) {
			return IOManager::getInstance().endProgramWithError(_T("setting options"));
		}
		//Connect to file and ARCGIS data
		if (is_success != ConnectToFileAndData()) {
			return IOManager::getInstance().endProgramWithError(_T("connect to file and database"));
		}
		//Print specified options into run log 
		m_OptionManager->printDescription();
	}
	catch (const _com_error e) {
		std::cout << std::endl;
		IOManager::getInstance().print_error(IOManager::ECode::E_COM_ERROR_IS_CATCHED, true, _T("E_COM_ERROR"), _T(""), (CString)e.ErrorMessage());
		return IOManager::getInstance().endProgramWithError("Com Error");
		std::cout << "Press any key to continue...";
		std::cin.get();
	}
	return IOManager::RCode::R_SUCCESS;
}

int PoiInfoToHNPUpdater::run() {
	
	PoiAssociation cPoiAssociation(m_OptionManager->m_poi_asso.c_str(), m_table_poi_asso);
	PoiEntrypoint cPoiEntrypoint(m_OptionManager->m_poi_entrypoint.c_str(), m_layer_poi_entry);
	HnpEntrypoint cHnpEntrypoint(m_OptionManager->m_hnp_entrypoint.c_str(), m_layer_hnp_entry, &cPoiEntrypoint);
	Hnp cHnp(m_OptionManager->m_hnp.c_str(), m_layer_hnp);
	PoiInfo cPoiInfo(m_OptionManager->m_poi_info.c_str(), m_layer_poi_info);
	OfficialName cOfficialName(m_OptionManager->m_official.c_str(), m_table_official, &cHnp);
	Translation cTranslation(m_OptionManager->m_translation.c_str(), m_table_translation);
	

	////get child POI list from POI_ASSOCIATION
	std::set<long> childPOIList;
	if (is_success != cPoiAssociation.getChildPOI(&childPOIList)) {
	return IOManager::getInstance().endProgramWithError(_T("get child POI list from POI_ASSOCIATION"));
	}
	IOManager::getInstance().print_run(true, true, _T("Successfully: Extracted CHILDID from POI_ASSOCIATION"));

	//get poi entry point object ID list from POI_ENTRYPOINT
	std::set<long> poiEntrypointList;
	if (is_success != cPoiEntrypoint.getPoiInfoID(m_OptionManager->m_sql_poientry.c_str(), &poiEntrypointList)) {
		return IOManager::getInstance().endProgramWithError(_T("get POI Entrypoint list from POI_ENTRYPOINT"));
	}
	IOManager::getInstance().print_run(true, true, _T("Successfully: Extracted POIINFOID from POI_ASSOCIATION"));

	//get official name list <OBJECTID, NAME> from OFFICIAL_NAME
	std::map<long, CString> officialNameList;
	if (is_success != cOfficialName.getOfficalName(&officialNameList)) {
		return IOManager::getInstance().endProgramWithError(_T("get name list from OFFICIAL_NAME"));
	}
	IOManager::getInstance().print_run(true, true, _T("Successfully: Extracted NAME from OFFICIAL_NAME"));

	//get only unique houseNumber information from POI_INFO
	std::vector<PoiInfo::poiInfo> uniquePoiInfoList;
	if (is_success != cPoiInfo.getUniquePoiInfoID(m_OptionManager->m_sql_poiinfo.c_str(), m_OptionManager->m_buffer_size, &childPOIList, &poiEntrypointList, &officialNameList, &uniquePoiInfoList)) {
		return IOManager::getInstance().endProgramWithError(_T("get unique house number list from POI_INFO"));
	}
	IOManager::getInstance().print_run(true, true, _T("Successfully: Extracted unique POI_INFO"));


	//create new records on HNP (where ROADNAMEID is NULL)
	std::map<long, long> updatedPoiHnpList;
	/*updatedPoiHnpList.insert(std::make_pair(641, 1759101));
	updatedPoiHnpList.insert(std::make_pair(581131, 1758737));
	updatedPoiHnpList.insert(std::make_pair(381521, 1758735));*/
	if (is_success != cHnp.insertNewRecordToHNP(m_workspace, &uniquePoiInfoList, &updatedPoiHnpList)) {
		return IOManager::getInstance().endProgramWithError(_T("Create new records on HNP"));
	}

	//create new records on HNP and OFFICIAL_NAME (where ROADNAMEID is NOT NULL)
	std::map<long, long> translationList;
	if (is_success != cOfficialName.insertNewRecordToHNPAndOfficial(m_workspace, &uniquePoiInfoList, &updatedPoiHnpList, &translationList)) {
		return IOManager::getInstance().endProgramWithError(_T("Create new records on HNP and OFFICIAL_NAME"));
	}
	IOManager::getInstance().print_run(true, true, _T("Successfully: Created new records on HNP and OFFICIAL_NAME"));

	//create new records on TRANSLATION
	//translationList.insert(std::make_pair(46, 1111));
	//translationList.insert(std::make_pair(397, 2222));
	//translationList.insert(std::make_pair(21, 3333));
	if (is_success != cTranslation.insertNewRecordToTranslation(m_workspace, &translationList)) {
		return IOManager::getInstance().endProgramWithError(_T("Create new records on TRANSLATION"));
	}
	IOManager::getInstance().print_run(true, true, _T("Successfully: Created new records on TRANSLATION"));

	//create new records on HNP_ENTRYPOINT
	if (is_success != cHnpEntrypoint.insertNewRecordToHNPEntrypoint(m_workspace, m_OptionManager->m_sql_poientry.c_str(), &updatedPoiHnpList)) {
		return IOManager::getInstance().endProgramWithError(_T("Create new records on HNP_ENTRYPOINT"));
	}
	IOManager::getInstance().print_run(true, true, _T("Successfully: Created new records on HNP_ENTRYPOINT"));

	return IOManager::getInstance().printSuccessfulEnd();
}






