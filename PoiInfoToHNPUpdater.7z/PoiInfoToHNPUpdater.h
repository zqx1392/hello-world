#pragma once

#include "AccessSV.h"
#include "IOManager.h"
#include "OptionManager.h"
#include "DataManager.h"
#include <crd_cnv/crd_cnv.h>

/**
* @brief	Tool main process :
	1.Create new HNP record by copying value from POI_INFO record whose HN value not null 
	2.Copy: HN, Coordinates.
	3.Create new record on OFFICIAL_NAME and TRANSLATION. the new record will copy value from POI_INFO's using POI_INFO.ROADNAMEID
	4.Copy new OFFICIAL_NAME.OBJECTID to HNP.ROADNAMEID
	5.(Planning) update existed HNP records which were created by this tool
*/

class PoiInfoToHNPUpdater
{
public:
	OptionManager *  m_OptionManager;
	DataManager * m_dataManager;
	crd_cnv m_crd_cnv;
	PoiInfoToHNPUpdater();
	~PoiInfoToHNPUpdater();

	//Structure for POI_INFO
	struct poiInfo {
		poiInfo() :OBJECTID(-1), houseNumber(_T("")), actualAddress(_T("")), roadNameID(-1), x(-1), y(-1) {}
		poiInfo(long OBJECTID, CString houseNumber, CString actualAddress, long roadNameID, double x, double y) :
			OBJECTID(OBJECTID),
			houseNumber(houseNumber),
			actualAddress(actualAddress),
			roadNameID(roadNameID),
			x(x),
			y(y) {}
		long OBJECTID;
		CString houseNumber;
		CString actualAddress;
		long roadNameID;
		double x;
		double y;
	};

	/**
	* @brief get all option arguments and parse all into data manager
	*/
	int setNewOption();
	/**
	* @brief Preset all input and output such as log files, DBs and featureclasses variables before start ArcGIS-related process
	* @return	RCode value [ex�FR_SUCCESS=0�AR_FAILED_FATAL_ERROR=1�A...]
	*/
	int presetData(const int& argc, _TCHAR* argv[]);
	/**
	* @brief start the tool
	* @return	RCode value [ex�FR_SUCCESS=0�AR_FAILED_FATAL_ERROR=1�A...]
	*/
	int run();



	/**
	* @brief start the tool
	* @return	RCode value [ex�FR_SUCCESS=0�AR_FAILED_FATAL_ERROR=1�A...]
	*/
	int getChildPOI(std::set<int> * childPOIList);
	/**
	* @brief start the tool
	* @return	RCode value [ex�FR_SUCCESS=0�AR_FAILED_FATAL_ERROR=1�A...]
	*/
	int getPoiEntrypoint(std::set<int> * poiEntrypointList);
	/**
	* @brief start the tool
	* @return	RCode value [ex�FR_SUCCESS=0�AR_FAILED_FATAL_ERROR=1�A...]
	*/
	int getOfficalName(std::set<int> * childPOIList, std::map<int, CString> * officialNameList);
	/**
	* @brief start the tool
	* @return	RCode value [ex�FR_SUCCESS=0�AR_FAILED_FATAL_ERROR=1�A...]
	*/
	int getUniquePoiInfoID(std::set<int> * childPOIList, std::set<int> * poiEntrypointList, std::map<int, CString> * officialNameList, std::vector<poiInfo> * uniquePoiInfoList);
	/**
	* @brief start the tool
	* @return	RCode value [ex�FR_SUCCESS=0�AR_FAILED_FATAL_ERROR=1�A...]
	*/
	int presetPoiInfoFeatureCursor(IQueryFilterPtr PoiInfoIpQueryFilter, IFeatureCursorPtr ipPoiInfoCursor);
	/**
	* @brief start the tool
	* @return	RCode value [ex�FR_SUCCESS=0�AR_FAILED_FATAL_ERROR=1�A...]
	*/
	int loopPoiInfo(std::map<int, CString> * officialNameList, std::vector<poiInfo> * uniquePoiInfoList);



	int getColumnIndex(IQueryFilterPtr POIipQueryFilter, IFeatureCursorPtr ipPOICursor, CComBSTR fieldName, long * index);








private:
	static const int is_success = IOManager::RCode::R_SUCCESS;

};