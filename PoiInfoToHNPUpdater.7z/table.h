#pragma once

class table {
public:

	int createNewBuffer();

	int insertNewRow(CComVariant * newHnpOID);

	int startAndInsertCursor(IWorkspacePtr& workspace);

	int flushAndStopEdit(IWorkspacePtr& workspacer);

protected:
	CString tableName;
	ITablePtr ipTable;
	_ICursorPtr insertCursor;
	IRowBufferPtr rowBuffer;

};