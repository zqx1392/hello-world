#pragma once
#include "AccessSV.h"
#include "ErrorManager.h"
#include "IOManager.h"
#include "DataManager.h"
/**
* @brief	Get all SiNDY-related data using SiNDY libraries and send to C# to compare the data 
*/

class DBComparer
{
public:
	AccessSV * m_accessSV;
	ErrorManager *  m_errorManager;
	IOManager * m_IOManager;
	DataManager * m_dataManager;

	DBComparer();
	~DBComparer();
	/**
	* @brief Set all management class
	* @param arg				[in]	Target management class object
	*/
	void setIOManager(IOManager * _IOManager);
	void setSVManager(AccessSV * _accessSV);
	void setErrorManager(ErrorManager * _errorManager);
	void setDataManager(DataManager * _dataManager);
	/**
	* @brief Preinitialize all input and output such as log files before start ArcGIS-related process
	* @return	0 is success, 1 if fail
	*/
	int preStartTool();
	/**
	* @brief Print fix messsage when the tool ends successfully
	* @return	RCode value [ex�FR_SUCCESS=0�AR_FAILED_FATAL_ERROR=1�A...]
	*/
	int printSuccessfulEnd();
	/**
	* @brief when error occured, print error details and ends program
	* @param errorPoint			[in]	String that describe the place when an error occured
	* @return	RCode value [ex�FR_SUCCESS=0�AR_FAILED_FATAL_ERROR=1�A...]
	*/
	int endProgramWithError(CString errorPoint);
	/**
	* @brief Connect to target SiNDY userDB 
	* @param DBname				[in]	target DB server name [ex. sindympa]
	* @param username			[in]	target DB owner name [ex. TEST2017A]
	* @param versionName		[in]	target DB server name [ex. SDE.DEFAULT]
	* @return	RCode value [ex�FR_SUCCESS=0�AR_FAILED_FATAL_ERROR=1�A...]
	*/
	int connectToDB(std::wstring DBname, std::wstring username, std::wstring versionName);
	/**
	* @brief get target featureclass's dataset name
	* @param DBname				[in]	target DB server name [ex. sindympa]
	* @param username			[in]	target DB owner name [ex. TEST2017A]
	* @param versionName		[in]	target DB server name [ex. SDE.DEFAULT]
	* @param featureClassName	[in]	target featureClass name [ex. sindy::schema::example:kfeatureClassName, "ROAD_LINK"]
	* @return	dataset name
	*/
	std::string getFeatureClassDataSetName(std::wstring DBname, std::wstring username, std::wstring versionName, std::wstring featureClassName);
	/**
	* @brief get target SiNDY userDB's all featureClass names and their total record numbers
	* @param DBname				[in]	target DB server name [ex. sindympa]
	* @param username			[in]	target DB owner name [ex. TEST2017A]
	* @param versionName		[in]	target DB server name [ex. SDE.DEFAULT]
	* @return	list of featureClass details ["name1","total count1","name2","total count2",...]
	*/
	std::vector<std::string> getFeatureClassAndCount(std::wstring DBname, std::wstring username, std::wstring versionName);
	/**
	* @brief get target featureClass's all field name 
	* @param DBname				[in]	target DB server name [ex. sindympa]
	* @param username			[in]	target DB owner name [ex. TEST2017A]
	* @param versionName		[in]	target DB server name [ex. SDE.DEFAULT]
	* @param featureClassName	[in]	target featureClass name [ex. sindy::schema::example:kfeatureClassName, "ROAD_LINK"]
	* @return	list of field name ["name1","name2","name3",...]
	*/
	std::vector<std::string> getfieldNameList(std::wstring DBname, std::wstring username, std::wstring versionName, std::wstring featureClassName);
	/**
	* @brief Check if target field contains a domain
	* @param DBname				[in]	target DB server name [ex. sindympa]
	* @param username			[in]	target DB owner name [ex. TEST2017A]
	* @param versionName		[in]	target DB server name [ex. SDE.DEFAULT]
	* @param featureClassName	[in]	target featureClass name [ex. sindy::schema::example:kfeatureClassName, "ROAD_LINK"]
	* @param fieldName			[in]	target field name [ex. OBJECTID]
	* @return	true if exist, false if not
	*/
	bool hasDomain(std::wstring DBname, std::wstring username, std::wstring versionName, std::wstring featureClassName, std::wstring fieldName);
	/**
	* @brief get target field's domain name and its codes
	* @param DBname				[in]	target DB server name [ex. sindympa]
	* @param username			[in]	target DB owner name [ex. TEST2017A]
	* @param versionName		[in]	target DB server name [ex. SDE.DEFAULT]
	* @param featureClassName	[in]	target featureClass name [ex. sindy::schema::example:kfeatureClassName, "ROAD_LINK"]
	* @param fieldName			[in]	target field name [ex. OBJECTID]
	* @return	domain name and list of code value and code name ["domain name","code value 1","code name 1","code value 2","code name 2",...]
	*/
	std::vector<std::string> getDomainNameList(std::wstring DBname, std::wstring username, std::wstring versionName, std::wstring featureClassName, std::wstring fieldName);
	/**
	* @brief test SQL text for where clause whether it has correct format, variable or not 
	* @param SQLText			[in]	SQL text to test [ex. 'OBJECTID > 10']
	* @param DBname				[in]	target DB server name [ex. sindympa]
	* @param username			[in]	target DB owner name [ex. TEST2017A]
	* @param versionName		[in]	target DB server name [ex. SDE.DEFAULT]
	* @param featureClassName	[in]	target featureClass name [ex. sindy::schema::example:kfeatureClassName, "ROAD_LINK"]
	* @param fieldName			[in]	target field name [ex. OBJECTID]
	* @return	true if correct, false if not
	*/
	bool checkSQLSyntax(std::string SQLText, std::wstring DBname, std::wstring username, std::wstring versionName, std::wstring featureClassName);
	/**
	* @brief get record number from target featureClass with specific where clause SQL text
	* @param SQLText			[in]	SQL text to test [ex. 'OBJECTID > 10']
	* @param DBname				[in]	target DB server name [ex. sindympa]
	* @param username			[in]	target DB owner name [ex. TEST2017A]
	* @param versionName		[in]	target DB server name [ex. SDE.DEFAULT]
	* @param featureClassName	[in]	target featureClass name [ex. sindy::schema::example:kfeatureClassName, "ROAD_LINK"]
	* @param fieldName			[in]	target field name [ex. OBJECTID]
	* @return	total distance or area, depending on type of data
	*/
	long getRecordNumber(std::string SQLText, std::wstring DBname, std::wstring username, std::wstring versionName, std::wstring featureClassName);
	/**
	* @brief get total distance or area from target featureClass with specific where clause SQL text
	* @param SQLText			[in]	SQL text to test [ex. 'OBJECTID > 10']
	* @param DBname				[in]	target DB server name [ex. sindympa]
	* @param username			[in]	target DB owner name [ex. TEST2017A]
	* @param versionName		[in]	target DB server name [ex. SDE.DEFAULT]
	* @param featureClassName	[in]	target featureClass name [ex. sindy::schema::example:kfeatureClassName, "ROAD_LINK"]
	* @param fieldName			[in]	target field name [ex. OBJECTID]
	* @return	total distance or area, depending on type of data
	*/
	double getTotalDistArea(std::string SQLText, std::wstring DBname, std::wstring username, std::wstring versionName, std::wstring featureClassName);
	/**
	* @brief get area from input shape
	* @param ipGeom				[in]	target shape
	* @return	value of area
	*/
	double getArea(IGeometryPtr & ipGeom);
	/**
	* @brief get distance from input shape
	* @param ipGeom				[in]	target shape
	* @param shapeType			[in]	type of shape [Polyline or Line]
	* @return	value of distance
	*/
	double getDist(IGeometryPtr & ipGeom, esriGeometryType shapeType);
private:
	static const int is_success = ErrorManager::RCode::R_SUCCESS;
};