// This is the main DLL file.
#pragma once
#include "stdafx.h"
#include "DBComparerWrapper.h"
#include <msclr/marshal_windows.h>
#include <msclr/marshal.h>
#include <msclr/marshal_cppstd.h>

#include "..\DBComparer\AccessSV.h"
#include "..\DBComparer\AccessSV.cpp"
#include "..\DBComparer\ErrorManager.h"
#include "..\DBComparer\ErrorManager.cpp"
#include "..\DBComparer\IOManager.h"
#include "..\DBComparer\IOManager.cpp"
#include "..\DBComparer\DataManager.h"
#include "..\DBComparer\DataManager.cpp"
#include "..\DBComparer\DBComparer.h"
#include "..\DBComparer\DBComparer.cpp"

//Constructor implementation
DBComparerWrapper::functionWrapper::functionWrapper() {
	DBComparerClass = new DBComparer();
}
bool DBComparerWrapper::functionWrapper::preStartTool() {
	int boolValue = DBComparerClass->preStartTool();
	if (boolValue == 0) return true;
	else return false;
}

void DBComparerWrapper::functionWrapper::printSuccessfulEnd() {
	DBComparerClass->printSuccessfulEnd();
}

bool DBComparerWrapper::functionWrapper::connectToDB(String^ DBname, String^ username, String^ versionName) {
	std::wstring convertedDBname = msclr::interop::marshal_as<std::wstring>(DBname);
	std::wstring convertedUsername = msclr::interop::marshal_as<std::wstring>(username);
	std::wstring convertedVersionName = msclr::interop::marshal_as<std::wstring>(versionName);
	int boolValue = DBComparerClass->connectToDB(convertedDBname, convertedUsername, convertedVersionName);
	if (boolValue == 0) return true;
	else return false;
}

String^ DBComparerWrapper::functionWrapper::getFeatureClassDataSetName(String^ DBname, String^ username, String^ versionName, String^ featureClassName) {
	std::wstring convertedDBname = msclr::interop::marshal_as<std::wstring>(DBname);
	std::wstring convertedUsername = msclr::interop::marshal_as<std::wstring>(username);
	std::wstring convertedVersionName = msclr::interop::marshal_as<std::wstring>(versionName);
	std::wstring convertedFeatureClassName = msclr::interop::marshal_as<std::wstring>(featureClassName);
	return gcnew String(DBComparerClass->getFeatureClassDataSetName(convertedDBname, convertedUsername, convertedVersionName, convertedFeatureClassName).c_str());
}
array<String^>^ DBComparerWrapper::functionWrapper::getFeatureClassAndCount(String^ DBname, String^ username, String^ versionName) {
	std::wstring convertedDBname = msclr::interop::marshal_as<std::wstring>(DBname);
	std::wstring convertedUsername = msclr::interop::marshal_as<std::wstring>(username);
	std::wstring convertedVersionName = msclr::interop::marshal_as<std::wstring>(versionName);
	std::vector<std::string> tempArray = DBComparerClass->getFeatureClassAndCount(convertedDBname, convertedUsername, convertedVersionName);
	const int SIZE = tempArray.size();
	array<String^>^ tempArr = gcnew array<String^>(SIZE);
	for (int i = 0; i < SIZE; i++)
	{
		tempArr[i] = gcnew String(tempArray[i].c_str());
	}
	return tempArr;
}
array<String^>^ DBComparerWrapper::functionWrapper::getfieldNameList(String^ DBname, String^ username, String^ versionName, String^ featureClassName) {
	std::wstring convertedDBname = msclr::interop::marshal_as<std::wstring>(DBname);
	std::wstring convertedUsername = msclr::interop::marshal_as<std::wstring>(username);
	std::wstring convertedVersionName = msclr::interop::marshal_as<std::wstring>(versionName);
	std::wstring convertedFeatureClassName = msclr::interop::marshal_as<std::wstring>(featureClassName);
	std::vector<std::string> tempArray = DBComparerClass->getfieldNameList(convertedDBname, convertedUsername, convertedVersionName, convertedFeatureClassName);
	const int SIZE = tempArray.size();
	array<String^>^ tempArr = gcnew array<String^>(SIZE);
	for (int i = 0; i < SIZE; i++)
	{
		tempArr[i] = gcnew String(tempArray[i].c_str());
	}
	return tempArr;
}
bool DBComparerWrapper::functionWrapper::hasDomain(String^ DBname, String^ username, String^ versionName, String^ featureClassName, String^ fieldName) {
	std::wstring convertedDBname = msclr::interop::marshal_as<std::wstring>(DBname);
	std::wstring convertedUsername = msclr::interop::marshal_as<std::wstring>(username);
	std::wstring convertedVersionName = msclr::interop::marshal_as<std::wstring>(versionName);
	std::wstring convertedFeatureClassName = msclr::interop::marshal_as<std::wstring>(featureClassName);
	std::wstring convertedFieldName = msclr::interop::marshal_as<std::wstring>(fieldName);
	return DBComparerClass->hasDomain(convertedDBname, convertedUsername, convertedVersionName, convertedFeatureClassName, convertedFieldName);
}
array<String^>^ DBComparerWrapper::functionWrapper::getDomainNameList(String^ DBname, String^ username, String^ versionName, String^ featureClassName, String^ fieldName) {
	std::wstring convertedDBname = msclr::interop::marshal_as<std::wstring>(DBname);
	std::wstring convertedUsername = msclr::interop::marshal_as<std::wstring>(username);
	std::wstring convertedVersionName = msclr::interop::marshal_as<std::wstring>(versionName);
	std::wstring convertedFeatureClassName = msclr::interop::marshal_as<std::wstring>(featureClassName);
	std::wstring convertedFieldName = msclr::interop::marshal_as<std::wstring>(fieldName);
	std::vector<std::string> tempArray = DBComparerClass->getDomainNameList(convertedDBname, convertedUsername, convertedVersionName, convertedFeatureClassName, convertedFieldName);
	const int SIZE = tempArray.size();
	array<String^>^ tempArr = gcnew array<String^>(SIZE);
	for (int i = 0; i < SIZE; i++)
	{
		tempArr[i] = gcnew String(tempArray[i].c_str());
	}
	return tempArr;
}

bool DBComparerWrapper::functionWrapper::checkSQLSyntax(String^ SQLText, String^ username, String^ DBname, String^ versionName, String^ featureClassName) {
	std::wstring convertedDBname = msclr::interop::marshal_as<std::wstring>(DBname);
	std::wstring convertedUsername = msclr::interop::marshal_as<std::wstring>(username);
	std::wstring convertedVersionName = msclr::interop::marshal_as<std::wstring>(versionName);
	std::wstring convertedFeatureClassName = msclr::interop::marshal_as<std::wstring>(featureClassName);
	std::string convertedSQLText = msclr::interop::marshal_as<std::string>(SQLText);
	return DBComparerClass->checkSQLSyntax(convertedSQLText, convertedDBname, convertedUsername, convertedVersionName, convertedFeatureClassName);
}
long DBComparerWrapper::functionWrapper::getRecordNumber(String^ SQLText, String^ DBname, String^ username, String^ versionName, String^ featureClassName) {
	std::wstring convertedDBname = msclr::interop::marshal_as<std::wstring>(DBname);
	std::wstring convertedUsername = msclr::interop::marshal_as<std::wstring>(username);
	std::wstring convertedVersionName = msclr::interop::marshal_as<std::wstring>(versionName);
	std::wstring convertedFeatureClassName = msclr::interop::marshal_as<std::wstring>(featureClassName);
	std::string convertedSQLText = msclr::interop::marshal_as<std::string>(SQLText);
	return DBComparerClass->getRecordNumber(convertedSQLText, convertedDBname, convertedUsername, convertedVersionName, convertedFeatureClassName);
}
double DBComparerWrapper::functionWrapper::getTotalDistArea(String^ SQLText, String^ DBname, String^ username, String^ versionName, String^ featureClassName) {
	std::wstring convertedDBname = msclr::interop::marshal_as<std::wstring>(DBname);
	std::wstring convertedUsername = msclr::interop::marshal_as<std::wstring>(username);
	std::wstring convertedVersionName = msclr::interop::marshal_as<std::wstring>(versionName);
	std::wstring convertedFeatureClassName = msclr::interop::marshal_as<std::wstring>(featureClassName);
	std::string convertedSQLText = msclr::interop::marshal_as<std::string>(SQLText);
	return DBComparerClass->getTotalDistArea(convertedSQLText, convertedDBname, convertedUsername, convertedVersionName, convertedFeatureClassName);
}
