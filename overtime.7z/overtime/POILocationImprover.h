#pragma once
#include "AccessSV.h"
#include "ErrorManager.h"
#include "IOManager.h"
#include "OptionManager.h"
#include "DataManager.h"
/**
* @brief	Tool main process : 
			1.Get POSTALPOINT.shape postal code and its respective coordinates(x,y) list
			2.Get POI_INFO record and extract postal code from ACTUAL ADDRESS field
			3.Compare postal code  2. with 1.
			4.If match, copy coordinates(x,y) from POSTAL_CODE and replace the old one in POI_INFO.shape
*/

class POILocationImprover
{
public:
	AccessSV * m_accessSV;
	ErrorManager *  m_errorManager;
	IOManager * m_IOManager;
	OptionManager *  m_OptionManager;
	DataManager * m_dataManager;

	POILocationImprover();
	~POILocationImprover();
	/**
	* @brief Set all management class
	* @param arg				[in]	Target management class object
	*/
	void setIOManager(IOManager * _IOManager);
	void setSVManager(AccessSV * _accessSV);
	void setErrorManager(ErrorManager * _errorManager);
	void setOptionManager(OptionManager * _OptionManager);
	void setDataManager(DataManager * _dataManager);
	/**
	* @brief Print fix messsage when the tool ends successfully
	* @return	RCode value [ex�FR_SUCCESS=0�AR_FAILED_FATAL_ERROR=1�A...]
	*/
	int printSuccessfulEnd();
	/**
	* @brief when error occured, print error details and ends program
	* @return	0
	*/
	int endProgramWithError(CString errorPoint);
	/**
	* @brief Check if input wstring is number of not (ie. not contain any character)
	* @return	true if number, false if not.
	*/
	bool is_number(const std::wstring& s);
	/**
	* @brief get all option arguments and parse all into data manager
	*/
	int setNewOption();
	/**
	* @brief Get all postal code record from POSTALPOINT and store its coordinates in std::map
	* @param PPCoordinates		[out]	Store { postal code : coordinate X, coordinate Y } as { key : value }
	* @return	RCode value [ex�FR_SUCCESS=0�AR_FAILED_FATAL_ERROR=1�A...]
	*/
	int findPPPostalCode(std::map<_bstr_t, std::pair<double, double> > * PPCoordinates);
	/**
	* @brief find new POI_INFO location coordinates from POSTALPOINT location coordinates whose postal code matched
	* @param objectID		[in]	A record of POI_INFO's Object ID
	* @param postalCode		[in]	A record of POI_INFO's postal code
	* @param ipPOIGeom		[in]	A record of POI_INFO's shape (location which stores coordinates)
	* @param PPCoordinates	[in]	Store { postal code : coordinate X, coordinate Y } as { key : value }
	* @return	RCode value [ex�FR_SUCCESS=0�AR_FAILED_FATAL_ERROR=1�A...]
	*/
	int copyPostalPointCoordinates(CString objectID, _bstr_t postalCode, IGeometryPtr & ipPOIGeom, std::map<_bstr_t, std::pair<double, double> > * PPCoordinates);
	/**
	* @brief Set all search condition for POI_INFO (column, where clause) 
	* @param POIipQueryFilter		[in]	a variable used for search condition
	* @return	RCode value [ex�FR_SUCCESS=0�AR_FAILED_FATAL_ERROR=1�A...]
	*/
	int setPOISearchCondition(IQueryFilterPtr POIipQueryFilter);
	/**
	* @brief Count total record of POI_INFO
	* @param POIipQueryFilter		[in]	a variable used for search condition
	* @return	RCode value [ex�FR_SUCCESS=0�AR_FAILED_FATAL_ERROR=1�A...]
	*/
	int countTotalPOIRecord(IQueryFilterPtr POIipQueryFilter);	
	/**
	* @brief After set all search condition, loop all POI record and get target OBJECTID that has valid postal code
	* @param PPCoordinates		[in]	Store { postal code : coordinate X, coordinate Y } as { key : value }
	* @param POIipQueryFilter	[in]	a variable used for search condition
	* @return	RCode value [ex�FR_SUCCESS=0�AR_FAILED_FATAL_ERROR=1�A...]
	*/
	int getTargetPOIRecord(std::map<_bstr_t, std::pair<double, double> > * PPCoordinates, IQueryFilterPtr POIipQueryFilter);
	/**
	* @brief Update all target record's coordinates into database 
	* @param PPCoordinates		[in]	Store { postal code : coordinate X, coordinate Y } as { key : value }
	* @param updateTargetPOI	[in]	List of target POI record 
	}
	* @return	RCode value [ex�FR_SUCCESS=0�AR_FAILED_FATAL_ERROR=1�A...]
	*/
	int updateToDatabase(std::map<_bstr_t, std::pair<double, double> > * PPCoordinates, std::set<CString> * updateTargetPOI);
	/**
	* @brief start the tool, get necessary variables for such as featureclass name, field name, and ArcGIS variables 
			 Also get Postal Code from POSTALPOINT, search condition, and count total POI record 
	* @param inputReader		[in]	IO management class
	* @return	RCode value [ex�FR_SUCCESS=0�AR_FAILED_FATAL_ERROR=1�A...]
	*/
	int startTool();

	/**
	* @brief Preinitialize all input and output such as log files, DBs and featureclasses variables before start ArcGIS-related process
	* @return	RCode value [ex�FR_SUCCESS=0�AR_FAILED_FATAL_ERROR=1�A...]
	*/
	int preStartTool(int argc, _TCHAR* argv[]);
	
private:
	static const int is_success = ErrorManager::RCode::R_SUCCESS;
	std::map<std::string, DataManager::featureClassDesc> m_featureClassList;
	std::map<std::string, _bstr_t> m_fieldNameList;
	CString m_PPFeatureClassName;
	CString m_POIFeatureClassName;
	IFeatureClassPtr m_PPFeatureClass;
	IFeatureClassPtr m_POIFeatureClass;
	IFeatureCursorPtr m_ipPOICursor;
	_bstr_t m_PPFIELD;
	_bstr_t m_POIFIELD;						
};