﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Oracle.ManagedDataAccess.Client;
using Oracle.ManagedDataAccess.EntityFramework;

using DBComparerWrapper;

namespace SiNDYDataComparer
{
    /// <summary>
    /// Connect to SiNDY via ArcSDE and acquire selected user's tables, columns and domains.
    /// can input second user to compare the data
    /// Input:
    ///     User1 -- Username, DB name, version
    ///     User2 -- Username, DB name, version
    /// Target data: 
    ///     Table, column name
    ///     Domain code, name
    ///     Record count
    ///     Area, Distance (if avaliable)
    /// Output:
    ///     TSV file
    /// </summary>
    public partial class MainWindow : Window
    {
        //current tool version
        static private String TOOL_VERSION = "0.0.0.9";

        //Log and error manager C++ class
        
        functionWrapper DBComparer;
        //Variables and session data
        private String currentDB;       //gaia
        private String currentUser;     //TEST2017A
        private String currentVersion;  //SDE.DEFAULT
        private String currentDB2;       //gaia
        private String currentUser2;     //TEST2017A
        private String currentVersion2;  //SDE.DEFAULT
        private String currentTable;    //TEST2017A@gaia(SDE.DEFAULT)-ROAD_LINK
        bool isTableLoadedFromFile = false;
        Dictionary<String,Tuple<bool,String>> tableConditionInfo;   //Dict<gaia-TEST2017A-SDE.DEFAULT-ROAD_LINK,<SELECTED=TRUE,CONDITION = "OBJECTID = 2017">>
        Dictionary<String, bool> columnSelectInfo;                  //Dict<gaia-TEST2017A-SDE.DEFAULT-ROAD_LINK-OBJECTID,SELECTED=TRUE>
        Dictionary<String, List<String>> tableColumnInfo;           //Dict<gaia-TEST2017A-SDE.DEFAULT-ROAD_LINK,COLUMN LIST=<OBJECTID,CLASS_C,PROG_NAME,...>>
        Dictionary<String, String> tableDatasetInfo;                //Dict<ROAD_LINK,DATASET="ROAD">
        HashSet<String> tableSelectAll;                             //HashSet<gaia-TEST2017A-SDE.DEFAULT-ROAD_LINK>. Use to convert * from config file to select every column.
        static private String suffix_close = "_close";              
        static private String suffix_check = "_chk";
        static private String suffix_count = "_count";
        static private String suffix_condition = "_condit";
        static private String res_gridColumnButton = "gridColumnButton";
        static private String res_columnButton = "columnButton"; 
        static private String res_closeButton = "CloseButton";
        static private String res_borderTableHeader = "borderTableHeader";
        static private String res_borderTableRow = "borderTableRow"; 
        static private String res_borderTableInner = "borderTableInner";
        static private String res_textBlockTable = "textBlockTable";
        static private String res_textBoxTable = "textBoxTable";

        /**
	    * @brief Initialize main component and data.
	    */
        public MainWindow()
        {
            InitializeComponent();
            DBComparer = new functionWrapper();
            tableConditionInfo = new Dictionary<String, Tuple<bool, String>>();
            columnSelectInfo = new Dictionary<String, bool>();
            tableColumnInfo = new Dictionary<String, List<String>>();
            tableSelectAll = new HashSet<String>();
            tableDatasetInfo = new Dictionary<String, String>();
        }
        /**
	    * @brief Get table list and its record count from selected user.
	    * @param sender		    [in]	triggered interface object
	    * @param e	        	[in]    triggered event
	    */
        private void getTable(object sender, RoutedEventArgs e)
        {   
            //Get all user information from the textboxes and connect to SiNDY 
            String user = user1.Text;
            String db = db1.Text;
            String version = version1.Text;
            if (String.IsNullOrWhiteSpace(version))
            {
                version = "SDE.DEFAULT";
            }
            user = user.ToUpper();
            bool isSuccess = DBComparer.preStartTool();
            if (!isSuccess)
            {
                System.Windows.MessageBox.Show("Cannot initialize connection to DB", "Connection Error");
                return;
            }
            isSuccess = DBComparer.connectToDB(db, user, version);
            if (!isSuccess)
            {
                System.Windows.MessageBox.Show("Cannot connect to DB", "Connection Error");
                return;
            }
            string[] featureClassAndCount = DBComparer.getFeatureClassAndCount(db,user,version);
            //format table
            formatTable();
            for (int i =0; i<featureClassAndCount.Length;i+=2)
            {
                String tableName = featureClassAndCount[i];
                int recordCount = Int32.Parse(featureClassAndCount[i + 1]);
                //create table button
                createTableButton(tableName, recordCount);
                //Auto select table and input condition from config file
                if (isTableLoadedFromFile)
                {
                    String tableKeyword = currentDB + "-" + currentUser + "-" + currentVersion + "-" + tableName;
                    if (tableConditionInfo.ContainsKey(tableKeyword))
                    {
                        //Auto input condition
                        TextBox txtBox = (TextBox)LogicalTreeHelper.FindLogicalNode(tableWrapper, tableName + suffix_condition);
                        txtBox.Text = tableConditionInfo[tableKeyword].Item2; // string
                        //Auto select table
                        if (tableConditionInfo[tableKeyword].Item1) // bool
                        {
                            CheckBox chkBox = (CheckBox)LogicalTreeHelper.FindLogicalNode(tableWrapper, tableName + suffix_check);
                            chkBox.IsChecked = true;
                        }
                    }         
                }
            }
            currentDB = db;
            currentUser = user;
            currentVersion = version;
            if (isTableLoadedFromFile)
            {
                //clear column after auto select table.
                formatColumn();
                isTableLoadedFromFile = false;
            }
        }
        /**
        * @brief Clear table panel before inserting table buttons. 
        */
        private void formatTable()
        {
            Border headTable = (Border)LogicalTreeHelper.FindLogicalNode(tableWrapper, res_borderTableHeader);
            tableWrapper.Children.Clear();
            tableWrapper.Background = Brushes.White;
            tableWrapper.Children.Add(headTable);
            tableScrollViewer.ScrollToTop();

        }

        /**
        * @brief Create a table button when load config file or click get table button
        * @param tableName		    [in]	Table Name
        * @param recoudCount	    [in]    The table's total record number
        */
        private void createTableButton(String tableName, int recordCount)
        {
            //Create border for coloured border and grid for button layout
            //    WIDTH
            //   3  38   47   12  = 100%
            //   _______________
            //  |_|____|_____|__|  checkbox:tablename:condition:recordcount
            Border newOuterBorder = new Border();
            newOuterBorder.Style = FindResource(res_borderTableRow) as Style;
            Grid newGrid = new Grid();
            double columnWidth1 = 3;
            double columnWidth2 = 38;
            double columnWidth3 = 47;
            double columnWidth4 = 12;
            ColumnDefinition gridCol = new ColumnDefinition();
            gridCol.Width = new GridLength(columnWidth1, GridUnitType.Star);
            ColumnDefinition gridCol2 = new ColumnDefinition();
            gridCol2.Width = new GridLength(columnWidth2, GridUnitType.Star);
            ColumnDefinition gridCol3 = new ColumnDefinition();
            gridCol3.Width = new GridLength(columnWidth3, GridUnitType.Star);
            ColumnDefinition gridCol4 = new ColumnDefinition();
            gridCol4.Width = new GridLength(columnWidth4, GridUnitType.Star);
            newGrid.ColumnDefinitions.Add(gridCol);
            newGrid.ColumnDefinitions.Add(gridCol2);
            newGrid.ColumnDefinitions.Add(gridCol3);
            newGrid.ColumnDefinitions.Add(gridCol4);
            //Create checkbox
            Viewbox newViewbox = new Viewbox();
            CheckBox newCheckbox = new CheckBox();
            newCheckbox.Name = tableName + suffix_check;
            newCheckbox.Unchecked += updateTableCondition;
            newCheckbox.Checked += updateTableCondition;
            newViewbox.Child = newCheckbox;
            //Add checkbox into the layout
            newGrid.Children.Add(newViewbox);
            //Create tablename textblock and its border
            Border nameInnerBorder = new Border();
            nameInnerBorder.Style = FindResource(res_borderTableInner) as Style;
            nameInnerBorder.SetValue(Grid.ColumnProperty, 1);
            nameInnerBorder.Cursor = Cursors.Hand;
            TextBlock nameTextBlock = new TextBlock();
            nameTextBlock.Style = FindResource(res_textBlockTable) as Style;
            nameTextBlock.Text = tableName;
            nameTextBlock.PreviewMouseLeftButtonDown += tableClick;
            nameTextBlock.Name = tableName;
            nameInnerBorder.Child = nameTextBlock;
            //Add textblock into the layout
            newGrid.Children.Add(nameInnerBorder);
            //Create condition textbox and its border
            Border conditionInnerBorder = new Border();
            conditionInnerBorder.Style = FindResource(res_borderTableInner) as Style;
            conditionInnerBorder.SetValue(Grid.ColumnProperty, 2);
            TextBox conditionTextBox = new TextBox();
            conditionTextBox.Style = FindResource(res_textBoxTable) as Style;
            conditionTextBox.Name = tableName + suffix_condition;
            conditionTextBox.PreviewKeyDown += pressEnter;
            conditionTextBox.LostFocus += updateTableCondition;
            conditionInnerBorder.Child = conditionTextBox;
            //Add textbox into the layout
            newGrid.Children.Add(conditionInnerBorder);
            //Create recordcount textblock and its border
            Border countInnerBorder = new Border();
            countInnerBorder.Style = FindResource(res_borderTableInner) as Style;
            countInnerBorder.SetValue(Grid.ColumnProperty, 3);
            TextBlock countTextBlock = new TextBlock();
            countTextBlock.Style = FindResource(res_textBlockTable) as Style;
            countTextBlock.Text = recordCount.ToString();
            countTextBlock.Name = tableName + suffix_count;
            countInnerBorder.Child = countTextBlock;
            //Add textblock into the layout
            newGrid.Children.Add(countInnerBorder);
            newOuterBorder.Child = newGrid;
            //Add the layout into table panel
            tableWrapper.Children.Add(newOuterBorder);
        }
        /**
        * @brief Update table condition into dict when a table checkbox or condition textblock has a change.
        * @param sender		    [in]	triggered interface object
        * @param e	        	[in]    triggered event
        */
        private void updateTableCondition(object sender, RoutedEventArgs e)
        {
            bool chkBoxChecked = false;
            String conditTxt;
            String tableName;
            //update when table checkbox is selected or deselected
            if (sender.GetType().Name == "CheckBox")
            {
                CheckBox obj = sender as CheckBox;
                chkBoxChecked = (bool)obj.IsChecked;
                String conditTxtBlockName = obj.Name.Substring(0, obj.Name.Length - 4) + suffix_condition;
                tableName = obj.Name.Substring(0, obj.Name.Length - 4);
                TextBox txtBox = (TextBox)LogicalTreeHelper.FindLogicalNode(tableWrapper, conditTxtBlockName);
                conditTxt = txtBox.Text;
            }
            //update when condition textblock lose keyboard focus
            else
            {
                TextBox obj = sender as TextBox;
                conditTxt = obj.Text;
                String chkBoxName = obj.Name.Substring(0, obj.Name.Length - 7) + suffix_check;
                tableName = obj.Name.Substring(0, obj.Name.Length - 7);
                CheckBox chkBox = (CheckBox)LogicalTreeHelper.FindLogicalNode(tableWrapper, chkBoxName);
                chkBoxChecked = (bool)chkBox.IsChecked;
            }
            //update to the dict
            String userTableData = currentDB + "-" + currentUser + "-" + currentVersion + '-' + tableName;
            var condition = Tuple.Create(chkBoxChecked, conditTxt);
            if (!tableConditionInfo.ContainsKey(userTableData))
            {
                tableConditionInfo.Add(userTableData, condition);
            }
            else
            {
                tableConditionInfo[userTableData] = condition;
            }
        }
        /**
        * @brief press entered when keyboard focus on a condition textblock to update a change.
        * @param sender		    [in]	triggered interface object
        * @param e	        	[in]    triggered event
        */
        private void pressEnter(object sender, KeyEventArgs e)
        {
            if (Key.Enter == e.Key)
            {
                updateTableCondition(sender, e);
                Keyboard.ClearFocus();
            }
        }
        /**
        * @brief When a tablename textblock is clicked, show its column list. 
        * @param sender		    [in]	triggered interface object
        * @param e	        	[in]    triggered event
        */
        private void tableClick(object sender, RoutedEventArgs e)
        {
            DependencyObject obj = sender as DependencyObject;
            TextBlock txtBlock = sender as TextBlock;
            String tableName = txtBlock.Name;
            //if this table is not selected already, show its column list
            if (tableName != currentTable)
            {
                currentTable = tableName;
                formatColumn();
                //print all column buttons into column panel.
                setColumnList(tableName);
                //check if there is any selected column
                String tableKeyWord = currentDB + "-" + currentUser + "-" + currentVersion + "-" + tableName;
                if (tableColumnInfo.ContainsKey(tableKeyWord))
                {
                    //check if config file choose select all for this table
                    bool IsPreConfigSelectAll = false;
                    if (tableSelectAll.Contains(tableKeyWord))
                    {
                        IsPreConfigSelectAll = true;
                        tableSelectAll.Remove(tableKeyWord);
                    }
                    //auto select column buttons from dict or config boolean. 
                    foreach (String columnName in tableColumnInfo[tableKeyWord])
                    {
                        String columnKeyword = tableKeyWord + "-" + columnName;
                        if ((columnSelectInfo.ContainsKey(columnKeyword) && columnSelectInfo[columnKeyword]) || IsPreConfigSelectAll)
                        {
                            Button btn = (Button)LogicalTreeHelper.FindLogicalNode(columnWrapper, columnName);
                            btn.RaiseEvent(new RoutedEventArgs(Button.ClickEvent));
                        }
                    }
                }
            }
            // auto select a table's checkboxes.
            String tes;
            do
            {
                obj = LogicalTreeHelper.GetParent(obj);
                tes = obj.GetType().Name;
            } while (tes != "Grid");
            foreach (CheckBox chkBox in FindVisualChildren<CheckBox>(obj))
            {
                if (chkBox.IsChecked == false)
                    chkBox.IsChecked = true;
            }
        }
        /**
        * @brief Select all table checkboxes programmatically when "Select All" button is clicked. 
        * @param sender		    [in]	triggered interface object
        * @param e	        	[in]    triggered event
        */
        private void selectAllTable(object sender, RoutedEventArgs e)
        {
            foreach (CheckBox chkBox in FindVisualChildren<CheckBox>(tableWrapper))
            {
                chkBox.IsChecked = true;
            }
            formatColumn();
            currentTable = "";
        }
        /**
        * @brief Deselect all table checkboxes programmatically when "Clear All" button is clicked. 
        * @param sender		    [in]	triggered interface object
        * @param e	        	[in]    triggered event
        */
        private void clearAllTable(object sender, RoutedEventArgs e)
        {
            foreach (CheckBox chkBox in FindVisualChildren<CheckBox>(tableWrapper))
            {
                chkBox.IsChecked = false;
            }
        }
        /**
        * @brief Clear column panel before inserting column buttons. 
        */
        private void formatColumn()
        {
            columnWrapper.Children.Clear();
            columnWrapper.Background = Brushes.White;
        }
        /**
        * @brief Create a column button when a table is selected
        * @param columnName		    [in]	Column Name [ex. OBJECTID]
        */
        private void createColumnButton(String columnName)
        {

            //Create button layout
            //    WIDTH
            //   _______
            //  |_|_|_|_|  HEI
            //  |_|_|_|_|  GHT

            Grid newGrid = new Grid();
            newGrid.Style = FindResource(res_gridColumnButton) as Style;
            ColumnDefinition gridCol = new ColumnDefinition();
            gridCol.Width = new GridLength(1, GridUnitType.Star);
            ColumnDefinition gridCol2 = new ColumnDefinition();
            gridCol2.Width = new GridLength(1, GridUnitType.Star);
            ColumnDefinition gridCol3 = new ColumnDefinition();
            gridCol3.Width = new GridLength(1, GridUnitType.Star);
            ColumnDefinition gridCol4 = new ColumnDefinition();
            gridCol4.Width = new GridLength(1, GridUnitType.Star);
            newGrid.ColumnDefinitions.Add(gridCol);
            newGrid.ColumnDefinitions.Add(gridCol2);
            newGrid.ColumnDefinitions.Add(gridCol3);
            newGrid.ColumnDefinitions.Add(gridCol4);
            RowDefinition gridRow = new RowDefinition();
            RowDefinition gridRow2 = new RowDefinition();
            gridRow.Height = new GridLength(1, GridUnitType.Star);
            gridRow2.Height = new GridLength(1, GridUnitType.Star);
            newGrid.RowDefinitions.Add(gridRow);
            newGrid.RowDefinitions.Add(gridRow2);
            //Create column button
            Button columnButton = new Button();
            columnButton.Style = FindResource(res_columnButton) as Style;
            columnButton.Content = columnName;
            columnButton.Click += selectColumn;
            columnButton.Name = columnName;
            //Create close button
            Button closeButton = new Button();
            closeButton.Style = FindResource(res_closeButton) as Style;
            closeButton.Visibility = Visibility.Hidden;
            closeButton.Click += closeColumn;
            closeButton.Name = columnName + suffix_close;
            //Add both buttons into the layout
            newGrid.Children.Add(closeButton);
            newGrid.Children.Add(columnButton);
            //Add the layout into column panel
            columnWrapper.Children.Add(newGrid);
        }
        /**
        * @brief Show animation and record selected column when a column button is clicked
        * @param sender		    [in]	triggered interface object
        * @param e	        	[in]    triggered event
        */
        private void selectColumn(object sender, RoutedEventArgs e)
        {
            Button btn = sender as Button;
            String columnName = btn.Name;
            //if it not selected yet
            if (btn.Background == Brushes.White)
            {
                //change background to green and show close button
                btn.Background = Brushes.LightGreen;
                Button closeButton = (Button)LogicalTreeHelper.FindLogicalNode(columnWrapper, columnName + suffix_close);
                if (closeButton == null)
                {
                    return;
                }
                closeButton.Visibility = Visibility.Visible;
                //record status into dict
                String userTableColData = currentDB + "-" + currentUser + "-" + currentVersion + '-' + currentTable + '-' + columnName;
                if (!columnSelectInfo.ContainsKey(userTableColData))
                {
                    columnSelectInfo.Add(userTableColData, true);
                }
                else
                {
                    columnSelectInfo[userTableColData] = true;
                }
            }
        }
        /**
        * @brief Show animation and record selected column when a close column button is clicked
        * @param sender		    [in]	triggered interface object
        * @param e	        	[in]    triggered event
        */
        private void closeColumn(object sender, RoutedEventArgs e)
        {
            Button btn = sender as Button;
            String columnName = btn.Name.Substring(0, btn.Name.Length - 6);
            Button columnButton = (Button)LogicalTreeHelper.FindLogicalNode(columnWrapper, columnName);
            //change background to white and hide close button
            columnButton.Background = Brushes.White;
            btn.Visibility = Visibility.Hidden;
            //record status into dict
            String userTableColData = currentDB + "-" + currentUser + "-" + currentVersion + '-' + currentTable + '-' + columnName;
            if (!columnSelectInfo.ContainsKey(userTableColData))
            {
                columnSelectInfo.Add(userTableColData, false);
            }
            else
            {
                columnSelectInfo[userTableColData] = false;
            }
        }
        /**
        * @brief Print all column buttons into column panel 
        * @param tablename		[in]	target table name
        */
        private void setColumnList(String tableName)
        {
            List<String> columnList = new List<String>();
            string[] getList = DBComparer.getfieldNameList(currentDB,currentUser,currentVersion,tableName);
            for (int i = 0; i < getList.Length; i ++)
            {
                String columnName = getList[i];
                if (columnName.Contains(".")) continue;
                columnList.Add(columnName);
                createColumnButton(columnName);
            }
            String tableKeyWord = currentDB + "-" + currentUser + "-" + currentVersion + "-" + tableName;
            tableColumnInfo[tableKeyWord] = columnList;
            columnLabel.Content = "Select target field(s) for " + tableName;
        }
        /**
        * @brief Select all columns programmatically when "Select All" button is clicked. 
        * @param sender		    [in]	triggered interface object
        * @param e	        	[in]    triggered event
        */
        private void selectAllColumn(object sender, RoutedEventArgs e)
        {
            foreach(Button btn in FindVisualChildren<Button>(columnWrapper))
            {
                int finding = btn.Name.IndexOf(suffix_close);
                if (finding == -1)
                    btn.RaiseEvent(new RoutedEventArgs(Button.ClickEvent));
            }
        }
        /**
        * @brief Deselect all columns programmatically when "Clear All" button is clicked. 
        * @param sender		    [in]	triggered interface object
        * @param e	        	[in]    triggered event
        */
        private void clearAllColumn(object sender, RoutedEventArgs e)
        {
            foreach (Button btn in FindVisualChildren<Button>(columnWrapper))
            {
                int finding = btn.Name.IndexOf(suffix_close);
                if (finding != -1)
                    btn.RaiseEvent(new RoutedEventArgs(Button.ClickEvent));
            }
        }
        /**
        * @brief Open config file
        * @param sender		    [in]	triggered interface object
        * @param e	        	[in]    triggered event
        */
        private void openFile(object sender, RoutedEventArgs e)
        {
            // Create OpenFileDialog 
            Microsoft.Win32.OpenFileDialog dlg = new Microsoft.Win32.OpenFileDialog();
            // Set filter for file extension and default file extension 
            dlg.Filter = "Text Files (*.txt)|*.txt|INI Files (*.ini)|*.ini|All Files (*.*)|*.*";
            // Display OpenFileDialog by calling ShowDialog method 
            Nullable<bool> result = dlg.ShowDialog();
            // Get the selected file name and proceed the settings 
            if (result == true)
            {
                // Open document 
                String filename = dlg.FileName;
                String tableName = "";
                bool readingField = false;
                List<String> previousLine = new List<String>();
                //proceed to read line by line
                foreach (String line in File.ReadLines(filename))
                {
                    String editedLine = excludeCommentandTrim(line);
                    //get DBuser info
                    openUserInfo(editedLine);
                    //while reading field...
                    if (editedLine == "%TABLE")
                    {
                        //end of field list
                        if (readingField == true)
                        {
                            readingField = false;
                        }
                        else if (tableName != "")
                        {
                            System.Windows.MessageBox.Show("Config file format is incorrect while reading field list of " + tableName, "File Error");
                            return;

                        }
                    }
                    //when find %FIELD, proceed to read a table's condition
                    else if (editedLine == "%FIELD")
                    {
                        //if reading field list but found field header again
                        if (readingField == true)
                        {
                            System.Windows.MessageBox.Show("Config file format is incorrect while reading field list of " + tableName, "File Error");
                            return;
                        }
                        //Acquire a table's condition
                        String conditionTxt = "";
                        for (int i = previousLine.Count - 1; i >= 0; i--)
                        {
                            //have condition
                            if (previousLine[i] == "%WHERE")
                            {
                                tableName = previousLine[i - 1].Trim();
                                getTableConditToDict(conditionTxt, tableName);
                                break;
                            }
                            //not have condition
                            else if (previousLine[i] == "%TABLE")
                            {
                                tableName = previousLine[i + 1].Trim();
                                getTableConditToDict("", tableName);
                                break;
                            }
                            //read till very first line == error
                            else if (i == 0)
                            {
                                System.Windows.MessageBox.Show("Config file format is incorrect while reading condition of " + tableName, "File Error");
                                break;
                            }
                            //concat condition string
                            conditionTxt = previousLine[i] + " " + conditionTxt;
                        }
                        //start reading field list
                        readingField = true;
                    }
                    //reading field list
                    else if (readingField)
                    {
                        openColumnInfo(editedLine.Trim(), tableName);
                    }
                    previousLine.Add(editedLine);
                }
                isTableLoadedFromFile = true;
                //finished reading config file, update the interface.
                System.Windows.MessageBox.Show("Successfully read config file", "Success");
                getTable(sender, e);
            }
            else
            {
                System.Windows.MessageBox.Show("Failed to open the file. Please try another file.", "File Error");
                return;
            }
        }
        /**
        * @brief Get a string line, delete comment (#...) and trim whitespace
        * @param line		    [in]	input string line
        * @return   processed string
        */
        private String excludeCommentandTrim(String line)
        {
            if (line.IndexOf("#") != -1)
                return line.Substring(0, line.IndexOf("#")).Trim();
            else
                return line.Trim();
        }
        /**
        * @brief Get a string line, detect if the line is related to DBuser information and copy to textbox
        * @param userInfo		    [in]	input string line
        */
        private void openUserInfo(String userInfo)
        {
            if (userInfo.Contains("user_1"))
            {
                user1.Text = getUserData(userInfo);
            }
            else if (userInfo.Contains("user_2"))
            {
                user2.Text = getUserData(userInfo);
            }
            else if (userInfo.Contains("server_1"))
            {
                db1.Text = getUserData(userInfo);
            }
            else if (userInfo.Contains("server_2"))
            {
                db2.Text = getUserData(userInfo);
            }
            else if (userInfo.Contains("version_1"))
            {
                version1.Text = getUserData(userInfo);
            }
            else if (userInfo.Contains("version_2"))
            {
                version2.Text = getUserData(userInfo);
            }
        }
        /**
        * @brief Get table condition and selection into dict for later process.
        * @param conditTxt		    [in]	table's condition
        * @param tableName		    [in]	table name
        */
        private void getTableConditToDict(String conditTxt,String tableName)
        {
            currentDB = db1.Text;
            currentUser = user1.Text;
            currentVersion = version1.Text;
            if (String.IsNullOrWhiteSpace(currentVersion))
            {
                currentVersion = "SDE.DEFAULT";
            }
            String tableKeyword = currentDB + "-" + currentUser + "-" + currentVersion + "-" + tableName;
            Tuple<bool, String> condit = Tuple.Create(true,conditTxt);
            if (!tableConditionInfo.ContainsKey(tableKeyword))
            {
                tableConditionInfo.Add(tableKeyword, condit);
            }
            else
            {
                tableConditionInfo[tableKeyword] = condit;
            }
        }
        /**
        * @brief Get column selection into dict for later process.
        * @param columnName		    [in]	column name
        * @param tableName		    [in]	table name
        */
        private void openColumnInfo(String columnName,String tableName)
        {
            //if none selected
            if (columnName == "-" || String.IsNullOrWhiteSpace(columnName))
            {
                return;
            }
            //if all selected
            else if (columnName == "*")
            {
                String tableHashKeyword = currentDB + "-" + currentUser + "-" + currentVersion + "-" + tableName;
                tableSelectAll.Add(tableHashKeyword);
            }
            String columnKeyword = currentDB + "-" + currentUser + "-" + currentVersion + "-" + tableName + "-" + columnName;
            if (!columnSelectInfo.ContainsKey(columnKeyword))
            {
                columnSelectInfo.Add(columnKeyword, true);
            }
            else
            {
                columnSelectInfo[columnKeyword] = true;
            }
        }
        /**
        * @brief Get variable value from a line in config file [ex. user_1 = TEST2017]
        * @param userInfo	    [in]	input string line
        * @return   variable value [ex. TEST2017]
        */
        private String getUserData(String userInfo)
        {
            int start = userInfo.IndexOf('=') + 1;
            int end = userInfo.Length;
            String variableValue = userInfo.Substring(start, end - start).Trim();
            return variableValue;
        }
        /**
        * @brief Save config file into the specified path.
        * @param sender		    [in]	triggered interface object
        * @param e	        	[in]    triggered event
        */
        private void saveFile(object sender, RoutedEventArgs e)
        {
            // Create OpenFileDialog 
            Microsoft.Win32.SaveFileDialog dlg = new Microsoft.Win32.SaveFileDialog();

            // Set filter for file extension and default file extension 
            dlg.Filter = "Text Files (*.txt)|*.txt|INI Files (*.ini)|*.ini|All Files (*.*)|*.*";

            // Display OpenFileDialog by calling ShowDialog method 
            Nullable<bool> result = dlg.ShowDialog();

            // Get the selected file name and display in a TextBox 
            if (result == true)
            {
                // Open document 
                String filename = dlg.FileName;
                writeConfigToFile(filename);
            }
        }
        /**
        * @brief Write config content into the specified file.
        * @param filename		   [in]	filename to write config content into
        */
        private void writeConfigToFile(String filename)
        {
            List<String> configText = new List<String>();
            configText.Add("###CONFIG LIST###");
            configText.Add("");
            configText.Add("##User 1 information");
            configText.Add("user_1=" + user1.Text);
            configText.Add("server_1=" + db1.Text);
            configText.Add("version_1=" + version1.Text + "\t#BLANK = 'SDE.DEFAULT'");
            configText.Add("##User 2 information");
            configText.Add("user_2=" + user2.Text);
            configText.Add("server_2=" + db2.Text);
            configText.Add("version_2=" + version2.Text + "\t#BLANK = 'SDE.DEFAULT'");
            configText.Add("");
            configText.Add("##Table and column list");
            configText.Add("#Below is format for input data");
            configText.Add("#%TABLE");
            configText.Add("#<TABLE_NAME>");
            configText.Add("#%WHERE");
            configText.Add("#<CONDITION>");
            configText.Add("#%FIELD");
            configText.Add("#<FIELD_NAME1>");
            configText.Add("#<FIELD_NAME2>");
            configText.Add("#:");
            configText.Add("#");
            configText.Add("#If you want a table to output all columns: use '*' under %FIELD line");
            configText.Add("#If you want a table to output no column(only table record count): use '-' under %FIELD line");
            List<String> tableList = new List<String>();
            List<String> columnList = new List<String>();
            //get table with selected condition
            foreach (KeyValuePair<String,Tuple<bool,String>> tableCon in tableConditionInfo)
            {
                //if not select, skip
                if (tableCon.Value.Item1 == false)
                    continue;
                String tableName = tableCon.Key;
                int a = tableName.IndexOf('-');
                int b = tableName.Length;
                tableName = tableName.Substring(a+1,b-a-1);
                //add %TABLE and tablename line
                configText.Add("%TABLE");
                configText.Add(tableName);
                //if condition is not empty, add %WHERE and condition line
                String tableCondition = tableCon.Value.Item2;
                if (!(tableCondition == null || tableCondition == ""))
                {
                    configText.Add("%WHERE");
                }
                //get selected column
                columnList = getColumnList(tableName,false);
                configText.Add("%FIELD");
                foreach (String columnName in columnList)
                {
                    //if select all
                    if (columnName == "*")
                    {
                        configText.Add("*");
                        break;
                    }
                    //if select none
                    else if (columnName == "-")
                    {
                        configText.Add("-");
                        break;
                    }
                    configText.Add(columnName);
                }
                configText.Add("");
            }
            configText.Add("###End of File###");
            File.WriteAllLines(filename, configText);
        }
        /**
        * @brief get column name list from a selected table
        * @param tableName		    [in]	tableName
        * @param isPrintToTSV	    [in]	Define that the output format is for TSV file or config file
        * return List of column name
        */
        private List<String> getColumnList(String tableName,bool isPrintToTSV)
        {
            String tableKeyword = currentDB + "-" + currentUser + "-" + currentVersion + "-" + tableName;
            List<String> columnList = new List<String>();
            int countSelected = 0;
            int countTotal = 0;
            //if none selected
            if (!tableColumnInfo.ContainsKey(tableKeyword))
            {
                return new List<String> { "-" };
            }
            //get column name 1 by 1
            foreach (String columnName in tableColumnInfo[tableKeyword])
            {
                String columnKeyword = tableKeyword + "-" + columnName; 
                if (columnSelectInfo.ContainsKey(columnKeyword) == true && columnSelectInfo[columnKeyword] == true)
                {
                        columnList.Add(columnName);
                        countSelected++;
                }
                countTotal++;
            }
            if (countTotal > 0)
            {
                //if all selected and not to TSV file
                if (countSelected == countTotal && !isPrintToTSV)
                {
                    return new List<String> { "*" };
                }
                //if none selected and not to TSV file
                else if (countSelected == 0 && !isPrintToTSV)
                {
                    return new List<String> { "-" };
                }
                //return all column names
                else
                {
                    return columnList;
                }
            }
            //if no column
            return new List<string> { "" };
        }
        /**
        * @brief Find all child objects which match selected object type under the selected element
        * @param T    	     [in]	object type [ex. Checkbox, textblock]
        * @param depObj      [in]	parent element
        * return List of found object
        */
        public static IEnumerable<T> FindVisualChildren<T>(DependencyObject depObj) where T : DependencyObject
        {
            if (depObj != null)
            {
                for (int i = 0; i < VisualTreeHelper.GetChildrenCount(depObj); i++)
                {
                    DependencyObject child = VisualTreeHelper.GetChild(depObj, i);
                    if (child != null && child is T)
                    {
                        yield return (T)child;
                    }

                    foreach (T childOfChild in FindVisualChildren<T>(child))
                    {
                        yield return childOfChild;
                    }
                }
            }
        }
        /**
        * @brief Auto change compare button text when user2 input textbox has a change. 
        * @param sender		    [in]	triggered interface object
        * @param e	        	[in]    triggered event
        */
        private void user2_textChanged(object sender, TextChangedEventArgs e)
        {
            TextBox txtBox = sender as TextBox;
            if (String.IsNullOrWhiteSpace(user2.Text) || String.IsNullOrWhiteSpace(db2.Text))
            {
                compareButton.Content = "Get Data";
            }
            else
            {
                compareButton.Content = "Compare";
            }
        }
        /**
        * @brief Check all table's condition correctness. Initiate log file, and start writing to TSV file 
        * @param sender		    [in]	triggered interface object
        * @param e	        	[in]    triggered event
        */
        private void getOrCompareData(object sender, RoutedEventArgs e)
        {
            //check all table's condition correctness
            foreach (TextBox txtBox in FindVisualChildren<TextBox>(tableWrapper))
            {
                int finding = txtBox.Name.IndexOf(suffix_condition);
                if (finding != -1)
                {
                    String SQLText  = txtBox.Text;
                    String tableName = txtBox.Name.Substring(0, finding);
                    bool isCorrect = DBComparer.checkSQLSyntax(SQLText,currentDB,currentUser,currentVersion,tableName);
                    if (!isCorrect)
                    {
                        System.Windows.MessageBox.Show(tableName + ": has wrong search condition(syntax or variable)", "Condition Error");
                        return;
                    }
                }
            }

            // Create OpenFileDialog 
            Microsoft.Win32.SaveFileDialog dlg = new Microsoft.Win32.SaveFileDialog();

            // Set filter for file extension and default file extension 
            dlg.Filter = "TSV Files (*.tsv)| *.tsv";

            // Display OpenFileDialog by calling ShowDialog method 
            Nullable<bool> fileResult = dlg.ShowDialog();

            // Get the selected file name and display in a TextBox 
            if (fileResult == true)
            {
                // Open document 
                String filename = dlg.FileName;
                //if user2 is not defined
                if (String.IsNullOrWhiteSpace(user2.Text) || String.IsNullOrWhiteSpace(db2.Text))
                {
                    printDataToTSV(filename, false);
                }
                //if user2 is defined
                else
                {
                    printDataToTSV(filename, true);
                }
            }
            //if something went wrong and can't open the file
            else
            {
                System.Windows.MessageBox.Show("Failed to open the file. Please try another file.", "File Error");
            }
        }
        /**
        * @brief print all selection and condition to TSV file. While including header and check for error
        * @param fileName	    [in]	TSV filename
        * @param isCompare     	[in]    only get 1 user or compare 2 users data
        */
        private void printDataToTSV(String filename, bool isCompare)
        {
            List<String> tsvText = new List<String>();
            var delimiter = "\t";
            //print TSV header
            List<String> tsvHeader;
            if (isCompare)
            {
                tsvHeader = new List<String> { "DATASET", "NAME", "QUERY_KEYWORD", "CODE", "DESCRIPTION", "RECORD_COUNT1", "DISTANCE(KM) AREA(KM2)", "RECORD_COUNT2", "DISTANCE(KM) AREA(KM2)" };
                connectToUser2();
            }
            else
            {
                tsvHeader = new List<String> { "DATASET", "NAME", "QUERY_KEYWORD", "CODE", "DESCRIPTION", "RECORD_COUNT", "DISTANCE(KM) AREA(KM2)" };
            }
            String headerLine = String.Join(delimiter, tsvHeader);
            tsvText.Add(headerLine);
            //record select objects
            List<String> selectObjects = new List<String>();
            selectObjects.Add("Selected objects :");
            //get table 1 by 1
            foreach (KeyValuePair<String, Tuple<bool, String>> tableCon in tableConditionInfo)
            {
                //skip if the table is not selected
                if (tableCon.Value.Item1 == false)
                    continue;
                String tableName = tableCon.Key;
                int a = tableName.IndexOf('-');
                int b = tableName.Length;
                tableName = tableName.Substring(a + 1, b - a - 1);
                String conditTxt = tableCon.Value.Item2;
                selectObjects.Add("\t" + tableName + "\t\t" + conditTxt);
                //get processed TSV format table data
                String tableRow = String.Join(delimiter, getTableRow(tableName, conditTxt, isCompare));
                tsvText.Add(tableRow);
                //get column 1 by 1
                List<String> columnList = getColumnList(tableName, true);
                foreach (String columnName in columnList)
                {
                    //if none selected
                    if (columnName == "-")
                    {
                        break;
                    }
                    // if the column has no domain
                    if (!DBComparer.hasDomain(currentDB,currentUser,currentVersion,tableName,columnName))
                    {
                        String columnRow = String.Join(delimiter, getNormalColumnRow(tableName, columnName, conditTxt, isCompare));
                        tsvText.Add(columnRow);
                    }
                    else
                    {
                        ///to add domain
                        List<String> multiColumnRow = getMultiColumnRow(delimiter,tableName, conditTxt, columnName, false);
                        foreach (String line in multiColumnRow)
                        {
                            tsvText.Add(line);
                        }
                    }
                    selectObjects.Add("\t\t" + columnName);

                }

            }          
            File.WriteAllLines(filename, tsvText);
            if (isCompare)
            {
                System.Windows.MessageBox.Show(" Successfully output the compare result to the TSV file", "Success");
            }
            else
            {
                System.Windows.MessageBox.Show(" Successfully output the result to the TSV file", "Success");
            }
        }
        /**
        * @brief Get TSV format table data
        * @param tableName	    [in]	table name
        * @param conditTxt      [in]    table condition
        * @param isCompare     	[in]    only get 1 user or compare 2 users data
        * return one line of string which is table data in TSV format
        */
        private List<String> getTableRow(String tableName, String conditTxt,bool isCompare)
        {
            /// TO ADD DATASET NAME
            String dataset = DBComparer.getFeatureClassDataSetName(currentDB, currentUser, currentVersion, tableName);
            if (conditTxt == null) conditTxt = "";
            String code = "";
            String description = "";
            String recordCount = DBComparer.getRecordNumber(conditTxt, currentDB, currentUser, currentVersion, tableName).ToString();
            String distArea = DBComparer.getTotalDistArea(conditTxt,currentDB,currentUser,currentVersion,tableName).ToString();
            if (distArea == "0")
            {
                distArea = "-";
            }
            List<String> tableRow;
            if (isCompare)
            {
                String recordCount2 = DBComparer.getRecordNumber(conditTxt, currentDB2, currentUser2, currentVersion2, tableName).ToString();
                if (recordCount2 == "-1")
                {
                    recordCount2 = "-";
                }
                String distArea2 = DBComparer.getTotalDistArea(conditTxt, currentDB2, currentUser2, currentVersion2, tableName).ToString();
                if (distArea2 == "-1")
                {
                    distArea2 = "-";
                }
                tableRow = new List<String> { dataset, tableName, conditTxt, code, description, recordCount, distArea, recordCount2, distArea2 };
            }
            else
            {
                tableRow = new List<String> { dataset, tableName, conditTxt, code, description, recordCount, distArea };
            }
            
            return tableRow;
        }
        /**
        * @brief Get TSV format column data
        * @param tableName      [in]    table name
        * @param columnName	    [in]	column name
        * @param conditTxt      [in]    search condition
        * @param isCompare     	[in]    only get 1 user or compare 2 users data
        * return one line of string which is column data in TSV format
        */
        private List<String> getNormalColumnRow(String columnName, String tableName, String conditTxt, bool isCompare)
        {
            String dataset = "";
            String recordCount = DBComparer.getRecordNumber(conditTxt, currentDB, currentUser, currentVersion, tableName).ToString();
            String distArea = DBComparer.getTotalDistArea(conditTxt, currentDB, currentUser, currentVersion, tableName).ToString();
            if (distArea == "0")
            {
                distArea = "-";
            }
            if (isCompare)
            {
                String recordCount2 = DBComparer.getRecordNumber(conditTxt, currentDB2, currentUser2, currentVersion2, tableName).ToString();
                if (recordCount2 == "-1")
                {
                    recordCount2 = "-";
                }
                String distArea2 = DBComparer.getTotalDistArea(conditTxt, currentDB2, currentUser2, currentVersion2, tableName).ToString();
                if (distArea2 == "-1")
                {
                    distArea2 = "-";
                }
                List<String> columnRow = new List<String> { dataset, columnName, "", "", "", recordCount, distArea, recordCount2, distArea2 };
                return columnRow;
            }
            else
            {
                List<String> columnRow = new List<String> { dataset, columnName, "", "", "", recordCount, distArea };
                return columnRow;

            }
            
        }
        /**
        * @brief Get TSV format column data
        * @param delimiter      [in]    \t
        * @param tableName      [in]    table name
        * @param conditTxt      [in]    search condition
        * @param columnName	    [in]	column name
        * @param isCompare     	[in]    only get 1 user or compare 2 users data
        * return multiple lines of string which is column and domain data in TSV format
        */
        private List<String> getMultiColumnRow(String delimiter, String tableName, String conditTxt, String columnName, bool isCompare)
        {
            // get all domain
            // print one line with code and desc
            // also search record_count and distArea using that domain
            String dataset = "";
            String recordCount = DBComparer.getRecordNumber(conditTxt, currentDB, currentUser, currentVersion, tableName).ToString();
            String distArea = DBComparer.getTotalDistArea(conditTxt, currentDB, currentUser, currentVersion, tableName).ToString();
            if (distArea == "0")
            {
                distArea = "-";
            }
            string[] domainDetails = DBComparer.getDomainNameList(currentDB,currentUser,currentVersion,tableName,columnName);
            List<String> multiColumnRow = new List<String>();
            if (isCompare)
            {
                String recordCount2 = DBComparer.getRecordNumber(conditTxt, currentDB2, currentUser2, currentVersion2, tableName).ToString();
                if (recordCount2 == "-1")
                {
                    recordCount2 = "-";
                }
                String distArea2 = DBComparer.getTotalDistArea(conditTxt, currentDB2, currentUser2, currentVersion2, tableName).ToString();
                if (distArea2 == "-1")
                {
                    distArea2 = "-";
                }
                List<String> fracture = new List<String> { dataset, columnName, "", domainDetails[0], "", recordCount, distArea, recordCount2, distArea2 };
                String columnRow = String.Join(delimiter, fracture);
                multiColumnRow.Add(columnRow);
                for (int i = 1; i < domainDetails.Length; i += 2)
                {
                    String code = domainDetails[i];
                    String description = domainDetails[i + 1];
                    String SQLText = conditTxt + " AND " + columnName + " = " + domainDetails[i]; //ex. where PRODUCT_C = 3
                    long fieldRecordCount = DBComparer.getRecordNumber(SQLText, currentDB, currentUser, currentVersion, tableName);
                    long fieldRecordCount2 = DBComparer.getRecordNumber(SQLText, currentDB2, currentUser2, currentVersion2, tableName);
                    double fieldDistArea = DBComparer.getTotalDistArea(SQLText, currentDB, currentUser, currentVersion, tableName);
                    double fieldDistArea2 = DBComparer.getTotalDistArea(SQLText, currentDB2, currentUser2, currentVersion2, tableName);
                    fracture = new List<String> { dataset, columnName, "", code, description, fieldRecordCount.ToString(), fieldDistArea.ToString(), fieldRecordCount2.ToString(), fieldDistArea2.ToString() };
                    columnRow = String.Join(delimiter, fracture);
                    multiColumnRow.Add(columnRow);
                }
            }
            else
            {
                List<String> fracture = new List<String> { dataset, columnName, "", domainDetails[0], "", recordCount, distArea };
                String columnRow = String.Join(delimiter, fracture);
                multiColumnRow.Add(columnRow);
                for (int i=1; i < domainDetails.Length; i += 2)
                {
                    String code = domainDetails[i];
                    String description = domainDetails[i + 1];
                    String SQLText = conditTxt + " AND " + columnName + " = " + domainDetails[i]; //ex. where PRODUCT_C = 3
                    long fieldRecordCount = DBComparer.getRecordNumber(SQLText, currentDB, currentUser, currentVersion, tableName);
                    double fieldDistArea = DBComparer.getTotalDistArea(SQLText, currentDB, currentUser, currentVersion, tableName);
                    fracture = new List<String> { dataset, columnName, conditTxt, code , description , fieldRecordCount.ToString(), fieldDistArea.ToString() };
                    columnRow = String.Join(delimiter, fracture);
                    multiColumnRow.Add(columnRow);
                }
                
            }
            return multiColumnRow;
        }

        private void connectToUser2()
        {
            currentUser2 = user2.Text;
            currentDB2 = db2.Text;
            currentVersion2 = version2.Text;
            currentUser2 = currentUser2.ToUpper();
            if (String.IsNullOrWhiteSpace(currentVersion2))
            {
                currentVersion2 = "SDE.DEFAULT";
            }
            bool isSuccess = DBComparer.connectToDB(currentDB2, currentUser2, currentVersion2);
            if (!isSuccess)
            {
                System.Windows.MessageBox.Show("Cannot connect to DB 2", "Connection Error");
                return;
            }
        }


    }
}
