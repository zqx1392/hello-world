#pragma once

/**
* @brief Manage server connection and store ArcGIS-related variable.
*/
class AccessSV
{
public:
	AccessSV(void);
	~AccessSV(void);

	/**
	* @brief Create new workspace
	* @param workspaceName		[in]	workspace full name [ex. TEST2017@gaia(SDE.DEFAULT)]
	* @return	success��0�Afailure��1
	*/
	int setWorkspace(CString workspaceName);
	/**
	* @brief Get created workspace
	* @param workspaceName		[in]	workspace full name [ex. TEST2017@gaia(SDE.DEFAULT)]
	* @return	workspace variable
	*/
	IWorkspacePtr getWorkspace(CString workspaceName);
	/**
	* @brief Clear workspace list
	*/
	void clearWorkspaceList();
	/**
	* @brief Create new featureClass
	* @param workspaceName		[in]	workspace full name [ex. TEST2017@gaia(SDE.DEFAULT)]
	* @param featureClassName	[in]	featureclass full name [ex. TEST2017.ROAD_LINK]
	* @return	success��0�Afailure��1
	*/
	int setFeatureClass (CString workspaceName, CString featureClassName);
	/**
	* @brief Get created featureClass
	* @param workspaceName		[in]	workspace full name [ex. TEST2017@gaia(SDE.DEFAULT)]
	* @param featureClassName	[in]	featureclass full name [ex. TEST2017.ROAD_LINK]
	* @return	featureClass variable
	*/
	IFeatureClassPtr getFeatureClass(CString workspaceName, CString featureClassName);
	/**
	* @brief Clear featureClass list
	*/
	void clearFeatureClassList();
	/**
	* @brief Create new table
	* @param workspaceName		[in]	workspace full name [ex. TEST2017@gaia(SDE.DEFAULT)]
	* @param tableName			[in]	table full name [ex. TEST2017.ALTERNATIVE_NAME]
	* @return	success��0�Afailure��1
	*/
	int setTable(CString workspaceName, CString tablesName);
	/**
	* @brief Get created table
	* @param workspaceName		[in]	workspace full name [ex. TEST2017@gaia(SDE.DEFAULT)]
	* @param tableName			[in]	table full name [ex. TEST2017.ALTERNATIVE_NAME]
	* @return	table variable
	*/
	ITablePtr getTable(CString workspaceName, CString tableName);
	/**
	* @brief Clear table list
	*/
	void clearTableList();
	/**
	* @brief Create new field
	* @param workspaceName		[in]	workspace full name [ex. TEST2017@gaia(SDE.DEFAULT)]
	* @param datasetName		[in]	target dataset name [ex. sindy::schema::example:kfeatureClassName, "ROAD_LINK", "ALTERNATIVE_NAME"]
	* @param fieldName			[in]	field name [ex. OBJECTID]
	* @param isTable			[in]	Is input dataset name table name or featureClass name
	* @return	success��0�Afailure��1
	*/
	int setField(CString workspaceName, CString featureClassName, CString fieldName, bool isTable);
	/**
	* @brief Get created featureClass
	* @param workspaceName		[in]	workspace full name [ex. TEST2017@gaia(SDE.DEFAULT)]
	* @param datasetName		[in]	target dataset name [ex. sindy::schema::example:kfeatureClassName, "ROAD_LINK", "ALTERNATIVE_NAME"]
	* @param fieldName			[in]	field name [ex. OBJECTID]
	* @return	field variable
	*/
	IFieldPtr getField(CString workspaceName, CString datasetName, CString fieldName);
	/**
	* @brief Clear field list
	*/
	void clearFieldList();

private:
	std::map<CString,IWorkspacePtr> workspaceMap;			//Record DB list
	std::map<CString,IFeatureClassPtr>  featureClassMap;	//Record current DB's featureclass list 
	std::map<CString, ITablePtr>  tableMap;					//Record current DB's table list
	std::map<CString, IFieldPtr> fieldMap;					//Record current featureclass's field list 

};