#pragma once
#include "stdafx.h"
#include "DBComparer.h"
#include <arctl/coinitializer.h>

arctl::coinitializer aCoInitializer;

DBComparer::DBComparer() {
}

DBComparer::~DBComparer() {

}
void DBComparer::setIOManager(IOManager * _IOManager) {
	m_IOManager = _IOManager;
}
void DBComparer::setSVManager(AccessSV * _accessSV) {
	m_accessSV = _accessSV;
}
void DBComparer::setErrorManager(ErrorManager * _errorManager) {
	m_errorManager = _errorManager;
}
void DBComparer::setDataManager(DataManager * _dataManager) {
	m_dataManager = _dataManager;
}
int DBComparer::preStartTool()
{
	ErrorManager * _errorManager = new ErrorManager();
	IOManager * _IOManager = new IOManager();
	DataManager * _dataManager = new DataManager();
	try {
		//Initialize utility classes
		
		setErrorManager(_errorManager);
		setIOManager(_IOManager);
		setDataManager(_dataManager);

		m_errorManager->initErrorMessage();
		m_IOManager->setErrorManager(m_errorManager);
		m_dataManager->setLogger(m_IOManager);

		m_dataManager->setNewFile("ERR", L"", IOManager::FileType::ERR);
		m_dataManager->setNewFile("RUN", L"", IOManager::FileType::RUN);

		//Create files specified in option
		if (is_success != m_dataManager->createFiles()) {
			return endProgramWithError("create files");
		}

		//Initialize connection to server
		AccessSV * _accessSV = new AccessSV();
		setSVManager(_accessSV);
		m_dataManager->setAccSV(m_accessSV);
	}
	catch (const _com_error e) {
		std::cout << std::endl;
		m_IOManager->print_error(ErrorManager::ECode::E_COM_ERROR_IS_CATCHED, (CString)e.ErrorMessage());
		return endProgramWithError("Com Error");
	}
	return 0;
}
int DBComparer::printSuccessfulEnd() {
	m_IOManager->print_run_no_cout("Program ends successfully");
	m_IOManager->print_no_timestamp_run("");
	m_IOManager->print_total_execution_time();
	m_IOManager->closeFile();
	return ErrorManager::RCode::R_SUCCESS;
}
int DBComparer::endProgramWithError(CString errorPoint) {
	CString errorDesc = "An error occured during " + errorPoint;
	m_IOManager->print_run(errorDesc);
	CString errorType;
	if (!_tcscmp(errorPoint, (CString)"Com Error")) {
		errorType = "Exception Error";
	}
	else {
		errorType = "Unsuccessful Termination";
	}
	m_IOManager->print_no_timestamp_run(errorType);
	m_IOManager->print_no_timestamp_run("");
	m_IOManager->closeFile();
	return ErrorManager::RCode::R_FAILED_FATAL_ERROR;
}

int DBComparer::connectToDB(std::wstring DBname, std::wstring username, std::wstring versionName) {
	//setup converter
	std::wstring label(username + L"." + DBname + L"."  + versionName);
	std::string labelName(label.begin(), label.end());
	m_dataManager->setNewDB_divideUserDBVersion(labelName,DBname,username,versionName,false,false);
	return m_dataManager->initDB(labelName);
	
}
std::string DBComparer::getFeatureClassDataSetName(std::wstring DBname, std::wstring username, std::wstring versionName, std::wstring featureClassName) {
	std::wstring DBLabel(username + L"." + DBname + L"." + versionName);
	std::wstring featureClassLabel(DBLabel + L"." + featureClassName);
	std::string DBLabelName(DBLabel.begin(), DBLabel.end());
	std::string featureClassLabelName(featureClassLabel.begin(), featureClassLabel.end());
	CString datasetName = m_dataManager->getFeatureClass(featureClassLabelName).datasetName;
	if (datasetName == "") {
		m_dataManager->setNewFeatureClass_divideUserDBVersion(DBLabelName, featureClassLabelName, username, featureClassName, false);
		m_dataManager->initFeatureClass(featureClassLabelName);
		datasetName = m_dataManager->getFeatureClass(featureClassLabelName).datasetName;
	}
	CT2CA cv(datasetName);
	std::string convertedDatasetName(cv);
	return convertedDatasetName;
}
std::vector<std::string> DBComparer::getFeatureClassAndCount(std::wstring DBname, std::wstring username, std::wstring versionName) {
	std::vector<std::string> featureClassList;
	std::vector<std::string> emptyList;
	std::wstring label(username + L"." + DBname + L"." + versionName);
	std::string labelName(label.begin(), label.end());
	IWorkspacePtr targetWorkspace = m_dataManager->getDB(labelName).workspace;
	IFeatureWorkspacePtr fw = (IFeatureWorkspacePtr)targetWorkspace;
	IEnumDatasetNamePtr datasets;
	if (S_OK != targetWorkspace->get_DatasetNames(esriDatasetType::esriDTFeatureDataset, &datasets)) {
		return emptyList;
	}
	IDatasetNamePtr dataset = NULL;
	//search featureClass
	while ((S_OK == datasets->Next(&dataset)) && dataset)
	{ 
			BSTR featureDatasetName;
			if (S_OK != dataset->get_Name(&featureDatasetName)) {
				return emptyList;
			}
			std::wstring convertedName(featureDatasetName, SysStringLen(featureDatasetName));
			std::string convertedStringName(convertedName.begin(), convertedName.end());
			if (convertedName.find(username) != std::wstring::npos) {
				IFeatureDatasetPtr targetDataset;
				if (S_OK != fw->OpenFeatureDataset(featureDatasetName, &targetDataset)) {
					return emptyList;
				}
				IEnumDatasetPtr targetSubset;
				if (S_OK != targetDataset->get_Subsets(&targetSubset)) {
					return emptyList;
				}
				IDatasetPtr target;
				while ((S_OK == targetSubset->Next(&target)) && target) {
					_bstr_t featureClassName = target->Name;
					IFeatureClassPtr targetFeatureClass;
					if (S_OK != fw->OpenFeatureClass(featureClassName, &targetFeatureClass)) {
					return emptyList;
					}
					IQueryFilterPtr ipQueryFilter(CLSID_QueryFilter);
					long progressCount = 0;
					if (S_OK != targetFeatureClass->FeatureCount(ipQueryFilter, &progressCount)) {
					return emptyList;
					}
					std::wstring cv(featureClassName, SysStringLen(featureClassName));
					cv = cv.substr(cv.find(L".") + 1);
					std::string convertedFeatureClassName(cv.begin(), cv.end());
					//get only table name, not username
					
					featureClassList.push_back(convertedFeatureClassName);
					featureClassList.push_back(std::to_string(progressCount));
					std::wstring featureClassLabel(label + L"." + cv);
					std::string featureClassLabelName(featureClassLabel.begin(), featureClassLabel.end());
					m_dataManager->setNewFeatureClass_divideUserDBVersion(labelName, featureClassLabelName, username, cv, false);
					m_dataManager->initFeatureClass(featureClassLabelName);
				}
			}
	}
	return featureClassList;
}
std::vector<std::string> DBComparer::getTableAndCount(std::wstring DBname, std::wstring username, std::wstring versionName) {
	std::vector<std::string> tableList;
	std::vector<std::string> emptyList;
	std::wstring label(username + L"." + DBname + L"." + versionName);
	std::string labelName(label.begin(), label.end());
	IWorkspacePtr targetWorkspace = m_dataManager->getDB(labelName).workspace;
	IFeatureWorkspacePtr fw = (IFeatureWorkspacePtr)targetWorkspace;
	IEnumDatasetNamePtr datasets;
	IDatasetNamePtr dataset = NULL;
	//search table
	if (S_OK != targetWorkspace->get_DatasetNames(esriDatasetType::esriDTTable, &datasets)) {
		return emptyList;
	}
	while ((S_OK == datasets->Next(&dataset)) && dataset)
	{
		_bstr_t tableName = dataset->Name;
		std::wstring convertedName(tableName, SysStringLen(tableName));
		if (convertedName.find(username) != std::wstring::npos) {
			ITablePtr targetTable;
			if (S_OK != fw->OpenTable(tableName, &targetTable)) {
				return emptyList;
			}
			IQueryFilterPtr ipQueryFilter(CLSID_QueryFilter);
			long progressCount = 0;
			if (S_OK != targetTable->RowCount(ipQueryFilter, &progressCount)) {
				return emptyList;
			}
			std::wstring cv(tableName, SysStringLen(tableName));
			cv = cv.substr(cv.find(L".") + 1);
			std::string convertedTableName(cv.begin(), cv.end());
			//get only table name, not username
			tableList.push_back(convertedTableName);
			tableList.push_back(std::to_string(progressCount));
			std::wstring tableLabel(label + L"." + cv);
			std::string tableLabelName(tableLabel.begin(), tableLabel.end());
			m_dataManager->setNewTable_divideUserDBVersion(labelName, tableLabelName, username, cv, false);
			m_dataManager->initTable(tableLabelName);
		}
	}
	return tableList;
}

std::vector<std::string> DBComparer::getfieldNameList(std::wstring DBname, std::wstring username, std::wstring versionName, std::wstring datasetName, bool isTable) {
	std::wstring DBLabel(username + L"." + DBname + L"." + versionName);
	std::wstring datasetLabel(DBLabel + L"." + datasetName);
	std::string DBLabelName(DBLabel.begin(), DBLabel.end());
	std::string datasetLabelName(datasetLabel.begin(),datasetLabel.end());
	std::vector<std::string> fieldNameList;
	std::vector<std::string> emptyList;
	IFieldsPtr fieldList;
	if (isTable){
		ITablePtr targetTable = m_dataManager->getTable(datasetLabelName).table;
		if (targetTable == NULL){
			m_dataManager->setNewTable_divideUserDBVersion(DBLabelName, datasetLabelName, username, datasetName, false);
			m_dataManager->initTable(datasetLabelName);
			targetTable = m_dataManager->getTable(datasetLabelName).table;
		}
		if (S_OK != targetTable->get_Fields(&fieldList)) {
			return emptyList;
		}
	}
	else{
		IFeatureClassPtr targetFeatureClass = m_dataManager->getFeatureClass(datasetLabelName).featureClass;
		if (targetFeatureClass == NULL) {
			m_dataManager->setNewFeatureClass_divideUserDBVersion(DBLabelName, datasetLabelName, username, datasetName, false);
			m_dataManager->initFeatureClass(datasetLabelName);
			targetFeatureClass = m_dataManager->getFeatureClass(datasetLabelName).featureClass;
		}
		if (S_OK != targetFeatureClass->get_Fields(&fieldList)) {
			return emptyList;
		}
	}
	long fieldCount;
	if (S_OK != fieldList->get_FieldCount(&fieldCount)) {
		return emptyList;
	}
	for (int i = 0; i < fieldCount; i++) {
		IFieldPtr field;
		if (S_OK != fieldList->get_Field(i, &field)) {
			return emptyList;
		}
		BSTR fieldName;
		if (S_OK != field->get_Name(&fieldName)) {
			return emptyList;
		}
		std::wstring cv(fieldName, SysStringLen(fieldName));
		std::string convertedFieldName(cv.begin(), cv.end());
		fieldNameList.push_back(convertedFieldName);
		m_dataManager->setNewField(datasetLabelName,datasetLabelName + "." + convertedFieldName, cv, isTable);
		m_dataManager->initField(datasetLabelName + "." + convertedFieldName);
	}
	return fieldNameList;
}

bool DBComparer::hasDomain(std::wstring DBname, std::wstring username, std::wstring versionName, std::wstring datasetName, std::wstring fieldName, bool isTable) {
	std::wstring DBLabel(username + L"." + DBname + L"." + versionName);
	std::wstring datasetLabel(DBLabel + L"." + datasetName);
	std::wstring fieldLabel(datasetLabel + L"." + fieldName);
	std::string datasetLabelName(datasetLabel.begin(), datasetLabel.end());
	std::string fieldLabelName(fieldLabel.begin(), fieldLabel.end());
	IFieldPtr targetField = m_dataManager->getField(fieldLabelName).field;
	if (targetField == NULL) {
		m_dataManager->setNewField(datasetLabelName, fieldLabelName, fieldName, isTable);
		m_dataManager->initField(fieldLabelName);
		targetField = m_dataManager->getField(fieldLabelName).field;
	}
	std::vector<std::string> domainNameList;
	std::vector<std::string> emptyList;
	IDomainPtr domain;
	if (S_OK != targetField->get_Domain(&domain)) {
		return false;
	}
	if (domain == NULL) {
		return false;
	}
	return true;
}

std::vector<std::string> DBComparer::getDomainNameList(std::wstring DBname, std::wstring username, std::wstring versionName, std::wstring datasetName, std::wstring fieldName, bool isTable ) {
	std::wstring DBLabel(username + L"." + DBname + L"." + versionName);
	std::wstring datasetLabel(DBLabel + L"." + datasetName);
	std::wstring fieldLabel(datasetLabel + L"." + fieldName);
	std::string datasetLabelName(datasetLabel.begin(), datasetLabel.end());
	std::string fieldLabelName(fieldLabel.begin(), fieldLabel.end());
	IFieldPtr targetField = m_dataManager->getField(fieldLabelName).field;
	if (targetField == NULL) {
		m_dataManager->setNewField(datasetLabelName, fieldLabelName, fieldName, isTable);
		m_dataManager->initField(fieldLabelName);
		targetField = m_dataManager->getField(fieldLabelName).field;
	}
	std::vector<std::string> domainNameList;
	std::vector<std::string> emptyList;
	IDomainPtr domain;
	if (S_OK != targetField->get_Domain(&domain)) {
		return emptyList;
	}
	BSTR domainName;
	if (S_OK != domain->get_Name(&domainName)) {
		return emptyList;
	}
	std::wstring cv(domainName, SysStringLen(domainName));
	std::string convertedDomainName(cv.begin(), cv.end());
	domainNameList.push_back(convertedDomainName);
	if (domain->Type == esriDomainType::esriDTCodedValue) {
		domainNameList.push_back("Coded Value");
		ICodedValueDomainPtr codedValueDomain = (ICodedValueDomainPtr) domain;	
		long totalCode;
		if (S_OK != codedValueDomain->get_CodeCount(&totalCode)) {
			return emptyList;
		}
		for (int i = 0; i < totalCode; i++) {
			_variant_t value;
			if (S_OK != codedValueDomain->get_Value(i, &value)) {
				return emptyList;
			}
			BSTR name;
			if (S_OK != codedValueDomain->get_Name(i, &name)) {
				return emptyList;
			}
			std::wstring cvName(name, SysStringLen(name));
			std::string convertedName(cvName.begin(), cvName.end());
			
			domainNameList.push_back(std::to_string(value.lVal));
			domainNameList.push_back(convertedName);
		}
	}
	else if (domain->Type == esriDomainType::esriDTRange) {
		domainNameList.push_back("Range");
		IRangeDomainPtr rangeDomain = (IRangeDomainPtr) domain;
		_variant_t min, max;
		if (S_OK != rangeDomain->get_MinValue(&min)) {
			return emptyList;
		}
		if (S_OK != rangeDomain->get_MaxValue(&max)) {
			return emptyList;
		}
		domainNameList.push_back(std::to_string(min.lVal));
		domainNameList.push_back(std::to_string(max.lVal));
	}
	return domainNameList;
}

bool DBComparer::checkSQLSyntax(std::string SQLText, std::wstring DBname, std::wstring username, std::wstring versionName, std::wstring datasetName, bool isTable) {
	IQueryFilterPtr ipQueryFilter(CLSID_QueryFilter);
	_bstr_t queryFilter = SQLText.c_str();
	if (S_OK != ipQueryFilter->put_WhereClause(queryFilter)) {
		m_IOManager->print_error(ErrorManager::ECode::E_FAILED_TO_SET_DATA, _T("Set search query"));
		return false;
	}
	std::wstring DBLabel(username + L"." + DBname + L"." + versionName);
	std::wstring datasetLabel(DBLabel + L"." + datasetName);
	std::string DBLabelName(DBLabel.begin(), DBLabel.end());
	std::string datasetLabelName(datasetLabel.begin(), datasetLabel.end());
	if (isTable){
		ITablePtr targetTable = m_dataManager->getTable(datasetLabelName).table;
		if (targetTable == NULL){
			m_dataManager->setNewTable_divideUserDBVersion(DBLabelName, datasetLabelName, username, datasetName, false);
			m_dataManager->initTable(datasetLabelName);
			targetTable = m_dataManager->getTable(datasetLabelName).table;
		}
		_ICursorPtr ipCursor;
		//set all condition into query variable
		if (S_OK != targetTable->Search(ipQueryFilter, VARIANT_FALSE, &ipCursor)) {
			m_IOManager->print_error(ErrorManager::ECode::E_FAILED_TO_SEARCH, m_dataManager->getTable(datasetLabelName).tableName);
			return false;
		}
	}
	else {
		IFeatureClassPtr targetFeatureClass = m_dataManager->getFeatureClass(datasetLabelName).featureClass;
		if (targetFeatureClass == NULL) {
			m_dataManager->setNewFeatureClass_divideUserDBVersion(DBLabelName, datasetLabelName, username, datasetName, false);
			m_dataManager->initFeatureClass(datasetLabelName);
			targetFeatureClass = m_dataManager->getFeatureClass(datasetLabelName).featureClass;
		}
		IFeatureCursorPtr ipCursor;
		//set all condition into query variable
		if (S_OK != targetFeatureClass->Search(ipQueryFilter, VARIANT_FALSE, &ipCursor)) {
			m_IOManager->print_error(ErrorManager::ECode::E_FAILED_TO_SEARCH, m_dataManager->getFeatureClass(datasetLabelName).featureClassName);
			return false;
		}
	}
	return true;
}
long DBComparer::getRecordNumber(std::string SQLText, std::wstring DBname, std::wstring username, std::wstring versionName, std::wstring datasetName, bool isTable) {
	IQueryFilterPtr ipQueryFilter(CLSID_QueryFilter);
	_bstr_t queryFilter = SQLText.c_str();
	if (S_OK != ipQueryFilter->put_WhereClause(queryFilter)) {
		m_IOManager->print_error(ErrorManager::ECode::E_FAILED_TO_SET_DATA, _T("Set search query"));
		return -1;
	}
	std::wstring DBLabel(username + L"." + DBname + L"." + versionName);
	std::wstring datasetLabel(DBLabel + L"." + datasetName);
	std::string DBLabelName(DBLabel.begin(), DBLabel.end());
	std::string datasetLabelName(datasetLabel.begin(), datasetLabel.end());
	long progressCount = 0;
	if (isTable){
		ITablePtr targetTable = m_dataManager->getTable(datasetLabelName).table;
		if (targetTable == NULL){
			m_dataManager->setNewTable_divideUserDBVersion(DBLabelName, datasetLabelName, username, datasetName, false);
			m_dataManager->initTable(datasetLabelName);
			targetTable = m_dataManager->getTable(datasetLabelName).table;
		}
		if (targetTable == NULL) {
			return -1;
		}
		if (S_OK != targetTable->RowCount(ipQueryFilter, &progressCount)) {
			return -1;
		}
	}
	else{
		IFeatureClassPtr targetFeatureClass = m_dataManager->getFeatureClass(datasetLabelName).featureClass;
		if (targetFeatureClass == NULL) {
			m_dataManager->setNewFeatureClass_divideUserDBVersion(DBLabelName, datasetLabelName, username, datasetName, false);
			m_dataManager->initFeatureClass(datasetLabelName);
			targetFeatureClass = m_dataManager->getFeatureClass(datasetLabelName).featureClass;
		}
		if (targetFeatureClass == NULL) {
			return -1;
		}
		if (S_OK != targetFeatureClass->FeatureCount(ipQueryFilter, &progressCount)) {
			return -1;
		}
	}
	return progressCount;
}
double DBComparer::getTotalDistArea(std::string SQLText, std::wstring DBname, std::wstring username, std::wstring versionName, std::wstring featureClassName) {
	IQueryFilterPtr ipQueryFilter(CLSID_QueryFilter);
	_bstr_t queryFilter = SQLText.c_str();
	if (S_OK != ipQueryFilter->put_WhereClause(queryFilter)) {
		m_IOManager->print_error(ErrorManager::ECode::E_FAILED_TO_SET_DATA, _T("Set search query"));
		return -1;
	}
	std::wstring DBLabel(username + L"." + DBname + L"." + versionName);
	std::wstring featureClassLabel(DBLabel + L"." + featureClassName);
	std::string DBLabelName(DBLabel.begin(), DBLabel.end());
	std::string featureClassLabelName(featureClassLabel.begin(), featureClassLabel.end());
	IFeatureClassPtr targetFeatureClass = m_dataManager->getFeatureClass(featureClassLabelName).featureClass;
	if (targetFeatureClass == NULL) {
		m_dataManager->setNewFeatureClass_divideUserDBVersion(DBLabelName, featureClassLabelName, username, featureClassName, false);
		m_dataManager->initFeatureClass(featureClassLabelName);
		targetFeatureClass = m_dataManager->getFeatureClass(featureClassLabelName).featureClass;
	}
	if (targetFeatureClass == NULL) {
		return -1;
	}
	IFeatureCursorPtr ipCursor;
	//set all condition into query variable
	if (S_OK != targetFeatureClass->Search(ipQueryFilter, VARIANT_FALSE, &ipCursor)) {
		m_IOManager->print_error(ErrorManager::ECode::E_FAILED_TO_SEARCH, m_dataManager->getFeatureClass(featureClassLabelName).featureClassName);
		return -1;
	}
	double distArea;
	double totalDistArea = 0;
	IFeaturePtr ipFeature;
	while (ipCursor->NextFeature(&ipFeature) == S_OK && ipFeature) {
		// get shape
		IGeometryPtr ipGeom;
		if (S_OK != ipFeature->get_ShapeCopy(&ipGeom)) {
			CString errorMsg = featureClassLabelName.c_str() + (CString)"shape";
			m_IOManager->print_error(ErrorManager::ECode::E_FAILED_TO_GET_DATA, errorMsg);
			return -1;
		}
		esriGeometryType shapeType;
		if (S_OK != ipGeom->get_GeometryType(&shapeType)) {
			CString errorMsg = featureClassLabelName.c_str() + (CString)"shape type";
			m_IOManager->print_error(ErrorManager::ECode::E_FAILED_TO_GET_DATA, errorMsg);
			return -1;
		}
		ISpatialReferenceFactoryPtr srFactory(CLSID_SpatialReferenceEnvironment);
		IProjectedCoordinateSystemPtr pcs;
		srFactory->CreateProjectedCoordinateSystem(getCoordinateSystem(username), &pcs);
		ISpatialReferencePtr sr2 = pcs;
		ipGeom->Project(sr2);
		if (shapeType == esriGeometryType::esriGeometryLine || shapeType == esriGeometryType::esriGeometryPolyline) {
			distArea = getDist(ipGeom, shapeType);
			if (distArea == -1) {
				CString errorMsg = featureClassLabelName.c_str() + (CString)"distance value";
				m_IOManager->print_error(ErrorManager::ECode::E_FAILED_TO_GET_DATA, errorMsg);
				return -1;
			}
			totalDistArea += distArea;
		}
		else if (shapeType == esriGeometryType::esriGeometryPolygon) {
			distArea = getArea(ipGeom);
			if (distArea == -1) {
				CString errorMsg = featureClassLabelName.c_str() + (CString)"distance value";
				m_IOManager->print_error(ErrorManager::ECode::E_FAILED_TO_GET_DATA, errorMsg);
				return -1;
			}
			totalDistArea += distArea;
		}
		else if (shapeType == esriGeometryType::esriGeometryPoint) {
			return 0;
		}
		else {
			CString errorMsg = featureClassLabelName.c_str() + (CString)"shape type is not point, line, or polygon";
			m_IOManager->print_error(ErrorManager::ECode::E_FAILED_TO_GET_DATA, errorMsg);
			return -1;
		}
	}
	return totalDistArea;
}
double DBComparer::getArea(IGeometryPtr & ipGeom) {
	IAreaPtr area = (IAreaPtr)ipGeom;
	double value;
	if (S_OK != area->get_Area(&value)) {
		return -1;
	}
	return value / 1000000; //KM^2
}
double DBComparer::getDist(IGeometryPtr & ipGeom, esriGeometryType shapeType) {
	if (shapeType == esriGeometryType::esriGeometryLine) {
		ILinePtr line = (ILinePtr)ipGeom;
		double length;
		if (S_OK != line->get_Length(&length)) {
			return -1;
		}
		return length / 1000; //KM 
	}
	else  {
		IPolylinePtr line = (IPolylinePtr)ipGeom;
		double length;
		if (S_OK != line->get_Length(&length)) {
			return -1;
		}
		return length / 1000; //KM 
	}
}
int DBComparer::getCoordinateSystem(std::wstring username) {
	std::transform(username.begin(),username.end(),username.begin(), ::toupper);
	if (username.find(L"MMR") != std::wstring::npos) { //Myanmar
		//return esriSRProjCSType::esriSRProjCS_WGS1984UTM_47N; //46N 47N
		return 6239;
	}
	if (username.find(L"THA") != std::wstring::npos) { //Thailand
		return  24047;//47N 48N 24047
	}
	if (username.find(L"LAO") != std::wstring::npos) { // Laos
		return esriSRProjCSType::esriSRProjCS_WGS1984UTM_48N; //47N 48N 4992
	}
	if (username.find(L"MYS") != std::wstring::npos) { //Malaysia
		return 6742; // 47N 48N 49N 50N , 3375 3376
	}
	if (username.find(L"KHM") != std::wstring::npos) { //Khmer
		return esriSRProjCSType::esriSRProjCS_WGS1984UTM_48N; //48N
	}
	if (username.find(L"SGP") != std::wstring::npos) { //Singapore
		return esriSRProjCSType::esriSRProjCS_WGS1984UTM_48N; //48N 3414
	}
	if (username.find(L"VNM") != std::wstring::npos) { //Vietnam
		return 6756; //48N 49N 3405
	}
	if (username.find(L"BRN") != std::wstring::npos) { //Brunei 
		return 5247; // 50N 5247
	}
	if (username.find(L"PHL") != std::wstring::npos) { //Philippines
		return 25395; // 50N 51N 4995
	}
	if (username.find(L"IDN") != std::wstring::npos) { //Indonesia
		return 23868; //Barabara
	}
}

///plan/update : dynamically update value when condition has been typed 
int updatefeatureClassRecordNumber() {
	return 0;
}




