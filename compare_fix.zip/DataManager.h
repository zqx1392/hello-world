#pragma once
/**
* @brief	Manage data and act as middleman between server, file, and core process who store all necessary data.
*/

class DataManager
{
public:

	IOManager * _IOCtrl;				//Control IO
	AccessSV * _AccSV;					//Control Server Access

	DataManager();
	~DataManager();
	//File Structure
	struct fileDesc {
		fileDesc() :fileName(""), fileType(IOManager::FileType::UNDEFINED) {}
		fileDesc(CString fileName, IOManager::FileType fileType):
			fileName(fileName), 
			fileType(fileType) {}
		CString fileName;					//ex.  C:/HAHA/THISWAY.txt
		IOManager::FileType fileType;		//ex.  ERR,RUN,OUT
	};
	//DB Structure
	struct DBDesc {
		DBDesc() :serverName(""), ownerName(""), versionName(""), fullDBName(""), workspace(NULL) {}
		DBDesc(CString serverName, CString ownerName, CString versionName, CString fullDBName, IWorkspacePtr workspace):
			serverName(serverName),
			ownerName(ownerName),
			versionName(versionName),
			fullDBName(fullDBName),
			workspace(workspace) {}
		CString serverName;					//ex.  yakumo, arion
		CString ownerName;					//ex.  REFERENCE,THA201701
		CString versionName;				//ex.  SDE.DEFAULT
		CString fullDBName;					//ex.  RONLY@yakumo(SDE.DEFAULT)
		IWorkspacePtr workspace;			//variable to access data
	};
	//Featureclass Structure
	struct featureClassDesc {
		featureClassDesc() : serverLabelName(""), featureClassName(""), ownerName(""), fullFeatureClassName(""), datasetName(""), featureClass(NULL) {}
		featureClassDesc(std::string serverLabelName, CString featureClassName, CString ownerName, CString fullFeatureClassName, CString datasetName, IFeatureClassPtr featureClass):
			serverLabelName(serverLabelName), 
			featureClassName(featureClassName), 
			ownerName(ownerName), 
			fullFeatureClassName(fullFeatureClassName), 
			datasetName(datasetName), 
			featureClass(featureClass) {}
		std::string serverLabelName;		//ex.  --'inputPP'
		CString featureClassName;			//ex.  sindy::schema::citymesh::kfeatureClassName
		CString ownerName;					//ex.  REFERENCE,THA201701
		CString fullFeatureClassName;		//ex.  REFRENCE.MESHCITY
		CString datasetName;				//ex.  ADDR
		IFeatureClassPtr featureClass;		//variable to access data
	};
	//Table Structure
	struct tableDesc {
		tableDesc() : serverLabelName(""), tableName(""), ownerName(""), fullTableName(""), table(NULL) {}
		tableDesc(std::string serverLabelName, CString tableName, CString ownerName, CString fullTableName, ITablePtr table) :
			serverLabelName(serverLabelName),
			tableName(tableName),
			ownerName(ownerName),
			fullTableName(fullTableName),
			table(table) {}
		std::string serverLabelName;		//ex.  --'inputPP'
		CString tableName;					//ex.  ALTERNATIVE_NAME
		CString ownerName;					//ex.  REFERENCE,THA201701
		CString fullTableName;				//ex.  REFRENCE.MESHCITY
		ITablePtr table;					//variable to access data
	};
	//Field structure
	struct fieldDesc {
		fieldDesc() :datasetLabelName(""), fieldName(""), isDatasetTable(false), field(NULL) {}
		fieldDesc(std::string datasetLabelName, CString fieldName, bool isDatasetTable, IFieldPtr field):
			datasetLabelName(datasetLabelName),
			fieldName(fieldName),
			isDatasetTable(isDatasetTable),
			field(field) {}
		std::string datasetLabelName;	//ex. --'layerPP'
		CString fieldName;					//ex. OBJECTID
		bool isDatasetTable;				//Check whether a dataset that contains this field is table or not.
		IFieldPtr field;					//variable to access data
	};
	/**
	* @brief Set output management class
	* @param IOCtrl				[in]	Target IOManager class object
	*/
	void setLogger(IOManager * IOCtrl);
	/**
	* @brief Set server management class
	* @param AccSV				[in]	Target AccessSV class object
	*/
	void setAccSV(AccessSV * AccSV);
	/**
	* @brief Add new file into fileList for creation
	* @param labelName			[in]	Label name for calling a file data with m_fileList[labelName]
	* @param fileName			[in]	target file name aka file path
	* @param fileType			[in]	File type[ERR,RUN,OUT]
	*/
	void setNewFile(std::string labelName, std::wstring fileName, IOManager::FileType fileType);
	/**
	* @brief Add new DB into DBList for creation
	* @param labelName			[in]	Label name for calling a DB data with m_DBList[labelName]
	* @param serverName			[in]	full SiNDY username [ex. TEST2017A@sindympa(SDE.DEFAULT)]
	* @param isFGDB				[in]	Is the target DB is FGDB
	* @param doEdit				[in]	If target db need to be edited
	*/
	void setNewDB(std::string labelName, std::wstring serverName, bool isFGDB, bool doEdit);
	/**
	* @brief Add new Database. Username, DB, version input are separate
	* @param labelName			[in]	Label name for calling a DB data with m_DBList[labelName]
	* @param serverName			[in]	target DB server name [ex. sindympa]
	* @param ownerName			[in]	target DB owner name [ex. TEST2017A]
	* @param versionName		[in]	target DB server name [ex. SDE.DEFAULT]
	* @param isFGDB				[in]	Is the target DB is FGDB
	* @param doEdit				[in]	If target db need to be edited
	*/
	void setNewDB_divideUserDBVersion(std::string labelName, std::wstring serverName, std::wstring ownerName, std::wstring versionName, bool isFGDB, bool doEdit);
	/**
	* @brief Add new featureclass for creation 
	* @param labelName			[in]	Label name for calling a featureclass data with m_featureClassList[labelName]
	* @param featureClassName	[in]	target featureClass name [ex. sindy::schema::example:kfeatureClassName, "ROAD_LINK"]
	* @param isFGDB				[in]	Is the target DB is FGDB
	*/
	void setNewFeatureClass(std::string serverLabelName, std::string labelName, std::wstring serverName, std::wstring featureClassName, bool isFGDB);
	/**
	* @brief Add new featureclass. Username, DB, version input are separate
	* @param labelName			[in]	Label name for calling a featureclass data with m_featureClassList[labelName]
	* @param serverOwner		[in]	target DB owner name [ex. TEST2017A]
	* @param featureClassName	[in]	target featureClass name [ex. sindy::schema::example:kfeatureClassName, "ROAD_LINK"]
	* @param isFGDB				[in]	Is the target DB is FGDB
	*/
	void setNewFeatureClass_divideUserDBVersion(std::string serverLabelName, std::string labelName, std::wstring serverOwner, std::wstring featureClassName, bool isFGDB);
	/**
	* @brief Add new table for creation
	* @param labelName			[in]	Label name for calling a featureclass data with m_featureClassList[labelName]
	* @param tableName			[in]	target table name [ex. ALTERNATIVE_NAME]
	* @param isFGDB				[in]	Is the target DB is FGDB
	*/
	void setNewTable(std::string serverLabelName, std::string labelName, std::wstring serverName, std::wstring tableName, bool isFGDB);
	/**
	* @brief Add new featureclass. Username, DB, version input are separate
	* @param labelName			[in]	Label name for calling a featureclass data with m_featureClassList[labelName]
	* @param serverOwner		[in]	target DB owner name [ex. TEST2017A]
	* @param tableName			[in]	target table name [ex. ALTERNATIVE_NAME]
	* @param isFGDB				[in]	Is the target DB is FGDB
	*/
	void setNewTable_divideUserDBVersion(std::string serverLabelName, std::string labelName, std::wstring serverOwner, std::wstring tableName, bool isFGDB);
	/**
	* @brief Add new field name for usage 
	* @param datasetLabelName			[in]	Label name for calling a dataset data
	* @param labelName			[in]	Label name for calling a field data with m_fieldList[labelName]
	* @param fieldName			[in]	target field Name [ex. POSTAL_CODE, OBJECTID]
	* @param isTable			[in]	Is input dataset name table name or featureClass name
	*/
	void DataManager::setNewField(std::string datasetLabelName, std::string labelName, std::wstring fieldName, bool isTable);
	/**
	* @brief Create all files that have been set from 'setNewFile' function
	* @return	RCode value [ex�FR_SUCCESS=0�AR_FAILED_FATAL_ERROR=1�A...]
	*/
	int createFiles();
	/**
	* @brief Initialize all DBs that have been set from 'setNewDB' and 'setNewDB_divideUserDBVersion' function
	* @return	RCode value [ex�FR_SUCCESS=0�AR_FAILED_FATAL_ERROR=1�A...]
	*/
	int initDBs();
	/**
	* @brief Initialize a selected DB that has been set from 'setNewDB' and 'setNewDB_divideUserDBVersion' function
	* @param labelName			[in]	Label name for calling a DB data with m_DBList[labelName]
	* @return	RCode value [ex�FR_SUCCESS=0�AR_FAILED_FATAL_ERROR=1�A...]
	*/
	int initDB(std::string labelName);
	/**
	* @brief Initialize all featureclasses that have been set from 'setNewFeatureClass' and 'setNewFeatureClass_divideUserDBVersion' function
	* @return	RCode value [ex�FR_SUCCESS=0�AR_FAILED_FATAL_ERROR=1�A...]
	*/
	int initFeatureClasses();
	/**
	* @brief Initialize a selected featureclass that has been set from 'setNewFeatureClass' and 'setNewFeatureClass_divideUserDBVersion' function
	* @param labelName			[in]	Label name for calling a featureclass data with m_featureClassList[labelName]
	* @return	RCode value [ex�FR_SUCCESS=0�AR_FAILED_FATAL_ERROR=1�A...]
	*/
	int initFeatureClass(std::string labelName);
	/**
	* @brief Initialize all table that have been set from 'setNewTable' and 'setNewTable_divideUserDBVersion' function
	* @return	RCode value [ex�FR_SUCCESS=0�AR_FAILED_FATAL_ERROR=1�A...]
	*/
	int initTables();
	/**
	* @brief Initialize a selected table that has been set from 'setNewTable' and 'setNewTable_divideUserDBVersion' function
	* @param labelName			[in]	Label name for calling a table data with m_tableList[labelName]
	* @return	RCode value [ex�FR_SUCCESS=0�AR_FAILED_FATAL_ERROR=1�A...]
	*/
	int initTable(std::string labelName);
	/**
	* @brief Initialize all fields that have been set from 'setNewField' function
	* @return	RCode value [ex�FR_SUCCESS=0�AR_FAILED_FATAL_ERROR=1�A...]
	*/
	int initFields();
	/**
	* @brief Initialize all fields that have been set from 'setNewField' function
	* @param labelName			[in]	Label name for calling a field data with m_fieldList[labelName]
	* @return	RCode value [ex�FR_SUCCESS=0�AR_FAILED_FATAL_ERROR=1�A...]
	*/
	int initField(std::string labelName);
	/**
	* @brief Get DB list
	* @return	List of DB
	*/
	std::map<std::string, DBDesc> getDBList();
	/**
	* @brief Get a DB
	* @param labelName			[in]	Label name for calling a DB data with m_DBList[labelName]
	* @return	A DB
	*/
	DBDesc getDB(std::string labelName);
	/**
	* @brief Get featureclass list
	* @return	List of featureclass
	*/
	std::map<std::string, featureClassDesc> getFeatureClassList();
	/**
	* @brief Get a featureClass
	* @param labelName			[in]	Label name for calling a featureclass data with m_featureClassList[labelName]
	* @return	A featureClass
	*/
	featureClassDesc getFeatureClass(std::string labelName);
	/**
	* @brief Get table list
	* @return	List of table
	*/
	std::map<std::string, tableDesc> getTableList();
	/**
	* @brief Get a table
	* @param labelName			[in]	Label name for calling a table data with m_TableList[labelName]
	* @return	A table
	*/
	tableDesc getTable(std::string labelName);
	/**
	* @brief Get field list
	* @return	List of field
	*/
	std::map<std::string, fieldDesc> getFieldList();
	/**
	* @brief Get a field
	* @param labelName			[in]	Label name for calling a field data with m_fieldList[labelName]
	* @return	A field
	*/
	fieldDesc getField(std::string labelName);


	
private:
	std::map<std::string, DBDesc> m_DBList;			//Store all set DB list
	std::map<std::string, fileDesc> m_fileList;		//Store all set file list
	std::map<std::string, featureClassDesc> m_featureClassList;	//Store all set featureClass list
	std::map<std::string, tableDesc> m_tableList;	//Store all set table list
	std::map<std::string, fieldDesc> m_fieldList;	//Store all set field name such as ACTUALADDRESS, POSTAL_CODE 
	static const int HAS_ERROR = 1;
};