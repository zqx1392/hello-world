#pragma once
#include "stdafx.h"
#include "ErrorManager.h"

ErrorManager::ErrorManager(void)
{ 
}

ErrorManager::~ErrorManager(void)
{
}

void ErrorManager::initErrorMessage(){
	createEachMessageFormat(E_INVALID_OPTION,_T("OPTION_ERROR"),_T("is incorrect"));
	createEachMessageFormat(E_FAILED_TO_OPEN_FILE_PATH,_T("FILE_ERROR"),_T("filepath cannot be found"));
	createEachMessageFormat(E_FAILED_TO_OPEN_WORKSPACE,_T("DB_ERROR"),_T("DB cannot be opened"));
	createEachMessageFormat(E_FAILED_TO_OPEN_FEATURECLASS,_T("FEATURECLASS_ERROR"),_T("featureclass cannot be opened"));
	createEachMessageFormat(E_FAILED_TO_OPEN_TABLE, _T("TABLE_ERROR"), _T("table cannot be opened"));
	createEachMessageFormat(E_FAILED_TO_OPEN_FIELD, _T("FIELD_ERROR"), _T("field cannot be opened"));
	createEachMessageFormat(E_FAILED_TO_SEARCH,_T("PROCESS_ERROR"),_T("failed to search"));
	createEachMessageFormat(E_FAILED_TO_GET_DATA,_T("PROCESS_ERROR"),_T("cannot be acquired"));
	createEachMessageFormat(E_FAILED_TO_SET_DATA,_T("PROCESS_ERROR"),_T("cannot be set"));
	createEachMessageFormat(E_FAILED_TO_PROCESS,_T("PROCESS_ERROR"),_T("has unexpected error"));
	createEachMessageFormat(E_COM_ERROR_IS_CATCHED,_T("COM_ERROR"),_T("catch _com_error in method"));
}

void ErrorManager::createEachMessageFormat(ECode errorCode,CString errorType,CString errorDesc){
	errorMsg tempErrorMessage = {errorCode,errorType,errorDesc};
	m_errorMessageGroup[errorCode] = tempErrorMessage;
}

std::map<ErrorManager::ECode, ErrorManager::errorMsg> ErrorManager::getErrorMessageFormat(){
	return m_errorMessageGroup;
}


