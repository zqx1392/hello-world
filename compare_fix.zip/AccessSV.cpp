#pragma once
#include "stdafx.h"
#include "AccessSV.h"

AccessSV::AccessSV(void)
{
}

AccessSV::~AccessSV(void)
{
	featureClassMap.empty();
}
int AccessSV::setWorkspace(CString workspaceName){
	IWorkspacePtr tempWorkspace (sindy::create_workspace(workspaceName));
	if (tempWorkspace == NULL){
		return 1;
	}
	workspaceMap.insert(std::make_pair(workspaceName,tempWorkspace));
	return 0;
}

IWorkspacePtr AccessSV::getWorkspace(CString workspaceName) {
	return workspaceMap[workspaceName];
}
void AccessSV::clearWorkspaceList() {
	workspaceMap.clear();
}

int AccessSV::setFeatureClass (CString workspaceName, CString featureClassName){
	IWorkspacePtr targetWorkspace = getWorkspace(workspaceName);
	IFeatureClassPtr tempClass = NULL;
	if (S_OK != IFeatureWorkspacePtr(targetWorkspace)->OpenFeatureClass(featureClassName.AllocSysString(), &tempClass)){
		return 1;
	}
	featureClassMap.insert(std::make_pair(workspaceName + "." + featureClassName,tempClass));
	return 0;
}
IFeatureClassPtr AccessSV::getFeatureClass(CString workspaceName, CString featureClassName) {
	return featureClassMap[workspaceName + "." + featureClassName];
}
void AccessSV::clearFeatureClassList() {
	featureClassMap.clear();
}

int AccessSV::setTable(CString workspaceName, CString tableName) {
	IWorkspacePtr targetWorkspace = getWorkspace(workspaceName);
	ITablePtr tempClass = NULL;
	if (S_OK != IFeatureWorkspacePtr(targetWorkspace)->OpenTable(tableName.AllocSysString(), &tempClass)) {
		return 1;
	}
	tableMap.insert(std::make_pair(workspaceName + "." + tableName, tempClass));
	return 0;
}
ITablePtr AccessSV::getTable(CString workspaceName, CString tableName) {
	return tableMap[workspaceName + "." + tableName];
}
void AccessSV::clearTableList() {
	tableMap.clear();
}

int AccessSV::setField(CString workspaceName, CString datasetName, CString fieldName, bool isTable) {
	long fieldIndex;
	IFieldPtr tempField;
	if (isTable) {
		ITablePtr targetTable = getTable(workspaceName, datasetName);
		targetTable->FindField(fieldName.AllocSysString(), &fieldIndex);
		if (S_OK != targetTable->GetFields()->get_Field(fieldIndex, &tempField)) {
			return 1;
		}
	}
	else {
		IFeatureClassPtr targetFeatureClass = getFeatureClass(workspaceName, datasetName);
		targetFeatureClass->FindField(fieldName.AllocSysString(), &fieldIndex);
		if (S_OK != targetFeatureClass->GetFields()->get_Field(fieldIndex, &tempField)) {
			return 1;
		}
	}
	fieldMap.insert(std::make_pair(workspaceName + "." + datasetName + "." + fieldName,tempField));
	return 0;
}

IFieldPtr AccessSV::getField(CString workspaceName, CString datasetName, CString fieldName) {
	return fieldMap[workspaceName + "." + datasetName + "." + fieldName];
}

void AccessSV::clearFieldList() {
	fieldMap.clear();
}

