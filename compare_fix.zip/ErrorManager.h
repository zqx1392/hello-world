#pragma once

/**
* @brief Manager error code
*/
class ErrorManager
{
public:
	ErrorManager();
	~ErrorManager();
	/**
	* @brief�@error enmum
	*/
	enum ECode : int {
		E_INVALID_OPTION				=101,
		E_FAILED_TO_OPEN_FILE_PATH		=201,
		E_FAILED_TO_OPEN_WORKSPACE		=202,
		E_FAILED_TO_OPEN_FEATURECLASS	=203,
		E_FAILED_TO_OPEN_TABLE			=204,
		E_FAILED_TO_OPEN_FIELD			=205,
		E_FAILED_TO_SEARCH				=301,
		E_FAILED_TO_GET_DATA			=302,
		E_FAILED_TO_SET_DATA			=303,
		E_FAILED_TO_PROCESS				=304,
		E_COM_ERROR_IS_CATCHED			=900
	};
	/**
	* @brief�@return result value
	*/
	enum RCode : int {
		R_SUCCESS					= 0,
		R_FAILED_FATAL_ERROR		= 1,
		R_FAILED_EXCEPTION_ERROR	= 2
	};
	/**
	* @brief Error message structure
	*/
	struct errorMsg{
		ECode errorCode;
		CString errorType;
		CString errorDesc;
	};
	/**
	* @brief Initialize error message
	*/
	void initErrorMessage();
	/**
	* @brief Create every type of error message
	* @param errorCode		[in]	ECode
	* @param errorType		[in]	Error type(FILE_ERROR,PROCESS_ERROR,ETC.)
	* @param errorDesc		[in]	Error details
	*/
	void createEachMessageFormat(ECode errorCode,CString errorType,CString errorDesc);
	/**
	* @brief Get list of error message format
	* @return	list of error message format in map structure
	*/
	std::map<ECode,errorMsg> getErrorMessageFormat();

private:
	std::map<ECode,errorMsg> m_errorMessageGroup;	//Error Meesage Group
};