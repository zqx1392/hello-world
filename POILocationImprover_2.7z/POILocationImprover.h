#pragma once
#include "AccessSV.h"
#include "ErrorManager.h"
#include "IOManager.h"
#include "OptionManager.h"
#include "DataManager.h"
/**
* @brief	Tool main process : 
			1.Get POSTALPOINT.shape postal code and its respective coordinates(x,y) list
			2.Get POI_INFO record and extract postal code from ACTUAL ADDRESS field
			3.Compare postal code  2. with 1.
			4.If match, copy coordinates(x,y) from POSTAL_CODE and replace the old one in POI_INFO.shape
*/

class POILocationImprover
{
public:
	AccessSV * m_accessSV;
	IOManager * m_IOManager;
	OptionManager *  m_OptionManager;
	DataManager * m_dataManager;

	POILocationImprover();
	~POILocationImprover();
	/**
	* @brief Set all management class
	* @param arg				[in]	Target management class object
	*/
	void setIOManager(IOManager * _IOManager);
	void setSVManager(AccessSV * _accessSV);
	void setOptionManager(OptionManager * _OptionManager);
	void setDataManager(DataManager * _dataManager);
	/**
	* @brief Print fix messsage when the tool ends successfully
	* @return	RCode value [ex�FR_SUCCESS=0�AR_FAILED_FATAL_ERROR=1�A...]
	*/
	int printSuccessfulEnd();
	/**
	* @brief when error occured, print error details and ends program
	* @return	0
	*/
	int endProgramWithError(const CString errorPoint);
	/**
	* @brief Check if input CString is number of not (ie. not contain any character)
	* @return	true if number, false if not.
	*/
	bool is_number(const CString str);
	/**
	* @brief get all option arguments and parse all into data manager
	*/
	int setNewOption();
	/**
	* @brief Get all postal code record from POSTALPOINT and store its coordinates in std::map
	* @param PPCoordinates		[out]	Store { postal code : coordinate X, coordinate Y } as { key : value }
	* @return	RCode value [ex�FR_SUCCESS=0�AR_FAILED_FATAL_ERROR=1�A...]
	*/
	int findPPPostalCode(std::map<CString, std::pair<double, double> > * PPCoordinates);
	/**
	* @brief find new POI_INFO location coordinates from POSTALPOINT location coordinates whose postal code matched
	* @param objectID		[in]	A record of POI_INFO's Object ID
	* @param postalCode		[in]	A record of POI_INFO's postal code
	* @param ipPOIGeom		[in]	A record of POI_INFO's shape (location which stores coordinates)
	* @param PPCoordinates	[in]	Store { postal code : coordinate X, coordinate Y } as { key : value }
	* @return	RCode value [ex�FR_SUCCESS=0�AR_FAILED_FATAL_ERROR=1�A...]
	*/
	int copyPostalPointCoordinates(const CString objectID, const CString postalCode, IGeometryPtr & ipPOIGeom, std::map<CString, std::pair<double, double> > * PPCoordinates);
	/**
	* @brief Set all search condition for POI_INFO (column, where clause) 
	* @param POIipQueryFilter		[in]	a variable used for search condition
	* @return	RCode value [ex�FR_SUCCESS=0�AR_FAILED_FATAL_ERROR=1�A...]
	*/
	int setPOISearchCondition(IQueryFilterPtr POIipQueryFilter);
	/**
	* @brief Count total record of POI_INFO
	* @param POIipQueryFilter		[in]	a variable used for search condition
	* @return	RCode value [ex�FR_SUCCESS=0�AR_FAILED_FATAL_ERROR=1�A...]
	*/
	int countTotalPOIRecord(IQueryFilterPtr POIipQueryFilter);	
	/**
	* @brief After set all search condition, loop all POI record and get target OBJECTID that has valid postal code
	* @param PPCoordinates		[in]	Store { postal code : coordinate X, coordinate Y } as { key : value }
	* @param POIipQueryFilter	[in]	a variable used for search condition
	* @param updateTargetPOI	[out]	record all target POI INFO record objectID
	* @return	RCode value [ex�FR_SUCCESS=0�AR_FAILED_FATAL_ERROR=1�A...]
	*/
	int getTargetPOIRecord(std::map<CString, std::pair<double, double> > * PPCoordinates, IQueryFilterPtr POIipQueryFilter, std::set<CString> * updateTargetPOI);
	/**
	* @brief start real edit the data and stop when done
	* @param PPCoordinates		[in]	Store { postal code : coordinate X, coordinate Y } as { key : value }
	* @param POIipQueryFilter	[in]	a variable used for search condition
	* @param updateTargetPOI	[out]	record all target POI INFO record objectID
	* @return	RCode value [ex�FR_SUCCESS=0�AR_FAILED_FATAL_ERROR=1�A...]
	*/
	int editing(std::map<CString, std::pair<double, double> > * PPCoordinates, IQueryFilterPtr POIipQueryFilter, std::set<CString> * updateTargetPOI);
	/**
	* @brief �ҏW�J�n
	* @retval true  �ҏW�J�n����
	* @retval false �ҏW�J�n���s
	*/
	bool startEdit();

	/**
	* @brief �ҏW�I��
	* @retval true  �ҏW�I������
	* @retval false �ҏW�I�����s
	*/
	bool stopEdit();

	/**
	* @brief �ҏW�j��
	* @retval true  �ҏW�j������
	* @retval false �ҏW�j�����s
	*/
	bool abortEdit();
	/**
	* @brief Update all target record's coordinates into database 
	* @param PPCoordinates		[in]	Store { postal code : coordinate X, coordinate Y } as { key : value }
	* @param POIipQueryFilter	[in]	a variable used for search condition
	* @param updateTargetPOI	[in]	List of target POI record 
	}
	* @return	RCode value [ex�FR_SUCCESS=0�AR_FAILED_FATAL_ERROR=1�A...]
	*/
	int updateToDatabase(std::map<CString, std::pair<double, double> > * PPCoordinates, IQueryFilterPtr POIipQueryFilter, std::set<CString> * updateTargetPOI);
	/**
	* @brief start the tool, get necessary variables for such as featureclass name, field name, and ArcGIS variables 
			 Also get Postal Code from POSTALPOINT, search condition, and count total POI record 
	* @param inputReader		[in]	IO management class
	* @return	RCode value [ex�FR_SUCCESS=0�AR_FAILED_FATAL_ERROR=1�A...]
	*/
	int run();

	/**
	* @brief Preinitialize all input and output such as log files, DBs and featureclasses variables before start ArcGIS-related process
	* @return	RCode value [ex�FR_SUCCESS=0�AR_FAILED_FATAL_ERROR=1�A...]
	*/
	int init(const int argc, _TCHAR* argv[]);
	
private:
	static const int is_success = ErrorManager::RCode::R_SUCCESS;
	std::map<CString, DataManager::DBDesc> m_DBList;
	std::map<CString, DataManager::featureClassDesc> m_featureClassList;
	std::map<CString, CComBSTR> m_fieldNameList;
	CString m_POIDBName;
	CString m_PPFeatureClassName;
	CString m_POIFeatureClassName;
	IWorkspacePtr m_POIFeatureWorkspace;
	IFeatureClassPtr m_PPFeatureClass;
	IFeatureClassPtr m_POIFeatureClass;
	CComBSTR m_PPFIELD;
	CComBSTR m_POIFIELD;
};