#pragma once
#include "stdafx.h"
#include "errorManager.h"
#include "IOManager.h"
#include "OptionManager.h"
#include <conio.h>


OptionManager::OptionManager() {
	
}

OptionManager::~OptionManager() {
}
void OptionManager::setLogger(IOManager * IOCtrl) {
	m_IOCtrl = IOCtrl;
}

int OptionManager::initOption() {
	m_optionNames[OptionName::POSTALPOINT_DB] = "inputPP";
	m_optionNames[OptionName::POSTALPOINT_LAYER] = "layerPP";
	m_optionNames[OptionName::POSTALPOINT_FIELD] = "fieldPP";
	m_optionNames[OptionName::POI_INFO_DB] = "inputPOI";
	m_optionNames[OptionName::POI_INFO_LAYER] = "layerPOI";
	m_optionNames[OptionName::POI_INFO_FIELD] = "fieldPOI";
	m_optionNames[OptionName::SQL] = "SQL";
	m_optionNames[OptionName::RUN_LOG] = "run_log";
	m_optionNames[OptionName::ERR_LOG] = "err_log";
	m_optionNames[OptionName::DB] = "DB";
	m_optionNames[OptionName::OWNER] = "owner";
	m_optionNames[OptionName::VERSION] = "version";
	return ErrorManager::RCode::R_SUCCESS;
}
std::string OptionManager::getOptionName(const OptionName optionName) {
	return m_optionNames[optionName];
}
int OptionManager::getOption(const int argc, _TCHAR* argv[]) {
	using namespace boost::program_options;
	options_description desc("Options");
	try {
		desc.add_options()
			("help,h", "Help screen")
			(getOptionName(OptionName::POSTALPOINT_DB).c_str(), wvalue<std::wstring>()->required(), "POSTALPOINT DB User")
			(getOptionName(OptionName::POI_INFO_DB).c_str(), wvalue<std::wstring>()->required(), "POI DB User")
			(getOptionName(OptionName::POSTALPOINT_LAYER).c_str(), wvalue<std::wstring>()->required(), "POSTALPOINT LAYER Name")
			(getOptionName(OptionName::POI_INFO_LAYER).c_str(), wvalue<std::wstring>()->required(), "POI Info LAYER Name")
			(getOptionName(OptionName::POSTALPOINT_FIELD).c_str(), wvalue<std::wstring>()->required(), "Postalcode FIELD Name")
			(getOptionName(OptionName::POI_INFO_FIELD).c_str(), wvalue<std::wstring>()->required(), "Actual Address FIELD Name")
			(getOptionName(OptionName::SQL).c_str(), wvalue<std::wstring>(), "SQL search query for POI Info")
			(getOptionName(OptionName::RUN_LOG).c_str(), wvalue<std::wstring>(), "Run log file path")
			(getOptionName(OptionName::ERR_LOG).c_str(), wvalue<std::wstring>(), "Error log file path");
		//END OF SETTING
		m_vm.clear();
		store(parse_command_line(argc, argv, desc), m_vm);
		notify(m_vm);
	}
	catch (const error &ex)
	{
		std::cerr << ex.what() << std::endl;
		std::cout << desc << std::endl;
		m_IOCtrl->print_error(ErrorManager::ECode::E_INVALID_OPTION, "Option setting");
		return ErrorManager::RCode::R_FAILED_FATAL_ERROR;
	}
	return ErrorManager::RCode::R_SUCCESS;
}
void OptionManager::printDescription() {
	//SETTING HERE
	m_IOCtrl->print_no_timestamp_run(_T("POILocationImprover.exe FILEVERSION:1.0.0.0  PRODUCTVERSION:1.0.0.0"));
	m_IOCtrl->print_no_timestamp_run(_T("[option]"));
	m_IOCtrl->print_no_timestamp_run(_T(""));
	print_all_option();
	m_IOCtrl->print_start();
	//END OF SETTING
}

void OptionManager::print_all_option() {
	using namespace boost::program_options;
	for (const auto& it : m_vm) {
		CString tmpString = "--" + (CString)it.first.c_str() + ": ";
		auto value = it.second.value();
		if (auto v = boost::any_cast<std::wstring>(&value)) {
			tmpString += v->c_str();
		}
		m_IOCtrl->print_no_timestamp_run(tmpString);
	}
	m_IOCtrl->print_no_timestamp_run("");
}
CString OptionManager::getOptionArgument(const OptionManager::OptionName opt){
	if (m_vm[getOptionName(opt)].empty())
		return L"";
	else
		return m_vm[getOptionName(opt)].as<std::wstring>().c_str();
}

