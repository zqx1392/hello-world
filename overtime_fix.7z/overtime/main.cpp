#pragma once
#include "stdafx.h"
#include "DBComparer.h"

int _tmain(int argc, _TCHAR* argv[])
{
	DBComparer * d = new DBComparer();
	int a = d->preStartTool();
	if (0 != d->connectToDB(L"sindympa", L"THA2017B", L"SDE.DEFAULT")){
		std::cout << "connect error" << std::endl;
		std::cin >> a;
	}
	else {
		std::cout << "success" << std::endl;
		std::vector <std::string> haha = d->getFeatureClassAndCount(L"sindympa", L"THA2017B", L"SDE.DEFAULT");
		if (haha.empty()) {
			std::cout << "get name error" << std::endl;
			std::cin >> a;
		}
		else {
			std::cout << "success" << std::endl;
			std::cin >> a;
		}
	}
	return 0;
}
