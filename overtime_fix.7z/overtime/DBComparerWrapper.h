// ErrorManagerWrapper.h

#pragma once

#include "..\DBComparer\AccessSV.h"
#include "..\DBComparer\AccessSV.cpp"
#include "..\DBComparer\ErrorManager.h"
#include "..\DBComparer\ErrorManager.cpp"
#include "..\DBComparer\IOManager.h"
#include "..\DBComparer\IOManager.cpp"
#include "..\DBComparer\DataManager.h"
#include "..\DBComparer\DataManager.cpp"
#include "..\DBComparer\DBComparer.h"
#include "..\DBComparer\DBComparer.cpp"

using namespace System;

namespace DBComparerWrapper {

	public ref class functionWrapper
	{
	public:
		//constructor
		functionWrapper();
		//wrapper variables
		/**
		* @brief�@error enmum
		*/
		enum class ECode : int {
			E_INVALID_OPTION = ErrorManager::ECode::E_INVALID_OPTION,
			E_FAILED_TO_OPEN_FILE_PATH = ErrorManager::ECode::E_FAILED_TO_OPEN_FILE_PATH,
			E_FAILED_TO_OPEN_WORKSPACE = ErrorManager::ECode::E_FAILED_TO_OPEN_FEATURECLASS,
			E_FAILED_TO_OPEN_FEATURECLASS = ErrorManager::ECode::E_FAILED_TO_OPEN_FEATURECLASS,
			E_FAILED_TO_SEARCH = ErrorManager::ECode::E_FAILED_TO_SEARCH,
			E_FAILED_TO_GET_DATA = ErrorManager::ECode::E_FAILED_TO_GET_DATA,
			E_FAILED_TO_SET_DATA = ErrorManager::ECode::E_FAILED_TO_SET_DATA,
			E_FAILED_TO_PROCESS = ErrorManager::ECode::E_FAILED_TO_PROCESS,
			E_COM_ERROR_IS_CATCHED = ErrorManager::ECode::E_COM_ERROR_IS_CATCHED
		};
		/**
		* @brief�@return result value
		*/
		enum class RCode : int {
			R_SUCCESS = ErrorManager::RCode::R_SUCCESS,
			R_FAILED_FATAL_ERROR = ErrorManager::RCode::R_FAILED_FATAL_ERROR,
			R_FAILED_EXCEPTION_ERROR = ErrorManager::RCode::R_FAILED_EXCEPTION_ERROR
		};
		
		//wrapper methods
		/**
		* @brief Preinitialize all input and output such as log files before start ArcGIS-related process
		* @return	true is success, false if fail
		*/
		bool preStartTool();
		/**
		* @brief Print fix messsage when the tool ends successfully
		*/
		void printSuccessfulEnd();
		/**
		* @brief Connect to target SiNDY userDB
		* @param DBname				[in]	target DB server name [ex. sindympa]
		* @param username			[in]	target DB owner name [ex. TEST2017A]
		* @param versionName		[in]	target DB server name [ex. SDE.DEFAULT]
		* @return	true is success, false if fail
		*/
		bool connectToDB(String^ DBname, String^ username, String^ versionName);
		/**
		* @brief get target featureclass's dataset name
		* @param DBname				[in]	target DB server name [ex. sindympa]
		* @param username			[in]	target DB owner name [ex. TEST2017A]
		* @param versionName		[in]	target DB server name [ex. SDE.DEFAULT]
		* @param featureClassName	[in]	target featureClass name [ex. sindy::schema::example:kfeatureClassName, "ROAD_LINK"]
		* @return	dataset name
		*/
		String^ getFeatureClassDataSetName(String^ DBname, String^ username, String^ versionName, String^ featureClassName);
		/**
		* @brief get target SiNDY userDB's all featureClass names and their total record numbers
		* @param DBname				[in]	target DB server name [ex. sindympa]
		* @param username			[in]	target DB owner name [ex. TEST2017A]
		* @param versionName		[in]	target DB server name [ex. SDE.DEFAULT]
		* @return	list of featureClass details ["name1","total count1","name2","total count2",...]
		*/
		array<String^>^ getFeatureClassAndCount(String^ DBname, String^ username, String^ versionName);
		/**
		* @brief get target SiNDY userDB's all ftable names and their total record numbers
		* @param DBname				[in]	target DB server name [ex. sindympa]
		* @param username			[in]	target DB owner name [ex. TEST2017A]
		* @param versionName		[in]	target DB server name [ex. SDE.DEFAULT]
		* @return	list of table details ["name1","total count1","name2","total count2",...]
		*/
		array<String^>^ getTableAndCount(String^ DBname, String^ username, String^ versionName);
		/**
		* @brief get target featureClass's all field name
		* @param DBname				[in]	target DB server name [ex. sindympa]
		* @param username			[in]	target DB owner name [ex. TEST2017A]
		* @param versionName		[in]	target DB server name [ex. SDE.DEFAULT]
		* @param datasetName		[in]	target dataset name [ex. sindy::schema::example:kfeatureClassName, "ROAD_LINK", "ALTERNATIVE_NAME"]
		* @param isTable			[in]	Is input dataset name table name or featureClass name
		* @return	list of field name ["name1","name2","name3",...]
		*/
		array<String^>^ getfieldNameList(String^ DBname, String^ username, String^ versionName, String^ datasetName, bool isTable);
		/**
		* @brief Check if target field contains a domain
		* @param DBname				[in]	target DB server name [ex. sindympa]
		* @param username			[in]	target DB owner name [ex. TEST2017A]
		* @param versionName		[in]	target DB server name [ex. SDE.DEFAULT]
		* @param datasetName		[in]	target dataset name [ex. sindy::schema::example:kfeatureClassName, "ROAD_LINK", "ALTERNATIVE_NAME"]
		* @param fieldName			[in]	target field name [ex. OBJECTID]
		* @return	true if exist, false if not
		*/
		bool hasDomain(String^ DBname, String^ username, String^ versionName, String^ datasetName, String^ fieldName);
		/**
		* @brief get target field's domain name and its codes
		* @param DBname				[in]	target DB server name [ex. sindympa]
		* @param username			[in]	target DB owner name [ex. TEST2017A]
		* @param versionName		[in]	target DB server name [ex. SDE.DEFAULT]
		* @param datasetName		[in]	target dataset name [ex. sindy::schema::example:kfeatureClassName, "ROAD_LINK", "ALTERNATIVE_NAME"]
		* @param fieldName			[in]	target field name [ex. OBJECTID]
		* @return	domain name and list of code value and code name ["domain name","code value 1","code name 1","code value 2","code name 2",...]
		*/
		array<String^>^ getDomainNameList(String^ DBname, String^ username, String^ versionName, String^ datasetName, String^ fieldName);
		/**
		* @brief test SQL text for where clause whether it has correct format, variable or not
		* @param SQLText			[in]	SQL text to test [ex. 'OBJECTID > 10']
		* @param DBname				[in]	target DB server name [ex. sindympa]
		* @param username			[in]	target DB owner name [ex. TEST2017A]
		* @param versionName		[in]	target DB server name [ex. SDE.DEFAULT]
		* @param datasetName		[in]	target dataset name [ex. sindy::schema::example:kfeatureClassName, "ROAD_LINK", "ALTERNATIVE_NAME"]
		* @param isTable			[in]	Is input dataset name table name or featureClass name
		* @return	true if correct, false if not
		*/
		bool checkSQLSyntax(String^ SQLText, String^ DBname, String^ username, String^ versionName, String^ datasetName, bool isTable);
		/**
		* @brief get record number from target featureClass with specific where clause SQL text
		* @param SQLText			[in]	SQL text to test [ex. 'OBJECTID > 10']
		* @param DBname				[in]	target DB server name [ex. sindympa]
		* @param username			[in]	target DB owner name [ex. TEST2017A]
		* @param versionName		[in]	target DB server name [ex. SDE.DEFAULT]
		* @param datasetName		[in]	target dataset name [ex. sindy::schema::example:kfeatureClassName, "ROAD_LINK", "ALTERNATIVE_NAME"]
		* @param isTable			[in]	Is input dataset name table name or featureClass name
		* @return	total distance or area, depending on type of data
		*/
		long getRecordNumber(String^ SQLText, String^ DBname, String^ username, String^ versionName, String^  datasetName, bool isTable);
		/**
		* @brief get total distance or area from target featureClass with specific where clause SQL text
		* @param SQLText			[in]	SQL text to test [ex. 'OBJECTID > 10']
		* @param DBname				[in]	target DB server name [ex. sindympa]
		* @param username			[in]	target DB owner name [ex. TEST2017A]
		* @param versionName		[in]	target DB server name [ex. SDE.DEFAULT]
		* @param featureClassName	[in]	target featureClass name [ex. sindy::schema::example:kfeatureClassName, "ROAD_LINK"]
		* @param fieldName			[in]	target field name [ex. OBJECTID]
		* @return	total distance or area, depending on type of data
		*/
		double getTotalDistArea(String^ SQLText, String^ DBname, String^ username, String^ versionName, String^ featureClassName);

	private:
		DBComparer *DBComparerClass;
	};
}
