#pragma once
#include "stdafx.h"
#include "AccessSV.h"

AccessSV::AccessSV(void)
{
}

AccessSV::~AccessSV(void)
{
	featureClassMap.empty();
}
int AccessSV::setWorkspace(CString workspaceName){
	IWorkspacePtr tempWorkspace (sindy::create_workspace(workspaceName));
	if (tempWorkspace == NULL){
		return 1;
	}
	workspaceMap.insert(std::make_pair(workspaceName,tempWorkspace));
	return 0;
}

IWorkspacePtr AccessSV::getWorkspace(CString workspaceName) {
	return workspaceMap[workspaceName];
}
void AccessSV::clearWorkspaceList() {
	workspaceMap.clear();
}

int AccessSV::setFeatureClass (CString workspaceName, CString featureClassName){
	IWorkspacePtr targetWorkspace = getWorkspace(workspaceName);
	IFeatureClassPtr tempClass = NULL;
	if (S_OK != IFeatureWorkspacePtr(targetWorkspace)->OpenFeatureClass(featureClassName.AllocSysString(), &tempClass)){
		return 1;
	}
	featureClassMap.insert(std::make_pair(workspaceName + "." + featureClassName,tempClass));
	return 0;
}
IFeatureClassPtr AccessSV::getFeatureClass(CString workspaceName, CString featureClassName) {
	return featureClassMap[workspaceName + "." + featureClassName];
}
void AccessSV::clearFeatureClassList() {
	featureClassMap.clear();
}

int AccessSV::setTable(CString workspaceName, CString tableName) {
	IWorkspacePtr targetWorkspace = getWorkspace(workspaceName);
	ITablePtr tempClass = NULL;
	if (S_OK != IFeatureWorkspacePtr(targetWorkspace)->OpenTable(tableName.AllocSysString(), &tempClass)) {
		return 1;
	}
	tableMap.insert(std::make_pair(workspaceName + "." + tableName, tempClass));
	return 0;
}
ITablePtr AccessSV::getTable(CString workspaceName, CString tableName) {
	return tableMap[workspaceName + "." + tableName];
}
void AccessSV::clearTableList() {
	tableMap.clear();
}

int AccessSV::setField(CString workspaceName, CString featureClassName, CString fieldName) {
	IFeatureClassPtr targetFeatureClass = getFeatureClass(workspaceName, featureClassName);
	long fieldIndex;
	targetFeatureClass->FindField(fieldName.AllocSysString(), &fieldIndex);
	IFieldPtr tempField;
	if (S_OK != targetFeatureClass->GetFields()->get_Field(fieldIndex, &tempField)) {
		return 1;
	}
	fieldMap.insert(std::make_pair(workspaceName + "." + featureClassName + "." + fieldName,tempField));
	return 0;
}

IFieldPtr AccessSV::getField(CString workspaceName, CString featureClassName, CString fieldName) {
	return fieldMap[workspaceName + "." + featureClassName + "." + fieldName];
}

void AccessSV::clearFieldList() {
	fieldMap.clear();
}

