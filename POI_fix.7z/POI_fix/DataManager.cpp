#pragma once
#include "stdafx.h"
#include "AccessSV.h"
#include "ErrorManager.h"
#include "IOManager.h"
#include "DataManager.h"
#include <conio.h>

DataManager::DataManager() {
}

DataManager::~DataManager() {
}

void DataManager::setLogger(IOManager * IOCtrl) {
	m_IOCtrl = IOCtrl;
}
void DataManager::setAccSV(AccessSV * AccSV) {
	m_AccSV = AccSV;
}

void DataManager::setNewFile(const std::string labelName, const std::wstring fileName,const IOManager::FileType fileType) {
	CString convertedFileName = fileName.c_str();
	if (!_tcscmp(convertedFileName,_T(""))) {
		if (fileType == IOManager::FileType::ERR) {
			fileName = L"err.log";
		}
		else if (fileType == IOManager::FileType::RUN) {
			fileName = L"run.log";
		}
		else if (fileType == IOManager::FileType::OUTPUT) {
			fileName = L"out.log";
		}
			
	}
	fileDesc tempFileDesc = { convertedFileName,fileType };
	m_fileList[labelName] = tempFileDesc;
}
void DataManager::setNewDB(const std::string labelName, const std::wstring serverName, const bool isFGDB, const bool doEdit) {
	std::wstring DBName = L"";
	std::wstring versionName = L"";
	if (!isFGDB) {
		size_t startDBName = serverName.find(L"@");
		size_t startVersionName = serverName.find(L"(");
		DBName = serverName.substr(startDBName + 1, startVersionName - startDBName - 1);
		versionName = serverName.substr(startVersionName + 1, serverName.length() - startVersionName - 2);
	}
	CString convertedServerName = serverName.c_str();
	CString convertedOwnerName = DBName.c_str();
	CString convertedVersionName = versionName.c_str();
	CString fullDBName = "";
	if (doEdit) fullDBName = convertedOwnerName + "@" +  convertedServerName + "(" + convertedVersionName + ")";
	else fullDBName = "RONLY@" + convertedServerName + "(" + convertedVersionName + ")";
	if (isFGDB) fullDBName = convertedServerName;
	DBDesc tempDBDesc = { 
		convertedServerName,
		convertedOwnerName,
		convertedVersionName,
		fullDBName
	};
	m_DBList[labelName] = tempDBDesc;
}
void DataManager::setNewDB_divideUserDBVersion(const std::string labelName, const std::wstring serverName, const std::wstring ownerName, const std::wstring versionName, const bool isFGDB, const bool doEdit) {
	CString convertedServerName = serverName.c_str();
	CString convertedOwnerName = ownerName.c_str();
	CString convertedVersionName = versionName.c_str();
	CString fullDBName = "";
	if (doEdit) fullDBName = convertedOwnerName + "@" + convertedServerName + "(" + convertedVersionName + ")";
	else fullDBName = "RONLY@" + convertedServerName + "(" + convertedVersionName + ")";
	if (isFGDB) fullDBName = convertedServerName;
	DBDesc tempDBDesc = { 
		convertedServerName,
		convertedOwnerName,
		convertedVersionName,
		fullDBName
	};
	m_DBList[labelName] = tempDBDesc;
}

void DataManager::setNewFeatureClass(const std::string serverLabelName, const std::string labelName, const std::wstring serverName, const std::wstring featureClassName, const bool isFGDB) {
	CString convertedFeatureClassName = featureClassName.c_str();
	std::wstring ownerName = L"";
	if (!isFGDB) {
		size_t startDBName = serverName.find(L"@");
		ownerName = serverName.substr(0, startDBName);
	}
	CString convertedOwnerName = ownerName.c_str();
	CString convertedfullFeatureClassName = convertedOwnerName + "." + convertedFeatureClassName;
	if (isFGDB) convertedfullFeatureClassName = convertedFeatureClassName;
	featureClassDesc tempTableDesc = {
		serverLabelName,
		convertedFeatureClassName,
		convertedOwnerName,
		convertedfullFeatureClassName
	};
	m_featureClassList[labelName] = tempTableDesc;
}
void DataManager::setNewFeatureClass_divideUserDBVersion(const std::string serverLabelName, const std::string labelName, const std::wstring serverOwner, const std::wstring featureClassName, const bool isFGDB) {
	CString convertedFeatureClassName = featureClassName.c_str();
	CString convertedOwnerName = serverOwner.c_str();
	CString convertedfullFeatureClassName = convertedOwnerName + "." + convertedFeatureClassName;
	if (isFGDB) convertedfullFeatureClassName = convertedFeatureClassName;
	featureClassDesc tempTableDesc = { 
		serverLabelName,
		convertedFeatureClassName,
		convertedOwnerName,
		convertedfullFeatureClassName 
	};
	m_featureClassList[labelName] = tempTableDesc;
}
void DataManager::setNewFieldName(const std::string labelName, const std::wstring fieldName) {
	_bstr_t convertedFieldName = fieldName.c_str();
	m_fieldNameList[labelName] = convertedFieldName;
}
int DataManager::createFiles() {
	std::vector<CString> fileNameList;
	for (std::pair<std::string, fileDesc> eachFile : m_fileList) {
		if (ErrorManager::RCode::R_SUCCESS != m_IOCtrl->initFile(eachFile.second.fileName, eachFile.second.fileType)) {
			return ErrorManager::RCode::R_FAILED_FATAL_ERROR;
		}
		else {
			fileNameList.push_back(eachFile.second.fileName);
		}
	}
	for (auto eachFile : fileNameList) {
		m_IOCtrl->print_run(eachFile + " has been created successfully");
	}
	return ErrorManager::RCode::R_SUCCESS;
}

int DataManager::initDBs() {
	for (std::pair<std::string, DBDesc> eachDB : m_DBList) {
		if (HAS_ERROR == m_AccSV->setWorkspace(eachDB.second.fullDBName)) {
			m_IOCtrl->print_error(ErrorManager::ECode::E_FAILED_TO_OPEN_WORKSPACE, eachDB.second.fullDBName);
			return ErrorManager::RCode::R_FAILED_FATAL_ERROR;
		}
		else {
			CString successMsg = " has been connected successfully";
			CString printMsg = eachDB.second.fullDBName + successMsg;
			m_IOCtrl->print_run(printMsg);
		}
	}
	return ErrorManager::RCode::R_SUCCESS;
}

int DataManager::initFeatureClasses() {
	for (std::pair<std::string, featureClassDesc> eachFeatureClass : m_featureClassList) {
		CString fullDBName = m_DBList[eachFeatureClass.second.serverLabelName].fullDBName;
		if (HAS_ERROR == m_AccSV->setFeatureClass(fullDBName, eachFeatureClass.second.fullFeatureClassName)) {
			m_IOCtrl->print_error(ErrorManager::ECode::E_FAILED_TO_OPEN_FEATURECLASS, eachFeatureClass.second.fullFeatureClassName);
			return ErrorManager::RCode::R_FAILED_FATAL_ERROR;
		}
		else {
			CString successMsg = " featureclass has been connected successfully";
			CString printMsg = eachFeatureClass.second.fullFeatureClassName + successMsg;
			m_IOCtrl->print_run(printMsg);
		}
	}
	return ErrorManager::RCode::R_SUCCESS;
}

std::map<std::string, DataManager::DBDesc> DataManager::getDBList() {
	return m_DBList;
}

std::map<std::string, DataManager::featureClassDesc> DataManager::getFeatureClassList() {
	return m_featureClassList;
}
std::map<std::string, _bstr_t> DataManager::getFieldNameList() {
	return  m_fieldNameList;
}

//for this tool only
void DataManager::setSQL(const std::wstring SQL){
	m_SQLText = SQL;
}
std::wstring DataManager::getSQL() {
	if (m_SQLText.empty()) {
		return L"PRODUCT_C=1";
	}
	return m_SQLText;
}

