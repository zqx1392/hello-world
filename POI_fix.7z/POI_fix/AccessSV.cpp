#pragma once
#include "stdafx.h"
#include "AccessSV.h"

AccessSV::AccessSV(void)
{
}

AccessSV::~AccessSV(void)
{
	featureClassMap.empty();
}
int AccessSV::setWorkspace(CString workspaceName){
	IWorkspacePtr tempWorkspace (sindy::create_workspace(workspaceName));
	if (tempWorkspace == NULL){
		return 1;
	}
	m_workspaceMap.insert(std::make_pair(workspaceName,tempWorkspace));
	return 0;
}

IWorkspacePtr AccessSV::getWorkspace(const CString workspaceName){
	return m_workspaceMap[workspaceName];
}

IFeatureClassPtr AccessSV::getFeatureClass(const CString workspaceName, const  CString featureClassName) {
	return m_featureClassMap[workspaceName + "." + featureClassName];
}

int AccessSV::setFeatureClass(const CString workspaceName,const CString featureClassName) {
	IWorkspacePtr targetWorkspace = getWorkspace(workspaceName);
	IFeatureClassPtr tempClass = NULL;
	if (S_OK != IFeatureWorkspacePtr(targetWorkspace)->OpenFeatureClass(featureClassName.AllocSysString(), &tempClass)) {
		return 1;
	}
	m_featureClassMap.insert(std::make_pair(workspaceName + "." + featureClassName, tempClass));
	return 0;
}