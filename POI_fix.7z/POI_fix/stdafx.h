#pragma once

#include "targetver.h"
#include <stdio.h>
#include <tchar.h>
#include <iostream>
#include <fstream>
#include <atlstr.h>
#include <set>
#include <map>
#include <utility> 
#include <time.h>
#include <string>
#include <WinLib/arcobjects_import_highmethod.h>
#include <sindy/workspace.h>
#include <sindy/libschema.h>
#include <sindy/schema.h>
#include <boost/program_options.hpp>





